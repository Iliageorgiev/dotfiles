
WeakAurasSaved = {
	["dynamicIconCache"] = {
	},
	["editor_tab_spaces"] = 4,
	["editor_font_size"] = 12,
	["lastArchiveClear"] = 1700400631,
	["minimap"] = {
		["hide"] = false,
	},
	["lastUpgrade"] = 1700400635,
	["dbVersion"] = 70,
	["displays"] = {
		["Dynamic Spells - Rogue"] = {
			["arcLength"] = 360,
			["controlledChildren"] = {
				"Garrote", -- [1]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["wagoID"] = "foIUC5_yM",
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["sortHybridTable"] = {
				["Garrote"] = false,
			},
			["anchorPoint"] = "TOPRIGHT",
			["grow"] = "CUSTOM",
			["fullCircle"] = true,
			["space"] = 2,
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["names"] = {
						},
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["unit"] = "player",
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 1,
			["radius"] = 200,
			["xOffset"] = -6.103515625e-05,
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["align"] = "CENTER",
			["growOn"] = "changed",
			["source"] = "import",
			["desc"] = "Made by Luxthos - twitch.tv/luxthos",
			["rotation"] = 0,
			["gridType"] = "RD",
			["version"] = 25,
			["subRegions"] = {
			},
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["rowSpace"] = 1,
			["load"] = {
				["size"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
			},
			["internalVersion"] = 70,
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["parent"] = "Luxthos - Rogue",
			["animate"] = false,
			["customGrow"] = "function(newPositions, activeRegions)\n    local LWA = LWA and LWA[\"Rogue\"] or {}\n\n    if LWA and LWA.GrowDynamicSpells then\n        LWA.GrowDynamicSpells(newPositions, activeRegions)\n    end\nend",
			["scale"] = 1,
			["centerType"] = "LR",
			["border"] = false,
			["anchorFrameFrame"] = "WeakAuras:General Options - Rogue",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 2,
			["sort"] = "none",
			["useLimit"] = false,
			["stagger"] = 0,
			["anchorFrameParent"] = false,
			["constantFactor"] = "RADIUS",
			["gridWidth"] = 5,
			["borderOffset"] = 4,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Dynamic Spells - Rogue",
			["borderEdge"] = "Square Full White",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["stepAngle"] = 15,
			["uid"] = "I19qCICQS(3",
			["limit"] = 5,
			["selfPoint"] = "BOTTOMRIGHT",
			["config"] = {
			},
			["conditions"] = {
			},
			["information"] = {
				["forceEvents"] = true,
			},
			["borderInset"] = 1,
		},
		["Blind"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["useMatch_count"] = true,
						["match_countOperator"] = ">",
						["auranames"] = {
							"2094", -- [1]
						},
						["ownOnly"] = true,
						["event"] = "Health",
						["unit"] = "multi",
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["spellIds"] = {
						},
						["subeventPrefix"] = "SPELL",
						["match_count"] = "0",
						["type"] = "aura2",
						["useName"] = true,
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["track"] = "auto",
						["use_matchedRune"] = false,
						["duration"] = "1",
						["genericShowOn"] = "showAlways",
						["names"] = {
						},
						["use_showgcd"] = true,
						["debuffType"] = "HELPFUL",
						["type"] = "spell",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "Blind",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["subeventPrefix"] = "SPELL",
						["use_genericShowOn"] = true,
						["use_track"] = true,
						["spellName"] = 2094,
					},
					["untrigger"] = {
						["genericShowOn"] = "showAlways",
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["class_and_spec"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["use_class"] = true,
				["use_spellknown"] = true,
				["zoneIds"] = "",
				["use_spec"] = true,
				["spec"] = {
					["single"] = 2,
					["multi"] = {
						[3] = true,
					},
				},
				["use_never"] = false,
				["spellknown"] = 2094,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "APb6(jGwggx",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = false,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "buttonOverlay",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -1,
						["variable"] = "incombat",
						["value"] = 0,
					},
					["changes"] = {
						{
							["property"] = "sub.3.glow",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [3]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "Pixel",
							["property"] = "sub.3.glowType",
						}, -- [2]
						{
							["property"] = "desaturate",
						}, -- [3]
						{
							["property"] = "inverse",
						}, -- [4]
						{
							["value"] = true,
							["property"] = "cooldownEdge",
						}, -- [5]
					},
				}, -- [4]
			},
			["parent"] = "Core - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Blind",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["displayIcon"] = "",
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Right Side - Rogue"] = {
			["arcLength"] = 360,
			["controlledChildren"] = {
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["wagoID"] = "foIUC5_yM",
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["sortHybridTable"] = {
			},
			["anchorPoint"] = "TOPRIGHT",
			["grow"] = "CUSTOM",
			["fullCircle"] = true,
			["space"] = 2,
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["names"] = {
						},
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["unit"] = "player",
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 1,
			["radius"] = 200,
			["xOffset"] = -6.103515625e-05,
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["align"] = "CENTER",
			["growOn"] = "changed",
			["source"] = "import",
			["desc"] = "Made by Luxthos - twitch.tv/luxthos",
			["rotation"] = 0,
			["gridType"] = "RD",
			["version"] = 25,
			["subRegions"] = {
			},
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["rowSpace"] = 1,
			["load"] = {
				["size"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
			},
			["internalVersion"] = 70,
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["parent"] = "Luxthos - Rogue",
			["animate"] = false,
			["customGrow"] = "function(newPositions, activeRegions)\n    local LWA = LWA and LWA[\"Rogue\"] or {}\n\n    if LWA and LWA.GrowRightSide then\n        LWA.GrowRightSide(newPositions, activeRegions)\n    end\nend",
			["scale"] = 1,
			["centerType"] = "LR",
			["border"] = false,
			["anchorFrameFrame"] = "WeakAuras:General Options - Rogue",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 2,
			["sort"] = "none",
			["useLimit"] = false,
			["stagger"] = 0,
			["anchorFrameParent"] = false,
			["constantFactor"] = "RADIUS",
			["gridWidth"] = 5,
			["borderOffset"] = 4,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Right Side - Rogue",
			["borderEdge"] = "Square Full White",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["stepAngle"] = 15,
			["uid"] = "yFXgV7(lSvL",
			["limit"] = 5,
			["selfPoint"] = "TOPLEFT",
			["config"] = {
			},
			["conditions"] = {
			},
			["information"] = {
				["forceEvents"] = true,
			},
			["borderInset"] = 1,
		},
		["Preparation"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["track"] = "auto",
						["use_matchedRune"] = false,
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showAlways",
						["unit"] = "player",
						["use_showgcd"] = false,
						["debuffType"] = "HELPFUL",
						["type"] = "spell",
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Cooldown Progress (Spell)",
						["use_exact_spellName"] = false,
						["realSpellName"] = "Preparation",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["spellName"] = 14185,
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["use_track"] = true,
						["names"] = {
						},
					},
					["untrigger"] = {
						["genericShowOn"] = "showAlways",
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["class_and_spec"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["single"] = 39,
					["multi"] = {
						[39] = true,
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["use_class"] = true,
				["use_spellknown"] = true,
				["zoneIds"] = "",
				["use_spec"] = true,
				["spec"] = {
					["single"] = 2,
					["multi"] = {
						[3] = true,
					},
				},
				["use_never"] = false,
				["spellknown"] = 14185,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "553xP3WoVBL",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "onCooldown",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = false,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "buttonOverlay",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -1,
						["variable"] = "incombat",
						["value"] = 0,
					},
					["changes"] = {
						{
							["property"] = "sub.3.glow",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "onCooldown",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [3]
			},
			["parent"] = "Core - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Preparation",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["displayIcon"] = "",
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Cast Bar - Rogue"] = {
			["overlays"] = {
				{
					1, -- [1]
					0.70196078431373, -- [2]
					0.23137254901961, -- [3]
					1, -- [4]
				}, -- [1]
			},
			["iconSource"] = -1,
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["sparkRotation"] = 0,
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["actions"] = {
				["start"] = {
					["do_sound"] = false,
				},
				["finish"] = {
				},
				["init"] = {
					["custom"] = "aura_env.region.configGroup = \"cast_bar\"\n",
					["do_custom"] = true,
				},
			},
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["enableGradient"] = false,
			["selfPoint"] = "TOP",
			["barColor"] = {
				0.71372549019608, -- [1]
				0.16078431372549, -- [2]
				0.16078431372549, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["sparkOffsetY"] = 0,
			["gradientOrientation"] = "HORIZONTAL",
			["load"] = {
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["use_class"] = true,
				["role"] = {
					["single"] = "DAMAGER",
					["multi"] = {
						["DAMAGER"] = true,
					},
				},
				["zoneIds"] = "",
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
						["WARLOCK"] = true,
					},
				},
				["race"] = {
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["smoothProgress"] = false,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["overlayclip"] = false,
			["texture"] = "Solid",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["auto"] = true,
			["tocversion"] = 30401,
			["alpha"] = 1,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["colorState"] = "",
			["sparkOffsetX"] = 0,
			["wagoID"] = "foIUC5_yM",
			["parent"] = "Resources - Rogue",
			["sparkRotationMode"] = "AUTO",
			["triggers"] = {
				{
					["trigger"] = {
						["use_showLatency"] = false,
						["use_inverse"] = false,
						["genericShowOn"] = "showOnCooldown",
						["names"] = {
						},
						["powertype"] = 6,
						["use_powertype"] = true,
						["debuffType"] = "HELPFUL",
						["type"] = "unit",
						["spellName"] = 0,
						["subeventSuffix"] = "_CAST_START",
						["use_unit"] = true,
						["unevent"] = "auto",
						["event"] = "Cast",
						["subeventPrefix"] = "SPELL",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["use_genericShowOn"] = true,
						["duration"] = "1",
						["use_absorbMode"] = true,
						["use_track"] = true,
						["unit"] = "player",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "unit",
						["use_alwaystrue"] = true,
						["use_unit"] = true,
						["debuffType"] = "HELPFUL",
						["event"] = "Conditions",
						["unit"] = "player",
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "custom",
						["use_eventtype"] = true,
						["event"] = "Chat Message",
						["unit"] = "player",
						["events"] = "PLAYER_ENTERING_WORLD",
						["custom_hide"] = "custom",
						["custom_type"] = "event",
						["use_unit"] = true,
						["custom"] = "function()\n    CastingBarFrame:UnregisterAllEvents()\nend",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [3]
				["disjunctive"] = "any",
				["customTriggerLogic"] = "",
				["activeTriggerMode"] = -10,
			},
			["configGroup"] = "cast_bar",
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["sparkMirror"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["type"] = "subforeground",
				}, -- [2]
				{
					["border_size"] = 2,
					["border_anchor"] = "bar",
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [3]
				{
					["text_shadowXOffset"] = 1,
					["text_text"] = "%p",
					["text_text_format_p_time_mod_rate"] = true,
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = true,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_text_format_p_format"] = "timed",
					["type"] = "subtext",
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_text_format_p_time_precision"] = 1,
					["text_shadowYOffset"] = -1,
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_RIGHT",
					["anchorYOffset"] = 0,
					["text_fontType"] = "OUTLINE",
					["text_fontSize"] = 13,
					["anchorXOffset"] = 0,
					["text_text_format_p_time_format"] = 0,
				}, -- [4]
				{
					["text_text_format_n_format"] = "none",
					["text_text"] = "%n",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = -1,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "OUTLINE",
					["text_anchorPoint"] = "INNER_LEFT",
					["text_shadowXOffset"] = 1,
					["text_fontSize"] = 13,
					["anchorXOffset"] = 0,
					["text_visible"] = true,
				}, -- [5]
			},
			["height"] = 20,
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["source"] = "import",
			["xOffset"] = 0,
			["barColor2"] = {
				1, -- [1]
				1, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["internalVersion"] = 70,
			["icon_side"] = "LEFT",
			["backgroundColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.30000001192093, -- [4]
			},
			["spark"] = true,
			["sparkHeight"] = 20,
			["desc"] = "Made by Luxthos - twitch.tv/luxthos",
			["overlaysTexture"] = {
				"Solid", -- [1]
			},
			["uid"] = "e(wQY26ljPy",
			["semver"] = "2.0.23",
			["icon"] = false,
			["sparkHidden"] = "NEVER",
			["anchorFrameType"] = "SCREEN",
			["frameStrata"] = 1,
			["width"] = 405,
			["id"] = "Cast Bar - Rogue",
			["zoom"] = 0.3,
			["inverse"] = false,
			["config"] = {
			},
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "interruptible",
						["value"] = 0,
						["checks"] = {
							{
								["trigger"] = 1,
								["variable"] = "interruptible",
								["value"] = 0,
							}, -- [1]
							{
								["value"] = 1,
								["variable"] = "show",
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = {
								["custom"] = "aura_env.region.colorState = \"unint\"\nWeakAuras.ScanEvents(\"LWA_UPDATE_BAR\", aura_env)",
							},
							["property"] = "customcode",
						}, -- [1]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -1,
						["variable"] = "alwaystrue",
					},
					["linked"] = true,
					["changes"] = {
						{
							["value"] = {
								["custom"] = "aura_env.region.colorState = \"\"\nWeakAuras.ScanEvents(\"LWA_UPDATE_BAR\", aura_env)",
							},
							["property"] = "customcode",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 0,
					},
					["changes"] = {
						{
							["property"] = "alpha",
						}, -- [1]
					},
				}, -- [3]
			},
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["sparkWidth"] = 10,
		},
		["Nameplate range check 17 "] = {
			["iconSource"] = 0,
			["displayText_format_1.minRange_realm_name"] = "never",
			["xOffset"] = 0,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["yOffset"] = 0,
			["anchorPoint"] = "RIGHT",
			["displayText_format_p_time_format"] = 0,
			["url"] = "https://wago.io/YP6nljWXe/7",
			["icon"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "LEFT",
			["displayText_format_destUnit_color"] = "class",
			["desc"] = "Checks nearest 20 nameplates and shows a starfall icon if they are in range of starfall (36 yrds). \n\nHelps you make any decisions about using starfall and to stop any ninja pulls. \n\nIf you want more nameplates you can simply duplicate one of the weak auras in the group and add a number to the trigger. \n\nIf anyone finds an easier way to make this kind of a weak aura let me know as this was made editing a pre existing weak aura with a similar function.",
			["font"] = "PT Sans Narrow",
			["load"] = {
				["use_never"] = false,
				["class"] = {
					["single"] = "DRUID",
					["multi"] = {
						["DRUID"] = true,
					},
				},
				["use_encounterid"] = false,
				["use_class"] = true,
				["use_itemequiped"] = false,
				["zoneIds"] = "",
				["use_not_item_bonusid_equipped"] = false,
				["talent2"] = {
					["multi"] = {
						[20] = false,
					},
				},
				["use_zoneIds"] = false,
				["item_bonusid_equipped"] = "62080",
				["spec"] = {
					["multi"] = {
					},
				},
				["not_item_bonusid_equipped"] = "62080",
				["use_talent"] = false,
				["use_spellknown"] = false,
				["talent"] = {
					["multi"] = {
						[24] = true,
					},
				},
				["itemequiped"] = {
					62080, -- [1]
				},
				["size"] = {
					["multi"] = {
					},
				},
				["use_exact_spellknown"] = false,
				["use_item_bonusid_equipped"] = false,
				["itemtypeequipped"] = {
				},
			},
			["displayText_format_1.maxRange_format"] = "none",
			["shadowXOffset"] = 1,
			["displayText_format_1.minRange_abbreviate"] = false,
			["regionType"] = "icon",
			["displayText_format_destUnit_abbreviate_max"] = 8,
			["zoom"] = 0,
			["displayText_format_destUnit_format"] = "Unit",
			["tocversion"] = 30401,
			["alpha"] = 1,
			["config"] = {
			},
			["fixedWidth"] = 200,
			["outline"] = "OUTLINE",
			["wagoID"] = "YP6nljWXe",
			["parent"] = "Starfall Range Check on Nameplate",
			["shadowYOffset"] = -1,
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "event",
			["automaticWidth"] = "Auto",
			["triggers"] = {
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "35",
						["unit"] = "nameplate17",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [1]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "20",
						["unit"] = "nameplate17",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = false,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [6]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "15",
						["unit"] = "nameplate17",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [7]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate17",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [8]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [9]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [10]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate17",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [11]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    if trigger[1] and trigger[3] and trigger[5] then\n        return true\n    elseif trigger[2] and trigger[4] and trigger[5] then\n        return true\n    elseif trigger[3] and trigger[8] and trigger[6] then\n        return true\n    elseif trigger[4] and trigger[7] and trigger[6] then\n        return true\n    elseif trigger[4] and (trigger[9] and trigger[10]) and trigger[7] then\n        return true\n    elseif trigger[3] and (trigger[9] and trigger[10]) and trigger[11] then\n        return true\n    end\nend",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["version"] = 7,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%maxRange",
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = false,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_text_format_p_time_mod_rate"] = true,
					["anchorXOffset"] = 0,
					["text_text_format_minRange_format"] = "none",
					["type"] = "subtext",
					["text_text_format_maxRange_format"] = "none",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_text_format_p_time_format"] = 0,
					["text_shadowYOffset"] = 0,
					["text_fontType"] = "OUTLINE",
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "CENTER",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["anchorYOffset"] = 0,
					["text_fontSize"] = 12,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_text_format_p_time_precision"] = 1,
				}, -- [2]
			},
			["height"] = 25,
			["displayText_format_destUnit_realm_name"] = "never",
			["preferToUpdate"] = false,
			["information"] = {
				["forceEvents"] = true,
			},
			["displayText_format_1.minRange_color"] = true,
			["source"] = "import",
			["conditions"] = {
			},
			["displayIcon"] = 236168,
			["cooldownTextDisabled"] = false,
			["displayText_format_1.minRange_round_type"] = "ceil",
			["authorOptions"] = {
			},
			["desaturate"] = false,
			["wordWrap"] = "WordWrap",
			["anchorFrameType"] = "NAMEPLATE",
			["useCooldownModRate"] = true,
			["displayText_format_destUnit_abbreviate"] = false,
			["displayText_format_1.minRange_format"] = "Number",
			["displayText_format_p_time_precision"] = 1,
			["color"] = {
				0.97647058823529, -- [1]
				1, -- [2]
				0.97647058823529, -- [3]
				1, -- [4]
			},
			["justify"] = "LEFT",
			["uid"] = "6p1RaMIhuUD",
			["semver"] = "1.0.6",
			["displayText"] = "%1.maxRange",
			["id"] = "Nameplate range check 17 ",
			["anchorFrameParent"] = false,
			["frameStrata"] = 1,
			["width"] = 25,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["fontSize"] = 16,
			["inverse"] = false,
			["displayText_format_1.minRange_abbreviate_max"] = 8,
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["displayText_format_1.minRange_decimal_precision"] = 0,
			["cooldown"] = false,
			["cooldownEdge"] = false,
		},
		["Nameplate range check 14 "] = {
			["iconSource"] = 0,
			["displayText_format_1.minRange_realm_name"] = "never",
			["xOffset"] = 0,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["yOffset"] = 0,
			["anchorPoint"] = "RIGHT",
			["displayText_format_p_time_format"] = 0,
			["url"] = "https://wago.io/YP6nljWXe/7",
			["icon"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "LEFT",
			["displayText_format_destUnit_color"] = "class",
			["desc"] = "Checks nearest 20 nameplates and shows a starfall icon if they are in range of starfall (36 yrds). \n\nHelps you make any decisions about using starfall and to stop any ninja pulls. \n\nIf you want more nameplates you can simply duplicate one of the weak auras in the group and add a number to the trigger. \n\nIf anyone finds an easier way to make this kind of a weak aura let me know as this was made editing a pre existing weak aura with a similar function.",
			["font"] = "PT Sans Narrow",
			["load"] = {
				["use_never"] = false,
				["class"] = {
					["single"] = "DRUID",
					["multi"] = {
						["DRUID"] = true,
					},
				},
				["use_encounterid"] = false,
				["use_class"] = true,
				["use_itemequiped"] = false,
				["zoneIds"] = "",
				["use_not_item_bonusid_equipped"] = false,
				["talent2"] = {
					["multi"] = {
						[20] = false,
					},
				},
				["use_zoneIds"] = false,
				["item_bonusid_equipped"] = "62080",
				["spec"] = {
					["multi"] = {
					},
				},
				["not_item_bonusid_equipped"] = "62080",
				["use_talent"] = false,
				["use_spellknown"] = false,
				["talent"] = {
					["multi"] = {
						[24] = true,
					},
				},
				["itemequiped"] = {
					62080, -- [1]
				},
				["size"] = {
					["multi"] = {
					},
				},
				["use_exact_spellknown"] = false,
				["use_item_bonusid_equipped"] = false,
				["itemtypeequipped"] = {
				},
			},
			["displayText_format_1.maxRange_format"] = "none",
			["shadowXOffset"] = 1,
			["displayText_format_1.minRange_abbreviate"] = false,
			["regionType"] = "icon",
			["displayText_format_destUnit_abbreviate_max"] = 8,
			["zoom"] = 0,
			["displayText_format_destUnit_format"] = "Unit",
			["tocversion"] = 30401,
			["alpha"] = 1,
			["config"] = {
			},
			["fixedWidth"] = 200,
			["outline"] = "OUTLINE",
			["wagoID"] = "YP6nljWXe",
			["parent"] = "Starfall Range Check on Nameplate",
			["shadowYOffset"] = -1,
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "event",
			["automaticWidth"] = "Auto",
			["triggers"] = {
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "35",
						["unit"] = "nameplate14",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [1]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "20",
						["unit"] = "nameplate14",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = false,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [6]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "15",
						["unit"] = "nameplate14",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [7]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate14",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [8]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [9]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [10]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate14",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [11]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    if trigger[1] and trigger[3] and trigger[5] then\n        return true\n    elseif trigger[2] and trigger[4] and trigger[5] then\n        return true\n    elseif trigger[3] and trigger[8] and trigger[6] then\n        return true\n    elseif trigger[4] and trigger[7] and trigger[6] then\n        return true\n    elseif trigger[4] and (trigger[9] and trigger[10]) and trigger[7] then\n        return true\n    elseif trigger[3] and (trigger[9] and trigger[10]) and trigger[11] then\n        return true\n    end\nend",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["version"] = 7,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%maxRange",
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = false,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_text_format_p_time_mod_rate"] = true,
					["anchorXOffset"] = 0,
					["text_text_format_minRange_format"] = "none",
					["type"] = "subtext",
					["text_text_format_maxRange_format"] = "none",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_text_format_p_time_format"] = 0,
					["text_shadowYOffset"] = 0,
					["text_fontType"] = "OUTLINE",
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "CENTER",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["anchorYOffset"] = 0,
					["text_fontSize"] = 12,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_text_format_p_time_precision"] = 1,
				}, -- [2]
			},
			["height"] = 25,
			["displayText_format_destUnit_realm_name"] = "never",
			["preferToUpdate"] = false,
			["information"] = {
				["forceEvents"] = true,
			},
			["displayText_format_1.minRange_color"] = true,
			["source"] = "import",
			["conditions"] = {
			},
			["displayIcon"] = 236168,
			["cooldownTextDisabled"] = false,
			["displayText_format_1.minRange_round_type"] = "ceil",
			["authorOptions"] = {
			},
			["desaturate"] = false,
			["wordWrap"] = "WordWrap",
			["anchorFrameType"] = "NAMEPLATE",
			["useCooldownModRate"] = true,
			["displayText_format_destUnit_abbreviate"] = false,
			["displayText_format_1.minRange_format"] = "Number",
			["displayText_format_p_time_precision"] = 1,
			["color"] = {
				0.97647058823529, -- [1]
				1, -- [2]
				0.97647058823529, -- [3]
				1, -- [4]
			},
			["justify"] = "LEFT",
			["uid"] = "UTYU6rZ7PA8",
			["semver"] = "1.0.6",
			["displayText"] = "%1.maxRange",
			["id"] = "Nameplate range check 14 ",
			["anchorFrameParent"] = false,
			["frameStrata"] = 1,
			["width"] = 25,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["fontSize"] = 16,
			["inverse"] = false,
			["displayText_format_1.minRange_abbreviate_max"] = 8,
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["displayText_format_1.minRange_decimal_precision"] = 0,
			["cooldown"] = false,
			["cooldownEdge"] = false,
		},
		["Nameplate range check 11 "] = {
			["iconSource"] = 0,
			["displayText_format_1.minRange_realm_name"] = "never",
			["xOffset"] = 0,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["yOffset"] = 0,
			["anchorPoint"] = "RIGHT",
			["displayText_format_p_time_format"] = 0,
			["url"] = "https://wago.io/YP6nljWXe/7",
			["icon"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "LEFT",
			["displayText_format_destUnit_color"] = "class",
			["desc"] = "Checks nearest 20 nameplates and shows a starfall icon if they are in range of starfall (36 yrds). \n\nHelps you make any decisions about using starfall and to stop any ninja pulls. \n\nIf you want more nameplates you can simply duplicate one of the weak auras in the group and add a number to the trigger. \n\nIf anyone finds an easier way to make this kind of a weak aura let me know as this was made editing a pre existing weak aura with a similar function.",
			["font"] = "PT Sans Narrow",
			["load"] = {
				["use_never"] = false,
				["class"] = {
					["single"] = "DRUID",
					["multi"] = {
						["DRUID"] = true,
					},
				},
				["use_encounterid"] = false,
				["use_class"] = true,
				["use_itemequiped"] = false,
				["zoneIds"] = "",
				["use_not_item_bonusid_equipped"] = false,
				["talent2"] = {
					["multi"] = {
						[20] = false,
					},
				},
				["use_zoneIds"] = false,
				["item_bonusid_equipped"] = "62080",
				["spec"] = {
					["multi"] = {
					},
				},
				["not_item_bonusid_equipped"] = "62080",
				["use_talent"] = false,
				["use_spellknown"] = false,
				["talent"] = {
					["multi"] = {
						[24] = true,
					},
				},
				["itemequiped"] = {
					62080, -- [1]
				},
				["size"] = {
					["multi"] = {
					},
				},
				["use_exact_spellknown"] = false,
				["use_item_bonusid_equipped"] = false,
				["itemtypeequipped"] = {
				},
			},
			["displayText_format_1.maxRange_format"] = "none",
			["shadowXOffset"] = 1,
			["displayText_format_1.minRange_abbreviate"] = false,
			["regionType"] = "icon",
			["displayText_format_destUnit_abbreviate_max"] = 8,
			["zoom"] = 0,
			["displayText_format_destUnit_format"] = "Unit",
			["tocversion"] = 30401,
			["alpha"] = 1,
			["config"] = {
			},
			["fixedWidth"] = 200,
			["outline"] = "OUTLINE",
			["wagoID"] = "YP6nljWXe",
			["parent"] = "Starfall Range Check on Nameplate",
			["shadowYOffset"] = -1,
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "event",
			["automaticWidth"] = "Auto",
			["triggers"] = {
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "35",
						["unit"] = "nameplate11",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [1]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "20",
						["unit"] = "nameplate11",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = false,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [6]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "15",
						["unit"] = "nameplate11",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [7]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate11",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [8]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [9]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [10]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate11",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [11]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    if trigger[1] and trigger[3] and trigger[5] then\n        return true\n    elseif trigger[2] and trigger[4] and trigger[5] then\n        return true\n    elseif trigger[3] and trigger[8] and trigger[6] then\n        return true\n    elseif trigger[4] and trigger[7] and trigger[6] then\n        return true\n    elseif trigger[4] and (trigger[9] and trigger[10]) and trigger[7] then\n        return true\n    elseif trigger[3] and (trigger[9] and trigger[10]) and trigger[11] then\n        return true\n    end\nend",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["version"] = 7,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%maxRange",
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = false,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_text_format_p_time_mod_rate"] = true,
					["anchorXOffset"] = 0,
					["text_text_format_minRange_format"] = "none",
					["type"] = "subtext",
					["text_text_format_maxRange_format"] = "none",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_text_format_p_time_format"] = 0,
					["text_shadowYOffset"] = 0,
					["text_fontType"] = "OUTLINE",
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "CENTER",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["anchorYOffset"] = 0,
					["text_fontSize"] = 12,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_text_format_p_time_precision"] = 1,
				}, -- [2]
			},
			["height"] = 25,
			["displayText_format_destUnit_realm_name"] = "never",
			["preferToUpdate"] = false,
			["information"] = {
				["forceEvents"] = true,
			},
			["displayText_format_1.minRange_color"] = true,
			["source"] = "import",
			["conditions"] = {
			},
			["displayIcon"] = 236168,
			["cooldownTextDisabled"] = false,
			["displayText_format_1.minRange_round_type"] = "ceil",
			["authorOptions"] = {
			},
			["desaturate"] = false,
			["wordWrap"] = "WordWrap",
			["anchorFrameType"] = "NAMEPLATE",
			["useCooldownModRate"] = true,
			["displayText_format_destUnit_abbreviate"] = false,
			["displayText_format_1.minRange_format"] = "Number",
			["displayText_format_p_time_precision"] = 1,
			["color"] = {
				0.97647058823529, -- [1]
				1, -- [2]
				0.97647058823529, -- [3]
				1, -- [4]
			},
			["justify"] = "LEFT",
			["uid"] = "Tg8iNzm9)wc",
			["semver"] = "1.0.6",
			["displayText"] = "%1.maxRange",
			["id"] = "Nameplate range check 11 ",
			["anchorFrameParent"] = false,
			["frameStrata"] = 1,
			["width"] = 25,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["fontSize"] = 16,
			["inverse"] = false,
			["displayText_format_1.minRange_abbreviate_max"] = 8,
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["displayText_format_1.minRange_decimal_precision"] = 0,
			["cooldown"] = false,
			["cooldownEdge"] = false,
		},
		["Resources - Rogue"] = {
			["controlledChildren"] = {
				"Health Bar - Rogue", -- [1]
				"Energy Bar - Rogue", -- [2]
				"Combo Points - Rogue", -- [3]
				"Cast Bar - Rogue", -- [4]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "TOP",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["names"] = {
						},
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["unit"] = "player",
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["desc"] = "Made by Luxthos - twitch.tv/luxthos",
			["version"] = 25,
			["subRegions"] = {
			},
			["load"] = {
				["size"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
			},
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["source"] = "import",
			["scale"] = 1,
			["customAnchor"] = "",
			["border"] = false,
			["borderEdge"] = "Square Full White",
			["regionType"] = "group",
			["borderSize"] = 2,
			["anchorFrameParent"] = false,
			["borderOffset"] = 4,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Resources - Rogue",
			["borderInset"] = 1,
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["parent"] = "Luxthos - Rogue",
			["uid"] = "u7uqvQj98aT",
			["config"] = {
			},
			["selfPoint"] = "CENTER",
			["conditions"] = {
			},
			["information"] = {
				["forceEvents"] = true,
			},
			["authorOptions"] = {
			},
		},
		["Nameplate range check 10 "] = {
			["iconSource"] = 0,
			["displayText_format_1.minRange_realm_name"] = "never",
			["xOffset"] = 0,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["yOffset"] = 0,
			["anchorPoint"] = "RIGHT",
			["displayText_format_p_time_format"] = 0,
			["url"] = "https://wago.io/YP6nljWXe/7",
			["icon"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "LEFT",
			["displayText_format_destUnit_color"] = "class",
			["desc"] = "Checks nearest 20 nameplates and shows a starfall icon if they are in range of starfall (36 yrds). \n\nHelps you make any decisions about using starfall and to stop any ninja pulls. \n\nIf you want more nameplates you can simply duplicate one of the weak auras in the group and add a number to the trigger. \n\nIf anyone finds an easier way to make this kind of a weak aura let me know as this was made editing a pre existing weak aura with a similar function.",
			["font"] = "PT Sans Narrow",
			["load"] = {
				["use_never"] = false,
				["class"] = {
					["single"] = "DRUID",
					["multi"] = {
						["DRUID"] = true,
					},
				},
				["use_encounterid"] = false,
				["use_class"] = true,
				["use_itemequiped"] = false,
				["zoneIds"] = "",
				["use_not_item_bonusid_equipped"] = false,
				["talent2"] = {
					["multi"] = {
						[20] = false,
					},
				},
				["use_zoneIds"] = false,
				["item_bonusid_equipped"] = "62080",
				["spec"] = {
					["multi"] = {
					},
				},
				["not_item_bonusid_equipped"] = "62080",
				["use_talent"] = false,
				["use_spellknown"] = false,
				["talent"] = {
					["multi"] = {
						[24] = true,
					},
				},
				["itemequiped"] = {
					62080, -- [1]
				},
				["size"] = {
					["multi"] = {
					},
				},
				["use_exact_spellknown"] = false,
				["use_item_bonusid_equipped"] = false,
				["itemtypeequipped"] = {
				},
			},
			["displayText_format_1.maxRange_format"] = "none",
			["shadowXOffset"] = 1,
			["displayText_format_1.minRange_abbreviate"] = false,
			["regionType"] = "icon",
			["displayText_format_destUnit_abbreviate_max"] = 8,
			["zoom"] = 0,
			["displayText_format_destUnit_format"] = "Unit",
			["tocversion"] = 30401,
			["alpha"] = 1,
			["config"] = {
			},
			["fixedWidth"] = 200,
			["outline"] = "OUTLINE",
			["wagoID"] = "YP6nljWXe",
			["parent"] = "Starfall Range Check on Nameplate",
			["shadowYOffset"] = -1,
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "event",
			["automaticWidth"] = "Auto",
			["triggers"] = {
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "35",
						["unit"] = "nameplate10",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [1]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "20",
						["unit"] = "nameplate10",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = false,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [6]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "15",
						["unit"] = "nameplate10",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [7]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate10",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [8]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [9]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [10]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate10",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [11]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    if trigger[1] and trigger[3] and trigger[5] then\n        return true\n    elseif trigger[2] and trigger[4] and trigger[5] then\n        return true\n    elseif trigger[3] and trigger[8] and trigger[6] then\n        return true\n    elseif trigger[4] and trigger[7] and trigger[6] then\n        return true\n    elseif trigger[4] and (trigger[9] and trigger[10]) and trigger[7] then\n        return true\n    elseif trigger[3] and (trigger[9] and trigger[10]) and trigger[11] then\n        return true\n    end\nend",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["version"] = 7,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%maxRange",
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = false,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_text_format_p_time_mod_rate"] = true,
					["anchorXOffset"] = 0,
					["text_text_format_minRange_format"] = "none",
					["type"] = "subtext",
					["text_text_format_maxRange_format"] = "none",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_text_format_p_time_format"] = 0,
					["text_shadowYOffset"] = 0,
					["text_fontType"] = "OUTLINE",
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "CENTER",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["anchorYOffset"] = 0,
					["text_fontSize"] = 12,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_text_format_p_time_precision"] = 1,
				}, -- [2]
			},
			["height"] = 25,
			["displayText_format_destUnit_realm_name"] = "never",
			["preferToUpdate"] = false,
			["information"] = {
				["forceEvents"] = true,
			},
			["displayText_format_1.minRange_color"] = true,
			["source"] = "import",
			["conditions"] = {
			},
			["displayIcon"] = 236168,
			["cooldownTextDisabled"] = false,
			["displayText_format_1.minRange_round_type"] = "ceil",
			["authorOptions"] = {
			},
			["desaturate"] = false,
			["wordWrap"] = "WordWrap",
			["anchorFrameType"] = "NAMEPLATE",
			["useCooldownModRate"] = true,
			["displayText_format_destUnit_abbreviate"] = false,
			["displayText_format_1.minRange_format"] = "Number",
			["displayText_format_p_time_precision"] = 1,
			["color"] = {
				0.97647058823529, -- [1]
				1, -- [2]
				0.97647058823529, -- [3]
				1, -- [4]
			},
			["justify"] = "LEFT",
			["uid"] = "3CV5ESavc6V",
			["semver"] = "1.0.6",
			["displayText"] = "%1.maxRange",
			["id"] = "Nameplate range check 10 ",
			["anchorFrameParent"] = false,
			["frameStrata"] = 1,
			["width"] = 25,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["fontSize"] = 16,
			["inverse"] = false,
			["displayText_format_1.minRange_abbreviate_max"] = 8,
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["displayText_format_1.minRange_decimal_precision"] = 0,
			["cooldown"] = false,
			["cooldownEdge"] = false,
		},
		["Adrenaline Rush"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "aura2",
						["auranames"] = {
							"13750", -- [1]
						},
						["event"] = "Health",
						["unit"] = "player",
						["spellIds"] = {
						},
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["useName"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["track"] = "auto",
						["use_matchedRune"] = false,
						["duration"] = "1",
						["genericShowOn"] = "showAlways",
						["names"] = {
						},
						["use_showgcd"] = false,
						["debuffType"] = "HELPFUL",
						["type"] = "spell",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "Adrenaline Rush",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["subeventPrefix"] = "SPELL",
						["use_genericShowOn"] = true,
						["use_track"] = true,
						["spellName"] = 13750,
					},
					["untrigger"] = {
						["genericShowOn"] = "showAlways",
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["class_and_spec"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["use_class"] = true,
				["use_spellknown"] = true,
				["zoneIds"] = "",
				["use_spec"] = true,
				["spec"] = {
					["single"] = 2,
					["multi"] = {
						[3] = true,
					},
				},
				["use_never"] = false,
				["spellknown"] = 13750,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "g2NhXZ6vF8X",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = false,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "buttonOverlay",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -1,
						["variable"] = "incombat",
						["value"] = 0,
					},
					["changes"] = {
						{
							["property"] = "sub.3.glow",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [3]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "Pixel",
							["property"] = "sub.3.glowType",
						}, -- [2]
						{
							["property"] = "desaturate",
						}, -- [3]
						{
							["property"] = "inverse",
						}, -- [4]
						{
							["value"] = true,
							["property"] = "cooldownEdge",
						}, -- [5]
					},
				}, -- [4]
			},
			["parent"] = "Core - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Adrenaline Rush",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["displayIcon"] = "",
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Health Bar - Rogue"] = {
			["overlays"] = {
				{
					0, -- [1]
					0, -- [2]
					0, -- [3]
					0.40000003576279, -- [4]
				}, -- [1]
			},
			["iconSource"] = -1,
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["sparkRotation"] = 0,
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["icon"] = false,
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["enableGradient"] = false,
			["selfPoint"] = "TOP",
			["barColor"] = {
				0.34509803921569, -- [1]
				0.64313725490196, -- [2]
				0.28235294117647, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["sparkOffsetY"] = 0,
			["gradientOrientation"] = "HORIZONTAL",
			["load"] = {
				["use_class"] = true,
				["use_petbattle"] = false,
				["use_never"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 3,
					["multi"] = {
						[3] = true,
					},
				},
				["zoneIds"] = "",
			},
			["smoothProgress"] = true,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["overlayclip"] = true,
			["texture"] = "Solid",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["auto"] = true,
			["tocversion"] = 30401,
			["alpha"] = 1,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["sparkOffsetX"] = 0,
			["wagoID"] = "foIUC5_yM",
			["parent"] = "Resources - Rogue",
			["customText"] = "function()\n    local s = aura_env.state\n    local LWA = LWA and LWA[\"Rogue\"] or {}\n    \n    if LWA and LWA.UpdateBarText then\n        local format = LWA.GetConfig(\"resources\").health_bar.format\n        \n        return LWA.UpdateBarText(s.value, s.percenthealth, format)\n    end\n    \n    return s.value\nend\n\n",
			["sparkRotationMode"] = "AUTO",
			["triggers"] = {
				{
					["trigger"] = {
						["names"] = {
						},
						["type"] = "unit",
						["use_absorbHealMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["duration"] = "1",
						["use_showCost"] = true,
						["subeventPrefix"] = "SPELL",
						["subeventSuffix"] = "_CAST_START",
						["powertype"] = 0,
						["spellIds"] = {
						},
						["event"] = "Health",
						["unit"] = "player",
						["use_absorbMode"] = true,
						["use_powertype"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = 1,
			},
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["isPrimaryResource"] = true,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["type"] = "subforeground",
				}, -- [2]
				{
					["border_size"] = 2,
					["border_anchor"] = "bar",
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [3]
				{
					["text_text_format_p_time_precision"] = 1,
					["text_text"] = "%c",
					["text_text_format_p_time_format"] = 0,
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_selfPoint"] = "CENTER",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["text_text_format_p_format"] = "timed",
					["text_text_format_c_format"] = "none",
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_text_format_p_time_legacy_floor"] = true,
					["text_shadowXOffset"] = 1,
					["text_font"] = "Friz Quadrata TT",
					["type"] = "subtext",
					["text_fontType"] = "OUTLINE",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_text_format_percenthealth_round_type"] = "floor",
					["text_text_format_percenthealth_decimal_precision"] = 0,
					["text_shadowYOffset"] = -1,
					["text_text_format_1.percentpower_format"] = "none",
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_CENTER",
					["anchorYOffset"] = 0,
					["text_text_format_p_time_mod_rate"] = true,
					["text_fontSize"] = 14,
					["anchorXOffset"] = 0,
					["text_text_format_percenthealth_format"] = "Number",
				}, -- [4]
			},
			["height"] = 20,
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["source"] = "import",
			["sparkWidth"] = 10,
			["icon_side"] = "RIGHT",
			["spark"] = false,
			["xOffset"] = 0,
			["sparkHeight"] = 30,
			["barColor2"] = {
				1, -- [1]
				1, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["configGroup"] = "health_bar",
			["actions"] = {
				["start"] = {
					["custom"] = "",
					["do_message"] = false,
					["do_custom"] = false,
				},
				["finish"] = {
				},
				["init"] = {
					["custom"] = "aura_env.region.configGroup = \"health_bar\"\n",
					["do_custom"] = true,
				},
			},
			["semver"] = "2.0.23",
			["zoom"] = 0,
			["sparkHidden"] = "NEVER",
			["config"] = {
			},
			["frameStrata"] = 1,
			["width"] = 405,
			["id"] = "Health Bar - Rogue",
			["anchorFrameType"] = "SCREEN",
			["inverse"] = false,
			["backgroundColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.30000001192093, -- [4]
			},
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
			},
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["uid"] = "UcfCe0hhPN9",
		},
		["Nameplate range check 5"] = {
			["iconSource"] = 0,
			["displayText_format_1.minRange_realm_name"] = "never",
			["xOffset"] = 0,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["yOffset"] = 0,
			["anchorPoint"] = "RIGHT",
			["displayText_format_p_time_format"] = 0,
			["url"] = "https://wago.io/YP6nljWXe/7",
			["icon"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "LEFT",
			["displayText_format_destUnit_color"] = "class",
			["desc"] = "Checks nearest 20 nameplates and shows a starfall icon if they are in range of starfall (36 yrds). \n\nHelps you make any decisions about using starfall and to stop any ninja pulls. \n\nIf you want more nameplates you can simply duplicate one of the weak auras in the group and add a number to the trigger. \n\nIf anyone finds an easier way to make this kind of a weak aura let me know as this was made editing a pre existing weak aura with a similar function.",
			["font"] = "PT Sans Narrow",
			["load"] = {
				["use_never"] = false,
				["class"] = {
					["single"] = "DRUID",
					["multi"] = {
						["DRUID"] = true,
					},
				},
				["use_encounterid"] = false,
				["use_class"] = true,
				["use_itemequiped"] = false,
				["zoneIds"] = "",
				["use_not_item_bonusid_equipped"] = false,
				["talent2"] = {
					["multi"] = {
						[20] = false,
					},
				},
				["use_zoneIds"] = false,
				["item_bonusid_equipped"] = "62080",
				["spec"] = {
					["multi"] = {
					},
				},
				["not_item_bonusid_equipped"] = "62080",
				["use_talent"] = false,
				["use_spellknown"] = false,
				["talent"] = {
					["multi"] = {
						[24] = true,
					},
				},
				["itemequiped"] = {
					62080, -- [1]
				},
				["size"] = {
					["multi"] = {
					},
				},
				["use_exact_spellknown"] = false,
				["use_item_bonusid_equipped"] = false,
				["itemtypeequipped"] = {
				},
			},
			["displayText_format_1.maxRange_format"] = "none",
			["shadowXOffset"] = 1,
			["displayText_format_1.minRange_abbreviate"] = false,
			["regionType"] = "icon",
			["displayText_format_destUnit_abbreviate_max"] = 8,
			["zoom"] = 0,
			["displayText_format_destUnit_format"] = "Unit",
			["tocversion"] = 30401,
			["alpha"] = 1,
			["config"] = {
			},
			["fixedWidth"] = 200,
			["outline"] = "OUTLINE",
			["wagoID"] = "YP6nljWXe",
			["parent"] = "Starfall Range Check on Nameplate",
			["shadowYOffset"] = -1,
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "event",
			["automaticWidth"] = "Auto",
			["triggers"] = {
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "35",
						["unit"] = "nameplate5",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [1]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "20",
						["unit"] = "nameplate5",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = false,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [6]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "15",
						["unit"] = "nameplate5",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [7]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate5",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [8]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [9]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [10]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate5",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [11]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    if trigger[1] and trigger[3] and trigger[5] then\n        return true\n    elseif trigger[2] and trigger[4] and trigger[5] then\n        return true\n    elseif trigger[3] and trigger[8] and trigger[6] then\n        return true\n    elseif trigger[4] and trigger[7] and trigger[6] then\n        return true\n    elseif trigger[4] and (trigger[9] and trigger[10]) and trigger[7] then\n        return true\n    elseif trigger[3] and (trigger[9] and trigger[10]) and trigger[11] then\n        return true\n    end\nend",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["version"] = 7,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%maxRange",
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = false,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_text_format_p_time_mod_rate"] = true,
					["anchorXOffset"] = 0,
					["text_text_format_minRange_format"] = "none",
					["type"] = "subtext",
					["text_text_format_maxRange_format"] = "none",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_text_format_p_time_format"] = 0,
					["text_shadowYOffset"] = 0,
					["text_fontType"] = "OUTLINE",
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "CENTER",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["anchorYOffset"] = 0,
					["text_fontSize"] = 12,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_text_format_p_time_precision"] = 1,
				}, -- [2]
			},
			["height"] = 25,
			["displayText_format_destUnit_realm_name"] = "never",
			["preferToUpdate"] = false,
			["information"] = {
				["forceEvents"] = true,
			},
			["displayText_format_1.minRange_color"] = true,
			["source"] = "import",
			["conditions"] = {
			},
			["displayIcon"] = 236168,
			["cooldownTextDisabled"] = false,
			["displayText_format_1.minRange_round_type"] = "ceil",
			["authorOptions"] = {
			},
			["desaturate"] = false,
			["wordWrap"] = "WordWrap",
			["anchorFrameType"] = "NAMEPLATE",
			["useCooldownModRate"] = true,
			["displayText_format_destUnit_abbreviate"] = false,
			["displayText_format_1.minRange_format"] = "Number",
			["displayText_format_p_time_precision"] = 1,
			["color"] = {
				0.97647058823529, -- [1]
				1, -- [2]
				0.97647058823529, -- [3]
				1, -- [4]
			},
			["justify"] = "LEFT",
			["uid"] = "4g6lE43CwbC",
			["semver"] = "1.0.6",
			["displayText"] = "%1.maxRange",
			["id"] = "Nameplate range check 5",
			["anchorFrameParent"] = false,
			["frameStrata"] = 1,
			["width"] = 25,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["fontSize"] = 16,
			["inverse"] = false,
			["displayText_format_1.minRange_abbreviate_max"] = 8,
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["displayText_format_1.minRange_decimal_precision"] = 0,
			["cooldown"] = false,
			["cooldownEdge"] = false,
		},
		["Tricks of the Trade"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["useMatch_count"] = true,
						["match_countOperator"] = ">",
						["auranames"] = {
							"57934", -- [1]
						},
						["ownOnly"] = true,
						["event"] = "Health",
						["unit"] = "group",
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["spellIds"] = {
						},
						["subeventPrefix"] = "SPELL",
						["match_count"] = "0",
						["type"] = "aura2",
						["useName"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["track"] = "auto",
						["use_matchedRune"] = false,
						["duration"] = "1",
						["genericShowOn"] = "showAlways",
						["names"] = {
						},
						["use_showgcd"] = true,
						["debuffType"] = "HELPFUL",
						["type"] = "spell",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "Tricks of the Trade",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["subeventPrefix"] = "SPELL",
						["use_genericShowOn"] = true,
						["use_track"] = true,
						["spellName"] = 57934,
					},
					["untrigger"] = {
						["genericShowOn"] = "showAlways",
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["class_and_spec"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["use_class"] = true,
				["use_spellknown"] = true,
				["zoneIds"] = "",
				["use_spec"] = true,
				["spec"] = {
					["single"] = 2,
					["multi"] = {
						[3] = true,
					},
				},
				["use_never"] = false,
				["spellknown"] = 57934,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "D4wmi3VLQBa",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = false,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "buttonOverlay",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -1,
						["variable"] = "incombat",
						["value"] = 0,
					},
					["changes"] = {
						{
							["property"] = "sub.3.glow",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [3]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "Pixel",
							["property"] = "sub.3.glowType",
						}, -- [2]
						{
							["property"] = "desaturate",
						}, -- [3]
						{
							["property"] = "inverse",
						}, -- [4]
						{
							["value"] = true,
							["property"] = "cooldownEdge",
						}, -- [5]
					},
				}, -- [4]
			},
			["parent"] = "Core - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Tricks of the Trade",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["displayIcon"] = "",
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Nameplate range check 4 "] = {
			["iconSource"] = 0,
			["displayText_format_1.minRange_realm_name"] = "never",
			["xOffset"] = 0,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["yOffset"] = 0,
			["anchorPoint"] = "RIGHT",
			["displayText_format_p_time_format"] = 0,
			["url"] = "https://wago.io/YP6nljWXe/7",
			["icon"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "LEFT",
			["displayText_format_destUnit_color"] = "class",
			["desc"] = "Checks nearest 20 nameplates and shows a starfall icon if they are in range of starfall (36 yrds). \n\nHelps you make any decisions about using starfall and to stop any ninja pulls. \n\nIf you want more nameplates you can simply duplicate one of the weak auras in the group and add a number to the trigger. \n\nIf anyone finds an easier way to make this kind of a weak aura let me know as this was made editing a pre existing weak aura with a similar function.",
			["font"] = "PT Sans Narrow",
			["load"] = {
				["use_never"] = false,
				["class"] = {
					["single"] = "DRUID",
					["multi"] = {
						["DRUID"] = true,
					},
				},
				["use_encounterid"] = false,
				["use_class"] = true,
				["use_itemequiped"] = false,
				["zoneIds"] = "",
				["use_not_item_bonusid_equipped"] = false,
				["talent2"] = {
					["multi"] = {
						[20] = false,
					},
				},
				["use_zoneIds"] = false,
				["item_bonusid_equipped"] = "62080",
				["spec"] = {
					["multi"] = {
					},
				},
				["not_item_bonusid_equipped"] = "62080",
				["use_talent"] = false,
				["use_spellknown"] = false,
				["talent"] = {
					["multi"] = {
						[24] = true,
					},
				},
				["itemequiped"] = {
					62080, -- [1]
				},
				["size"] = {
					["multi"] = {
					},
				},
				["use_exact_spellknown"] = false,
				["use_item_bonusid_equipped"] = false,
				["itemtypeequipped"] = {
				},
			},
			["displayText_format_1.maxRange_format"] = "none",
			["shadowXOffset"] = 1,
			["displayText_format_1.minRange_abbreviate"] = false,
			["regionType"] = "icon",
			["displayText_format_destUnit_abbreviate_max"] = 8,
			["zoom"] = 0,
			["displayText_format_destUnit_format"] = "Unit",
			["tocversion"] = 30401,
			["alpha"] = 1,
			["config"] = {
			},
			["fixedWidth"] = 200,
			["outline"] = "OUTLINE",
			["wagoID"] = "YP6nljWXe",
			["parent"] = "Starfall Range Check on Nameplate",
			["shadowYOffset"] = -1,
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "event",
			["automaticWidth"] = "Auto",
			["triggers"] = {
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "35",
						["unit"] = "nameplate4",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [1]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "20",
						["unit"] = "nameplate4",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = false,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [6]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "15",
						["unit"] = "nameplate4",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [7]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate4",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [8]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [9]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [10]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate4",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [11]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    if trigger[1] and trigger[3] and trigger[5] then\n        return true\n    elseif trigger[2] and trigger[4] and trigger[5] then\n        return true\n    elseif trigger[3] and trigger[8] and trigger[6] then\n        return true\n    elseif trigger[4] and trigger[7] and trigger[6] then\n        return true\n    elseif trigger[4] and (trigger[9] and trigger[10]) and trigger[7] then\n        return true\n    elseif trigger[3] and (trigger[9] and trigger[10]) and trigger[11] then\n        return true\n    end\nend",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["version"] = 7,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%maxRange",
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = false,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_text_format_p_time_mod_rate"] = true,
					["anchorXOffset"] = 0,
					["text_text_format_minRange_format"] = "none",
					["type"] = "subtext",
					["text_text_format_maxRange_format"] = "none",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_text_format_p_time_format"] = 0,
					["text_shadowYOffset"] = 0,
					["text_fontType"] = "OUTLINE",
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "CENTER",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["anchorYOffset"] = 0,
					["text_fontSize"] = 12,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_text_format_p_time_precision"] = 1,
				}, -- [2]
			},
			["height"] = 25,
			["displayText_format_destUnit_realm_name"] = "never",
			["preferToUpdate"] = false,
			["information"] = {
				["forceEvents"] = true,
			},
			["displayText_format_1.minRange_color"] = true,
			["source"] = "import",
			["conditions"] = {
			},
			["displayIcon"] = 236168,
			["cooldownTextDisabled"] = false,
			["displayText_format_1.minRange_round_type"] = "ceil",
			["authorOptions"] = {
			},
			["desaturate"] = false,
			["wordWrap"] = "WordWrap",
			["anchorFrameType"] = "NAMEPLATE",
			["useCooldownModRate"] = true,
			["displayText_format_destUnit_abbreviate"] = false,
			["displayText_format_1.minRange_format"] = "Number",
			["displayText_format_p_time_precision"] = 1,
			["color"] = {
				0.97647058823529, -- [1]
				1, -- [2]
				0.97647058823529, -- [3]
				1, -- [4]
			},
			["justify"] = "LEFT",
			["uid"] = "mMG)0RLNtPS",
			["semver"] = "1.0.6",
			["displayText"] = "%1.maxRange",
			["id"] = "Nameplate range check 4 ",
			["anchorFrameParent"] = false,
			["frameStrata"] = 1,
			["width"] = 25,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["fontSize"] = 16,
			["inverse"] = false,
			["displayText_format_1.minRange_abbreviate_max"] = 8,
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["displayText_format_1.minRange_decimal_precision"] = 0,
			["cooldown"] = false,
			["cooldownEdge"] = false,
		},
		["Combo Point 5 - Rogue"] = {
			["sparkWidth"] = 10,
			["iconSource"] = -1,
			["authorOptions"] = {
			},
			["adjustedMax"] = "5",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["sparkRotation"] = 0,
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["backgroundColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.34336978197098, -- [4]
			},
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["enableGradient"] = false,
			["selfPoint"] = "TOP",
			["barColor"] = {
				0.85882352941176, -- [1]
				0.14509803921569, -- [2]
				0.050980392156863, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["sparkOffsetY"] = 0,
			["gradientOrientation"] = "HORIZONTAL",
			["load"] = {
				["use_class"] = true,
				["use_petbattle"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 3,
					["multi"] = {
						[3] = true,
					},
				},
				["zoneIds"] = "",
			},
			["smoothProgress"] = false,
			["useAdjustededMin"] = true,
			["regionType"] = "aurabar",
			["texture"] = "Solid",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["auto"] = true,
			["tocversion"] = 30401,
			["alpha"] = 1,
			["config"] = {
			},
			["colorState"] = "",
			["sparkOffsetX"] = 0,
			["wagoID"] = "foIUC5_yM",
			["parent"] = "Combo Points - Rogue",
			["adjustedMin"] = "4",
			["sparkRotationMode"] = "AUTO",
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "unit",
						["names"] = {
						},
						["unevent"] = "auto",
						["use_unit"] = true,
						["duration"] = "1",
						["event"] = "Power",
						["subeventPrefix"] = "SPELL",
						["subeventSuffix"] = "_CAST_START",
						["powertype"] = 4,
						["spellIds"] = {
						},
						["use_power"] = false,
						["unit"] = "player",
						["use_absorbMode"] = true,
						["use_powertype"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = 1,
			},
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["isPrimaryResource"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["type"] = "subforeground",
				}, -- [2]
				{
					["border_size"] = 2,
					["border_anchor"] = "bar",
					["type"] = "subborder",
					["border_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
					},
					["border_visible"] = false,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [3]
			},
			["height"] = 20,
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = true,
			["source"] = "import",
			["xOffset"] = 0,
			["icon_side"] = "RIGHT",
			["preferToUpdate"] = false,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["sparkHeight"] = 30,
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["icon"] = false,
			["configGroup"] = "combo_points",
			["semver"] = "2.0.23",
			["spark"] = false,
			["sparkHidden"] = "NEVER",
			["zoom"] = 0,
			["frameStrata"] = 1,
			["width"] = 56,
			["id"] = "Combo Point 5 - Rogue",
			["anchorFrameType"] = "SCREEN",
			["inverse"] = false,
			["uid"] = "C)jASheVT)B",
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "<=",
						["value"] = "3",
						["variable"] = "power",
					},
					["changes"] = {
						{
							["value"] = {
								["custom"] = "aura_env.region.colorState = \"\"\nWeakAuras.ScanEvents(\"LWA_UPDATE_BAR\", aura_env, 5, 5)",
							},
							["property"] = "customcode",
						}, -- [1]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "==",
						["value"] = "4",
						["variable"] = "power",
					},
					["linked"] = true,
					["changes"] = {
						{
							["value"] = {
								["custom"] = "aura_env.region.colorState = \"highlight\"\nWeakAuras.ScanEvents(\"LWA_UPDATE_BAR\", aura_env, 5, 5)",
							},
							["property"] = "customcode",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "==",
						["value"] = "5",
						["variable"] = "power",
					},
					["linked"] = true,
					["changes"] = {
						{
							["value"] = {
								["custom"] = "aura_env.region.colorState = \"full\"\nWeakAuras.ScanEvents(\"LWA_UPDATE_BAR\", aura_env, 5, 5)",
							},
							["property"] = "customcode",
						}, -- [1]
					},
				}, -- [3]
			},
			["barColor2"] = {
				1, -- [1]
				1, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
					["custom"] = "aura_env.region.configGroup = \"combo_points\"",
					["do_custom"] = true,
				},
			},
		},
		["General Options - Rogue"] = {
			["iconSource"] = 0,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "custom",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "GTFO",
						["unit"] = "player",
						["debuffType"] = "HELPFUL",
						["custom"] = "function(event, ...)\n    local arg1, arg2 = ...\n    local LWA = LWA[aura_env.CLASS]\n    local valid = false\n    \n    if \"OPTIONS\" == event then\n        LWA.ThrottledInit()\n        \n    elseif \"PLAYER_ENTERING_WORLD\" == event and (arg1 or arg2) then\n        C_Timer.After(0.05, LWA.Init)\n        C_Timer.After(1, LWA.ThrottledInit)\n        \n    elseif \"UNIT_PET\" == event or \"UNIT_ENTERED_VEHICLE\" == event or \"UNIT_EXITED_VEHICLE\" == event then\n        valid = (\"player\" == arg1)\n        \n    elseif \"UNIT_HEALTH\" == event then\n        valid = (\"pet\" == arg1)\n        \n    elseif \"LWA_UPDATE_BAR\" == event and arg1 then\n        LWA.UpdateBar(...)\n    else\n        valid = true\n    end\n    \n    if valid then\n        C_Timer.After(0.05, LWA.UpdateResources)\n    end\nend",
						["events"] = "OPTIONS,PLAYER_ENTERING_WORLD,PLAYER_SPECIALIZATION_CHANGED,UPDATE_SHAPESHIFT_FORM,PLAYER_TALENT_UPDATE,PLAYER_PVP_TALENT_UPDATE,PLAYER_LEVEL_UP,UNIT_PET,UNIT_ENTERED_VEHICLE,UNIT_EXITED_VEHICLE,UNIT_HEALTH,CINEMATIC_STOP,STOP_MOVIE,CLIENT_SCENE_CLOSED,LWA_UPDATE_BAR",
						["custom_type"] = "event",
						["names"] = {
						},
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["custom_hide"] = "timed",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "GTFO",
						["unit"] = "player",
						["debuffType"] = "HELPFUL",
						["custom"] = "function(event, ...)\n    if not aura_env.parentFrame then\n        aura_env.parentFrame = WeakAuras.GetRegion(aura_env.parent)\n    end\n    \n    local frame = aura_env.parentFrame\n    \n    if frame then\n        local alpha = 1\n        \n        if \"BARBER_SHOP_OPEN\" == event then\n            alpha = 0\n        else\n            local cfg = LWA[aura_env.CLASS].GetConfig(\"ooc_alpha\")\n            \n            if not UnitAffectingCombat(\"player\") then\n                alpha = cfg.alpha\n            end\n            \n            if UnitExists(\"target\") then\n                local isEnemy = UnitCanAttack(\"player\", \"target\") or UnitIsEnemy(\"player\", \"target\")\n                \n                if (not isEnemy and cfg.ignore_friendly) or (isEnemy and cfg.ignore_enemy) then\n                    alpha = 1\n                end\n            end\n        end\n        \n        frame:SetAlpha(alpha)\n        \n        return true\n    end\n    \n    return false\nend",
						["events"] = "PLAYER_ENTERING_WORLD,PLAYER_REGEN_ENABLED,PLAYER_REGEN_DISABLED,PLAYER_TARGET_CHANGED,PLAYER_ALIVE,PLAYER_DEAD,PLAYER_UNGHOST,BARBER_SHOP_OPEN,BARBER_SHOP_CLOSE,OPTIONS",
						["custom_type"] = "event",
						["names"] = {
						},
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["custom_hide"] = "timed",
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "custom",
						["events"] = "STATUS",
						["custom_type"] = "status",
						["check"] = "event",
						["debuffType"] = "HELPFUL",
						["custom"] = "function()\n    local LWA = LWA[aura_env.CLASS]\n    \n    LWA.ThrottledInit()\n    C_Timer.After(1, LWA.Init)\nend",
						["unit"] = "player",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["type"] = "unit",
						["use_alwaystrue"] = true,
						["use_unit"] = true,
						["debuffType"] = "HELPFUL",
						["event"] = "Conditions",
						["unit"] = "player",
					},
					["untrigger"] = {
					},
				}, -- [4]
				["disjunctive"] = "any",
				["customTriggerLogic"] = "",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = false,
			["selfPoint"] = "TOP",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
			},
			["height"] = 48,
			["load"] = {
				["use_class"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["uid"] = "w5ZoRpdOLlZ",
			["authorOptions"] = {
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Global Settings",
					["noMerge"] = false,
					["width"] = 1,
				}, -- [1]
				{
					["subOptions"] = {
						{
							["type"] = "space",
							["variableWidth"] = true,
							["height"] = 2,
							["useHeight"] = true,
							["width"] = 2,
						}, -- [1]
						{
							["softMin"] = 0,
							["type"] = "range",
							["bigStep"] = 1,
							["max"] = 10,
							["step"] = 1,
							["width"] = 1,
							["min"] = 0,
							["key"] = "border_size",
							["softMax"] = 10,
							["default"] = 0,
							["name"] = "Border Size",
							["useDesc"] = false,
						}, -- [2]
						{
							["softMin"] = 0,
							["type"] = "range",
							["bigStep"] = 1,
							["max"] = 100,
							["step"] = 1,
							["width"] = 1,
							["min"] = 0,
							["key"] = "zoom",
							["softMax"] = 100,
							["default"] = 30,
							["name"] = "Icon Zoom",
							["useDesc"] = false,
						}, -- [3]
						{
							["type"] = "color",
							["default"] = {
								0, -- [1]
								0, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["key"] = "border_color",
							["name"] = "Border Color",
							["useDesc"] = false,
							["width"] = 1,
						}, -- [4]
						{
							["type"] = "toggle",
							["default"] = true,
							["key"] = "apply_border",
							["name"] = "Apply Border to Resources",
							["useDesc"] = false,
							["width"] = 1,
						}, -- [5]
						{
							["type"] = "space",
							["variableWidth"] = true,
							["height"] = 2,
							["useHeight"] = true,
							["width"] = 2,
						}, -- [6]
					},
					["hideReorder"] = true,
					["useDesc"] = false,
					["nameSource"] = 0,
					["width"] = 1,
					["useCollapse"] = true,
					["name"] = "Global Style",
					["collapse"] = true,
					["type"] = "group",
					["limitType"] = "none",
					["groupType"] = "simple",
					["key"] = "style",
					["size"] = 10,
				}, -- [2]
				{
					["subOptions"] = {
						{
							["type"] = "space",
							["variableWidth"] = true,
							["height"] = 2,
							["useHeight"] = true,
							["width"] = 2,
						}, -- [1]
						{
							["softMin"] = 0,
							["type"] = "range",
							["bigStep"] = 0.05,
							["max"] = 1,
							["step"] = 0.05,
							["width"] = 2,
							["min"] = 0,
							["key"] = "alpha",
							["default"] = 1,
							["softMax"] = 1,
							["name"] = "Out of Combat Alpha",
							["useDesc"] = true,
							["desc"] = "Change the alpha of the groups when out of combat.",
						}, -- [2]
						{
							["type"] = "toggle",
							["default"] = true,
							["width"] = 1,
							["name"] = "Ignore on Enemy Target",
							["useDesc"] = true,
							["key"] = "ignore_enemy",
							["desc"] = "Enable to show full opacity on enemy target.",
						}, -- [3]
						{
							["type"] = "toggle",
							["default"] = true,
							["width"] = 1,
							["name"] = "Ignore on Friendly Target",
							["useDesc"] = true,
							["key"] = "ignore_friendly",
							["desc"] = "Enable to show full opacity on friendly target.",
						}, -- [4]
						{
							["type"] = "space",
							["variableWidth"] = true,
							["height"] = 2,
							["useHeight"] = true,
							["width"] = 2,
						}, -- [5]
					},
					["hideReorder"] = true,
					["useDesc"] = false,
					["nameSource"] = 0,
					["width"] = 1,
					["useCollapse"] = true,
					["name"] = "Out of Combat Alpha",
					["collapse"] = true,
					["type"] = "group",
					["limitType"] = "none",
					["groupType"] = "simple",
					["key"] = "ooc_alpha",
					["size"] = 10,
				}, -- [3]
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Icons Size & Spacing",
					["noMerge"] = false,
					["width"] = 1,
				}, -- [4]
				{
					["subOptions"] = {
						{
							["type"] = "space",
							["variableWidth"] = true,
							["height"] = 2,
							["useHeight"] = true,
							["width"] = 2,
						}, -- [1]
						{
							["softMin"] = 16,
							["type"] = "range",
							["bigStep"] = 2,
							["max"] = 72,
							["step"] = 2,
							["width"] = 1,
							["min"] = 16,
							["key"] = "width",
							["softMax"] = 72,
							["default"] = 48,
							["name"] = "Width",
							["useDesc"] = false,
						}, -- [2]
						{
							["softMin"] = 8,
							["type"] = "range",
							["bigStep"] = 2,
							["max"] = 72,
							["step"] = 2,
							["width"] = 1,
							["min"] = 8,
							["key"] = "height",
							["softMax"] = 72,
							["default"] = 48,
							["name"] = "Height",
							["useDesc"] = false,
						}, -- [3]
						{
							["softMin"] = 0,
							["type"] = "range",
							["bigStep"] = 1,
							["max"] = 20,
							["step"] = 1,
							["width"] = 1,
							["min"] = 0,
							["key"] = "spacing",
							["softMax"] = 20,
							["default"] = 3,
							["name"] = "Spacing",
							["useDesc"] = false,
						}, -- [4]
						{
							["softMin"] = 4,
							["type"] = "range",
							["bigStep"] = 1,
							["max"] = 12,
							["step"] = 1,
							["width"] = 1,
							["min"] = 4,
							["key"] = "nb",
							["softMax"] = 12,
							["default"] = 8,
							["name"] = "Number of Icons",
							["useDesc"] = false,
						}, -- [5]
						{
							["type"] = "select",
							["default"] = 2,
							["values"] = {
								"Above Main Icons", -- [1]
								"Below Main Icons", -- [2]
							},
							["name"] = "Resources Position",
							["useDesc"] = false,
							["key"] = "resources_position",
							["width"] = 1,
						}, -- [6]
						{
							["type"] = "space",
							["variableWidth"] = true,
							["height"] = 2,
							["useHeight"] = true,
							["width"] = 2,
						}, -- [7]
					},
					["hideReorder"] = true,
					["useDesc"] = false,
					["nameSource"] = 0,
					["width"] = 1,
					["useCollapse"] = true,
					["name"] = "Main Icons",
					["collapse"] = true,
					["type"] = "group",
					["limitType"] = "none",
					["groupType"] = "simple",
					["key"] = "primary",
					["size"] = 10,
				}, -- [5]
				{
					["subOptions"] = {
						{
							["type"] = "space",
							["variableWidth"] = true,
							["height"] = 2,
							["useHeight"] = true,
							["width"] = 2,
						}, -- [1]
						{
							["softMin"] = 16,
							["type"] = "range",
							["bigStep"] = 2,
							["max"] = 72,
							["step"] = 2,
							["width"] = 1,
							["min"] = 16,
							["key"] = "width",
							["softMax"] = 72,
							["default"] = 32,
							["name"] = "Width",
							["useDesc"] = false,
						}, -- [2]
						{
							["softMin"] = 8,
							["type"] = "range",
							["bigStep"] = 2,
							["max"] = 72,
							["step"] = 2,
							["width"] = 1,
							["min"] = 8,
							["key"] = "height",
							["softMax"] = 72,
							["default"] = 32,
							["name"] = "Height",
							["useDesc"] = false,
						}, -- [3]
						{
							["softMin"] = 0,
							["type"] = "range",
							["bigStep"] = 1,
							["max"] = 20,
							["step"] = 1,
							["width"] = 1,
							["min"] = 0,
							["key"] = "spacing",
							["softMax"] = 20,
							["default"] = 3,
							["name"] = "Spacing",
							["useDesc"] = false,
						}, -- [4]
						{
							["type"] = "space",
							["variableWidth"] = true,
							["height"] = 2,
							["useHeight"] = true,
							["width"] = 2,
						}, -- [5]
					},
					["hideReorder"] = true,
					["useDesc"] = false,
					["nameSource"] = 0,
					["width"] = 1,
					["useCollapse"] = true,
					["name"] = "Secondary Icons",
					["collapse"] = true,
					["type"] = "group",
					["limitType"] = "none",
					["groupType"] = "simple",
					["key"] = "secondary",
					["size"] = 10,
				}, -- [6]
				{
					["subOptions"] = {
						{
							["type"] = "space",
							["variableWidth"] = true,
							["height"] = 2,
							["useHeight"] = true,
							["width"] = 2,
						}, -- [1]
						{
							["softMin"] = 16,
							["type"] = "range",
							["bigStep"] = 2,
							["max"] = 72,
							["step"] = 2,
							["width"] = 1,
							["min"] = 16,
							["key"] = "width",
							["softMax"] = 72,
							["default"] = 34,
							["name"] = "Width",
							["useDesc"] = false,
						}, -- [2]
						{
							["softMin"] = 8,
							["type"] = "range",
							["bigStep"] = 2,
							["max"] = 72,
							["step"] = 2,
							["width"] = 1,
							["min"] = 8,
							["key"] = "height",
							["softMax"] = 72,
							["default"] = 34,
							["name"] = "Height",
							["useDesc"] = false,
						}, -- [3]
						{
							["softMin"] = 0,
							["type"] = "range",
							["bigStep"] = 1,
							["max"] = 20,
							["step"] = 1,
							["width"] = 1,
							["min"] = 0,
							["key"] = "spacing",
							["softMax"] = 20,
							["default"] = 3,
							["name"] = "Spacing",
							["useDesc"] = false,
						}, -- [4]
						{
							["softMin"] = 0,
							["type"] = "range",
							["bigStep"] = 1,
							["max"] = 200,
							["step"] = 1,
							["width"] = 1,
							["min"] = 0,
							["key"] = "margin",
							["softMax"] = 50,
							["default"] = 10,
							["name"] = "Bottom Margin",
							["useDesc"] = false,
						}, -- [5]
						{
							["type"] = "space",
							["variableWidth"] = true,
							["height"] = 2,
							["useHeight"] = true,
							["width"] = 2,
						}, -- [6]
					},
					["hideReorder"] = true,
					["useDesc"] = false,
					["nameSource"] = 0,
					["width"] = 1,
					["useCollapse"] = true,
					["name"] = "Dynamic Icons",
					["collapse"] = true,
					["type"] = "group",
					["limitType"] = "none",
					["groupType"] = "simple",
					["key"] = "dynamic",
					["size"] = 10,
				}, -- [7]
				{
					["subOptions"] = {
						{
							["type"] = "space",
							["variableWidth"] = true,
							["height"] = 2,
							["useHeight"] = true,
							["width"] = 2,
						}, -- [1]
						{
							["softMin"] = 16,
							["type"] = "range",
							["bigStep"] = 2,
							["max"] = 72,
							["step"] = 2,
							["width"] = 1,
							["min"] = 16,
							["key"] = "width",
							["softMax"] = 72,
							["default"] = 36,
							["name"] = "Width",
							["useDesc"] = false,
						}, -- [2]
						{
							["softMin"] = 8,
							["type"] = "range",
							["bigStep"] = 2,
							["max"] = 72,
							["step"] = 2,
							["width"] = 1,
							["min"] = 8,
							["key"] = "height",
							["softMax"] = 72,
							["default"] = 36,
							["name"] = "Height",
							["useDesc"] = false,
						}, -- [3]
						{
							["softMin"] = 0,
							["type"] = "range",
							["bigStep"] = 1,
							["max"] = 20,
							["step"] = 1,
							["width"] = 1,
							["min"] = 0,
							["key"] = "spacing",
							["softMax"] = 20,
							["default"] = 3,
							["name"] = "Spacing",
							["useDesc"] = false,
						}, -- [4]
						{
							["softMin"] = 0,
							["type"] = "range",
							["bigStep"] = 1,
							["max"] = 200,
							["step"] = 1,
							["width"] = 1,
							["min"] = 0,
							["key"] = "margin",
							["softMax"] = 50,
							["default"] = 3,
							["name"] = "Side Margin",
							["useDesc"] = false,
						}, -- [5]
						{
							["type"] = "toggle",
							["default"] = false,
							["key"] = "grow_horizontal",
							["name"] = "Grow Horizontally",
							["useDesc"] = false,
							["width"] = 1,
						}, -- [6]
						{
							["type"] = "space",
							["variableWidth"] = true,
							["height"] = 2,
							["useHeight"] = true,
							["width"] = 2,
						}, -- [7]
					},
					["hideReorder"] = true,
					["useDesc"] = false,
					["nameSource"] = 0,
					["width"] = 1,
					["useCollapse"] = true,
					["name"] = "Side Icons",
					["collapse"] = true,
					["type"] = "group",
					["limitType"] = "none",
					["groupType"] = "simple",
					["key"] = "side",
					["size"] = 10,
				}, -- [8]
				{
					["subOptions"] = {
						{
							["type"] = "space",
							["variableWidth"] = true,
							["height"] = 2,
							["useHeight"] = true,
							["width"] = 2,
						}, -- [1]
						{
							["text"] = "Please take note that all maintenance icons will be hidden while in a rested area out of combat no matter what behavior is selected. To see the normal behavior, leave the rested area or simply enter combat.",
							["type"] = "description",
							["fontSize"] = "medium",
							["width"] = 2,
						}, -- [2]
						{
							["type"] = "space",
							["variableWidth"] = true,
							["height"] = 1,
							["useHeight"] = true,
							["width"] = 2,
						}, -- [3]
						{
							["useName"] = true,
							["type"] = "header",
							["text"] = "Icon Size & Spacing",
							["noMerge"] = true,
							["width"] = 1,
						}, -- [4]
						{
							["softMin"] = 16,
							["type"] = "range",
							["bigStep"] = 2,
							["max"] = 72,
							["step"] = 2,
							["width"] = 1,
							["min"] = 16,
							["key"] = "width",
							["softMax"] = 72,
							["default"] = 36,
							["name"] = "Width",
							["useDesc"] = false,
						}, -- [5]
						{
							["softMin"] = 8,
							["type"] = "range",
							["bigStep"] = 2,
							["max"] = 72,
							["step"] = 2,
							["width"] = 1,
							["min"] = 8,
							["key"] = "height",
							["softMax"] = 72,
							["default"] = 36,
							["name"] = "Height",
							["useDesc"] = false,
						}, -- [6]
						{
							["softMin"] = 0,
							["type"] = "range",
							["bigStep"] = 1,
							["max"] = 20,
							["step"] = 1,
							["width"] = 1,
							["min"] = 0,
							["key"] = "spacing",
							["softMax"] = 20,
							["default"] = 3,
							["name"] = "Spacing",
							["useDesc"] = false,
						}, -- [7]
						{
							["softMin"] = 0,
							["type"] = "range",
							["bigStep"] = 1,
							["max"] = 200,
							["step"] = 1,
							["width"] = 1,
							["min"] = 0,
							["key"] = "margin",
							["softMax"] = 50,
							["default"] = 10,
							["name"] = "Top Margin",
							["useDesc"] = false,
						}, -- [8]
						{
							["type"] = "space",
							["variableWidth"] = true,
							["height"] = 2,
							["useHeight"] = true,
							["width"] = 2,
						}, -- [9]
					},
					["hideReorder"] = true,
					["useDesc"] = false,
					["nameSource"] = 0,
					["width"] = 1,
					["useCollapse"] = true,
					["name"] = "Maintenance Icons",
					["collapse"] = true,
					["type"] = "group",
					["limitType"] = "none",
					["groupType"] = "simple",
					["key"] = "maintenance",
					["size"] = 10,
				}, -- [9]
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Resources",
					["noMerge"] = false,
					["width"] = 1,
				}, -- [10]
				{
					["subOptions"] = {
						{
							["subOptions"] = {
								{
									["type"] = "space",
									["variableWidth"] = true,
									["height"] = 2,
									["useHeight"] = true,
									["width"] = 2,
								}, -- [1]
								{
									["softMin"] = 5,
									["type"] = "range",
									["bigStep"] = 1,
									["max"] = 50,
									["step"] = 1,
									["width"] = 1.25,
									["min"] = 5,
									["key"] = "height",
									["softMax"] = 50,
									["default"] = 20,
									["name"] = "Resource Height",
									["useDesc"] = false,
								}, -- [2]
								{
									["type"] = "select",
									["default"] = 1,
									["values"] = {
										"12345", -- [1]
										"12,3K", -- [2]
										"12345 (100%)", -- [3]
										"12,3K (100%)", -- [4]
										"100%", -- [5]
									},
									["name"] = "Text Format",
									["useDesc"] = false,
									["key"] = "format",
									["width"] = 0.75,
								}, -- [3]
								{
									["type"] = "space",
									["variableWidth"] = true,
									["height"] = 2,
									["useHeight"] = true,
									["width"] = 2,
								}, -- [4]
								{
									["useName"] = true,
									["type"] = "header",
									["text"] = "Default Color",
									["noMerge"] = true,
									["width"] = 1,
								}, -- [5]
								{
									["type"] = "color",
									["default"] = {
										0.34509803921569, -- [1]
										0.64313725490196, -- [2]
										0.28235294117647, -- [3]
										1, -- [4]
									},
									["key"] = "color1",
									["name"] = "Color 1",
									["useDesc"] = false,
									["width"] = 1,
								}, -- [6]
								{
									["type"] = "color",
									["default"] = {
										0.5843137254902, -- [1]
										0.90588235294118, -- [2]
										0.52156862745098, -- [3]
										1, -- [4]
									},
									["key"] = "color2",
									["name"] = "Color 2",
									["useDesc"] = false,
									["width"] = 1,
								}, -- [7]
								{
									["type"] = "select",
									["default"] = 1,
									["values"] = {
										"Horizontal", -- [1]
										"Vertical", -- [2]
										"None", -- [3]
									},
									["name"] = "Gradient Direction",
									["useDesc"] = false,
									["key"] = "gradient",
									["width"] = 1,
								}, -- [8]
								{
									["type"] = "space",
									["variableWidth"] = true,
									["height"] = 2,
									["useHeight"] = true,
									["width"] = 2,
								}, -- [9]
							},
							["hideReorder"] = true,
							["useDesc"] = false,
							["nameSource"] = 0,
							["width"] = 1,
							["useCollapse"] = true,
							["name"] = "Health Bar",
							["collapse"] = true,
							["type"] = "group",
							["limitType"] = "none",
							["groupType"] = "simple",
							["key"] = "health_bar",
							["size"] = 10,
						}, -- [1]
						{
							["subOptions"] = {
								{
									["type"] = "space",
									["variableWidth"] = true,
									["height"] = 2,
									["useHeight"] = true,
									["width"] = 2,
								}, -- [1]
								{
									["softMin"] = 5,
									["type"] = "range",
									["bigStep"] = 1,
									["max"] = 50,
									["step"] = 1,
									["width"] = 1.25,
									["min"] = 5,
									["key"] = "height",
									["softMax"] = 50,
									["default"] = 20,
									["name"] = "Resource Height",
									["useDesc"] = false,
								}, -- [2]
								{
									["type"] = "space",
									["variableWidth"] = true,
									["height"] = 2,
									["useHeight"] = true,
									["width"] = 2,
								}, -- [3]
								{
									["useName"] = true,
									["type"] = "header",
									["text"] = "Default Color",
									["noMerge"] = true,
									["width"] = 1,
								}, -- [4]
								{
									["type"] = "color",
									["default"] = {
										0.52941176470588, -- [1]
										0.090196078431373, -- [2]
										0.090196078431373, -- [3]
										1, -- [4]
									},
									["key"] = "color1",
									["name"] = "Color 1",
									["useDesc"] = false,
									["width"] = 1,
								}, -- [5]
								{
									["type"] = "color",
									["default"] = {
										0.77647058823529, -- [1]
										0.1843137254902, -- [2]
										0.1843137254902, -- [3]
										1, -- [4]
									},
									["key"] = "color2",
									["name"] = "Color 2",
									["useDesc"] = false,
									["width"] = 1,
								}, -- [6]
								{
									["type"] = "select",
									["default"] = 1,
									["values"] = {
										"Horizontal", -- [1]
										"Vertical", -- [2]
										"None", -- [3]
									},
									["name"] = "Gradient Direction",
									["useDesc"] = false,
									["key"] = "gradient",
									["width"] = 1,
								}, -- [7]
								{
									["useName"] = true,
									["type"] = "header",
									["text"] = "Uninterruptible",
									["noMerge"] = true,
									["width"] = 1,
								}, -- [8]
								{
									["type"] = "color",
									["default"] = {
										0.52549019607843, -- [1]
										0.52549019607843, -- [2]
										0.52549019607843, -- [3]
										0.90000000596046, -- [4]
									},
									["key"] = "unint_color1",
									["name"] = "Color 1",
									["useDesc"] = false,
									["width"] = 1,
								}, -- [9]
								{
									["type"] = "color",
									["default"] = {
										0.70980392156863, -- [1]
										0.70980392156863, -- [2]
										0.70980392156863, -- [3]
										1, -- [4]
									},
									["key"] = "unint_color2",
									["name"] = "Color 2",
									["useDesc"] = false,
									["width"] = 1,
								}, -- [10]
								{
									["type"] = "select",
									["default"] = 1,
									["values"] = {
										"Horizontal", -- [1]
										"Vertical", -- [2]
										"None", -- [3]
									},
									["name"] = "Gradient Direction",
									["useDesc"] = false,
									["key"] = "unint_gradient",
									["width"] = 1,
								}, -- [11]
								{
									["type"] = "space",
									["variableWidth"] = true,
									["height"] = 2,
									["useHeight"] = true,
									["width"] = 2,
								}, -- [12]
							},
							["hideReorder"] = true,
							["useDesc"] = false,
							["nameSource"] = 0,
							["width"] = 1,
							["useCollapse"] = true,
							["name"] = "Cast Bar",
							["collapse"] = true,
							["type"] = "group",
							["limitType"] = "none",
							["groupType"] = "simple",
							["key"] = "cast_bar",
							["size"] = 10,
						}, -- [2]
					},
					["hideReorder"] = true,
					["useDesc"] = false,
					["nameSource"] = 0,
					["name"] = "Resources",
					["width"] = 1,
					["useCollapse"] = false,
					["noMerge"] = false,
					["collapse"] = false,
					["type"] = "group",
					["limitType"] = "none",
					["groupType"] = "simple",
					["key"] = "resources",
					["size"] = 10,
				}, -- [11]
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Cast Bar Notice",
					["noMerge"] = false,
					["width"] = 1,
				}, -- [12]
				{
					["text"] = "This suite of WeakAuras contains a Casting Bar that will replace the default World of Warcraft casting bar. If you want to remove it, simply select the \"Cast Bar\" aura inside the Resources Group and check \"Never\" in the Load Tab. Once that's done, make sure to \"/reload\".\n\n",
					["type"] = "description",
					["fontSize"] = "medium",
					["width"] = 2,
				}, -- [13]
			},
			["color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
			},
			["regionType"] = "icon",
			["cooldown"] = false,
			["conditions"] = {
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
					["custom"] = "local local_env = aura_env\nlocal CLASS = local_env.id:gsub(\"General Options %- \", \"\")\nlocal_env.CLASS = CLASS\n\nLWA = LWA or {}\nLWA[CLASS] = LWA[CLASS] or {}\n\nlocal LWA = LWA[CLASS]\n\nLWA.config = nil\nLWA.configs = LWA.configs or {}\nLWA.configs[\"general\"] = local_env.config\n\nLWA.CLASS = CLASS\nLWA.MAX_WIDTH = 405\nLWA.RESOURCES_HEIGHT = 0\n\nlocal CLASS_GROUP = \"Luxthos - \" .. CLASS\nlocal CLASS_OPTIONS = \"Class Options - \" .. CLASS\nlocal CORE_GROUP = \"Core - \" .. CLASS\nlocal RESOURCES_GROUP = \"Resources - \" .. CLASS\nlocal DYNAMIC_EFFECTS_GROUP = \"Dynamic Effects - \" .. CLASS\nlocal DYNAMIC_SPELLS_GROUP = \"Dynamic Spells - \" .. CLASS\nlocal LEFT_SIDE_GROUP = \"Left Side - \" .. CLASS\nlocal RIGHT_SIDE_GROUP = \"Right Side - \" .. CLASS\nlocal MAINTENANCE_GROUP = \"Maintenance - \" .. CLASS\nlocal CAST_BAR = \"Cast Bar - \" .. CLASS\n\nlocal_env.parent = CLASS_GROUP\nlocal nbCore = 8\nlocal resources\n\nlocal function tclone(t1)\n    local t = {}\n    \n    if t1 then\n        for k, v in pairs(t1) do\n            if \"table\" == type(v) then\n                v = tclone(v)\n            end\n            \n            if \"string\" == type(k) then\n                t[k] = v\n            else\n                tinsert(t, v)\n            end\n        end\n    end\n    \n    return t\nend\n\nlocal function tmerge(...)\n    local ts = {...}\n    local t = tclone(ts[1])\n    local t2\n    \n    for i = 2, #ts do\n        t2 = ts[i] or {}\n        \n        for k, v in pairs(t2) do\n            if \"table\" == type(v) then\n                v = tclone(v)\n                \n                if t[k] and #t[k] == 0 then\n                    t[k] = tmerge(t[k], v)\n                else\n                    t[k] = v\n                end\n            else\n                t[k] = v\n            end\n        end\n    end\n    \n    return t\nend\n\nlocal function SetRegionSize(r, w, h)\n    r:SetRegionWidth(w)\n    r:SetRegionHeight(h)\nend\n\nlocal function ResizeAnchorFrame()\n    local config = LWA.GetConfig()\n    local h = 0\n    local cr = WeakAuras.GetRegion(CORE_GROUP)\n    \n    if cr and cr:IsVisible() then\n        h = cr:GetHeight()\n        \n        if config.primary.resources_position == 1 then -- Above\n            h = h + config.primary.spacing + LWA.RESOURCES_HEIGHT\n        end\n    end\n    \n    if 1 == h % 2 then\n        h = h + 1\n    end\n    \n    SetRegionSize(local_env.region, LWA.MAX_WIDTH, max(1, h, config.primary.height + config.primary.spacing + LWA.RESOURCES_HEIGHT))\n    \n    local g = WeakAuras.GetRegion(g)\n    \n    if g then\n        g:PositionChildren()\n        \n        if 0 == #g.sortedChildren then\n            g:SetHeight(configs[i].height)\n            g.currentHeight = configs[i].height\n        end\n    end\nend\n\nfunction LWA.GetConfig(grp, force)\n    local default = {\n        style = {\n            border_size = 0,\n            border_color = { [1] = 0, [2] = 0, [3] = 0, [4] = 1 },\n            apply_border = true,\n            zoom = 30,\n        },\n        primary = {\n            nb = 8,\n            width = 48,\n            height = 48,\n            spacing = 0,\n            resources_position = 2, -- Below\n        },\n        secondary = {\n            width = 38,\n            height = 38,\n            spacing = 0,\n        },\n        dynamic = {\n            width = 38,\n            height = 38,\n            spacing = 0,\n            margin = 10,\n        },\n        side = {\n            width = 36,\n            height = 36,\n            spacing = 0,\n            margin = 3,\n            grow_horizontal = 0,\n        },\n        maintenance = {\n            width = 36,\n            height = 36,\n            spacing = 0,\n            margin = 10,\n        },\n        ooc_alpha = {\n            alpha = 1,\n            ignore_enemy = true,\n            ignore_friendly = true,\n        },\n        resources = {\n            health_bar = {\n                format = 1\n            },\n            mana_bar = {\n                format = 1\n            }\n        },\n    }\n    \n    if force or not LWA.config or WeakAuras.IsOptionsOpen() then\n        LWA.config = tmerge(\n            default,\n            LWA.configs[\"general\"],\n            LWA.configs[\"class\"] or {}\n        )\n    end\n    \n    if grp then\n        return LWA.config[grp] or {}\n    end\n    \n    return LWA.config\nend\n\nlocal throttledInitHandler = nil\nlocal initLastRun = 0\n\nfunction LWA.ThrottledInit()\n    if throttledInitHandler then return end\n    \n    local currentTime = time()\n    \n    if WeakAuras.IsImporting() then\n        throttledInitHandler = C_Timer.NewTimer(2, LWA.ThrottledInit)\n        \n    elseif initLastRun <= currentTime - 0.2 then\n        throttledInitHandler = C_Timer.NewTimer(0.05, LWA.Init)\n    else\n        throttledInitHandler = C_Timer.NewTimer(max(0.05, currentTime - initLastRun), LWA.Init)\n    end\nend\n\nfunction LWA.Init()\n    if WeakAuras.IsImporting() then return end\n    \n    initLastRun = time()\n    \n    local config = LWA.GetConfig(nil, true)\n    local isOptionsOpen = WeakAuras.IsOptionsOpen()\n    local zoom = config.style.zoom / 100\n    \n    if throttledInitHandler then\n        throttledInitHandler:Cancel()\n        throttledInitHandler = nil\n    end\n    \n    if not local_env.parentFrame then\n        local_env.parentFrame = WeakAuras.GetRegion(CLASS_GROUP)\n    end\n    \n    if local_env.parentFrame and not local_env.parentFrame.SetRealScale then\n        local_env.parentFrame.SetRealScale = local_env.parentFrame.SetScale\n        \n        local_env.parentFrame.SetScale = function(self, scale)\n            local_env.parentFrame:SetRealScale(scale)\n            local castBar = WeakAuras.GetRegion(CAST_BAR)\n            \n            if castBar then\n                castBar:SetScale(scale)\n            end\n        end\n    end\n    \n    if isOptionsOpen then\n        nbCore = config.primary.nb\n    else\n        nbCore = max(4, min(nbCore, config.primary.nb))\n    end\n    \n    LWA.MAX_WIDTH = nbCore * (config.primary.width + config.primary.spacing) - config.primary.spacing\n    \n    local function InitIcons(group, c, selfPoint)\n        local grpRegion = WeakAuras.GetRegion(group)\n        \n        if not grpRegion then return end\n        \n        local i, isAbilities = 0, CORE_GROUP == group\n        \n        for childId, regions in pairs(grpRegion.controlledChildren) do\n            local region = regions[\"\"] and regions[\"\"].regionData.region\n            \n            i = i + 1\n            \n            if region then\n                region:SetAnchor(selfPoint, region.relativeTo, region.relativePoint)\n                \n                if region.SetZoom then\n                    region:SetZoom(min(1, zoom + (region.extraZoom or 0)))\n                else\n                    print(\"LWA Issue: \" .. CLASS .. \" > \" .. group .. \" > \" .. childId)\n                end\n                \n                if isAbilities and i > nbCore then\n                    SetRegionSize(region, config.secondary.width, config.secondary.height)\n                else\n                    SetRegionSize(region, c.width, c.height)\n                end\n                \n                LWA.UpdateBorder(region)\n            end\n        end\n        \n        if isAbilities then\n            grpRegion:PositionChildren()\n            \n            if not isOptionsOpen then\n                nbCore = max(4, min(#grpRegion.sortedChildren, config.primary.nb))\n                \n                LWA.MAX_WIDTH = nbCore * (config.primary.width + config.primary.spacing) - config.primary.spacing\n            end\n            \n            local_env.region:SetRegionWidth(LWA.MAX_WIDTH)\n        end\n    end\n    \n    InitIcons(CORE_GROUP, config.primary, \"TOP\")\n    InitIcons(LEFT_SIDE_GROUP, config.side, \"TOPRIGHT\")\n    InitIcons(RIGHT_SIDE_GROUP, config.side, \"TOPLEFT\")\n    InitIcons(MAINTENANCE_GROUP, config.maintenance, \"TOP\")\n    InitIcons(DYNAMIC_EFFECTS_GROUP, config.dynamic, \"BOTTOMLEFT\")\n    InitIcons(DYNAMIC_SPELLS_GROUP, config.dynamic, \"BOTTOMRIGHT\")\n    \n    LWA.UpdateResources()\n    \n    for i, g in ipairs({ DYNAMIC_EFFECTS_GROUP, DYNAMIC_SPELLS_GROUP, LEFT_SIDE_GROUP, RIGHT_SIDE_GROUP }) do\n        g = WeakAuras.GetRegion(g)\n        \n        if g then\n            g:PositionChildren()\n        end\n    end\nend\n\nhooksecurefunc(\"SetUIVisibility\", function(isVisible)\n        if isVisible and LWA.ThrottledInit then\n            LWA.ThrottledInit()\n        end\nend)\n\nfunction LWA.UpdateResources()\n    if WeakAuras.IsImporting() then return end\n    \n    local config = LWA.GetConfig()\n    \n    local totalHeight, nb = 0, 0\n    local h1 = config.primary.height\n    local s1 = config.primary.spacing\n    local y = 0\n    local grpRegion = WeakAuras.GetRegion(RESOURCES_GROUP)\n    \n    if not resources then\n        local grpData = WeakAuras.GetData(RESOURCES_GROUP)\n        \n        resources = grpData and grpData.controlledChildren\n    end\n    \n    if grpRegion and resources and #resources > 0 then\n        if config.primary.resources_position == 2 then -- Below\n            y = h1 + s1\n        end\n        \n        grpRegion:SetOffset(0, -y)\n        \n        local isOptionsOpen = WeakAuras.IsOptionsOpen()\n        \n        local resData, resRegion, isVisible, regionType\n        local w, h = 0, 0\n        \n        local function InitResource(region, index, nb)\n            if not region then return end\n            \n            index = max(1, index or 1)\n            nb = max(1, nb or 1)\n            \n            w, h = LWA.MAX_WIDTH, 20\n            \n            if nb > 1 then\n                local s = config.primary.spacing\n                \n                w = (w + s) / nb - s\n            end\n            \n            local cg = region.configGroup\n            \n            if cg and config.resources[cg] then\n                h = config.resources[cg].height or 20\n            end\n            \n            SetRegionSize(region, w, h)\n            region.bar:Update()\n            LWA.UpdateBorder(region, true)\n            LWA.UpdateBar({ region = region }, index, nb)\n            \n            if region.bar.spark then\n                region.bar.spark:SetHeight(max(15, Round(h * 2)))\n            end\n        end\n        \n        y = 0\n        \n        for _, resId in ipairs(resources) do\n            resRegion = WeakAuras.GetRegion(resId)\n            \n            if resRegion then\n                isVisible = isOptionsOpen or resRegion:IsVisible()\n                regionType = resRegion.regionType\n                h = 0\n                \n                if \"aurabar\" == regionType then\n                    InitResource(resRegion)\n                    \n                elseif \"dynamicgroup\" == regionType then\n                    local nbChild = 0\n                    local childRegions = {}\n                    \n                    for _, region in pairs(resRegion.controlledChildren) do\n                        if region and region[\"\"] then\n                            nbChild = nbChild + 1\n                            \n                            childRegions[region[\"\"].regionData.dataIndex] = region[\"\"].regionData.region\n                        end\n                    end\n                    \n                    if not isOptionsOpen and childRegions[1] then\n                        isVisible = childRegions[1]:IsVisible()\n                    end\n                    \n                    for i, region in ipairs(childRegions) do\n                        InitResource(region, i, nbChild)\n                        \n                        region:SetYOffset(-y)\n                    end\n                end\n                \n                if isVisible then\n                    nb = nb + 1\n                    \n                    if isVisible then\n                        if \"dynamicgroup\" == regionType then\n                            resRegion:PositionChildren()\n                        else\n                            resRegion:SetOffset(0, -y)\n                        end\n                    end\n                    \n                    totalHeight = totalHeight + h\n                    y = y + h + s1\n                end\n            end\n        end\n        \n        LWA.RESOURCES_HEIGHT = totalHeight + max(nb - 1, 0) * config.primary.spacing\n    end\n    \n    grpRegion = WeakAuras.GetRegion(CORE_GROUP)\n    \n    if grpRegion then\n        grpRegion:DoPositionChildren()\n    end\n    \n    ResizeAnchorFrame()\n    \n    local castBar = WeakAuras.GetRegion(CAST_BAR)\n    \n    if castBar then\n        castBar:SetParent(UIParent)\n        \n        if local_env.parentFrame then\n            castBar:SetScale(local_env.parentFrame:GetScale())\n        end\n    end\n    \n    grpRegion = WeakAuras.GetRegion(MAINTENANCE_GROUP)\n    \n    if grpRegion then\n        grpRegion:DoPositionChildren()\n    end\n    \n    C_Timer.After(0.1, ResizeAnchorFrame)\nend\n\nfunction LWA.GrowCore(newPositions, activeRegions)\n    local nb = #activeRegions\n    \n    if nb <= 0 then\n        C_Timer.After(0.125, ResizeAnchorFrame)\n        \n        return\n    end\n    \n    local config = LWA.GetConfig()\n    \n    local w1 = config.primary.width\n    local h1 = config.primary.height\n    local s1 = config.primary.spacing\n    \n    \n    local maxCore = min(nb, config.primary.nb)\n    local x, y\n    local xOffset = ((maxCore - 1) * (w1 + s1) / 2)\n    local yOffset = 0\n    \n    if not WeakAuras.IsOptionsOpen() then\n        nbCore = max(4, maxCore)\n        \n        LWA.MAX_WIDTH = nbCore * (w1 + s1) - s1\n        \n        ResizeAnchorFrame()\n    end\n    \n    if config.primary.resources_position == 1 then  -- Above\n        yOffset = LWA.RESOURCES_HEIGHT + s1\n    end\n    \n    for i, regionData in ipairs(activeRegions) do\n        x = (i - 1) * (w1 + s1) - xOffset\n        y = -yOffset\n        \n        SetRegionSize(regionData.region, w1, h1)\n        \n        newPositions[i] = { x, y }\n        \n        if i == maxCore then break end\n    end\n    \n    local maxSecondary = nb - maxCore\n    \n    if maxSecondary > 0 then\n        local w2 = config.secondary.width\n        local h2 = config.secondary.height\n        local s2 = config.secondary.spacing\n        \n        local nbPerRow = math.floor((LWA.MAX_WIDTH + s2) / (w2 + s2)) or 1\n        local yOffset = yOffset + h1 - h2 + max(s1, s2) - s2\n        local i2, m\n        \n        if config.primary.resources_position == 2 then -- Below\n            yOffset = yOffset + LWA.RESOURCES_HEIGHT + s1\n        end\n        \n        for i, regionData in ipairs(activeRegions) do\n            if i > maxCore then\n                i2 = i - maxCore\n                m = (i2 % nbPerRow)\n                \n                if m == 1 then\n                    xOffset = (min(maxSecondary - i + maxCore, nbPerRow - 1)) * (w2 + s2) / 2\n                    yOffset = yOffset + h2 + s2\n                end\n                \n                if m == 0 then\n                    m = nbPerRow\n                end\n                \n                x = (m - 1) * (w2 + s2) - xOffset\n                y = -yOffset\n                \n                SetRegionSize(regionData.region, w2, h2)\n                \n                newPositions[i] = { x, y }\n            end\n        end\n    end\n    \n    C_Timer.After(0.125, ResizeAnchorFrame)\nend\n\nfunction LWA.GrowDynamicEffects(newPositions, activeRegions)\n    local nb = #activeRegions\n    \n    if nb <= 0 then return end\n    \n    local config = LWA.GetConfig()\n    \n    local w = config.dynamic.width\n    local h = config.dynamic.height\n    local s1 = config.primary.spacing\n    local s2 = config.dynamic.spacing\n    \n    local xOffset = 0\n    local yOffset = config.dynamic.margin + max(s1, s2) - s2 - h\n    local nbPerRow, m = math.floor(((LWA.MAX_WIDTH / 2) + s2) / (w + s2)) or 1\n    \n    for i, regionData in ipairs(activeRegions) do\n        m = (i % nbPerRow)\n        \n        if m == 1 then\n            xOffset = 0\n            yOffset = yOffset + h + s2\n        end\n        \n        if m == 0 then\n            m = nbPerRow\n        end\n        \n        newPositions[i] = { xOffset, yOffset }\n        \n        xOffset = xOffset + w + s2\n    end\nend\n\nfunction LWA.GrowDynamicSpells(newPositions, activeRegions)\n    local nb = #activeRegions\n    \n    if nb <= 0 then return end\n    \n    local config = LWA.GetConfig()\n    \n    local w = config.dynamic.width\n    local h = config.dynamic.height\n    local s1 = config.primary.spacing\n    local s2 = config.dynamic.spacing\n    \n    local xOffset = 0\n    local yOffset = config.dynamic.margin + max(s1, s2) - s2 - h\n    local nbPerRow, m = math.floor(((LWA.MAX_WIDTH / 2) + s2) / (w + s2)) or 1\n    \n    for i, regionData in ipairs(activeRegions) do\n        m = (i % nbPerRow)\n        \n        if m == 1 then\n            xOffset = 0\n            yOffset = yOffset + h + s2\n        end\n        \n        if m == 0 then\n            m = nbPerRow\n        end\n        \n        newPositions[i] = { -xOffset, yOffset }\n        \n        xOffset = xOffset + w + s2\n    end\nend\n\nfunction LWA.GrowLeftSide(newPositions, activeRegions)\n    local nb = #activeRegions\n    \n    if nb <= 0 then return end\n    \n    local config = LWA.GetConfig()\n    \n    local w1 = config.primary.width\n    local h1 = config.primary.height\n    local s1 = config.primary.spacing\n    \n    local w2 = config.side.width\n    local h2 = config.side.height\n    local s2 = config.side.spacing\n    \n    local x, y\n    local xOffset = config.side.margin + max(s1, s2)\n    local yOffset = 0\n    \n    for i, regionData in ipairs(activeRegions) do\n        x = -xOffset\n        y = -yOffset\n        \n        newPositions[i] = { x, y }\n        \n        if config.side.grow_horizontal then\n            xOffset = xOffset + w2 + s2\n        else\n            yOffset = yOffset + h2 + s2\n        end\n    end\nend\n\nfunction LWA.GrowRightSide(newPositions, activeRegions)\n    local nb = #activeRegions\n    \n    if nb <= 0 then return end\n    \n    local config = LWA.GetConfig()\n    \n    local w1 = config.primary.width\n    local h1 = config.primary.height\n    local s1 = config.primary.spacing\n    \n    local w2 = config.side.width\n    local h2 = config.side.height\n    local s2 = config.side.spacing\n    \n    local x, y\n    local xOffset = config.side.margin + max(s1, s2)\n    local yOffset = 0\n    \n    for i, regionData in ipairs(activeRegions) do\n        x = xOffset\n        y = -yOffset\n        \n        newPositions[i] = { x, y }\n        \n        if config.side.grow_horizontal then\n            xOffset = xOffset + w2 + s2\n        else\n            yOffset = yOffset + h2 + s2\n        end\n    end\nend\n\nfunction LWA.GrowMaintenance(newPositions, activeRegions)\n    local nb = #activeRegions\n    \n    if nb <= 0 then return end\n    \n    local config = LWA.GetConfig()\n    \n    local maxCore = min(nb, config.primary.nb)\n    \n    local w1 = config.primary.width\n    local h1 = config.primary.height\n    local s1 = config.primary.spacing\n    \n    local w2 = config.maintenance.width\n    local h2 = config.maintenance.height\n    local s2 = config.maintenance.spacing\n    \n    local x, y\n    local xOffset = (maxCore - 1) * (w1 + s1) / 2\n    local yOffset = config.maintenance.margin + max(s1, s2) - s2 - h2\n    \n    local nbPerRow = math.floor((LWA.MAX_WIDTH + s2) / (w2 + s2)) or 1\n    local m\n    \n    for i, regionData in ipairs(activeRegions) do\n        m = (i % nbPerRow)\n        \n        if m == 1 then\n            xOffset = (min(nb - i, nbPerRow - 1)) * (w2 + s2) / 2\n            yOffset = yOffset + h2 + s2\n        end\n        \n        if m == 0 then\n            m = nbPerRow\n        end\n        \n        x = (m - 1) * (w2 + s2) - xOffset\n        y = -yOffset\n        \n        newPositions[i] = { x, y }\n    end\nend\n\nfunction LWA.UpdateBorder(region, isBar)\n    if #region.subRegions > 0 then\n        local config, size, r, g, b, a = LWA.GetConfig(), 0\n        \n        if not isBar or (isBar and config.style.apply_border) then\n            size = config.style.border_size\n            r, g, b, a = unpack(config.style.border_color)\n        end\n        \n        for _, border in ipairs(region.subRegions) do\n            if \"subborder\" == border.type then\n                border:SetVisible(size > 0)\n                \n                if size > 0 then\n                    local bd = border:GetBackdrop()\n                    bd.edgeSize = size\n                    border:SetBackdrop(bd)\n                    border:SetBorderColor(r, g, b, a)\n                end\n            end\n        end\n    end\nend\n\nlocal function MixRGB(c1, c2, pos)\n    pos = 1 - (pos or 0.5)\n    \n    return {\n        (c1[1] * pos) + (c2[1] * (1 - pos)),\n        (c1[2] * pos) + (c2[2] * (1 - pos)),\n        (c1[3] * pos) + (c2[3] * (1 - pos)),\n        (c1[4] * pos) + (c2[4] * (1 - pos))\n    }\nend\n\nfunction LWA.UpdateBar(aura, i, nb)\n    local config = LWA.GetConfig(\"resources\")\n    local e = aura or aura_env\n    local region = e.region\n    local cg = region.configGroup\n    \n    if not (region and cg and config[cg]) then return end\n    \n    cg = config[cg]\n    \n    local cs = region.colorState or \"\"\n    \n    if cs ~= \"\" then\n        cs = cs .. \"_\"\n    end\n    \n    i = (i or region.index or 1) - (region.colorOffset or 0)\n    nb = min(region.colorMax or 99, nb or 1)\n    \n    local c1, c2 = cg[cs .. \"color1\"], cg[cs .. \"color2\"]\n    local bar = region.bar\n    \n    if c1 and c2 then\n        if cg[cs .. \"gradient\"] and cg[cs .. \"gradient\"] < 3 then\n            if nb > 1 and 1 == cg[cs .. \"gradient\"] then\n                local cc1, cc2 = c1, c2\n                \n                if i > 1 then\n                    c1 = MixRGB(cc1, cc2, (i - 1) / nb)\n                end\n                \n                c2 = MixRGB(cc1, cc2, i / nb)\n            end\n            \n            local orientation = \"HORIZONTAL\"\n            \n            if 2 == cg[cs .. \"gradient\"] then\n                orientation = \"VERTICAL\"\n                \n                local tmp = c1\n                c1 = c2\n                c2 = tmp\n            end\n            \n            bar.fg:SetGradient(orientation, CreateColor(unpack(c1)), CreateColor(unpack(c2)))\n        else\n            bar:SetForegroundColor(unpack(c1))\n        end\n        \n        if region.ot then\n            region.ot:SetColorTexture(unpack(c2))\n        end\n    end\nend\n\nfunction LWA.GrowDynamicResource(newPositions, activeRegions)\n    local nb = #activeRegions\n    \n    if nb <= 0 then return end\n    \n    local config = LWA.GetConfig()\n    \n    local s = config.primary.spacing\n    \n    local w, h = (LWA.MAX_WIDTH + s) / nb\n    local x, xOffset = 0, (LWA.MAX_WIDTH - w + s) / 2\n    \n    for i, regionData in ipairs(activeRegions) do\n        x = (i - 1) * w - xOffset\n        \n        regionData.region:SetRegionWidth(w - s)\n        LWA.UpdateBar({ region = regionData.region }, i, nb)\n        regionData.region.bar:Update()\n        \n        newPositions[i] = { x, 0 }\n    end\nend\n\nlocal function round(num, decimals)\n    local mult = 10^(decimals or 0)\n    \n    return Round(num * mult) / mult\nend\n\nlocal barFormats = {\n    \"value\",\n    \"kvalue\",\n    \"value (percent%)\",\n    \"kvalue (percent%)\",\n    \"percent%\",\n}\n\nfunction LWA.UpdateBarText(value, percent, format)\n    local text = barFormats[format] or \"value\"\n    \n    text = text:gsub(\"percent\", round(percent, 0))\n    \n    if 2 == format or 4 == format then\n        local rem = math.fmod(value, 1000) or 0\n        \n        if rem >= 950 then\n            rem = 0\n        end\n        \n        text = text:gsub(\"kvalue\", FormatLargeNumber(Round((value - rem) / 1000)) .. \".\" .. Round(rem / 100) .. \"K\"):gsub(\"%.0K\", \"K\"):gsub(\"%.\", DECIMAL_SEPERATOR)\n    else\n        text = text:gsub(\"value\", value)\n    end\n    \n    return text\nend",
					["do_custom"] = true,
				},
			},
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 0,
			["zoom"] = 0,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "General Options - Rogue",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 405,
			["cooldownTextDisabled"] = false,
			["config"] = {
				["maintenance"] = {
					["height"] = 36,
					["spacing"] = 3,
					["margin"] = 10,
					["width"] = 36,
				},
				["style"] = {
					["apply_border"] = true,
					["border_size"] = 0,
					["zoom"] = 30,
					["border_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
				},
				["side"] = {
					["grow_horizontal"] = false,
					["spacing"] = 3,
					["height"] = 36,
					["margin"] = 3,
					["width"] = 36,
				},
				["dynamic"] = {
					["height"] = 34,
					["spacing"] = 3,
					["margin"] = 10,
					["width"] = 34,
				},
				["resources"] = {
					["cast_bar"] = {
						["color2"] = {
							0.77647058823529, -- [1]
							0.1843137254902, -- [2]
							0.1843137254902, -- [3]
							1, -- [4]
						},
						["unint_gradient"] = 1,
						["unint_color2"] = {
							0.70980392156863, -- [1]
							0.70980392156863, -- [2]
							0.70980392156863, -- [3]
							1, -- [4]
						},
						["height"] = 20,
						["gradient"] = 1,
						["unint_color1"] = {
							0.52549019607843, -- [1]
							0.52549019607843, -- [2]
							0.52549019607843, -- [3]
							0.90000000596046, -- [4]
						},
						["color1"] = {
							0.52941176470588, -- [1]
							0.090196078431373, -- [2]
							0.090196078431373, -- [3]
							1, -- [4]
						},
					},
					["health_bar"] = {
						["color2"] = {
							0.5843137254902, -- [1]
							0.90588235294118, -- [2]
							0.52156862745098, -- [3]
							1, -- [4]
						},
						["height"] = 20,
						["format"] = 1,
						["gradient"] = 1,
						["color1"] = {
							0.34509803921569, -- [1]
							0.64313725490196, -- [2]
							0.28235294117647, -- [3]
							1, -- [4]
						},
					},
				},
				["primary"] = {
					["spacing"] = 3,
					["height"] = 48,
					["resources_position"] = 2,
					["nb"] = 8,
					["width"] = 48,
				},
				["ooc_alpha"] = {
					["ignore_enemy"] = true,
					["alpha"] = 1,
					["ignore_friendly"] = true,
				},
				["secondary"] = {
					["height"] = 32,
					["width"] = 32,
					["spacing"] = 3,
				},
			},
			["inverse"] = false,
			["parent"] = "Luxthos - Rogue",
			["displayIcon"] = 134520,
			["information"] = {
				["forceEvents"] = true,
			},
			["desc"] = "Made by Luxthos - twitch.tv/luxthos",
		},
		["Dynamic Effects - Rogue"] = {
			["arcLength"] = 360,
			["controlledChildren"] = {
				"Remorseless Attacks", -- [1]
				"Master of Subtlety", -- [2]
				"Hunger For Blood", -- [3]
				"Overkill", -- [4]
				"Cheat Death", -- [5]
				"Clearcasting - Rogue", -- [6]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["wagoID"] = "foIUC5_yM",
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["sortHybridTable"] = {
				["Remorseless Attacks"] = false,
				["Cheat Death"] = false,
				["Master of Subtlety"] = false,
				["Hunger For Blood"] = false,
				["Overkill"] = false,
				["Clearcasting - Rogue"] = false,
			},
			["anchorPoint"] = "TOPLEFT",
			["grow"] = "CUSTOM",
			["fullCircle"] = true,
			["space"] = 2,
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["names"] = {
						},
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["unit"] = "player",
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 1,
			["radius"] = 200,
			["xOffset"] = -6.103515625e-05,
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["align"] = "CENTER",
			["growOn"] = "changed",
			["source"] = "import",
			["desc"] = "Made by Luxthos - twitch.tv/luxthos",
			["rotation"] = 0,
			["gridType"] = "RD",
			["version"] = 25,
			["subRegions"] = {
			},
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["rowSpace"] = 1,
			["load"] = {
				["size"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
			},
			["internalVersion"] = 70,
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["parent"] = "Luxthos - Rogue",
			["animate"] = false,
			["customGrow"] = "function(newPositions, activeRegions)\n    local LWA = LWA and LWA[\"Rogue\"] or {}\n\n    if LWA and LWA.GrowDynamicEffects then\n        LWA.GrowDynamicEffects(newPositions, activeRegions)\n    end\nend",
			["scale"] = 1,
			["centerType"] = "LR",
			["border"] = false,
			["anchorFrameFrame"] = "WeakAuras:General Options - Rogue",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 2,
			["sort"] = "none",
			["useLimit"] = false,
			["stagger"] = 0,
			["anchorFrameParent"] = false,
			["constantFactor"] = "RADIUS",
			["gridWidth"] = 5,
			["borderOffset"] = 4,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Dynamic Effects - Rogue",
			["borderEdge"] = "Square Full White",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["stepAngle"] = 15,
			["uid"] = "TH6gBc2dY9i",
			["limit"] = 5,
			["selfPoint"] = "BOTTOMLEFT",
			["config"] = {
			},
			["conditions"] = {
			},
			["information"] = {
				["forceEvents"] = true,
			},
			["borderInset"] = 1,
		},
		["Rupture"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["parent"] = "Core - Rogue",
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["showClones"] = false,
						["type"] = "aura2",
						["useName"] = true,
						["useExactSpellId"] = false,
						["subeventSuffix"] = "_CAST_START",
						["ownOnly"] = true,
						["event"] = "Health",
						["unit"] = "target",
						["unitExists"] = true,
						["names"] = {
						},
						["spellIds"] = {
						},
						["auraspellids"] = {
							"146739", -- [1]
						},
						["subeventPrefix"] = "SPELL",
						["auranames"] = {
							"1943", -- [1]
						},
						["matchesShowOn"] = "showAlways",
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["customTriggerLogic"] = "",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["zoneIds"] = "",
				["use_class"] = true,
				["race"] = {
				},
				["use_spellknown"] = true,
				["use_spec"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["role"] = {
					["single"] = "DAMAGER",
					["multi"] = {
						["DAMAGER"] = true,
					},
				},
				["spellknown"] = 1943,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["config"] = {
			},
			["zoom"] = 0.3,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["regionType"] = "icon",
			["cooldownEdge"] = false,
			["cooldown"] = true,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["auto"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Rupture",
			["alpha"] = 1,
			["useCooldownModRate"] = true,
			["anchorFrameType"] = "SCREEN",
			["frameStrata"] = 1,
			["uid"] = "1tvZOU7w8Y7",
			["inverse"] = false,
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = -2,
						["variable"] = "AND",
						["checks"] = {
							{
								["trigger"] = -1,
								["variable"] = "incombat",
								["value"] = 1,
							}, -- [1]
							{
								["trigger"] = 1,
								["variable"] = "buffed",
								["value"] = 0,
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = false,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "buttonOverlay",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "buffed",
						["value"] = 0,
						["checks"] = {
							{
								["trigger"] = 1,
								["variable"] = "show",
								["value"] = 0,
							}, -- [1]
							{
								["value"] = "0",
								["op"] = "==",
								["variable"] = "matchCount",
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
						{
							["value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								0.5, -- [4]
							},
							["property"] = "color",
						}, -- [2]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "buffed",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "Pixel",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [3]
			},
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["xOffset"] = 0,
		},
		["Nameplate range check 8 "] = {
			["iconSource"] = 0,
			["displayText_format_1.minRange_realm_name"] = "never",
			["xOffset"] = 0,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["yOffset"] = 0,
			["anchorPoint"] = "RIGHT",
			["displayText_format_p_time_format"] = 0,
			["url"] = "https://wago.io/YP6nljWXe/7",
			["icon"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "LEFT",
			["displayText_format_destUnit_color"] = "class",
			["desc"] = "Checks nearest 20 nameplates and shows a starfall icon if they are in range of starfall (36 yrds). \n\nHelps you make any decisions about using starfall and to stop any ninja pulls. \n\nIf you want more nameplates you can simply duplicate one of the weak auras in the group and add a number to the trigger. \n\nIf anyone finds an easier way to make this kind of a weak aura let me know as this was made editing a pre existing weak aura with a similar function.",
			["font"] = "PT Sans Narrow",
			["load"] = {
				["use_never"] = false,
				["class"] = {
					["single"] = "DRUID",
					["multi"] = {
						["DRUID"] = true,
					},
				},
				["use_encounterid"] = false,
				["use_class"] = true,
				["use_itemequiped"] = false,
				["zoneIds"] = "",
				["use_not_item_bonusid_equipped"] = false,
				["talent2"] = {
					["multi"] = {
						[20] = false,
					},
				},
				["use_zoneIds"] = false,
				["item_bonusid_equipped"] = "62080",
				["spec"] = {
					["multi"] = {
					},
				},
				["not_item_bonusid_equipped"] = "62080",
				["use_talent"] = false,
				["use_spellknown"] = false,
				["talent"] = {
					["multi"] = {
						[24] = true,
					},
				},
				["itemequiped"] = {
					62080, -- [1]
				},
				["size"] = {
					["multi"] = {
					},
				},
				["use_exact_spellknown"] = false,
				["use_item_bonusid_equipped"] = false,
				["itemtypeequipped"] = {
				},
			},
			["displayText_format_1.maxRange_format"] = "none",
			["shadowXOffset"] = 1,
			["displayText_format_1.minRange_abbreviate"] = false,
			["regionType"] = "icon",
			["displayText_format_destUnit_abbreviate_max"] = 8,
			["zoom"] = 0,
			["displayText_format_destUnit_format"] = "Unit",
			["tocversion"] = 30401,
			["alpha"] = 1,
			["config"] = {
			},
			["fixedWidth"] = 200,
			["outline"] = "OUTLINE",
			["wagoID"] = "YP6nljWXe",
			["parent"] = "Starfall Range Check on Nameplate",
			["shadowYOffset"] = -1,
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "event",
			["automaticWidth"] = "Auto",
			["triggers"] = {
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "35",
						["unit"] = "nameplate8",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [1]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "20",
						["unit"] = "nameplate8",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = false,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [6]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "15",
						["unit"] = "nameplate8",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [7]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate8",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [8]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [9]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [10]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate8",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [11]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    if trigger[1] and trigger[3] and trigger[5] then\n        return true\n    elseif trigger[2] and trigger[4] and trigger[5] then\n        return true\n    elseif trigger[3] and trigger[8] and trigger[6] then\n        return true\n    elseif trigger[4] and trigger[7] and trigger[6] then\n        return true\n    elseif trigger[4] and (trigger[9] and trigger[10]) and trigger[7] then\n        return true\n    elseif trigger[3] and (trigger[9] and trigger[10]) and trigger[11] then\n        return true\n    end\nend",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["version"] = 7,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%maxRange",
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = false,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_text_format_p_time_mod_rate"] = true,
					["anchorXOffset"] = 0,
					["text_text_format_minRange_format"] = "none",
					["type"] = "subtext",
					["text_text_format_maxRange_format"] = "none",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_text_format_p_time_format"] = 0,
					["text_shadowYOffset"] = 0,
					["text_fontType"] = "OUTLINE",
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "CENTER",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["anchorYOffset"] = 0,
					["text_fontSize"] = 12,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_text_format_p_time_precision"] = 1,
				}, -- [2]
			},
			["height"] = 25,
			["displayText_format_destUnit_realm_name"] = "never",
			["preferToUpdate"] = false,
			["information"] = {
				["forceEvents"] = true,
			},
			["displayText_format_1.minRange_color"] = true,
			["source"] = "import",
			["conditions"] = {
			},
			["displayIcon"] = 236168,
			["cooldownTextDisabled"] = false,
			["displayText_format_1.minRange_round_type"] = "ceil",
			["authorOptions"] = {
			},
			["desaturate"] = false,
			["wordWrap"] = "WordWrap",
			["anchorFrameType"] = "NAMEPLATE",
			["useCooldownModRate"] = true,
			["displayText_format_destUnit_abbreviate"] = false,
			["displayText_format_1.minRange_format"] = "Number",
			["displayText_format_p_time_precision"] = 1,
			["color"] = {
				0.97647058823529, -- [1]
				1, -- [2]
				0.97647058823529, -- [3]
				1, -- [4]
			},
			["justify"] = "LEFT",
			["uid"] = "oS)g(RvQw2p",
			["semver"] = "1.0.6",
			["displayText"] = "%1.maxRange",
			["id"] = "Nameplate range check 8 ",
			["anchorFrameParent"] = false,
			["frameStrata"] = 1,
			["width"] = 25,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["fontSize"] = 16,
			["inverse"] = false,
			["displayText_format_1.minRange_abbreviate_max"] = 8,
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["displayText_format_1.minRange_decimal_precision"] = 0,
			["cooldown"] = false,
			["cooldownEdge"] = false,
		},
		["Nameplate range check 15 "] = {
			["iconSource"] = 0,
			["displayText_format_1.minRange_realm_name"] = "never",
			["xOffset"] = 0,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["yOffset"] = 0,
			["anchorPoint"] = "RIGHT",
			["displayText_format_p_time_format"] = 0,
			["url"] = "https://wago.io/YP6nljWXe/7",
			["icon"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "LEFT",
			["displayText_format_destUnit_color"] = "class",
			["desc"] = "Checks nearest 20 nameplates and shows a starfall icon if they are in range of starfall (36 yrds). \n\nHelps you make any decisions about using starfall and to stop any ninja pulls. \n\nIf you want more nameplates you can simply duplicate one of the weak auras in the group and add a number to the trigger. \n\nIf anyone finds an easier way to make this kind of a weak aura let me know as this was made editing a pre existing weak aura with a similar function.",
			["font"] = "PT Sans Narrow",
			["load"] = {
				["use_never"] = false,
				["class"] = {
					["single"] = "DRUID",
					["multi"] = {
						["DRUID"] = true,
					},
				},
				["use_encounterid"] = false,
				["use_class"] = true,
				["use_itemequiped"] = false,
				["zoneIds"] = "",
				["use_not_item_bonusid_equipped"] = false,
				["talent2"] = {
					["multi"] = {
						[20] = false,
					},
				},
				["use_zoneIds"] = false,
				["item_bonusid_equipped"] = "62080",
				["spec"] = {
					["multi"] = {
					},
				},
				["not_item_bonusid_equipped"] = "62080",
				["use_talent"] = false,
				["use_spellknown"] = false,
				["talent"] = {
					["multi"] = {
						[24] = true,
					},
				},
				["itemequiped"] = {
					62080, -- [1]
				},
				["size"] = {
					["multi"] = {
					},
				},
				["use_exact_spellknown"] = false,
				["use_item_bonusid_equipped"] = false,
				["itemtypeequipped"] = {
				},
			},
			["displayText_format_1.maxRange_format"] = "none",
			["shadowXOffset"] = 1,
			["displayText_format_1.minRange_abbreviate"] = false,
			["regionType"] = "icon",
			["displayText_format_destUnit_abbreviate_max"] = 8,
			["zoom"] = 0,
			["displayText_format_destUnit_format"] = "Unit",
			["tocversion"] = 30401,
			["alpha"] = 1,
			["config"] = {
			},
			["fixedWidth"] = 200,
			["outline"] = "OUTLINE",
			["wagoID"] = "YP6nljWXe",
			["parent"] = "Starfall Range Check on Nameplate",
			["shadowYOffset"] = -1,
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "event",
			["automaticWidth"] = "Auto",
			["triggers"] = {
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "35",
						["unit"] = "nameplate15",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [1]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "20",
						["unit"] = "nameplate15",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = false,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [6]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "15",
						["unit"] = "nameplate15",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [7]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate15",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [8]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [9]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [10]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate15",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [11]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    if trigger[1] and trigger[3] and trigger[5] then\n        return true\n    elseif trigger[2] and trigger[4] and trigger[5] then\n        return true\n    elseif trigger[3] and trigger[8] and trigger[6] then\n        return true\n    elseif trigger[4] and trigger[7] and trigger[6] then\n        return true\n    elseif trigger[4] and (trigger[9] and trigger[10]) and trigger[7] then\n        return true\n    elseif trigger[3] and (trigger[9] and trigger[10]) and trigger[11] then\n        return true\n    end\nend",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["version"] = 7,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%maxRange",
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = false,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_text_format_p_time_mod_rate"] = true,
					["anchorXOffset"] = 0,
					["text_text_format_minRange_format"] = "none",
					["type"] = "subtext",
					["text_text_format_maxRange_format"] = "none",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_text_format_p_time_format"] = 0,
					["text_shadowYOffset"] = 0,
					["text_fontType"] = "OUTLINE",
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "CENTER",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["anchorYOffset"] = 0,
					["text_fontSize"] = 12,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_text_format_p_time_precision"] = 1,
				}, -- [2]
			},
			["height"] = 25,
			["displayText_format_destUnit_realm_name"] = "never",
			["preferToUpdate"] = false,
			["information"] = {
				["forceEvents"] = true,
			},
			["displayText_format_1.minRange_color"] = true,
			["source"] = "import",
			["conditions"] = {
			},
			["displayIcon"] = 236168,
			["cooldownTextDisabled"] = false,
			["displayText_format_1.minRange_round_type"] = "ceil",
			["authorOptions"] = {
			},
			["desaturate"] = false,
			["wordWrap"] = "WordWrap",
			["anchorFrameType"] = "NAMEPLATE",
			["useCooldownModRate"] = true,
			["displayText_format_destUnit_abbreviate"] = false,
			["displayText_format_1.minRange_format"] = "Number",
			["displayText_format_p_time_precision"] = 1,
			["color"] = {
				0.97647058823529, -- [1]
				1, -- [2]
				0.97647058823529, -- [3]
				1, -- [4]
			},
			["justify"] = "LEFT",
			["uid"] = "z5ARcV26Z7t",
			["semver"] = "1.0.6",
			["displayText"] = "%1.maxRange",
			["id"] = "Nameplate range check 15 ",
			["anchorFrameParent"] = false,
			["frameStrata"] = 1,
			["width"] = 25,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["fontSize"] = 16,
			["inverse"] = false,
			["displayText_format_1.minRange_abbreviate_max"] = 8,
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["displayText_format_1.minRange_decimal_precision"] = 0,
			["cooldown"] = false,
			["cooldownEdge"] = false,
		},
		["Poison - Main Hand"] = {
			["iconSource"] = 6,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["enchant"] = "",
						["itemName"] = 6265,
						["use_count"] = false,
						["auranames"] = {
							"465", -- [1]
							"7294", -- [2]
							"19746", -- [3]
							"19876", -- [4]
							"19888", -- [5]
							"19891", -- [6]
							"32223", -- [7]
						},
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["names"] = {
						},
						["unitExists"] = true,
						["use_weapon"] = true,
						["use_unit"] = true,
						["use_enchant"] = false,
						["matchesShowOn"] = "showAlways",
						["debuffType"] = "HELPFUL",
						["spellName"] = 0,
						["subeventPrefix"] = "SPELL",
						["type"] = "item",
						["unevent"] = "auto",
						["subeventSuffix"] = "_CAST_START",
						["use_showOn"] = true,
						["event"] = "Weapon Enchant",
						["use_itemName"] = true,
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["useName"] = true,
						["showOn"] = "showOnActive",
						["duration"] = "1",
						["use_track"] = true,
						["weapon"] = "main",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["enchant"] = "",
						["auranames"] = {
							"465", -- [1]
							"7294", -- [2]
							"19746", -- [3]
							"19876", -- [4]
							"19888", -- [5]
							"19891", -- [6]
							"32223", -- [7]
						},
						["duration"] = "1",
						["remaining"] = "300",
						["use_weapon"] = true,
						["spellName"] = 0,
						["subeventSuffix"] = "_CAST_START",
						["use_showOn"] = true,
						["use_itemName"] = true,
						["use_track"] = true,
						["itemName"] = 6265,
						["use_count"] = false,
						["genericShowOn"] = "showOnCooldown",
						["subeventPrefix"] = "SPELL",
						["unitExists"] = true,
						["use_unit"] = true,
						["debuffType"] = "HELPFUL",
						["use_enchant"] = false,
						["use_remaining"] = true,
						["matchesShowOn"] = "showAlways",
						["unevent"] = "auto",
						["names"] = {
						},
						["type"] = "item",
						["remaining_operator"] = "<=",
						["useName"] = true,
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["unit"] = "player",
						["showOn"] = "showOnActive",
						["use_genericShowOn"] = true,
						["event"] = "Weapon Enchant",
						["weapon"] = "main",
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["enchant"] = "",
						["itemName"] = 6265,
						["use_count"] = false,
						["auranames"] = {
							"465", -- [1]
							"7294", -- [2]
							"19746", -- [3]
							"19876", -- [4]
							"19888", -- [5]
							"19891", -- [6]
							"32223", -- [7]
						},
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["names"] = {
						},
						["unitExists"] = true,
						["use_weapon"] = true,
						["use_unit"] = true,
						["use_enchant"] = false,
						["matchesShowOn"] = "showAlways",
						["debuffType"] = "HELPFUL",
						["spellName"] = 0,
						["subeventPrefix"] = "SPELL",
						["type"] = "item",
						["unevent"] = "auto",
						["subeventSuffix"] = "_CAST_START",
						["use_showOn"] = true,
						["event"] = "Weapon Enchant",
						["use_itemName"] = true,
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["useName"] = true,
						["showOn"] = "showOnMissing",
						["duration"] = "1",
						["use_track"] = true,
						["weapon"] = "main",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["use_resting"] = true,
						["use_incombat"] = false,
						["debuffType"] = "HELPFUL",
						["type"] = "unit",
						["unit"] = "player",
						["event"] = "Conditions",
						["use_unit"] = true,
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["type"] = "custom",
						["custom"] = "function()\n    if LWA and LWA.Init then\n        LWA.Init()\n    end\nend",
						["custom_type"] = "event",
						["debuffType"] = "HELPFUL",
						["events"] = "OPTIONS",
						["unit"] = "player",
						["custom_hide"] = "custom",
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["itemName"] = 0,
						["use_genericShowOn"] = true,
						["use_itemName"] = true,
						["unit"] = "player",
						["use_itemSlot"] = true,
						["itemSlot"] = 16,
						["event"] = "Cooldown Progress (Equipment Slot)",
						["type"] = "item",
						["genericShowOn"] = "showAlways",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [6]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(t)\n    if t[4] then -- If in Rested Area\n        return false\n    end\n    \n    local behavior = aura_env.config.maintenance.poison.behavior\n    \n    if behavior == 1 then -- Show if Applied\n        return t[1]\n    elseif behavior == 2 then -- Show if Missing\n        return t[2] or t[3]\n    else -- Always Show\n        return true\n    end\nend",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_level"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["use_class"] = true,
				["use_spellknown"] = false,
				["itemtypeequipped"] = {
					["multi"] = {
						[516] = true,
						[525] = true,
						[513] = true,
						[522] = true,
						[517] = true,
						[512] = true,
						[527] = true,
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["level"] = {
					"20", -- [1]
				},
				["level_operator"] = {
					">=", -- [1]
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "tqFPI2(gthS",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
				{
					["subOptions"] = {
						{
							["useName"] = true,
							["type"] = "header",
							["text"] = "Behavior",
							["noMerge"] = false,
							["width"] = 1,
						}, -- [1]
						{
							["subOptions"] = {
								{
									["text"] = "Poison",
									["type"] = "description",
									["fontSize"] = "large",
									["width"] = 1,
								}, -- [1]
								{
									["type"] = "select",
									["default"] = 2,
									["values"] = {
										"Show if Applied", -- [1]
										"Show if Missing", -- [2]
										"Always Show", -- [3]
									},
									["name"] = "Behavior",
									["useDesc"] = false,
									["key"] = "behavior",
									["width"] = 1,
								}, -- [2]
							},
							["hideReorder"] = true,
							["useDesc"] = false,
							["nameSource"] = 0,
							["name"] = "Poison",
							["width"] = 1,
							["useCollapse"] = false,
							["noMerge"] = false,
							["collapse"] = false,
							["type"] = "group",
							["limitType"] = "none",
							["groupType"] = "simple",
							["key"] = "poison",
							["size"] = 10,
						}, -- [2]
					},
					["hideReorder"] = true,
					["useDesc"] = false,
					["nameSource"] = 0,
					["name"] = "Maintenance Icons",
					["width"] = 1,
					["useCollapse"] = true,
					["noMerge"] = false,
					["collapse"] = true,
					["type"] = "group",
					["limitType"] = "none",
					["groupType"] = "simple",
					["key"] = "maintenance",
					["size"] = 10,
				}, -- [1]
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								0.5, -- [4]
							},
							["property"] = "color",
						}, -- [1]
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [2]
					},
				}, -- [1]
			},
			["parent"] = "Maintenance - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Poison - Main Hand",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
				["maintenance"] = {
					["poison"] = {
						["behavior"] = 2,
					},
				},
			},
			["inverse"] = false,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["displayIcon"] = "",
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Sprint"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["useMatch_count"] = true,
						["match_countOperator"] = ">",
						["auranames"] = {
							"2983", -- [1]
						},
						["ownOnly"] = true,
						["event"] = "Health",
						["unit"] = "player",
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["spellIds"] = {
						},
						["subeventPrefix"] = "SPELL",
						["match_count"] = "0",
						["type"] = "aura2",
						["useName"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["track"] = "auto",
						["use_matchedRune"] = false,
						["duration"] = "1",
						["genericShowOn"] = "showAlways",
						["names"] = {
						},
						["use_showgcd"] = true,
						["debuffType"] = "HELPFUL",
						["type"] = "spell",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "Sprint",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["subeventPrefix"] = "SPELL",
						["use_genericShowOn"] = true,
						["use_track"] = true,
						["spellName"] = 2983,
					},
					["untrigger"] = {
						["genericShowOn"] = "showAlways",
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["class_and_spec"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["use_class"] = true,
				["use_spellknown"] = true,
				["zoneIds"] = "",
				["use_spec"] = true,
				["spec"] = {
					["single"] = 2,
					["multi"] = {
						[3] = true,
					},
				},
				["use_never"] = false,
				["spellknown"] = 2983,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "oLckeGnuPG4",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = false,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "buttonOverlay",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -1,
						["variable"] = "incombat",
						["value"] = 0,
					},
					["changes"] = {
						{
							["property"] = "sub.3.glow",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [3]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "Pixel",
							["property"] = "sub.3.glowType",
						}, -- [2]
						{
							["property"] = "desaturate",
						}, -- [3]
						{
							["property"] = "inverse",
						}, -- [4]
						{
							["value"] = true,
							["property"] = "cooldownEdge",
						}, -- [5]
					},
				}, -- [4]
			},
			["parent"] = "Core - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Sprint",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["displayIcon"] = "",
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Energy Bar - Rogue"] = {
			["sparkWidth"] = 10,
			["sparkOffsetX"] = 0,
			["wagoID"] = "foIUC5_yM",
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["overlays"] = {
				{
					0, -- [1]
					0, -- [2]
					0, -- [3]
					0.40000003576279, -- [4]
				}, -- [1]
			},
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["width"] = 405,
			["iconSource"] = -1,
			["sparkRotation"] = 0,
			["sparkRotationMode"] = "AUTO",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["backgroundColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.30000001192093, -- [4]
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "unit",
						["names"] = {
						},
						["unevent"] = "auto",
						["use_unit"] = true,
						["duration"] = "1",
						["use_showCost"] = false,
						["subeventPrefix"] = "SPELL",
						["subeventSuffix"] = "_CAST_START",
						["powertype"] = 3,
						["spellIds"] = {
						},
						["event"] = "Power",
						["unit"] = "player",
						["use_absorbMode"] = true,
						["use_powertype"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = 1,
			},
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["internalVersion"] = 70,
			["xOffset"] = 0,
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["isPrimaryResource"] = true,
			["parent"] = "Resources - Rogue",
			["barColor"] = {
				1, -- [1]
				0.78823529411765, -- [2]
				0.23921568627451, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["icon"] = false,
			["configGroup"] = "energy_bar",
			["sparkOffsetY"] = 0,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["type"] = "subforeground",
				}, -- [2]
				{
					["border_size"] = 2,
					["border_anchor"] = "bar",
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [3]
				{
					["text_shadowXOffset"] = 1,
					["text_text"] = "%p",
					["text_text_format_p_time_mod_rate"] = true,
					["text_selfPoint"] = "CENTER",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = true,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["type"] = "subtext",
					["text_text_format_p_time_format"] = 0,
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_text_format_p_time_precision"] = 1,
					["text_shadowYOffset"] = -1,
					["text_text_format_1.percentpower_format"] = "none",
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_CENTER",
					["anchorYOffset"] = 0,
					["text_fontType"] = "OUTLINE",
					["text_fontSize"] = 14,
					["anchorXOffset"] = 0,
					["text_text_format_p_format"] = "timed",
				}, -- [4]
			},
			["height"] = 20,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["load"] = {
				["use_class"] = true,
				["use_petbattle"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 3,
					["multi"] = {
						[3] = true,
					},
				},
				["zoneIds"] = "",
			},
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["selfPoint"] = "TOP",
			["source"] = "import",
			["barColor2"] = {
				1, -- [1]
				1, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["actions"] = {
				["start"] = {
					["custom"] = "",
					["do_message"] = false,
					["do_custom"] = false,
				},
				["finish"] = {
				},
				["init"] = {
					["custom"] = "aura_env.region.configGroup = \"energy_bar\"",
					["do_custom"] = true,
				},
			},
			["version"] = 25,
			["smoothProgress"] = true,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["gradientOrientation"] = "HORIZONTAL",
			["enableGradient"] = false,
			["icon_side"] = "RIGHT",
			["sparkHidden"] = "NEVER",
			["config"] = {
			},
			["sparkHeight"] = 30,
			["texture"] = "Solid",
			["semver"] = "2.0.23",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["auto"] = true,
			["tocversion"] = 30401,
			["id"] = "Energy Bar - Rogue",
			["overlayclip"] = true,
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["frameStrata"] = 1,
			["uid"] = "r(hsUJGtEPM",
			["inverse"] = false,
			["zoom"] = 0,
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
			},
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["spark"] = false,
		},
		["Cheat Death"] = {
			["iconSource"] = 0,
			["wagoID"] = "foIUC5_yM",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "aura2",
						["auranames"] = {
							"45182", -- [1]
						},
						["ownOnly"] = true,
						["event"] = "Health",
						["unit"] = "player",
						["spellIds"] = {
						},
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["useName"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["spellId"] = {
							"45182", -- [1]
						},
						["auranames"] = {
						},
						["duration"] = "60",
						["subeventPrefix"] = "SPELL",
						["unitExists"] = true,
						["debuffType"] = "HELPFUL",
						["showClones"] = false,
						["useName"] = true,
						["auraspellids"] = {
							"146739", -- [1]
						},
						["unit"] = "player",
						["event"] = "Combat Log",
						["matchesShowOn"] = "showAlways",
						["subeventSuffix"] = "_AURA_APPLIED",
						["use_spellId"] = true,
						["spellIds"] = {
						},
						["use_sourceUnit"] = true,
						["type"] = "combatlog",
						["useExactSpellId"] = false,
						["sourceUnit"] = "player",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "any",
				["customTriggerLogic"] = "",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
						[102] = true,
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["zoneIds"] = "",
				["use_talent"] = false,
				["use_class"] = true,
				["race"] = {
				},
				["use_spellknown"] = false,
				["use_spec"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["role"] = {
					["single"] = "DAMAGER",
					["multi"] = {
						["DAMAGER"] = true,
					},
				},
				["spellknown"] = 34503,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["anchorFrameType"] = "SCREEN",
			["frameStrata"] = 1,
			["desc"] = "",
			["xOffset"] = 0,
			["cooldown"] = true,
			["regionType"] = "icon",
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = -1,
						["variable"] = "incombat",
						["value"] = 0,
					},
					["changes"] = {
						{
							["property"] = "sub.3.glow",
						}, -- [1]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "Pixel",
							["property"] = "sub.3.glowType",
						}, -- [2]
						{
							["property"] = "desaturate",
						}, -- [3]
						{
							["property"] = "inverse",
						}, -- [4]
						{
							["value"] = true,
							["property"] = "cooldownEdge",
						}, -- [5]
					},
				}, -- [3]
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["uid"] = "rbJ4Nj0fEwG",
			["useCooldownModRate"] = true,
			["authorOptions"] = {
			},
			["cooldownTextDisabled"] = false,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Cheat Death",
			["auto"] = true,
			["alpha"] = 1,
			["width"] = 48,
			["zoom"] = 0.3,
			["config"] = {
			},
			["inverse"] = true,
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["displayIcon"] = 132285,
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["parent"] = "Dynamic Effects - Rogue",
		},
		["Maintenance - Rogue"] = {
			["arcLength"] = 360,
			["controlledChildren"] = {
				"Stealth", -- [1]
				"Poison - Main Hand", -- [2]
				"Poison - Off Hand", -- [3]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["wagoID"] = "foIUC5_yM",
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["sortHybridTable"] = {
				["Stealth"] = false,
				["Poison - Off Hand"] = false,
				["Poison - Main Hand"] = false,
			},
			["anchorPoint"] = "BOTTOM",
			["grow"] = "CUSTOM",
			["fullCircle"] = true,
			["space"] = 2,
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["names"] = {
						},
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["unit"] = "player",
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 1,
			["radius"] = 200,
			["xOffset"] = 0,
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["align"] = "CENTER",
			["growOn"] = "changed",
			["source"] = "import",
			["desc"] = "Made by Luxthos - twitch.tv/luxthos",
			["rotation"] = 0,
			["gridType"] = "RD",
			["version"] = 25,
			["subRegions"] = {
			},
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["rowSpace"] = 1,
			["load"] = {
				["size"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
			},
			["internalVersion"] = 70,
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["parent"] = "Luxthos - Rogue",
			["animate"] = false,
			["customGrow"] = "function(newPositions, activeRegions)\n    local LWA = LWA and LWA[\"Rogue\"] or {}\n\n    if LWA and LWA.GrowMaintenance then\n        LWA.GrowMaintenance(newPositions, activeRegions)\n    end\nend",
			["scale"] = 1,
			["centerType"] = "LR",
			["border"] = false,
			["anchorFrameFrame"] = "WeakAuras:General Options - Rogue",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 2,
			["sort"] = "none",
			["useLimit"] = false,
			["stagger"] = 0,
			["anchorFrameParent"] = false,
			["constantFactor"] = "RADIUS",
			["gridWidth"] = 5,
			["borderOffset"] = 4,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Maintenance - Rogue",
			["borderEdge"] = "Square Full White",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["stepAngle"] = 15,
			["uid"] = "9bvnKTdU3Hx",
			["limit"] = 5,
			["selfPoint"] = "TOP",
			["config"] = {
			},
			["conditions"] = {
			},
			["information"] = {
				["forceEvents"] = true,
			},
			["borderInset"] = 1,
		},
		["Combo Point 1 - Rogue"] = {
			["sparkWidth"] = 10,
			["iconSource"] = -1,
			["authorOptions"] = {
			},
			["adjustedMax"] = "1",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["sparkRotation"] = 0,
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["backgroundColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.34336978197098, -- [4]
			},
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["enableGradient"] = false,
			["selfPoint"] = "TOP",
			["barColor"] = {
				0.85882352941176, -- [1]
				0.14509803921569, -- [2]
				0.050980392156863, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["sparkOffsetY"] = 0,
			["gradientOrientation"] = "HORIZONTAL",
			["load"] = {
				["use_class"] = true,
				["use_petbattle"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 3,
					["multi"] = {
						[3] = true,
					},
				},
				["zoneIds"] = "",
			},
			["smoothProgress"] = false,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["texture"] = "Solid",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["auto"] = true,
			["tocversion"] = 30401,
			["alpha"] = 1,
			["config"] = {
			},
			["colorState"] = "",
			["sparkOffsetX"] = 0,
			["wagoID"] = "foIUC5_yM",
			["parent"] = "Combo Points - Rogue",
			["adjustedMin"] = "0",
			["sparkRotationMode"] = "AUTO",
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "unit",
						["names"] = {
						},
						["unevent"] = "auto",
						["use_unit"] = true,
						["duration"] = "1",
						["event"] = "Power",
						["subeventPrefix"] = "SPELL",
						["subeventSuffix"] = "_CAST_START",
						["powertype"] = 4,
						["spellIds"] = {
						},
						["use_power"] = false,
						["unit"] = "player",
						["use_absorbMode"] = true,
						["use_powertype"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = 1,
			},
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["isPrimaryResource"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["type"] = "subforeground",
				}, -- [2]
				{
					["border_size"] = 2,
					["border_anchor"] = "bar",
					["type"] = "subborder",
					["border_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
					},
					["border_visible"] = false,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [3]
			},
			["height"] = 20,
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = true,
			["source"] = "import",
			["xOffset"] = 0,
			["icon_side"] = "RIGHT",
			["preferToUpdate"] = false,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["sparkHeight"] = 30,
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["icon"] = false,
			["configGroup"] = "combo_points",
			["semver"] = "2.0.23",
			["spark"] = false,
			["sparkHidden"] = "NEVER",
			["zoom"] = 0,
			["frameStrata"] = 1,
			["width"] = 56,
			["id"] = "Combo Point 1 - Rogue",
			["anchorFrameType"] = "SCREEN",
			["inverse"] = false,
			["uid"] = "8QVHJzVOAJb",
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "<=",
						["value"] = "3",
						["variable"] = "power",
					},
					["changes"] = {
						{
							["value"] = {
								["custom"] = "aura_env.region.colorState = \"\"\nWeakAuras.ScanEvents(\"LWA_UPDATE_BAR\", aura_env, 1, 5)",
							},
							["property"] = "customcode",
						}, -- [1]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "==",
						["value"] = "4",
						["variable"] = "power",
					},
					["linked"] = true,
					["changes"] = {
						{
							["value"] = {
								["custom"] = "aura_env.region.colorState = \"highlight\"\nWeakAuras.ScanEvents(\"LWA_UPDATE_BAR\", aura_env, 1, 5)",
							},
							["property"] = "customcode",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "==",
						["value"] = "5",
						["variable"] = "power",
					},
					["linked"] = true,
					["changes"] = {
						{
							["value"] = {
								["custom"] = "aura_env.region.colorState = \"full\"\nWeakAuras.ScanEvents(\"LWA_UPDATE_BAR\", aura_env, 1, 5)",
							},
							["property"] = "customcode",
						}, -- [1]
					},
				}, -- [3]
			},
			["barColor2"] = {
				1, -- [1]
				1, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["actions"] = {
				["start"] = {
					["do_custom"] = false,
				},
				["finish"] = {
				},
				["init"] = {
					["custom"] = "aura_env.region.configGroup = \"combo_points\"",
					["do_custom"] = true,
				},
			},
		},
		["Combo Point 4 - Rogue"] = {
			["sparkWidth"] = 10,
			["iconSource"] = -1,
			["authorOptions"] = {
			},
			["adjustedMax"] = "4",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["sparkRotation"] = 0,
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["backgroundColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.34336978197098, -- [4]
			},
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["enableGradient"] = false,
			["selfPoint"] = "TOP",
			["barColor"] = {
				0.85882352941176, -- [1]
				0.14509803921569, -- [2]
				0.050980392156863, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["sparkOffsetY"] = 0,
			["gradientOrientation"] = "HORIZONTAL",
			["load"] = {
				["use_class"] = true,
				["use_petbattle"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 3,
					["multi"] = {
						[3] = true,
					},
				},
				["zoneIds"] = "",
			},
			["smoothProgress"] = false,
			["useAdjustededMin"] = true,
			["regionType"] = "aurabar",
			["texture"] = "Solid",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["auto"] = true,
			["tocversion"] = 30401,
			["alpha"] = 1,
			["config"] = {
			},
			["colorState"] = "",
			["sparkOffsetX"] = 0,
			["wagoID"] = "foIUC5_yM",
			["parent"] = "Combo Points - Rogue",
			["adjustedMin"] = "3",
			["sparkRotationMode"] = "AUTO",
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "unit",
						["names"] = {
						},
						["unevent"] = "auto",
						["use_unit"] = true,
						["duration"] = "1",
						["event"] = "Power",
						["subeventPrefix"] = "SPELL",
						["subeventSuffix"] = "_CAST_START",
						["powertype"] = 4,
						["spellIds"] = {
						},
						["use_power"] = false,
						["unit"] = "player",
						["use_absorbMode"] = true,
						["use_powertype"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = 1,
			},
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["isPrimaryResource"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["type"] = "subforeground",
				}, -- [2]
				{
					["border_size"] = 2,
					["border_anchor"] = "bar",
					["type"] = "subborder",
					["border_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
					},
					["border_visible"] = false,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [3]
			},
			["height"] = 20,
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = true,
			["source"] = "import",
			["xOffset"] = 0,
			["icon_side"] = "RIGHT",
			["preferToUpdate"] = false,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["sparkHeight"] = 30,
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["icon"] = false,
			["configGroup"] = "combo_points",
			["semver"] = "2.0.23",
			["spark"] = false,
			["sparkHidden"] = "NEVER",
			["zoom"] = 0,
			["frameStrata"] = 1,
			["width"] = 56,
			["id"] = "Combo Point 4 - Rogue",
			["anchorFrameType"] = "SCREEN",
			["inverse"] = false,
			["uid"] = "xCfJzSLQT1r",
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "<=",
						["value"] = "3",
						["variable"] = "power",
					},
					["changes"] = {
						{
							["value"] = {
								["custom"] = "aura_env.region.colorState = \"\"\nWeakAuras.ScanEvents(\"LWA_UPDATE_BAR\", aura_env, 4, 5)",
							},
							["property"] = "customcode",
						}, -- [1]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "==",
						["value"] = "4",
						["variable"] = "power",
					},
					["linked"] = true,
					["changes"] = {
						{
							["value"] = {
								["custom"] = "aura_env.region.colorState = \"highlight\"\nWeakAuras.ScanEvents(\"LWA_UPDATE_BAR\", aura_env, 4, 5)",
							},
							["property"] = "customcode",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "==",
						["value"] = "5",
						["variable"] = "power",
					},
					["linked"] = true,
					["changes"] = {
						{
							["value"] = {
								["custom"] = "aura_env.region.colorState = \"full\"\nWeakAuras.ScanEvents(\"LWA_UPDATE_BAR\", aura_env, 4, 5)",
							},
							["property"] = "customcode",
						}, -- [1]
					},
				}, -- [3]
			},
			["barColor2"] = {
				1, -- [1]
				1, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
					["custom"] = "aura_env.region.configGroup = \"combo_points\"",
					["do_custom"] = true,
				},
			},
		},
		["Expose Armor"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = true,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["showClones"] = false,
						["type"] = "aura2",
						["auraspellids"] = {
							"146739", -- [1]
						},
						["useExactSpellId"] = false,
						["matchesShowOn"] = "showAlways",
						["event"] = "Health",
						["unit"] = "target",
						["unitExists"] = true,
						["subeventSuffix"] = "_CAST_START",
						["spellIds"] = {
						},
						["names"] = {
						},
						["subeventPrefix"] = "SPELL",
						["useName"] = true,
						["auranames"] = {
							"8647", -- [1]
							"7386", -- [2]
						},
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["customTriggerLogic"] = "",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
				{
					["text_shadowXOffset"] = 0,
					["text_text_format_s_format"] = "none",
					["text_text"] = "%s",
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "CENTER",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_text_format_p_time_format"] = 0,
					["type"] = "subtext",
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_color"] = {
						1, -- [1]
						0.88627450980392, -- [2]
						0.76862745098039, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_anchorYOffset"] = -4,
					["text_shadowYOffset"] = 0,
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "OUTER_TOP",
					["text_text_format_2.s_format"] = "none",
					["text_fontType"] = "OUTLINE",
					["text_fontSize"] = 18,
					["anchorXOffset"] = 0,
					["text_text_format_p_time_precision"] = 1,
				}, -- [4]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["zoneIds"] = "",
				["use_class"] = true,
				["race"] = {
				},
				["use_spellknown"] = true,
				["use_spec"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["role"] = {
					["single"] = "DAMAGER",
					["multi"] = {
						["DAMAGER"] = true,
					},
				},
				["spellknown"] = 8647,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "P4RB0sbSLj5",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 0,
					},
					["changes"] = {
						{
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "buttonOverlay",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "buffed",
						["value"] = 0,
						["checks"] = {
							{
								["trigger"] = 1,
								["variable"] = "show",
								["value"] = 0,
							}, -- [1]
							{
								["value"] = "0",
								["op"] = "==",
								["variable"] = "matchCount",
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
						{
							["value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								0.5, -- [4]
							},
							["property"] = "color",
						}, -- [2]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "buffed",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "Pixel",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [3]
			},
			["parent"] = "Core - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Expose Armor",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = false,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["displayIcon"] = "",
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Luxthos - Rogue"] = {
			["controlledChildren"] = {
				"Class Options - Rogue", -- [1]
				"General Options - Rogue", -- [2]
				"Dynamic Effects - Rogue", -- [3]
				"Dynamic Spells - Rogue", -- [4]
				"Left Side - Rogue", -- [5]
				"Right Side - Rogue", -- [6]
				"Core - Rogue", -- [7]
				"Maintenance - Rogue", -- [8]
				"Resources - Rogue", -- [9]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["wagoID"] = "foIUC5_yM",
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["yOffset"] = -293.3333333333334,
			["anchorPoint"] = "CENTER",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["names"] = {
						},
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["unit"] = "player",
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["desc"] = "Made by Luxthos - twitch.tv/luxthos",
			["version"] = 25,
			["subRegions"] = {
			},
			["load"] = {
				["size"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
			},
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["source"] = "import",
			["scale"] = 0.5999999999999996,
			["border"] = false,
			["borderEdge"] = "Square Full White",
			["regionType"] = "group",
			["borderSize"] = 2,
			["borderOffset"] = 4,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Luxthos - Rogue",
			["config"] = {
			},
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["xOffset"] = 0,
			["uid"] = "wEjyBTynrkZ",
			["borderInset"] = 1,
			["selfPoint"] = "CENTER",
			["conditions"] = {
			},
			["information"] = {
				["forceEvents"] = true,
			},
			["groupIcon"] = "interface/icons/classicon_rogue.blp",
		},
		["Nameplate range check 3"] = {
			["iconSource"] = 0,
			["displayText_format_1.minRange_realm_name"] = "never",
			["xOffset"] = 0,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["yOffset"] = 0,
			["anchorPoint"] = "RIGHT",
			["displayText_format_p_time_format"] = 0,
			["url"] = "https://wago.io/YP6nljWXe/7",
			["icon"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "LEFT",
			["displayText_format_destUnit_color"] = "class",
			["desc"] = "Checks nearest 20 nameplates and shows a starfall icon if they are in range of starfall (36 yrds). \n\nHelps you make any decisions about using starfall and to stop any ninja pulls. \n\nIf you want more nameplates you can simply duplicate one of the weak auras in the group and add a number to the trigger. \n\nIf anyone finds an easier way to make this kind of a weak aura let me know as this was made editing a pre existing weak aura with a similar function.",
			["font"] = "PT Sans Narrow",
			["load"] = {
				["use_never"] = false,
				["class"] = {
					["single"] = "DRUID",
					["multi"] = {
						["DRUID"] = true,
					},
				},
				["use_encounterid"] = false,
				["use_class"] = true,
				["use_itemequiped"] = false,
				["zoneIds"] = "",
				["use_not_item_bonusid_equipped"] = false,
				["talent2"] = {
					["multi"] = {
						[20] = false,
					},
				},
				["use_zoneIds"] = false,
				["item_bonusid_equipped"] = "62080",
				["spec"] = {
					["multi"] = {
					},
				},
				["not_item_bonusid_equipped"] = "62080",
				["use_talent"] = false,
				["use_spellknown"] = false,
				["talent"] = {
					["multi"] = {
						[24] = true,
					},
				},
				["itemequiped"] = {
					62080, -- [1]
				},
				["size"] = {
					["multi"] = {
					},
				},
				["use_exact_spellknown"] = false,
				["use_item_bonusid_equipped"] = false,
				["itemtypeequipped"] = {
				},
			},
			["displayText_format_1.maxRange_format"] = "none",
			["shadowXOffset"] = 1,
			["displayText_format_1.minRange_abbreviate"] = false,
			["regionType"] = "icon",
			["displayText_format_destUnit_abbreviate_max"] = 8,
			["zoom"] = 0,
			["displayText_format_destUnit_format"] = "Unit",
			["tocversion"] = 30401,
			["alpha"] = 1,
			["config"] = {
			},
			["fixedWidth"] = 200,
			["outline"] = "OUTLINE",
			["wagoID"] = "YP6nljWXe",
			["parent"] = "Starfall Range Check on Nameplate",
			["shadowYOffset"] = -1,
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "event",
			["automaticWidth"] = "Auto",
			["triggers"] = {
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "35",
						["unit"] = "nameplate3",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [1]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "20",
						["unit"] = "nameplate3",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = false,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [6]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "15",
						["unit"] = "nameplate3",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [7]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate3",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [8]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [9]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [10]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate3",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [11]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    if trigger[1] and trigger[3] and trigger[5] then\n        return true\n    elseif trigger[2] and trigger[4] and trigger[5] then\n        return true\n    elseif trigger[3] and trigger[8] and trigger[6] then\n        return true\n    elseif trigger[4] and trigger[7] and trigger[6] then\n        return true\n    elseif trigger[4] and (trigger[9] and trigger[10]) and trigger[7] then\n        return true\n    elseif trigger[3] and (trigger[9] and trigger[10]) and trigger[11] then\n        return true\n    end\nend",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["version"] = 7,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%maxRange",
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = false,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_text_format_p_time_mod_rate"] = true,
					["anchorXOffset"] = 0,
					["text_text_format_minRange_format"] = "none",
					["type"] = "subtext",
					["text_text_format_maxRange_format"] = "none",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_text_format_p_time_format"] = 0,
					["text_shadowYOffset"] = 0,
					["text_fontType"] = "OUTLINE",
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "CENTER",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["anchorYOffset"] = 0,
					["text_fontSize"] = 12,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_text_format_p_time_precision"] = 1,
				}, -- [2]
			},
			["height"] = 25,
			["displayText_format_destUnit_realm_name"] = "never",
			["preferToUpdate"] = false,
			["information"] = {
				["forceEvents"] = true,
			},
			["displayText_format_1.minRange_color"] = true,
			["source"] = "import",
			["conditions"] = {
			},
			["displayIcon"] = 236168,
			["cooldownTextDisabled"] = false,
			["displayText_format_1.minRange_round_type"] = "ceil",
			["authorOptions"] = {
			},
			["desaturate"] = false,
			["wordWrap"] = "WordWrap",
			["anchorFrameType"] = "NAMEPLATE",
			["useCooldownModRate"] = true,
			["displayText_format_destUnit_abbreviate"] = false,
			["displayText_format_1.minRange_format"] = "Number",
			["displayText_format_p_time_precision"] = 1,
			["color"] = {
				0.97647058823529, -- [1]
				1, -- [2]
				0.97647058823529, -- [3]
				1, -- [4]
			},
			["justify"] = "LEFT",
			["uid"] = "s)WZ5FNgrND",
			["semver"] = "1.0.6",
			["displayText"] = "%1.maxRange",
			["id"] = "Nameplate range check 3",
			["anchorFrameParent"] = false,
			["frameStrata"] = 1,
			["width"] = 25,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["fontSize"] = 16,
			["inverse"] = false,
			["displayText_format_1.minRange_abbreviate_max"] = 8,
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["displayText_format_1.minRange_decimal_precision"] = 0,
			["cooldown"] = false,
			["cooldownEdge"] = false,
		},
		["Nameplate range check 9 "] = {
			["iconSource"] = 0,
			["displayText_format_1.minRange_realm_name"] = "never",
			["xOffset"] = 0,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["yOffset"] = 0,
			["anchorPoint"] = "RIGHT",
			["displayText_format_p_time_format"] = 0,
			["url"] = "https://wago.io/YP6nljWXe/7",
			["icon"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "LEFT",
			["displayText_format_destUnit_color"] = "class",
			["desc"] = "Checks nearest 20 nameplates and shows a starfall icon if they are in range of starfall (36 yrds). \n\nHelps you make any decisions about using starfall and to stop any ninja pulls. \n\nIf you want more nameplates you can simply duplicate one of the weak auras in the group and add a number to the trigger. \n\nIf anyone finds an easier way to make this kind of a weak aura let me know as this was made editing a pre existing weak aura with a similar function.",
			["font"] = "PT Sans Narrow",
			["load"] = {
				["use_never"] = false,
				["class"] = {
					["single"] = "DRUID",
					["multi"] = {
						["DRUID"] = true,
					},
				},
				["use_encounterid"] = false,
				["use_class"] = true,
				["use_itemequiped"] = false,
				["zoneIds"] = "",
				["use_not_item_bonusid_equipped"] = false,
				["talent2"] = {
					["multi"] = {
						[20] = false,
					},
				},
				["use_zoneIds"] = false,
				["item_bonusid_equipped"] = "62080",
				["spec"] = {
					["multi"] = {
					},
				},
				["not_item_bonusid_equipped"] = "62080",
				["use_talent"] = false,
				["use_spellknown"] = false,
				["talent"] = {
					["multi"] = {
						[24] = true,
					},
				},
				["itemequiped"] = {
					62080, -- [1]
				},
				["size"] = {
					["multi"] = {
					},
				},
				["use_exact_spellknown"] = false,
				["use_item_bonusid_equipped"] = false,
				["itemtypeequipped"] = {
				},
			},
			["displayText_format_1.maxRange_format"] = "none",
			["shadowXOffset"] = 1,
			["displayText_format_1.minRange_abbreviate"] = false,
			["regionType"] = "icon",
			["displayText_format_destUnit_abbreviate_max"] = 8,
			["zoom"] = 0,
			["displayText_format_destUnit_format"] = "Unit",
			["tocversion"] = 30401,
			["alpha"] = 1,
			["config"] = {
			},
			["fixedWidth"] = 200,
			["outline"] = "OUTLINE",
			["wagoID"] = "YP6nljWXe",
			["parent"] = "Starfall Range Check on Nameplate",
			["shadowYOffset"] = -1,
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "event",
			["automaticWidth"] = "Auto",
			["triggers"] = {
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "35",
						["unit"] = "nameplate9",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [1]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "20",
						["unit"] = "nameplate9",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = false,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [6]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "15",
						["unit"] = "nameplate9",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [7]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate9",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [8]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [9]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [10]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate9",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [11]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    if trigger[1] and trigger[3] and trigger[5] then\n        return true\n    elseif trigger[2] and trigger[4] and trigger[5] then\n        return true\n    elseif trigger[3] and trigger[8] and trigger[6] then\n        return true\n    elseif trigger[4] and trigger[7] and trigger[6] then\n        return true\n    elseif trigger[4] and (trigger[9] and trigger[10]) and trigger[7] then\n        return true\n    elseif trigger[3] and (trigger[9] and trigger[10]) and trigger[11] then\n        return true\n    end\nend",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["version"] = 7,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%maxRange",
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = false,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_text_format_p_time_mod_rate"] = true,
					["anchorXOffset"] = 0,
					["text_text_format_minRange_format"] = "none",
					["type"] = "subtext",
					["text_text_format_maxRange_format"] = "none",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_text_format_p_time_format"] = 0,
					["text_shadowYOffset"] = 0,
					["text_fontType"] = "OUTLINE",
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "CENTER",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["anchorYOffset"] = 0,
					["text_fontSize"] = 12,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_text_format_p_time_precision"] = 1,
				}, -- [2]
			},
			["height"] = 25,
			["displayText_format_destUnit_realm_name"] = "never",
			["preferToUpdate"] = false,
			["information"] = {
				["forceEvents"] = true,
			},
			["displayText_format_1.minRange_color"] = true,
			["source"] = "import",
			["conditions"] = {
			},
			["displayIcon"] = 236168,
			["cooldownTextDisabled"] = false,
			["displayText_format_1.minRange_round_type"] = "ceil",
			["authorOptions"] = {
			},
			["desaturate"] = false,
			["wordWrap"] = "WordWrap",
			["anchorFrameType"] = "NAMEPLATE",
			["useCooldownModRate"] = true,
			["displayText_format_destUnit_abbreviate"] = false,
			["displayText_format_1.minRange_format"] = "Number",
			["displayText_format_p_time_precision"] = 1,
			["color"] = {
				0.97647058823529, -- [1]
				1, -- [2]
				0.97647058823529, -- [3]
				1, -- [4]
			},
			["justify"] = "LEFT",
			["uid"] = "izVDwDc2QMI",
			["semver"] = "1.0.6",
			["displayText"] = "%1.maxRange",
			["id"] = "Nameplate range check 9 ",
			["anchorFrameParent"] = false,
			["frameStrata"] = 1,
			["width"] = 25,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["fontSize"] = 16,
			["inverse"] = false,
			["displayText_format_1.minRange_abbreviate_max"] = 8,
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["displayText_format_1.minRange_decimal_precision"] = 0,
			["cooldown"] = false,
			["cooldownEdge"] = false,
		},
		["Shadowstep"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["track"] = "auto",
						["use_matchedRune"] = false,
						["duration"] = "1",
						["genericShowOn"] = "showAlways",
						["names"] = {
						},
						["use_showgcd"] = false,
						["debuffType"] = "HELPFUL",
						["type"] = "spell",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "Shadowstep",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["subeventPrefix"] = "SPELL",
						["use_genericShowOn"] = true,
						["use_track"] = true,
						["spellName"] = 36554,
					},
					["untrigger"] = {
						["genericShowOn"] = "showAlways",
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["class_and_spec"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["single"] = 39,
					["multi"] = {
						[39] = true,
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["use_class"] = true,
				["use_spellknown"] = true,
				["zoneIds"] = "",
				["use_spec"] = true,
				["spec"] = {
					["single"] = 2,
					["multi"] = {
						[3] = true,
					},
				},
				["use_never"] = false,
				["spellknown"] = 36554,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "vQEdFWFyTI9",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "onCooldown",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = false,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "buttonOverlay",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -1,
						["variable"] = "incombat",
						["value"] = 0,
					},
					["changes"] = {
						{
							["property"] = "sub.3.glow",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "onCooldown",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [3]
			},
			["parent"] = "Core - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Shadowstep",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["displayIcon"] = "",
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Gouge"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "aura2",
						["auranames"] = {
							"1776", -- [1]
						},
						["ownOnly"] = true,
						["event"] = "Health",
						["unit"] = "target",
						["spellIds"] = {
						},
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["useName"] = true,
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["track"] = "auto",
						["use_matchedRune"] = false,
						["duration"] = "1",
						["genericShowOn"] = "showAlways",
						["names"] = {
						},
						["use_showgcd"] = true,
						["debuffType"] = "HELPFUL",
						["type"] = "spell",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "Gouge",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["subeventPrefix"] = "SPELL",
						["use_genericShowOn"] = true,
						["use_track"] = true,
						["spellName"] = 1776,
					},
					["untrigger"] = {
						["genericShowOn"] = "showAlways",
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["class_and_spec"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["use_class"] = true,
				["use_spellknown"] = true,
				["zoneIds"] = "",
				["use_spec"] = true,
				["spec"] = {
					["single"] = 2,
					["multi"] = {
						[3] = true,
					},
				},
				["use_never"] = false,
				["spellknown"] = 1776,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "seC7yheCnR2",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = false,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "buttonOverlay",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = -1,
						["variable"] = "incombat",
						["value"] = 0,
					},
					["changes"] = {
						{
							["property"] = "sub.3.glow",
						}, -- [1]
					},
				}, -- [3]
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "insufficientResources",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								0.47450980392157, -- [1]
								0.51372549019608, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["property"] = "color",
						}, -- [1]
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [2]
					},
				}, -- [4]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "Pixel",
							["property"] = "sub.3.glowType",
						}, -- [2]
						{
							["value"] = false,
							["property"] = "desaturate",
						}, -- [3]
						{
							["property"] = "inverse",
						}, -- [4]
						{
							["property"] = "color",
						}, -- [5]
						{
							["value"] = true,
							["property"] = "cooldownEdge",
						}, -- [6]
					},
				}, -- [5]
			},
			["parent"] = "Core - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Gouge",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["displayIcon"] = "",
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Distract"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["track"] = "auto",
						["use_matchedRune"] = false,
						["duration"] = "1",
						["genericShowOn"] = "showAlways",
						["names"] = {
						},
						["use_showgcd"] = true,
						["debuffType"] = "HELPFUL",
						["type"] = "spell",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "Distract",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["subeventPrefix"] = "SPELL",
						["use_genericShowOn"] = true,
						["use_track"] = true,
						["spellName"] = 1725,
					},
					["untrigger"] = {
						["genericShowOn"] = "showAlways",
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["class_and_spec"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["use_class"] = true,
				["use_spellknown"] = true,
				["zoneIds"] = "",
				["use_spec"] = true,
				["spec"] = {
					["single"] = 2,
					["multi"] = {
						[3] = true,
					},
				},
				["use_never"] = false,
				["spellknown"] = 1725,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "0UVyfJ(kvN9",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "onCooldown",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = false,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "buttonOverlay",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "onCooldown",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = -1,
						["variable"] = "incombat",
						["value"] = 0,
					},
					["changes"] = {
						{
							["property"] = "sub.3.glow",
						}, -- [1]
					},
				}, -- [3]
			},
			["parent"] = "Core - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Distract",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["displayIcon"] = "",
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Cold Blood"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "aura2",
						["auranames"] = {
							"14177", -- [1]
						},
						["ownOnly"] = true,
						["event"] = "Health",
						["unit"] = "player",
						["spellIds"] = {
						},
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["useName"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["track"] = "auto",
						["use_matchedRune"] = false,
						["duration"] = "1",
						["genericShowOn"] = "showAlways",
						["names"] = {
						},
						["use_showgcd"] = false,
						["debuffType"] = "HELPFUL",
						["type"] = "spell",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "Cold Blood",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["subeventPrefix"] = "SPELL",
						["use_genericShowOn"] = true,
						["use_track"] = true,
						["spellName"] = 14177,
					},
					["untrigger"] = {
						["genericShowOn"] = "showAlways",
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["class_and_spec"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["use_class"] = true,
				["use_spellknown"] = true,
				["zoneIds"] = "",
				["use_spec"] = true,
				["spec"] = {
					["single"] = 2,
					["multi"] = {
						[3] = true,
					},
				},
				["use_never"] = false,
				["spellknown"] = 14177,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "(fCkjKRYtNH",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = false,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "buttonOverlay",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -1,
						["variable"] = "incombat",
						["value"] = 0,
					},
					["changes"] = {
						{
							["property"] = "sub.3.glow",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [3]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "Pixel",
							["property"] = "sub.3.glowType",
						}, -- [2]
						{
							["property"] = "desaturate",
						}, -- [3]
						{
							["property"] = "inverse",
						}, -- [4]
						{
							["value"] = true,
							["property"] = "cooldownEdge",
						}, -- [5]
					},
				}, -- [4]
			},
			["parent"] = "Core - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Cold Blood",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["displayIcon"] = "",
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Dismantle"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "aura2",
						["auranames"] = {
							"51722", -- [1]
						},
						["ownOnly"] = true,
						["event"] = "Health",
						["unit"] = "target",
						["spellIds"] = {
						},
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["useName"] = true,
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["track"] = "auto",
						["use_matchedRune"] = false,
						["duration"] = "1",
						["genericShowOn"] = "showAlways",
						["names"] = {
						},
						["use_showgcd"] = true,
						["debuffType"] = "HELPFUL",
						["type"] = "spell",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "Dismantle",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["subeventPrefix"] = "SPELL",
						["use_genericShowOn"] = true,
						["use_track"] = true,
						["spellName"] = 51722,
					},
					["untrigger"] = {
						["genericShowOn"] = "showAlways",
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["class_and_spec"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["use_class"] = true,
				["use_spellknown"] = true,
				["zoneIds"] = "",
				["use_spec"] = true,
				["spec"] = {
					["single"] = 2,
					["multi"] = {
						[3] = true,
					},
				},
				["use_never"] = false,
				["spellknown"] = 51722,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "VQh(H5GjvlV",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = false,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "buttonOverlay",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = -1,
						["variable"] = "incombat",
						["value"] = 0,
					},
					["changes"] = {
						{
							["property"] = "sub.3.glow",
						}, -- [1]
					},
				}, -- [3]
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "insufficientResources",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								0.47450980392157, -- [1]
								0.51372549019608, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["property"] = "color",
						}, -- [1]
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [2]
					},
				}, -- [4]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "Pixel",
							["property"] = "sub.3.glowType",
						}, -- [2]
						{
							["value"] = false,
							["property"] = "desaturate",
						}, -- [3]
						{
							["property"] = "inverse",
						}, -- [4]
						{
							["property"] = "color",
						}, -- [5]
						{
							["value"] = true,
							["property"] = "cooldownEdge",
						}, -- [6]
					},
				}, -- [5]
			},
			["parent"] = "Core - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Dismantle",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["displayIcon"] = "",
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Kick"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["track"] = "auto",
						["use_matchedRune"] = false,
						["duration"] = "1",
						["genericShowOn"] = "showAlways",
						["names"] = {
						},
						["use_showgcd"] = true,
						["debuffType"] = "HELPFUL",
						["type"] = "spell",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "Kick",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["subeventPrefix"] = "SPELL",
						["use_genericShowOn"] = true,
						["use_track"] = true,
						["spellName"] = 1766,
					},
					["untrigger"] = {
						["genericShowOn"] = "showAlways",
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["class_and_spec"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["zoneIds"] = "",
				["use_class"] = true,
				["use_spellknown"] = true,
				["use_never"] = false,
				["use_spec"] = true,
				["spec"] = {
					["single"] = 2,
					["multi"] = {
						[3] = true,
					},
				},
				["use_exact_spellknown"] = false,
				["spellknown"] = 1766,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "(BKRn3GfZQW",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "onCooldown",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = false,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "buttonOverlay",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -1,
						["variable"] = "incombat",
						["value"] = 0,
					},
					["changes"] = {
						{
							["property"] = "sub.3.glow",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "onCooldown",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [3]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "insufficientResources",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								0.47450980392157, -- [1]
								0.51372549019608, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["property"] = "color",
						}, -- [1]
						{
							["property"] = "desaturate",
						}, -- [2]
					},
				}, -- [4]
			},
			["parent"] = "Core - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Kick",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["displayIcon"] = "",
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Left Side - Rogue"] = {
			["arcLength"] = 360,
			["controlledChildren"] = {
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["wagoID"] = "foIUC5_yM",
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["sortHybridTable"] = {
			},
			["anchorPoint"] = "TOPLEFT",
			["grow"] = "CUSTOM",
			["fullCircle"] = true,
			["space"] = 2,
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["names"] = {
						},
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["unit"] = "player",
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 1,
			["radius"] = 200,
			["xOffset"] = -6.103515625e-05,
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["align"] = "CENTER",
			["growOn"] = "changed",
			["source"] = "import",
			["desc"] = "Made by Luxthos - twitch.tv/luxthos",
			["rotation"] = 0,
			["gridType"] = "RD",
			["version"] = 25,
			["subRegions"] = {
			},
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["rowSpace"] = 1,
			["load"] = {
				["size"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
			},
			["internalVersion"] = 70,
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["parent"] = "Luxthos - Rogue",
			["animate"] = false,
			["customGrow"] = "function(newPositions, activeRegions)\n    local LWA = LWA and LWA[\"Rogue\"] or {}\n\n    if LWA and LWA.GrowLeftSide then\n        LWA.GrowLeftSide(newPositions, activeRegions)\n    end\nend",
			["scale"] = 1,
			["centerType"] = "LR",
			["border"] = false,
			["anchorFrameFrame"] = "WeakAuras:General Options - Rogue",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 2,
			["sort"] = "none",
			["useLimit"] = false,
			["stagger"] = 0,
			["anchorFrameParent"] = false,
			["constantFactor"] = "RADIUS",
			["gridWidth"] = 5,
			["borderOffset"] = 4,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Left Side - Rogue",
			["borderEdge"] = "Square Full White",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["stepAngle"] = 15,
			["uid"] = "0Z2tm7ttAmW",
			["limit"] = 5,
			["selfPoint"] = "TOPRIGHT",
			["config"] = {
			},
			["conditions"] = {
			},
			["information"] = {
				["forceEvents"] = true,
			},
			["borderInset"] = 1,
		},
		["Feint"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["track"] = "auto",
						["use_matchedRune"] = false,
						["duration"] = "1",
						["genericShowOn"] = "showAlways",
						["names"] = {
						},
						["use_showgcd"] = true,
						["debuffType"] = "HELPFUL",
						["type"] = "spell",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "Feint",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["subeventPrefix"] = "SPELL",
						["use_genericShowOn"] = true,
						["use_track"] = true,
						["spellName"] = 1966,
					},
					["untrigger"] = {
						["genericShowOn"] = "showAlways",
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["class_and_spec"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["use_class"] = true,
				["use_spellknown"] = true,
				["zoneIds"] = "",
				["use_spec"] = true,
				["spec"] = {
					["single"] = 2,
					["multi"] = {
						[3] = true,
					},
				},
				["use_never"] = false,
				["spellknown"] = 1966,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "LcfjUSy8NXU",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "onCooldown",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = false,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "buttonOverlay",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "onCooldown",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = -1,
						["variable"] = "incombat",
						["value"] = 0,
					},
					["changes"] = {
						{
							["property"] = "sub.3.glow",
						}, -- [1]
					},
				}, -- [3]
			},
			["parent"] = "Core - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Feint",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["displayIcon"] = "",
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Shadow Dance"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "aura2",
						["auranames"] = {
							"51713", -- [1]
						},
						["event"] = "Health",
						["unit"] = "player",
						["spellIds"] = {
						},
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["useName"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["track"] = "auto",
						["use_matchedRune"] = false,
						["duration"] = "1",
						["genericShowOn"] = "showAlways",
						["names"] = {
						},
						["use_showgcd"] = false,
						["debuffType"] = "HELPFUL",
						["type"] = "spell",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "Shadow Dance",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["subeventPrefix"] = "SPELL",
						["use_genericShowOn"] = true,
						["use_track"] = true,
						["spellName"] = 51713,
					},
					["untrigger"] = {
						["genericShowOn"] = "showAlways",
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["class_and_spec"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["use_class"] = true,
				["use_spellknown"] = true,
				["zoneIds"] = "",
				["use_spec"] = true,
				["spec"] = {
					["single"] = 2,
					["multi"] = {
						[3] = true,
					},
				},
				["use_never"] = false,
				["spellknown"] = 51713,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "S4Fk4Zy0LqV",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = false,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "buttonOverlay",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -1,
						["variable"] = "incombat",
						["value"] = 0,
					},
					["changes"] = {
						{
							["property"] = "sub.3.glow",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [3]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "Pixel",
							["property"] = "sub.3.glowType",
						}, -- [2]
						{
							["property"] = "desaturate",
						}, -- [3]
						{
							["property"] = "inverse",
						}, -- [4]
						{
							["value"] = true,
							["property"] = "cooldownEdge",
						}, -- [5]
					},
				}, -- [4]
			},
			["parent"] = "Core - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Shadow Dance",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["displayIcon"] = "",
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Nameplate range check 18 "] = {
			["iconSource"] = 0,
			["displayText_format_1.minRange_realm_name"] = "never",
			["xOffset"] = 0,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["yOffset"] = 0,
			["anchorPoint"] = "RIGHT",
			["displayText_format_p_time_format"] = 0,
			["url"] = "https://wago.io/YP6nljWXe/7",
			["icon"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "LEFT",
			["displayText_format_destUnit_color"] = "class",
			["desc"] = "Checks nearest 20 nameplates and shows a starfall icon if they are in range of starfall (36 yrds). \n\nHelps you make any decisions about using starfall and to stop any ninja pulls. \n\nIf you want more nameplates you can simply duplicate one of the weak auras in the group and add a number to the trigger. \n\nIf anyone finds an easier way to make this kind of a weak aura let me know as this was made editing a pre existing weak aura with a similar function.",
			["font"] = "PT Sans Narrow",
			["load"] = {
				["use_never"] = false,
				["class"] = {
					["single"] = "DRUID",
					["multi"] = {
						["DRUID"] = true,
					},
				},
				["use_encounterid"] = false,
				["use_class"] = true,
				["use_itemequiped"] = false,
				["zoneIds"] = "",
				["use_not_item_bonusid_equipped"] = false,
				["talent2"] = {
					["multi"] = {
						[20] = false,
					},
				},
				["use_zoneIds"] = false,
				["item_bonusid_equipped"] = "62080",
				["spec"] = {
					["multi"] = {
					},
				},
				["not_item_bonusid_equipped"] = "62080",
				["use_talent"] = false,
				["use_spellknown"] = false,
				["talent"] = {
					["multi"] = {
						[24] = true,
					},
				},
				["itemequiped"] = {
					62080, -- [1]
				},
				["size"] = {
					["multi"] = {
					},
				},
				["use_exact_spellknown"] = false,
				["use_item_bonusid_equipped"] = false,
				["itemtypeequipped"] = {
				},
			},
			["displayText_format_1.maxRange_format"] = "none",
			["shadowXOffset"] = 1,
			["displayText_format_1.minRange_abbreviate"] = false,
			["regionType"] = "icon",
			["displayText_format_destUnit_abbreviate_max"] = 8,
			["zoom"] = 0,
			["displayText_format_destUnit_format"] = "Unit",
			["tocversion"] = 30401,
			["alpha"] = 1,
			["config"] = {
			},
			["fixedWidth"] = 200,
			["outline"] = "OUTLINE",
			["wagoID"] = "YP6nljWXe",
			["parent"] = "Starfall Range Check on Nameplate",
			["shadowYOffset"] = -1,
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "event",
			["automaticWidth"] = "Auto",
			["triggers"] = {
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "35",
						["unit"] = "nameplate18",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [1]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "20",
						["unit"] = "nameplate18",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = false,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [6]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "15",
						["unit"] = "nameplate18",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [7]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate18",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [8]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [9]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [10]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate18",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [11]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    if trigger[1] and trigger[3] and trigger[5] then\n        return true\n    elseif trigger[2] and trigger[4] and trigger[5] then\n        return true\n    elseif trigger[3] and trigger[8] and trigger[6] then\n        return true\n    elseif trigger[4] and trigger[7] and trigger[6] then\n        return true\n    elseif trigger[4] and (trigger[9] and trigger[10]) and trigger[7] then\n        return true\n    elseif trigger[3] and (trigger[9] and trigger[10]) and trigger[11] then\n        return true\n    end\nend",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["version"] = 7,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%maxRange",
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = false,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_text_format_p_time_mod_rate"] = true,
					["anchorXOffset"] = 0,
					["text_text_format_minRange_format"] = "none",
					["type"] = "subtext",
					["text_text_format_maxRange_format"] = "none",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_text_format_p_time_format"] = 0,
					["text_shadowYOffset"] = 0,
					["text_fontType"] = "OUTLINE",
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "CENTER",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["anchorYOffset"] = 0,
					["text_fontSize"] = 12,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_text_format_p_time_precision"] = 1,
				}, -- [2]
			},
			["height"] = 25,
			["displayText_format_destUnit_realm_name"] = "never",
			["preferToUpdate"] = false,
			["information"] = {
				["forceEvents"] = true,
			},
			["displayText_format_1.minRange_color"] = true,
			["source"] = "import",
			["conditions"] = {
			},
			["displayIcon"] = 236168,
			["cooldownTextDisabled"] = false,
			["displayText_format_1.minRange_round_type"] = "ceil",
			["authorOptions"] = {
			},
			["desaturate"] = false,
			["wordWrap"] = "WordWrap",
			["anchorFrameType"] = "NAMEPLATE",
			["useCooldownModRate"] = true,
			["displayText_format_destUnit_abbreviate"] = false,
			["displayText_format_1.minRange_format"] = "Number",
			["displayText_format_p_time_precision"] = 1,
			["color"] = {
				0.97647058823529, -- [1]
				1, -- [2]
				0.97647058823529, -- [3]
				1, -- [4]
			},
			["justify"] = "LEFT",
			["uid"] = "rXt7TWdyGEq",
			["semver"] = "1.0.6",
			["displayText"] = "%1.maxRange",
			["id"] = "Nameplate range check 18 ",
			["anchorFrameParent"] = false,
			["frameStrata"] = 1,
			["width"] = 25,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["fontSize"] = 16,
			["inverse"] = false,
			["displayText_format_1.minRange_abbreviate_max"] = 8,
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["displayText_format_1.minRange_decimal_precision"] = 0,
			["cooldown"] = false,
			["cooldownEdge"] = false,
		},
		["Hunger For Blood"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["showClones"] = false,
						["type"] = "aura2",
						["auraspellids"] = {
							"146739", -- [1]
						},
						["useExactSpellId"] = false,
						["matchesShowOn"] = "showOnActive",
						["event"] = "Health",
						["unit"] = "player",
						["unitExists"] = true,
						["subeventSuffix"] = "_CAST_START",
						["spellIds"] = {
						},
						["names"] = {
						},
						["subeventPrefix"] = "SPELL",
						["useName"] = true,
						["auranames"] = {
							"63848", -- [1]
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["customTriggerLogic"] = "",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
						[27] = true,
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["zoneIds"] = "",
				["use_talent"] = false,
				["use_class"] = true,
				["race"] = {
				},
				["use_spellknown"] = false,
				["use_spec"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["role"] = {
					["single"] = "DAMAGER",
					["multi"] = {
						["DAMAGER"] = true,
					},
				},
				["spellknown"] = 34503,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "jhaxZ1hKs)e",
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["icon"] = true,
			["regionType"] = "icon",
			["cooldown"] = true,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["parent"] = "Dynamic Effects - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Hunger For Blood",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = false,
			["desc"] = "",
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "Pixel",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
			},
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["authorOptions"] = {
			},
		},
		["Nameplate range check 12"] = {
			["iconSource"] = 0,
			["displayText_format_1.minRange_realm_name"] = "never",
			["xOffset"] = 0,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["yOffset"] = 0,
			["anchorPoint"] = "RIGHT",
			["displayText_format_p_time_format"] = 0,
			["url"] = "https://wago.io/YP6nljWXe/7",
			["icon"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "LEFT",
			["displayText_format_destUnit_color"] = "class",
			["desc"] = "Checks nearest 20 nameplates and shows a starfall icon if they are in range of starfall (36 yrds). \n\nHelps you make any decisions about using starfall and to stop any ninja pulls. \n\nIf you want more nameplates you can simply duplicate one of the weak auras in the group and add a number to the trigger. \n\nIf anyone finds an easier way to make this kind of a weak aura let me know as this was made editing a pre existing weak aura with a similar function.",
			["font"] = "PT Sans Narrow",
			["load"] = {
				["use_never"] = false,
				["class"] = {
					["single"] = "DRUID",
					["multi"] = {
						["DRUID"] = true,
					},
				},
				["use_encounterid"] = false,
				["use_class"] = true,
				["use_itemequiped"] = false,
				["zoneIds"] = "",
				["use_not_item_bonusid_equipped"] = false,
				["talent2"] = {
					["multi"] = {
						[20] = false,
					},
				},
				["use_zoneIds"] = false,
				["item_bonusid_equipped"] = "62080",
				["spec"] = {
					["multi"] = {
					},
				},
				["not_item_bonusid_equipped"] = "62080",
				["use_talent"] = false,
				["use_spellknown"] = false,
				["talent"] = {
					["multi"] = {
						[24] = true,
					},
				},
				["itemequiped"] = {
					62080, -- [1]
				},
				["size"] = {
					["multi"] = {
					},
				},
				["use_exact_spellknown"] = false,
				["use_item_bonusid_equipped"] = false,
				["itemtypeequipped"] = {
				},
			},
			["displayText_format_1.maxRange_format"] = "none",
			["shadowXOffset"] = 1,
			["displayText_format_1.minRange_abbreviate"] = false,
			["regionType"] = "icon",
			["displayText_format_destUnit_abbreviate_max"] = 8,
			["zoom"] = 0,
			["displayText_format_destUnit_format"] = "Unit",
			["tocversion"] = 30401,
			["alpha"] = 1,
			["config"] = {
			},
			["fixedWidth"] = 200,
			["outline"] = "OUTLINE",
			["wagoID"] = "YP6nljWXe",
			["parent"] = "Starfall Range Check on Nameplate",
			["shadowYOffset"] = -1,
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "event",
			["automaticWidth"] = "Auto",
			["triggers"] = {
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "35",
						["unit"] = "nameplate12",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [1]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "20",
						["unit"] = "nameplate12",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = false,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [6]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "15",
						["unit"] = "nameplate12",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [7]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate12",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [8]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [9]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [10]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate12",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [11]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    if trigger[1] and trigger[3] and trigger[5] then\n        return true\n    elseif trigger[2] and trigger[4] and trigger[5] then\n        return true\n    elseif trigger[3] and trigger[8] and trigger[6] then\n        return true\n    elseif trigger[4] and trigger[7] and trigger[6] then\n        return true\n    elseif trigger[4] and (trigger[9] and trigger[10]) and trigger[7] then\n        return true\n    elseif trigger[3] and (trigger[9] and trigger[10]) and trigger[11] then\n        return true\n    end\nend",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["version"] = 7,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%maxRange",
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = false,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_text_format_p_time_mod_rate"] = true,
					["anchorXOffset"] = 0,
					["text_text_format_minRange_format"] = "none",
					["type"] = "subtext",
					["text_text_format_maxRange_format"] = "none",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_text_format_p_time_format"] = 0,
					["text_shadowYOffset"] = 0,
					["text_fontType"] = "OUTLINE",
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "CENTER",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["anchorYOffset"] = 0,
					["text_fontSize"] = 12,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_text_format_p_time_precision"] = 1,
				}, -- [2]
			},
			["height"] = 25,
			["displayText_format_destUnit_realm_name"] = "never",
			["preferToUpdate"] = false,
			["information"] = {
				["forceEvents"] = true,
			},
			["displayText_format_1.minRange_color"] = true,
			["source"] = "import",
			["conditions"] = {
			},
			["displayIcon"] = 236168,
			["cooldownTextDisabled"] = false,
			["displayText_format_1.minRange_round_type"] = "ceil",
			["authorOptions"] = {
			},
			["desaturate"] = false,
			["wordWrap"] = "WordWrap",
			["anchorFrameType"] = "NAMEPLATE",
			["useCooldownModRate"] = true,
			["displayText_format_destUnit_abbreviate"] = false,
			["displayText_format_1.minRange_format"] = "Number",
			["displayText_format_p_time_precision"] = 1,
			["color"] = {
				0.97647058823529, -- [1]
				1, -- [2]
				0.97647058823529, -- [3]
				1, -- [4]
			},
			["justify"] = "LEFT",
			["uid"] = "3KrWLLzkc(0",
			["semver"] = "1.0.6",
			["displayText"] = "%1.maxRange",
			["id"] = "Nameplate range check 12",
			["anchorFrameParent"] = false,
			["frameStrata"] = 1,
			["width"] = 25,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["fontSize"] = 16,
			["inverse"] = false,
			["displayText_format_1.minRange_abbreviate_max"] = 8,
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["displayText_format_1.minRange_decimal_precision"] = 0,
			["cooldown"] = false,
			["cooldownEdge"] = false,
		},
		["Nameplate range check 1"] = {
			["iconSource"] = 0,
			["displayText_format_1.minRange_realm_name"] = "never",
			["xOffset"] = 0,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["yOffset"] = 0,
			["anchorPoint"] = "RIGHT",
			["displayText_format_p_time_format"] = 0,
			["url"] = "https://wago.io/YP6nljWXe/7",
			["icon"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "LEFT",
			["displayText_format_destUnit_color"] = "class",
			["desc"] = "Checks nearest 20 nameplates and shows a starfall icon if they are in range of starfall (36 yrds). \n\nHelps you make any decisions about using starfall and to stop any ninja pulls. \n\nIf you want more nameplates you can simply duplicate one of the weak auras in the group and add a number to the trigger. \n\nIf anyone finds an easier way to make this kind of a weak aura let me know as this was made editing a pre existing weak aura with a similar function.",
			["font"] = "PT Sans Narrow",
			["load"] = {
				["use_never"] = false,
				["class"] = {
					["single"] = "DRUID",
					["multi"] = {
						["DRUID"] = true,
					},
				},
				["use_encounterid"] = false,
				["use_class"] = true,
				["use_itemequiped"] = false,
				["zoneIds"] = "",
				["use_not_item_bonusid_equipped"] = false,
				["talent2"] = {
					["multi"] = {
						[20] = false,
					},
				},
				["use_zoneIds"] = false,
				["item_bonusid_equipped"] = "62080",
				["spec"] = {
					["multi"] = {
					},
				},
				["not_item_bonusid_equipped"] = "62080",
				["use_talent"] = false,
				["use_spellknown"] = false,
				["talent"] = {
					["multi"] = {
						[24] = true,
					},
				},
				["itemequiped"] = {
					62080, -- [1]
				},
				["size"] = {
					["multi"] = {
					},
				},
				["use_exact_spellknown"] = false,
				["use_item_bonusid_equipped"] = false,
				["itemtypeequipped"] = {
				},
			},
			["displayText_format_1.maxRange_format"] = "none",
			["shadowXOffset"] = 1,
			["displayText_format_1.minRange_abbreviate"] = false,
			["regionType"] = "icon",
			["displayText_format_destUnit_abbreviate_max"] = 8,
			["zoom"] = 0,
			["displayText_format_destUnit_format"] = "Unit",
			["tocversion"] = 30401,
			["alpha"] = 1,
			["config"] = {
			},
			["fixedWidth"] = 200,
			["outline"] = "OUTLINE",
			["wagoID"] = "YP6nljWXe",
			["parent"] = "Starfall Range Check on Nameplate",
			["shadowYOffset"] = -1,
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "event",
			["automaticWidth"] = "Auto",
			["triggers"] = {
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "35",
						["unit"] = "nameplate1",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [1]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "20",
						["unit"] = "nameplate1",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = false,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [6]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "15",
						["unit"] = "nameplate1",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [7]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate1",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [8]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [9]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [10]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate1",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [11]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    if trigger[1] and trigger[3] and trigger[5] then\n        return true\n    elseif trigger[2] and trigger[4] and trigger[5] then\n        return true\n    elseif trigger[3] and trigger[8] and trigger[6] then\n        return true\n    elseif trigger[4] and trigger[7] and trigger[6] then\n        return true\n    elseif trigger[4] and (trigger[9] and trigger[10]) and trigger[7] then\n        return true\n    elseif trigger[3] and (trigger[9] and trigger[10]) and trigger[11] then\n        return true\n    end\nend",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["version"] = 7,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%maxRange",
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = false,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_text_format_p_time_mod_rate"] = true,
					["anchorXOffset"] = 0,
					["text_text_format_minRange_format"] = "none",
					["type"] = "subtext",
					["text_text_format_maxRange_format"] = "none",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_text_format_p_time_format"] = 0,
					["text_shadowYOffset"] = 0,
					["text_fontType"] = "OUTLINE",
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "CENTER",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["anchorYOffset"] = 0,
					["text_fontSize"] = 12,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_text_format_p_time_precision"] = 1,
				}, -- [2]
			},
			["height"] = 25,
			["displayText_format_destUnit_realm_name"] = "never",
			["preferToUpdate"] = false,
			["information"] = {
				["forceEvents"] = true,
			},
			["displayText_format_1.minRange_color"] = true,
			["source"] = "import",
			["conditions"] = {
			},
			["displayIcon"] = 236168,
			["cooldownTextDisabled"] = false,
			["displayText_format_1.minRange_round_type"] = "ceil",
			["authorOptions"] = {
			},
			["desaturate"] = false,
			["wordWrap"] = "WordWrap",
			["anchorFrameType"] = "NAMEPLATE",
			["useCooldownModRate"] = true,
			["displayText_format_destUnit_abbreviate"] = false,
			["displayText_format_1.minRange_format"] = "Number",
			["displayText_format_p_time_precision"] = 1,
			["color"] = {
				0.97647058823529, -- [1]
				1, -- [2]
				0.97647058823529, -- [3]
				1, -- [4]
			},
			["justify"] = "LEFT",
			["uid"] = "VVpkATVaEjK",
			["semver"] = "1.0.6",
			["displayText"] = "%1.maxRange",
			["id"] = "Nameplate range check 1",
			["anchorFrameParent"] = false,
			["frameStrata"] = 1,
			["width"] = 25,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["fontSize"] = 16,
			["inverse"] = false,
			["displayText_format_1.minRange_abbreviate_max"] = 8,
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["displayText_format_1.minRange_decimal_precision"] = 0,
			["cooldown"] = false,
			["cooldownEdge"] = false,
		},
		["Blade Flurry"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "aura2",
						["auranames"] = {
							"13877", -- [1]
						},
						["ownOnly"] = true,
						["event"] = "Health",
						["unit"] = "player",
						["spellIds"] = {
						},
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["useName"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["track"] = "auto",
						["use_matchedRune"] = false,
						["duration"] = "1",
						["genericShowOn"] = "showAlways",
						["names"] = {
						},
						["use_showgcd"] = false,
						["debuffType"] = "HELPFUL",
						["type"] = "spell",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "Blade Flurry",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["subeventPrefix"] = "SPELL",
						["use_genericShowOn"] = true,
						["use_track"] = true,
						["spellName"] = 13877,
					},
					["untrigger"] = {
						["genericShowOn"] = "showAlways",
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["class_and_spec"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["use_class"] = true,
				["use_spellknown"] = true,
				["zoneIds"] = "",
				["use_spec"] = true,
				["spec"] = {
					["single"] = 2,
					["multi"] = {
						[3] = true,
					},
				},
				["use_never"] = false,
				["spellknown"] = 13877,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "t2lE)HwvhWt",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = false,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "buttonOverlay",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -1,
						["variable"] = "incombat",
						["value"] = 0,
					},
					["changes"] = {
						{
							["property"] = "sub.3.glow",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [3]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "Pixel",
							["property"] = "sub.3.glowType",
						}, -- [2]
						{
							["property"] = "desaturate",
						}, -- [3]
						{
							["property"] = "inverse",
						}, -- [4]
						{
							["value"] = true,
							["property"] = "cooldownEdge",
						}, -- [5]
					},
				}, -- [4]
			},
			["parent"] = "Core - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Blade Flurry",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["displayIcon"] = "",
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Overkill"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["showClones"] = false,
						["type"] = "aura2",
						["auraspellids"] = {
							"146739", -- [1]
						},
						["useExactSpellId"] = false,
						["matchesShowOn"] = "showOnActive",
						["event"] = "Health",
						["unit"] = "player",
						["unitExists"] = true,
						["subeventSuffix"] = "_CAST_START",
						["spellIds"] = {
						},
						["names"] = {
						},
						["subeventPrefix"] = "SPELL",
						["useName"] = true,
						["auranames"] = {
							"58427", -- [1]
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["customTriggerLogic"] = "",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
						[12] = true,
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["zoneIds"] = "",
				["use_talent"] = false,
				["use_class"] = true,
				["race"] = {
				},
				["use_spellknown"] = false,
				["use_spec"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["role"] = {
					["single"] = "DAMAGER",
					["multi"] = {
						["DAMAGER"] = true,
					},
				},
				["spellknown"] = 34503,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "X8q2R68yrMH",
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["icon"] = true,
			["regionType"] = "icon",
			["cooldown"] = true,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["parent"] = "Dynamic Effects - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Overkill",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = false,
			["desc"] = "",
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "Pixel",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
			},
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["authorOptions"] = {
			},
		},
		["Riposte"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["track"] = "auto",
						["use_matchedRune"] = false,
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showAlways",
						["unit"] = "player",
						["use_showgcd"] = false,
						["debuffType"] = "HELPFUL",
						["type"] = "spell",
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Cooldown Progress (Spell)",
						["use_exact_spellName"] = false,
						["realSpellName"] = "Riposte",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["spellName"] = 14251,
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["use_track"] = true,
						["names"] = {
						},
					},
					["untrigger"] = {
						["genericShowOn"] = "showAlways",
					},
				}, -- [1]
				["disjunctive"] = "all",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["class_and_spec"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["zoneIds"] = "",
				["use_class"] = true,
				["use_spellknown"] = true,
				["use_never"] = false,
				["use_spec"] = true,
				["spec"] = {
					["single"] = 2,
					["multi"] = {
						[3] = true,
					},
				},
				["use_exact_spellknown"] = false,
				["spellknown"] = 14251,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "6D6mcgmJusU",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = -2,
						["variable"] = "AND",
						["checks"] = {
							{
								["trigger"] = 1,
								["variable"] = "onCooldown",
								["value"] = 0,
							}, -- [1]
							{
								["trigger"] = 1,
								["variable"] = "spellUsable",
								["value"] = 1,
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "buttonOverlay",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -1,
						["variable"] = "incombat",
						["value"] = 0,
					},
					["changes"] = {
						{
							["property"] = "sub.3.glow",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "onCooldown",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [3]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "spellUsable",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [4]
				{
					["check"] = {
						["trigger"] = -2,
						["variable"] = "AND",
						["checks"] = {
							{
								["trigger"] = 1,
								["variable"] = "spellUsable",
								["value"] = 1,
							}, -- [1]
							{
								["trigger"] = 1,
								["variable"] = "onCooldown",
								["value"] = 0,
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [5]
			},
			["parent"] = "Core - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Riposte",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["displayIcon"] = "",
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Slice and Dice"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["parent"] = "Core - Rogue",
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["showClones"] = false,
						["type"] = "aura2",
						["useName"] = true,
						["useExactSpellId"] = false,
						["subeventSuffix"] = "_CAST_START",
						["ownOnly"] = true,
						["event"] = "Health",
						["unit"] = "player",
						["unitExists"] = true,
						["names"] = {
						},
						["spellIds"] = {
						},
						["auraspellids"] = {
							"146739", -- [1]
						},
						["subeventPrefix"] = "SPELL",
						["auranames"] = {
							"5171", -- [1]
						},
						["matchesShowOn"] = "showAlways",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["customTriggerLogic"] = "",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["zoneIds"] = "",
				["use_class"] = true,
				["race"] = {
				},
				["use_spellknown"] = true,
				["use_spec"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["role"] = {
					["single"] = "DAMAGER",
					["multi"] = {
						["DAMAGER"] = true,
					},
				},
				["spellknown"] = 5171,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["config"] = {
			},
			["zoom"] = 0.3,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["regionType"] = "icon",
			["cooldownEdge"] = true,
			["cooldown"] = true,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["auto"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Slice and Dice",
			["alpha"] = 1,
			["useCooldownModRate"] = true,
			["anchorFrameType"] = "SCREEN",
			["frameStrata"] = 1,
			["uid"] = "jwowMTfqGSk",
			["inverse"] = false,
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 0,
					},
					["changes"] = {
						{
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "buttonOverlay",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "buffed",
						["value"] = 0,
						["checks"] = {
							{
								["trigger"] = 1,
								["variable"] = "show",
								["value"] = 0,
							}, -- [1]
							{
								["value"] = "0",
								["op"] = "==",
								["variable"] = "matchCount",
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
						{
							["value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								0.5, -- [4]
							},
							["property"] = "color",
						}, -- [2]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "buffed",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "Pixel",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [3]
			},
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["xOffset"] = 0,
		},
		["Evasion"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["useMatch_count"] = true,
						["match_countOperator"] = ">",
						["auranames"] = {
							"5277", -- [1]
						},
						["ownOnly"] = true,
						["event"] = "Health",
						["unit"] = "player",
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["spellIds"] = {
						},
						["subeventPrefix"] = "SPELL",
						["match_count"] = "0",
						["type"] = "aura2",
						["useName"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["track"] = "auto",
						["use_matchedRune"] = false,
						["duration"] = "1",
						["genericShowOn"] = "showAlways",
						["names"] = {
						},
						["use_showgcd"] = true,
						["debuffType"] = "HELPFUL",
						["type"] = "spell",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "Evasion",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["subeventPrefix"] = "SPELL",
						["use_genericShowOn"] = true,
						["use_track"] = true,
						["spellName"] = 5277,
					},
					["untrigger"] = {
						["genericShowOn"] = "showAlways",
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["class_and_spec"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["use_class"] = true,
				["use_spellknown"] = true,
				["zoneIds"] = "",
				["use_spec"] = true,
				["spec"] = {
					["single"] = 2,
					["multi"] = {
						[3] = true,
					},
				},
				["use_never"] = false,
				["spellknown"] = 5277,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = ")QfT4aqWnHS",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = false,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "buttonOverlay",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -1,
						["variable"] = "incombat",
						["value"] = 0,
					},
					["changes"] = {
						{
							["property"] = "sub.3.glow",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [3]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "Pixel",
							["property"] = "sub.3.glowType",
						}, -- [2]
						{
							["property"] = "desaturate",
						}, -- [3]
						{
							["property"] = "inverse",
						}, -- [4]
						{
							["value"] = true,
							["property"] = "cooldownEdge",
						}, -- [5]
					},
				}, -- [4]
			},
			["parent"] = "Core - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Evasion",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["displayIcon"] = "",
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Starfall Range Check on Nameplate"] = {
			["controlledChildren"] = {
				"Nameplate range check 1", -- [1]
				"Nameplate range check 2", -- [2]
				"Nameplate range check 3", -- [3]
				"Nameplate range check 4 ", -- [4]
				"Nameplate range check 5", -- [5]
				"Nameplate range check 6", -- [6]
				"Nameplate range check 7 ", -- [7]
				"Nameplate range check 8 ", -- [8]
				"Nameplate range check 9 ", -- [9]
				"Nameplate range check 10 ", -- [10]
				"Nameplate range check 11 ", -- [11]
				"Nameplate range check 12", -- [12]
				"Nameplate range check 13 ", -- [13]
				"Nameplate range check 14 ", -- [14]
				"Nameplate range check 15 ", -- [15]
				"Nameplate range check 16 ", -- [16]
				"Nameplate range check 17 ", -- [17]
				"Nameplate range check 18 ", -- [18]
				"Nameplate range check 19 ", -- [19]
				"Nameplate range check 20 ", -- [20]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["wagoID"] = "YP6nljWXe",
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["url"] = "https://wago.io/YP6nljWXe/7",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["unit"] = "player",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["desc"] = "Checks nearest 20 nameplates and shows a starfall icon if they are in range of starfall (36 yrds). \n\nHelps you make any decisions about using starfall and to stop any ninja pulls. \n\nIf you want more nameplates you can simply duplicate one of the weak auras in the group and add a number to the trigger. \n\nIf anyone finds an easier way to make this kind of a weak aura let me know as this was made editing a pre existing weak aura with a similar function.\n",
			["version"] = 7,
			["subRegions"] = {
			},
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["zoneIds"] = "",
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["source"] = "import",
			["scale"] = 1,
			["border"] = false,
			["borderEdge"] = "Square Full White",
			["regionType"] = "group",
			["borderSize"] = 2,
			["borderOffset"] = 4,
			["semver"] = "1.0.6",
			["tocversion"] = 30401,
			["id"] = "Starfall Range Check on Nameplate",
			["config"] = {
			},
			["frameStrata"] = 2,
			["anchorFrameType"] = "SCREEN",
			["xOffset"] = 0,
			["uid"] = "D(XeUqH2r8x",
			["borderInset"] = 1,
			["groupIcon"] = 236168,
			["conditions"] = {
			},
			["information"] = {
				["forceEvents"] = true,
			},
			["selfPoint"] = "CENTER",
		},
		["Nameplate range check 16 "] = {
			["iconSource"] = 0,
			["displayText_format_1.minRange_realm_name"] = "never",
			["xOffset"] = 0,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["yOffset"] = 0,
			["anchorPoint"] = "RIGHT",
			["displayText_format_p_time_format"] = 0,
			["url"] = "https://wago.io/YP6nljWXe/7",
			["icon"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "LEFT",
			["displayText_format_destUnit_color"] = "class",
			["desc"] = "Checks nearest 20 nameplates and shows a starfall icon if they are in range of starfall (36 yrds). \n\nHelps you make any decisions about using starfall and to stop any ninja pulls. \n\nIf you want more nameplates you can simply duplicate one of the weak auras in the group and add a number to the trigger. \n\nIf anyone finds an easier way to make this kind of a weak aura let me know as this was made editing a pre existing weak aura with a similar function.",
			["font"] = "PT Sans Narrow",
			["load"] = {
				["use_never"] = false,
				["class"] = {
					["single"] = "DRUID",
					["multi"] = {
						["DRUID"] = true,
					},
				},
				["use_encounterid"] = false,
				["use_class"] = true,
				["use_itemequiped"] = false,
				["zoneIds"] = "",
				["use_not_item_bonusid_equipped"] = false,
				["talent2"] = {
					["multi"] = {
						[20] = false,
					},
				},
				["use_zoneIds"] = false,
				["item_bonusid_equipped"] = "62080",
				["spec"] = {
					["multi"] = {
					},
				},
				["not_item_bonusid_equipped"] = "62080",
				["use_talent"] = false,
				["use_spellknown"] = false,
				["talent"] = {
					["multi"] = {
						[24] = true,
					},
				},
				["itemequiped"] = {
					62080, -- [1]
				},
				["size"] = {
					["multi"] = {
					},
				},
				["use_exact_spellknown"] = false,
				["use_item_bonusid_equipped"] = false,
				["itemtypeequipped"] = {
				},
			},
			["displayText_format_1.maxRange_format"] = "none",
			["shadowXOffset"] = 1,
			["displayText_format_1.minRange_abbreviate"] = false,
			["regionType"] = "icon",
			["displayText_format_destUnit_abbreviate_max"] = 8,
			["zoom"] = 0,
			["displayText_format_destUnit_format"] = "Unit",
			["tocversion"] = 30401,
			["alpha"] = 1,
			["config"] = {
			},
			["fixedWidth"] = 200,
			["outline"] = "OUTLINE",
			["wagoID"] = "YP6nljWXe",
			["parent"] = "Starfall Range Check on Nameplate",
			["shadowYOffset"] = -1,
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "event",
			["automaticWidth"] = "Auto",
			["triggers"] = {
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "35",
						["unit"] = "nameplate16",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [1]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "20",
						["unit"] = "nameplate16",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = false,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [6]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "15",
						["unit"] = "nameplate16",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [7]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate16",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [8]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [9]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [10]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate16",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [11]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    if trigger[1] and trigger[3] and trigger[5] then\n        return true\n    elseif trigger[2] and trigger[4] and trigger[5] then\n        return true\n    elseif trigger[3] and trigger[8] and trigger[6] then\n        return true\n    elseif trigger[4] and trigger[7] and trigger[6] then\n        return true\n    elseif trigger[4] and (trigger[9] and trigger[10]) and trigger[7] then\n        return true\n    elseif trigger[3] and (trigger[9] and trigger[10]) and trigger[11] then\n        return true\n    end\nend",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["version"] = 7,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%maxRange",
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = false,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_text_format_p_time_mod_rate"] = true,
					["anchorXOffset"] = 0,
					["text_text_format_minRange_format"] = "none",
					["type"] = "subtext",
					["text_text_format_maxRange_format"] = "none",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_text_format_p_time_format"] = 0,
					["text_shadowYOffset"] = 0,
					["text_fontType"] = "OUTLINE",
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "CENTER",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["anchorYOffset"] = 0,
					["text_fontSize"] = 12,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_text_format_p_time_precision"] = 1,
				}, -- [2]
			},
			["height"] = 25,
			["displayText_format_destUnit_realm_name"] = "never",
			["preferToUpdate"] = false,
			["information"] = {
				["forceEvents"] = true,
			},
			["displayText_format_1.minRange_color"] = true,
			["source"] = "import",
			["conditions"] = {
			},
			["displayIcon"] = 236168,
			["cooldownTextDisabled"] = false,
			["displayText_format_1.minRange_round_type"] = "ceil",
			["authorOptions"] = {
			},
			["desaturate"] = false,
			["wordWrap"] = "WordWrap",
			["anchorFrameType"] = "NAMEPLATE",
			["useCooldownModRate"] = true,
			["displayText_format_destUnit_abbreviate"] = false,
			["displayText_format_1.minRange_format"] = "Number",
			["displayText_format_p_time_precision"] = 1,
			["color"] = {
				0.97647058823529, -- [1]
				1, -- [2]
				0.97647058823529, -- [3]
				1, -- [4]
			},
			["justify"] = "LEFT",
			["uid"] = "JwCcFbuWhMK",
			["semver"] = "1.0.6",
			["displayText"] = "%1.maxRange",
			["id"] = "Nameplate range check 16 ",
			["anchorFrameParent"] = false,
			["frameStrata"] = 1,
			["width"] = 25,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["fontSize"] = 16,
			["inverse"] = false,
			["displayText_format_1.minRange_abbreviate_max"] = 8,
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["displayText_format_1.minRange_decimal_precision"] = 0,
			["cooldown"] = false,
			["cooldownEdge"] = false,
		},
		["Cloak of Shadows"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["useMatch_count"] = true,
						["match_countOperator"] = ">",
						["auranames"] = {
							"31224", -- [1]
						},
						["ownOnly"] = true,
						["event"] = "Health",
						["unit"] = "player",
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["spellIds"] = {
						},
						["subeventPrefix"] = "SPELL",
						["match_count"] = "0",
						["type"] = "aura2",
						["useName"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["track"] = "auto",
						["use_matchedRune"] = false,
						["duration"] = "1",
						["genericShowOn"] = "showAlways",
						["names"] = {
						},
						["use_showgcd"] = true,
						["debuffType"] = "HELPFUL",
						["type"] = "spell",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "Cloak of Shadows",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["subeventPrefix"] = "SPELL",
						["use_genericShowOn"] = true,
						["use_track"] = true,
						["spellName"] = 31224,
					},
					["untrigger"] = {
						["genericShowOn"] = "showAlways",
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["class_and_spec"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["use_class"] = true,
				["use_spellknown"] = true,
				["zoneIds"] = "",
				["use_spec"] = true,
				["spec"] = {
					["single"] = 2,
					["multi"] = {
						[3] = true,
					},
				},
				["use_never"] = false,
				["spellknown"] = 31224,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "RQOB8LmlmCa",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = false,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "buttonOverlay",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -1,
						["variable"] = "incombat",
						["value"] = 0,
					},
					["changes"] = {
						{
							["property"] = "sub.3.glow",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [3]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "Pixel",
							["property"] = "sub.3.glowType",
						}, -- [2]
						{
							["property"] = "desaturate",
						}, -- [3]
						{
							["property"] = "inverse",
						}, -- [4]
						{
							["value"] = true,
							["property"] = "cooldownEdge",
						}, -- [5]
					},
				}, -- [4]
			},
			["parent"] = "Core - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Cloak of Shadows",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["displayIcon"] = "",
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Core - Rogue"] = {
			["grow"] = "CUSTOM",
			["controlledChildren"] = {
				"Ghostly Strike", -- [1]
				"Rupture", -- [2]
				"Envenom", -- [3]
				"Slice and Dice", -- [4]
				"Expose Armor", -- [5]
				"Riposte", -- [6]
				"Blade Flurry", -- [7]
				"Killing Spree", -- [8]
				"Adrenaline Rush", -- [9]
				"Shadow Dance", -- [10]
				"Cold Blood", -- [11]
				"Premeditation", -- [12]
				"Preparation", -- [13]
				"Kidney Shot", -- [14]
				"Kick", -- [15]
				"Gouge", -- [16]
				"Dismantle", -- [17]
				"Evasion", -- [18]
				"Cloak of Shadows", -- [19]
				"Shadowstep", -- [20]
				"Sprint", -- [21]
				"Tricks of the Trade", -- [22]
				"Blind", -- [23]
				"Feint", -- [24]
				"Distract", -- [25]
				"Vanish", -- [26]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = -6.103515625e-05,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["animate"] = false,
			["frameStrata"] = 1,
			["fullCircle"] = true,
			["space"] = 2,
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["names"] = {
						},
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["unit"] = "player",
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 1,
			["internalVersion"] = 70,
			["stagger"] = 0,
			["useLimit"] = false,
			["align"] = "CENTER",
			["growOn"] = "changed",
			["radius"] = 200,
			["desc"] = "Made by Luxthos - twitch.tv/luxthos",
			["rotation"] = 0,
			["sortHybridTable"] = {
				["Sprint"] = false,
				["Evasion"] = false,
				["Expose Armor"] = false,
				["Riposte"] = false,
				["Killing Spree"] = false,
				["Blade Flurry"] = false,
				["Slice and Dice"] = false,
				["Rupture"] = false,
				["Envenom"] = false,
				["Shadow Dance"] = false,
				["Preparation"] = false,
				["Kick"] = false,
				["Blind"] = false,
				["Ghostly Strike"] = false,
				["Gouge"] = false,
				["Dismantle"] = false,
				["Premeditation"] = false,
				["Distract"] = false,
				["Adrenaline Rush"] = false,
				["Cold Blood"] = false,
				["Shadowstep"] = false,
				["Kidney Shot"] = false,
				["Feint"] = false,
				["Tricks of the Trade"] = false,
				["Cloak of Shadows"] = false,
				["Vanish"] = false,
			},
			["version"] = 25,
			["subRegions"] = {
			},
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["selfPoint"] = "TOP",
			["load"] = {
				["size"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
			},
			["parent"] = "Luxthos - Rogue",
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["uid"] = "SmPiGrw(yso",
			["source"] = "import",
			["customGrow"] = "function(newPositions, activeRegions)\n    local LWA = LWA and LWA[\"Rogue\"] or {}\n\n    if LWA and LWA.GrowCore then\n        LWA.GrowCore(newPositions, activeRegions)\n    end\nend",
			["scale"] = 1,
			["centerType"] = "LR",
			["border"] = false,
			["borderEdge"] = "Square Full White",
			["stepAngle"] = 15,
			["borderSize"] = 2,
			["sort"] = "none",
			["regionType"] = "dynamicgroup",
			["config"] = {
			},
			["constantFactor"] = "RADIUS",
			["rowSpace"] = 1,
			["borderOffset"] = 4,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Core - Rogue",
			["limit"] = 5,
			["gridWidth"] = 5,
			["anchorFrameType"] = "SCREEN",
			["authorOptions"] = {
			},
			["borderInset"] = 1,
			["gridType"] = "RD",
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["conditions"] = {
			},
			["information"] = {
				["forceEvents"] = true,
			},
			["arcLength"] = 360,
		},
		["Kidney Shot"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "aura2",
						["auranames"] = {
							"408", -- [1]
						},
						["ownOnly"] = true,
						["event"] = "Health",
						["unit"] = "target",
						["spellIds"] = {
						},
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["useName"] = true,
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["track"] = "auto",
						["use_matchedRune"] = false,
						["duration"] = "1",
						["genericShowOn"] = "showAlways",
						["names"] = {
						},
						["use_showgcd"] = true,
						["debuffType"] = "HELPFUL",
						["type"] = "spell",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "Kidney Shot",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["subeventPrefix"] = "SPELL",
						["use_genericShowOn"] = true,
						["use_track"] = true,
						["spellName"] = 408,
					},
					["untrigger"] = {
						["genericShowOn"] = "showAlways",
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["class_and_spec"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["use_class"] = true,
				["use_spellknown"] = true,
				["zoneIds"] = "",
				["use_spec"] = true,
				["spec"] = {
					["single"] = 2,
					["multi"] = {
						[3] = true,
					},
				},
				["use_never"] = false,
				["spellknown"] = 408,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "Q9IWhK232ZJ",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = false,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "buttonOverlay",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = -1,
						["variable"] = "incombat",
						["value"] = 0,
					},
					["changes"] = {
						{
							["property"] = "sub.3.glow",
						}, -- [1]
					},
				}, -- [3]
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "insufficientResources",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								0.47450980392157, -- [1]
								0.51372549019608, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["property"] = "color",
						}, -- [1]
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [2]
					},
				}, -- [4]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "Pixel",
							["property"] = "sub.3.glowType",
						}, -- [2]
						{
							["value"] = false,
							["property"] = "desaturate",
						}, -- [3]
						{
							["property"] = "inverse",
						}, -- [4]
						{
							["property"] = "color",
						}, -- [5]
						{
							["value"] = true,
							["property"] = "cooldownEdge",
						}, -- [6]
					},
				}, -- [5]
			},
			["parent"] = "Core - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Kidney Shot",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["displayIcon"] = "",
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Nameplate range check 19 "] = {
			["iconSource"] = 0,
			["displayText_format_1.minRange_realm_name"] = "never",
			["xOffset"] = 0,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["yOffset"] = 0,
			["anchorPoint"] = "RIGHT",
			["displayText_format_p_time_format"] = 0,
			["url"] = "https://wago.io/YP6nljWXe/7",
			["icon"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "LEFT",
			["displayText_format_destUnit_color"] = "class",
			["desc"] = "Checks nearest 20 nameplates and shows a starfall icon if they are in range of starfall (36 yrds). \n\nHelps you make any decisions about using starfall and to stop any ninja pulls. \n\nIf you want more nameplates you can simply duplicate one of the weak auras in the group and add a number to the trigger. \n\nIf anyone finds an easier way to make this kind of a weak aura let me know as this was made editing a pre existing weak aura with a similar function.",
			["font"] = "PT Sans Narrow",
			["load"] = {
				["use_never"] = false,
				["class"] = {
					["single"] = "DRUID",
					["multi"] = {
						["DRUID"] = true,
					},
				},
				["use_encounterid"] = false,
				["use_class"] = true,
				["use_itemequiped"] = false,
				["zoneIds"] = "",
				["use_not_item_bonusid_equipped"] = false,
				["talent2"] = {
					["multi"] = {
						[20] = false,
					},
				},
				["use_zoneIds"] = false,
				["item_bonusid_equipped"] = "62080",
				["spec"] = {
					["multi"] = {
					},
				},
				["not_item_bonusid_equipped"] = "62080",
				["use_talent"] = false,
				["use_spellknown"] = false,
				["talent"] = {
					["multi"] = {
						[24] = true,
					},
				},
				["itemequiped"] = {
					62080, -- [1]
				},
				["size"] = {
					["multi"] = {
					},
				},
				["use_exact_spellknown"] = false,
				["use_item_bonusid_equipped"] = false,
				["itemtypeequipped"] = {
				},
			},
			["displayText_format_1.maxRange_format"] = "none",
			["shadowXOffset"] = 1,
			["displayText_format_1.minRange_abbreviate"] = false,
			["regionType"] = "icon",
			["displayText_format_destUnit_abbreviate_max"] = 8,
			["zoom"] = 0,
			["displayText_format_destUnit_format"] = "Unit",
			["tocversion"] = 30401,
			["alpha"] = 1,
			["config"] = {
			},
			["fixedWidth"] = 200,
			["outline"] = "OUTLINE",
			["wagoID"] = "YP6nljWXe",
			["parent"] = "Starfall Range Check on Nameplate",
			["shadowYOffset"] = -1,
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "event",
			["automaticWidth"] = "Auto",
			["triggers"] = {
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "35",
						["unit"] = "nameplate19",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [1]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "20",
						["unit"] = "nameplate19",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = false,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [6]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "15",
						["unit"] = "nameplate19",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [7]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate19",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [8]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [9]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [10]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate19",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [11]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    if trigger[1] and trigger[3] and trigger[5] then\n        return true\n    elseif trigger[2] and trigger[4] and trigger[5] then\n        return true\n    elseif trigger[3] and trigger[8] and trigger[6] then\n        return true\n    elseif trigger[4] and trigger[7] and trigger[6] then\n        return true\n    elseif trigger[4] and (trigger[9] and trigger[10]) and trigger[7] then\n        return true\n    elseif trigger[3] and (trigger[9] and trigger[10]) and trigger[11] then\n        return true\n    end\nend",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["version"] = 7,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%maxRange",
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = false,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_text_format_p_time_mod_rate"] = true,
					["anchorXOffset"] = 0,
					["text_text_format_minRange_format"] = "none",
					["type"] = "subtext",
					["text_text_format_maxRange_format"] = "none",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_text_format_p_time_format"] = 0,
					["text_shadowYOffset"] = 0,
					["text_fontType"] = "OUTLINE",
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "CENTER",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["anchorYOffset"] = 0,
					["text_fontSize"] = 12,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_text_format_p_time_precision"] = 1,
				}, -- [2]
			},
			["height"] = 25,
			["displayText_format_destUnit_realm_name"] = "never",
			["preferToUpdate"] = false,
			["information"] = {
				["forceEvents"] = true,
			},
			["displayText_format_1.minRange_color"] = true,
			["source"] = "import",
			["conditions"] = {
			},
			["displayIcon"] = 236168,
			["cooldownTextDisabled"] = false,
			["displayText_format_1.minRange_round_type"] = "ceil",
			["authorOptions"] = {
			},
			["desaturate"] = false,
			["wordWrap"] = "WordWrap",
			["anchorFrameType"] = "NAMEPLATE",
			["useCooldownModRate"] = true,
			["displayText_format_destUnit_abbreviate"] = false,
			["displayText_format_1.minRange_format"] = "Number",
			["displayText_format_p_time_precision"] = 1,
			["color"] = {
				0.97647058823529, -- [1]
				1, -- [2]
				0.97647058823529, -- [3]
				1, -- [4]
			},
			["justify"] = "LEFT",
			["uid"] = "pN3MUWhiaEm",
			["semver"] = "1.0.6",
			["displayText"] = "%1.maxRange",
			["id"] = "Nameplate range check 19 ",
			["anchorFrameParent"] = false,
			["frameStrata"] = 1,
			["width"] = 25,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["fontSize"] = 16,
			["inverse"] = false,
			["displayText_format_1.minRange_abbreviate_max"] = 8,
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["displayText_format_1.minRange_decimal_precision"] = 0,
			["cooldown"] = false,
			["cooldownEdge"] = false,
		},
		["Combo Points - Rogue"] = {
			["grow"] = "CUSTOM",
			["controlledChildren"] = {
				"Combo Point 1 - Rogue", -- [1]
				"Combo Point 2 - Rogue", -- [2]
				"Combo Point 3 - Rogue", -- [3]
				"Combo Point 4 - Rogue", -- [4]
				"Combo Point 5 - Rogue", -- [5]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["wagoID"] = "foIUC5_yM",
			["parent"] = "Resources - Rogue",
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["regionType"] = "dynamicgroup",
			["fullCircle"] = true,
			["space"] = 2,
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["names"] = {
						},
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["unit"] = "player",
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 1,
			["radius"] = 200,
			["frameStrata"] = 1,
			["useLimit"] = false,
			["align"] = "LEFT",
			["growOn"] = "changed",
			["rowSpace"] = 1,
			["internalVersion"] = 70,
			["rotation"] = 0,
			["arcLength"] = 360,
			["version"] = 25,
			["subRegions"] = {
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["load"] = {
				["size"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
			},
			["sortHybridTable"] = {
				["Combo Point 4 - Rogue"] = false,
				["Combo Point 2 - Rogue"] = false,
				["Combo Point 1 - Rogue"] = false,
				["Combo Point 5 - Rogue"] = false,
				["Combo Point 3 - Rogue"] = false,
			},
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["borderInset"] = 1,
			["source"] = "import",
			["customGrow"] = "function(newPositions, activeRegions)\n    local LWA = LWA and LWA[\"Rogue\"] or {}\n    \n    if LWA and LWA.GrowDynamicResource then\n        LWA.GrowDynamicResource(newPositions, activeRegions)\n    end\nend",
			["scale"] = 1,
			["centerType"] = "LR",
			["border"] = false,
			["borderEdge"] = "Square Full White",
			["stepAngle"] = 15,
			["borderSize"] = 2,
			["sort"] = "none",
			["limit"] = 6,
			["selfPoint"] = "TOP",
			["constantFactor"] = "RADIUS",
			["animate"] = false,
			["borderOffset"] = 4,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Combo Points - Rogue",
			["stagger"] = 0,
			["gridWidth"] = 5,
			["anchorFrameType"] = "SCREEN",
			["config"] = {
			},
			["uid"] = "FLBcuLhB7ny",
			["xOffset"] = 0,
			["authorOptions"] = {
			},
			["conditions"] = {
			},
			["information"] = {
				["forceEvents"] = true,
			},
			["gridType"] = "RD",
		},
		["Vanish"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["track"] = "auto",
						["use_matchedRune"] = false,
						["duration"] = "1",
						["genericShowOn"] = "showAlways",
						["names"] = {
						},
						["use_showgcd"] = true,
						["debuffType"] = "HELPFUL",
						["type"] = "spell",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "Vanish",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["subeventPrefix"] = "SPELL",
						["use_genericShowOn"] = true,
						["use_track"] = true,
						["spellName"] = 1856,
					},
					["untrigger"] = {
						["genericShowOn"] = "showAlways",
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["class_and_spec"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["use_class"] = true,
				["use_spellknown"] = true,
				["zoneIds"] = "",
				["use_spec"] = true,
				["spec"] = {
					["single"] = 2,
					["multi"] = {
						[3] = true,
					},
				},
				["use_never"] = false,
				["spellknown"] = 1856,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "cxNXxCCnmJw",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "onCooldown",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = false,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "buttonOverlay",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "onCooldown",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = -1,
						["variable"] = "incombat",
						["value"] = 0,
					},
					["changes"] = {
						{
							["property"] = "sub.3.glow",
						}, -- [1]
					},
				}, -- [3]
			},
			["parent"] = "Core - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Vanish",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["displayIcon"] = "",
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Garrote"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["parent"] = "Dynamic Spells - Rogue",
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "aura2",
						["auranames"] = {
							"703", -- [1]
						},
						["matchesShowOn"] = "showOnActive",
						["event"] = "Health",
						["unit"] = "target",
						["unitExists"] = false,
						["ownOnly"] = true,
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["useName"] = true,
						["names"] = {
						},
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_class"] = true,
				["use_spellknown"] = true,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["spellknown"] = 703,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["cooldownTextDisabled"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["regionType"] = "icon",
			["cooldownEdge"] = true,
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["information"] = {
				["forceEvents"] = true,
			},
			["authorOptions"] = {
			},
			["config"] = {
			},
			["frameStrata"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Garrote",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["width"] = 48,
			["useCooldownModRate"] = true,
			["uid"] = "utW(qZ21NjT",
			["inverse"] = false,
			["icon"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "Pixel",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
			},
			["cooldown"] = true,
			["xOffset"] = 0,
		},
		["Nameplate range check 2"] = {
			["iconSource"] = 0,
			["displayText_format_1.minRange_realm_name"] = "never",
			["xOffset"] = 0,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["yOffset"] = 0,
			["anchorPoint"] = "RIGHT",
			["displayText_format_p_time_format"] = 0,
			["url"] = "https://wago.io/YP6nljWXe/7",
			["icon"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "LEFT",
			["displayText_format_destUnit_color"] = "class",
			["desc"] = "Checks nearest 20 nameplates and shows a starfall icon if they are in range of starfall (36 yrds). \n\nHelps you make any decisions about using starfall and to stop any ninja pulls. \n\nIf you want more nameplates you can simply duplicate one of the weak auras in the group and add a number to the trigger. \n\nIf anyone finds an easier way to make this kind of a weak aura let me know as this was made editing a pre existing weak aura with a similar function.",
			["font"] = "PT Sans Narrow",
			["load"] = {
				["use_never"] = false,
				["class"] = {
					["single"] = "DRUID",
					["multi"] = {
						["DRUID"] = true,
					},
				},
				["use_encounterid"] = false,
				["use_class"] = true,
				["use_itemequiped"] = false,
				["zoneIds"] = "",
				["use_not_item_bonusid_equipped"] = false,
				["talent2"] = {
					["multi"] = {
						[20] = false,
					},
				},
				["use_zoneIds"] = false,
				["item_bonusid_equipped"] = "62080",
				["spec"] = {
					["multi"] = {
					},
				},
				["not_item_bonusid_equipped"] = "62080",
				["use_talent"] = false,
				["use_spellknown"] = false,
				["talent"] = {
					["multi"] = {
						[24] = true,
					},
				},
				["itemequiped"] = {
					62080, -- [1]
				},
				["size"] = {
					["multi"] = {
					},
				},
				["use_exact_spellknown"] = false,
				["use_item_bonusid_equipped"] = false,
				["itemtypeequipped"] = {
				},
			},
			["displayText_format_1.maxRange_format"] = "none",
			["shadowXOffset"] = 1,
			["displayText_format_1.minRange_abbreviate"] = false,
			["regionType"] = "icon",
			["displayText_format_destUnit_abbreviate_max"] = 8,
			["zoom"] = 0,
			["displayText_format_destUnit_format"] = "Unit",
			["tocversion"] = 30401,
			["alpha"] = 1,
			["config"] = {
			},
			["fixedWidth"] = 200,
			["outline"] = "OUTLINE",
			["wagoID"] = "YP6nljWXe",
			["parent"] = "Starfall Range Check on Nameplate",
			["shadowYOffset"] = -1,
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "event",
			["automaticWidth"] = "Auto",
			["triggers"] = {
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "35",
						["unit"] = "nameplate2",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [1]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "20",
						["unit"] = "nameplate2",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = false,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [6]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "15",
						["unit"] = "nameplate2",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [7]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate2",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [8]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [9]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [10]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate2",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [11]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    if trigger[1] and trigger[3] and trigger[5] then\n        return true\n    elseif trigger[2] and trigger[4] and trigger[5] then\n        return true\n    elseif trigger[3] and trigger[8] and trigger[6] then\n        return true\n    elseif trigger[4] and trigger[7] and trigger[6] then\n        return true\n    elseif trigger[4] and (trigger[9] and trigger[10]) and trigger[7] then\n        return true\n    elseif trigger[3] and (trigger[9] and trigger[10]) and trigger[11] then\n        return true\n    end\nend",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["version"] = 7,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%maxRange",
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = false,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_text_format_p_time_mod_rate"] = true,
					["anchorXOffset"] = 0,
					["text_text_format_minRange_format"] = "none",
					["type"] = "subtext",
					["text_text_format_maxRange_format"] = "none",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_text_format_p_time_format"] = 0,
					["text_shadowYOffset"] = 0,
					["text_fontType"] = "OUTLINE",
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "CENTER",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["anchorYOffset"] = 0,
					["text_fontSize"] = 12,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_text_format_p_time_precision"] = 1,
				}, -- [2]
			},
			["height"] = 25,
			["displayText_format_destUnit_realm_name"] = "never",
			["preferToUpdate"] = false,
			["information"] = {
				["forceEvents"] = true,
			},
			["displayText_format_1.minRange_color"] = true,
			["source"] = "import",
			["conditions"] = {
			},
			["displayIcon"] = 236168,
			["cooldownTextDisabled"] = false,
			["displayText_format_1.minRange_round_type"] = "ceil",
			["authorOptions"] = {
			},
			["desaturate"] = false,
			["wordWrap"] = "WordWrap",
			["anchorFrameType"] = "NAMEPLATE",
			["useCooldownModRate"] = true,
			["displayText_format_destUnit_abbreviate"] = false,
			["displayText_format_1.minRange_format"] = "Number",
			["displayText_format_p_time_precision"] = 1,
			["color"] = {
				0.97647058823529, -- [1]
				1, -- [2]
				0.97647058823529, -- [3]
				1, -- [4]
			},
			["justify"] = "LEFT",
			["uid"] = "3N0ZfCDa0m4",
			["semver"] = "1.0.6",
			["displayText"] = "%1.maxRange",
			["id"] = "Nameplate range check 2",
			["anchorFrameParent"] = false,
			["frameStrata"] = 1,
			["width"] = 25,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["fontSize"] = 16,
			["inverse"] = false,
			["displayText_format_1.minRange_abbreviate_max"] = 8,
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["displayText_format_1.minRange_decimal_precision"] = 0,
			["cooldown"] = false,
			["cooldownEdge"] = false,
		},
		["Master of Subtlety"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["showClones"] = false,
						["type"] = "aura2",
						["auraspellids"] = {
							"146739", -- [1]
						},
						["useExactSpellId"] = false,
						["matchesShowOn"] = "showOnActive",
						["event"] = "Health",
						["unit"] = "player",
						["unitExists"] = true,
						["subeventSuffix"] = "_CAST_START",
						["spellIds"] = {
						},
						["names"] = {
						},
						["subeventPrefix"] = "SPELL",
						["useName"] = true,
						["auranames"] = {
							"31665", -- [1]
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["customTriggerLogic"] = "",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
						[100] = true,
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["zoneIds"] = "",
				["use_talent"] = false,
				["use_class"] = true,
				["race"] = {
				},
				["use_spellknown"] = false,
				["use_spec"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["role"] = {
					["single"] = "DAMAGER",
					["multi"] = {
						["DAMAGER"] = true,
					},
				},
				["spellknown"] = 34503,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "vJx3b1GivOJ",
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["icon"] = true,
			["regionType"] = "icon",
			["cooldown"] = true,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["parent"] = "Dynamic Effects - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Master of Subtlety",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = false,
			["desc"] = "",
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "Pixel",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
			},
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["authorOptions"] = {
			},
		},
		["Ghostly Strike"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "aura2",
						["auranames"] = {
							"14278", -- [1]
						},
						["ownOnly"] = true,
						["event"] = "Health",
						["unit"] = "player",
						["spellIds"] = {
						},
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["useName"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["track"] = "auto",
						["use_matchedRune"] = false,
						["duration"] = "1",
						["genericShowOn"] = "showAlways",
						["names"] = {
						},
						["use_showgcd"] = false,
						["debuffType"] = "HELPFUL",
						["type"] = "spell",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "Ghostly Strike",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["subeventPrefix"] = "SPELL",
						["use_genericShowOn"] = true,
						["use_track"] = true,
						["spellName"] = 14278,
					},
					["untrigger"] = {
						["genericShowOn"] = "showAlways",
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["class_and_spec"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["use_class"] = true,
				["use_spellknown"] = true,
				["zoneIds"] = "",
				["use_spec"] = true,
				["spec"] = {
					["single"] = 2,
					["multi"] = {
						[3] = true,
					},
				},
				["use_never"] = false,
				["spellknown"] = 14278,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "Ux96ACN3FJO",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = false,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "buttonOverlay",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = -1,
						["variable"] = "incombat",
						["value"] = 0,
					},
					["changes"] = {
						{
							["property"] = "sub.3.glow",
						}, -- [1]
					},
				}, -- [3]
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "insufficientResources",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								0.47450980392157, -- [1]
								0.51372549019608, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["property"] = "color",
						}, -- [1]
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [2]
					},
				}, -- [4]
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "spellInRange",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = {
								0.87450980392157, -- [1]
								0.34117647058824, -- [2]
								0.32941176470588, -- [3]
								1, -- [4]
							},
							["property"] = "color",
						}, -- [1]
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [2]
					},
				}, -- [5]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "Pixel",
							["property"] = "sub.3.glowType",
						}, -- [2]
						{
							["value"] = false,
							["property"] = "desaturate",
						}, -- [3]
						{
							["property"] = "inverse",
						}, -- [4]
						{
							["property"] = "color",
						}, -- [5]
						{
							["value"] = true,
							["property"] = "cooldownEdge",
						}, -- [6]
					},
				}, -- [6]
			},
			["parent"] = "Core - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Ghostly Strike",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["displayIcon"] = "",
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Nameplate range check 13 "] = {
			["iconSource"] = 0,
			["displayText_format_1.minRange_realm_name"] = "never",
			["xOffset"] = 0,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["yOffset"] = 0,
			["anchorPoint"] = "RIGHT",
			["displayText_format_p_time_format"] = 0,
			["url"] = "https://wago.io/YP6nljWXe/7",
			["icon"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "LEFT",
			["displayText_format_destUnit_color"] = "class",
			["desc"] = "Checks nearest 20 nameplates and shows a starfall icon if they are in range of starfall (36 yrds). \n\nHelps you make any decisions about using starfall and to stop any ninja pulls. \n\nIf you want more nameplates you can simply duplicate one of the weak auras in the group and add a number to the trigger. \n\nIf anyone finds an easier way to make this kind of a weak aura let me know as this was made editing a pre existing weak aura with a similar function.",
			["font"] = "PT Sans Narrow",
			["load"] = {
				["use_never"] = false,
				["class"] = {
					["single"] = "DRUID",
					["multi"] = {
						["DRUID"] = true,
					},
				},
				["use_encounterid"] = false,
				["use_class"] = true,
				["use_itemequiped"] = false,
				["zoneIds"] = "",
				["use_not_item_bonusid_equipped"] = false,
				["talent2"] = {
					["multi"] = {
						[20] = false,
					},
				},
				["use_zoneIds"] = false,
				["item_bonusid_equipped"] = "62080",
				["spec"] = {
					["multi"] = {
					},
				},
				["not_item_bonusid_equipped"] = "62080",
				["use_talent"] = false,
				["use_spellknown"] = false,
				["talent"] = {
					["multi"] = {
						[24] = true,
					},
				},
				["itemequiped"] = {
					62080, -- [1]
				},
				["size"] = {
					["multi"] = {
					},
				},
				["use_exact_spellknown"] = false,
				["use_item_bonusid_equipped"] = false,
				["itemtypeequipped"] = {
				},
			},
			["displayText_format_1.maxRange_format"] = "none",
			["shadowXOffset"] = 1,
			["displayText_format_1.minRange_abbreviate"] = false,
			["regionType"] = "icon",
			["displayText_format_destUnit_abbreviate_max"] = 8,
			["zoom"] = 0,
			["displayText_format_destUnit_format"] = "Unit",
			["tocversion"] = 30401,
			["alpha"] = 1,
			["config"] = {
			},
			["fixedWidth"] = 200,
			["outline"] = "OUTLINE",
			["wagoID"] = "YP6nljWXe",
			["parent"] = "Starfall Range Check on Nameplate",
			["shadowYOffset"] = -1,
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "event",
			["automaticWidth"] = "Auto",
			["triggers"] = {
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "35",
						["unit"] = "nameplate13",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [1]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "20",
						["unit"] = "nameplate13",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = false,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [6]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "15",
						["unit"] = "nameplate13",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [7]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate13",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [8]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [9]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [10]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate13",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [11]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    if trigger[1] and trigger[3] and trigger[5] then\n        return true\n    elseif trigger[2] and trigger[4] and trigger[5] then\n        return true\n    elseif trigger[3] and trigger[8] and trigger[6] then\n        return true\n    elseif trigger[4] and trigger[7] and trigger[6] then\n        return true\n    elseif trigger[4] and (trigger[9] and trigger[10]) and trigger[7] then\n        return true\n    elseif trigger[3] and (trigger[9] and trigger[10]) and trigger[11] then\n        return true\n    end\nend",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["version"] = 7,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%maxRange",
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = false,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_text_format_p_time_mod_rate"] = true,
					["anchorXOffset"] = 0,
					["text_text_format_minRange_format"] = "none",
					["type"] = "subtext",
					["text_text_format_maxRange_format"] = "none",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_text_format_p_time_format"] = 0,
					["text_shadowYOffset"] = 0,
					["text_fontType"] = "OUTLINE",
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "CENTER",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["anchorYOffset"] = 0,
					["text_fontSize"] = 12,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_text_format_p_time_precision"] = 1,
				}, -- [2]
			},
			["height"] = 25,
			["displayText_format_destUnit_realm_name"] = "never",
			["preferToUpdate"] = false,
			["information"] = {
				["forceEvents"] = true,
			},
			["displayText_format_1.minRange_color"] = true,
			["source"] = "import",
			["conditions"] = {
			},
			["displayIcon"] = 236168,
			["cooldownTextDisabled"] = false,
			["displayText_format_1.minRange_round_type"] = "ceil",
			["authorOptions"] = {
			},
			["desaturate"] = false,
			["wordWrap"] = "WordWrap",
			["anchorFrameType"] = "NAMEPLATE",
			["useCooldownModRate"] = true,
			["displayText_format_destUnit_abbreviate"] = false,
			["displayText_format_1.minRange_format"] = "Number",
			["displayText_format_p_time_precision"] = 1,
			["color"] = {
				0.97647058823529, -- [1]
				1, -- [2]
				0.97647058823529, -- [3]
				1, -- [4]
			},
			["justify"] = "LEFT",
			["uid"] = "gvgDlhpSozO",
			["semver"] = "1.0.6",
			["displayText"] = "%1.maxRange",
			["id"] = "Nameplate range check 13 ",
			["anchorFrameParent"] = false,
			["frameStrata"] = 1,
			["width"] = 25,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["fontSize"] = 16,
			["inverse"] = false,
			["displayText_format_1.minRange_abbreviate_max"] = 8,
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["displayText_format_1.minRange_decimal_precision"] = 0,
			["cooldown"] = false,
			["cooldownEdge"] = false,
		},
		["Clearcasting - Rogue"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["showClones"] = false,
						["type"] = "aura2",
						["auranames"] = {
							"67210", -- [1]
						},
						["matchesShowOn"] = "showOnActive",
						["event"] = "Health",
						["unit"] = "player",
						["unitExists"] = true,
						["spellIds"] = {
						},
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["useName"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "item",
						["genericShowOn"] = "showOnCooldown",
						["use_equipped"] = true,
						["use_itemName"] = true,
						["unit"] = "player",
						["equipped_operator"] = ">=",
						["use_itemSetId"] = true,
						["itemSetId"] = "150",
						["itemName"] = 0,
						["event"] = "Item Set",
						["use_genericShowOn"] = true,
						["equipped"] = "2",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "item",
						["genericShowOn"] = "showOnCooldown",
						["use_equipped"] = true,
						["use_itemName"] = true,
						["unit"] = "player",
						["equipped_operator"] = ">=",
						["use_itemSetId"] = true,
						["itemSetId"] = "151",
						["itemName"] = 0,
						["event"] = "Item Set",
						["use_genericShowOn"] = true,
						["equipped"] = "2",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["type"] = "item",
						["genericShowOn"] = "showOnCooldown",
						["use_equipped"] = true,
						["use_itemName"] = true,
						["unit"] = "player",
						["equipped_operator"] = ">=",
						["use_itemSetId"] = true,
						["itemSetId"] = "188",
						["itemName"] = 0,
						["event"] = "Item Set",
						["use_genericShowOn"] = true,
						["equipped"] = "2",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["type"] = "item",
						["genericShowOn"] = "showOnCooldown",
						["use_equipped"] = true,
						["use_itemName"] = true,
						["unit"] = "player",
						["equipped_operator"] = ">=",
						["use_itemSetId"] = true,
						["itemSetId"] = "189",
						["itemName"] = 0,
						["event"] = "Item Set",
						["use_genericShowOn"] = true,
						["equipped"] = "2",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["type"] = "item",
						["genericShowOn"] = "showOnCooldown",
						["use_equipped"] = true,
						["use_itemName"] = true,
						["unit"] = "player",
						["equipped_operator"] = ">=",
						["use_itemSetId"] = true,
						["itemSetId"] = "815",
						["itemName"] = 0,
						["event"] = "Item Set",
						["use_genericShowOn"] = true,
						["equipped"] = "2",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [6]
				{
					["trigger"] = {
						["type"] = "item",
						["genericShowOn"] = "showOnCooldown",
						["use_equipped"] = true,
						["use_itemName"] = true,
						["unit"] = "player",
						["equipped_operator"] = ">=",
						["use_itemSetId"] = true,
						["itemSetId"] = "816",
						["itemName"] = 0,
						["event"] = "Item Set",
						["use_genericShowOn"] = true,
						["equipped"] = "2",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [7]
				{
					["trigger"] = {
						["type"] = "item",
						["genericShowOn"] = "showOnCooldown",
						["use_equipped"] = true,
						["use_itemName"] = true,
						["unit"] = "player",
						["equipped_operator"] = ">=",
						["use_itemSetId"] = true,
						["itemSetId"] = "858",
						["itemName"] = 0,
						["event"] = "Item Set",
						["use_genericShowOn"] = true,
						["equipped"] = "2",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [8]
				{
					["trigger"] = {
						["type"] = "item",
						["genericShowOn"] = "showOnCooldown",
						["use_equipped"] = true,
						["use_itemName"] = true,
						["unit"] = "player",
						["equipped_operator"] = ">=",
						["use_itemSetId"] = true,
						["itemSetId"] = "857",
						["itemName"] = 0,
						["event"] = "Item Set",
						["use_genericShowOn"] = true,
						["equipped"] = "2",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [9]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(t)\n    -- VanCleef's & Garona's Battlegear\n    return t[1] and (t[2] or t[3] or t[4] or t[5] or t[6] or t[7] or t[8] or t[9])\nend",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["use_never"] = false,
				["talent"] = {
					["single"] = 8,
					["multi"] = {
						[8] = true,
					},
				},
				["zoneIds"] = "",
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["level_operator"] = {
					">=", -- [1]
				},
				["use_spellknown"] = false,
				["use_class"] = true,
				["race"] = {
				},
				["role"] = {
					["single"] = "DAMAGER",
					["multi"] = {
						["DAMAGER"] = true,
					},
				},
				["use_spec"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["level"] = {
					"80", -- [1]
				},
				["use_level"] = true,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "o4wt(5B08B3",
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["icon"] = true,
			["regionType"] = "icon",
			["cooldown"] = true,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["parent"] = "Dynamic Effects - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Clearcasting - Rogue",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = false,
			["desc"] = "",
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "Pixel",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
			},
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["authorOptions"] = {
			},
		},
		["Remorseless Attacks"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["showClones"] = false,
						["type"] = "aura2",
						["auraspellids"] = {
							"146739", -- [1]
						},
						["useExactSpellId"] = false,
						["matchesShowOn"] = "showOnActive",
						["event"] = "Health",
						["unit"] = "player",
						["unitExists"] = true,
						["subeventSuffix"] = "_CAST_START",
						["spellIds"] = {
						},
						["names"] = {
						},
						["subeventPrefix"] = "SPELL",
						["useName"] = true,
						["auranames"] = {
							"14143", -- [1]
							"14149", -- [2]
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["customTriggerLogic"] = "",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
						[4] = true,
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["zoneIds"] = "",
				["use_talent"] = false,
				["use_class"] = true,
				["race"] = {
				},
				["use_spellknown"] = false,
				["use_spec"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["role"] = {
					["single"] = "DAMAGER",
					["multi"] = {
						["DAMAGER"] = true,
					},
				},
				["spellknown"] = 34503,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "NJwvJYt)uFb",
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["icon"] = true,
			["regionType"] = "icon",
			["cooldown"] = true,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["parent"] = "Dynamic Effects - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Remorseless Attacks",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = false,
			["desc"] = "",
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "Pixel",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
			},
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["authorOptions"] = {
			},
		},
		["Nameplate range check 6"] = {
			["iconSource"] = 0,
			["displayText_format_1.minRange_realm_name"] = "never",
			["xOffset"] = 0,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["yOffset"] = 0,
			["anchorPoint"] = "RIGHT",
			["displayText_format_p_time_format"] = 0,
			["url"] = "https://wago.io/YP6nljWXe/7",
			["icon"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "LEFT",
			["displayText_format_destUnit_color"] = "class",
			["desc"] = "Checks nearest 20 nameplates and shows a starfall icon if they are in range of starfall (36 yrds). \n\nHelps you make any decisions about using starfall and to stop any ninja pulls. \n\nIf you want more nameplates you can simply duplicate one of the weak auras in the group and add a number to the trigger. \n\nIf anyone finds an easier way to make this kind of a weak aura let me know as this was made editing a pre existing weak aura with a similar function.",
			["font"] = "PT Sans Narrow",
			["load"] = {
				["use_never"] = false,
				["class"] = {
					["single"] = "DRUID",
					["multi"] = {
						["DRUID"] = true,
					},
				},
				["use_encounterid"] = false,
				["use_class"] = true,
				["use_itemequiped"] = false,
				["zoneIds"] = "",
				["use_not_item_bonusid_equipped"] = false,
				["talent2"] = {
					["multi"] = {
						[20] = false,
					},
				},
				["use_zoneIds"] = false,
				["item_bonusid_equipped"] = "62080",
				["spec"] = {
					["multi"] = {
					},
				},
				["not_item_bonusid_equipped"] = "62080",
				["use_talent"] = false,
				["use_spellknown"] = false,
				["talent"] = {
					["multi"] = {
						[24] = true,
					},
				},
				["itemequiped"] = {
					62080, -- [1]
				},
				["size"] = {
					["multi"] = {
					},
				},
				["use_exact_spellknown"] = false,
				["use_item_bonusid_equipped"] = false,
				["itemtypeequipped"] = {
				},
			},
			["displayText_format_1.maxRange_format"] = "none",
			["shadowXOffset"] = 1,
			["displayText_format_1.minRange_abbreviate"] = false,
			["regionType"] = "icon",
			["displayText_format_destUnit_abbreviate_max"] = 8,
			["zoom"] = 0,
			["displayText_format_destUnit_format"] = "Unit",
			["tocversion"] = 30401,
			["alpha"] = 1,
			["config"] = {
			},
			["fixedWidth"] = 200,
			["outline"] = "OUTLINE",
			["wagoID"] = "YP6nljWXe",
			["parent"] = "Starfall Range Check on Nameplate",
			["shadowYOffset"] = -1,
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "event",
			["automaticWidth"] = "Auto",
			["triggers"] = {
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "35",
						["unit"] = "nameplate6",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [1]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "20",
						["unit"] = "nameplate6",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = false,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [6]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "15",
						["unit"] = "nameplate6",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [7]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate6",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [8]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [9]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [10]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate6",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [11]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    if trigger[1] and trigger[3] and trigger[5] then\n        return true\n    elseif trigger[2] and trigger[4] and trigger[5] then\n        return true\n    elseif trigger[3] and trigger[8] and trigger[6] then\n        return true\n    elseif trigger[4] and trigger[7] and trigger[6] then\n        return true\n    elseif trigger[4] and (trigger[9] and trigger[10]) and trigger[7] then\n        return true\n    elseif trigger[3] and (trigger[9] and trigger[10]) and trigger[11] then\n        return true\n    end\nend",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["version"] = 7,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%maxRange",
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = false,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_text_format_p_time_mod_rate"] = true,
					["anchorXOffset"] = 0,
					["text_text_format_minRange_format"] = "none",
					["type"] = "subtext",
					["text_text_format_maxRange_format"] = "none",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_text_format_p_time_format"] = 0,
					["text_shadowYOffset"] = 0,
					["text_fontType"] = "OUTLINE",
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "CENTER",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["anchorYOffset"] = 0,
					["text_fontSize"] = 12,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_text_format_p_time_precision"] = 1,
				}, -- [2]
			},
			["height"] = 25,
			["displayText_format_destUnit_realm_name"] = "never",
			["preferToUpdate"] = false,
			["information"] = {
				["forceEvents"] = true,
			},
			["displayText_format_1.minRange_color"] = true,
			["source"] = "import",
			["conditions"] = {
			},
			["displayIcon"] = 236168,
			["cooldownTextDisabled"] = false,
			["displayText_format_1.minRange_round_type"] = "ceil",
			["authorOptions"] = {
			},
			["desaturate"] = false,
			["wordWrap"] = "WordWrap",
			["anchorFrameType"] = "NAMEPLATE",
			["useCooldownModRate"] = true,
			["displayText_format_destUnit_abbreviate"] = false,
			["displayText_format_1.minRange_format"] = "Number",
			["displayText_format_p_time_precision"] = 1,
			["color"] = {
				0.97647058823529, -- [1]
				1, -- [2]
				0.97647058823529, -- [3]
				1, -- [4]
			},
			["justify"] = "LEFT",
			["uid"] = "WjkmEhUdlHS",
			["semver"] = "1.0.6",
			["displayText"] = "%1.maxRange",
			["id"] = "Nameplate range check 6",
			["anchorFrameParent"] = false,
			["frameStrata"] = 1,
			["width"] = 25,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["fontSize"] = 16,
			["inverse"] = false,
			["displayText_format_1.minRange_abbreviate_max"] = 8,
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["displayText_format_1.minRange_decimal_precision"] = 0,
			["cooldown"] = false,
			["cooldownEdge"] = false,
		},
		["Envenom"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = true,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "aura2",
						["auranames"] = {
							"32684", -- [1]
						},
						["matchesShowOn"] = "showAlways",
						["event"] = "Health",
						["unit"] = "player",
						["unitExists"] = true,
						["spellIds"] = {
						},
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["useName"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "aura2",
						["auranames"] = {
							"11354", -- [1]
						},
						["debuffType"] = "HARMFUL",
						["ownOnly"] = true,
						["useName"] = true,
						["unit"] = "target",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
				{
					["text_shadowXOffset"] = 0,
					["text_text_format_s_format"] = "none",
					["text_text"] = "%2.s",
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "CENTER",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_text_format_p_time_format"] = 0,
					["type"] = "subtext",
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_color"] = {
						1, -- [1]
						0.88627450980392, -- [2]
						0.76862745098039, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_anchorYOffset"] = -4,
					["text_shadowYOffset"] = 0,
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "OUTER_TOP",
					["text_text_format_2.s_format"] = "none",
					["text_fontType"] = "OUTLINE",
					["text_fontSize"] = 18,
					["anchorXOffset"] = 0,
					["text_text_format_p_time_precision"] = 1,
				}, -- [4]
			},
			["height"] = 48,
			["load"] = {
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
						[16] = true,
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["use_talent"] = false,
				["use_class"] = true,
				["use_spellknown"] = true,
				["spec"] = {
					["multi"] = {
					},
				},
				["spellknown"] = 32645,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "UdPRMR7y8DC",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "buffed",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
						{
							["value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								0.5, -- [4]
							},
							["property"] = "color",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "buffed",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "Pixel",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [2]
			},
			["parent"] = "Core - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Envenom",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = false,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["displayIcon"] = "",
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Killing Spree"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "aura2",
						["auranames"] = {
							"51690", -- [1]
						},
						["ownOnly"] = true,
						["event"] = "Health",
						["unit"] = "player",
						["spellIds"] = {
						},
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["useName"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["track"] = "auto",
						["use_matchedRune"] = false,
						["duration"] = "1",
						["genericShowOn"] = "showAlways",
						["names"] = {
						},
						["use_showgcd"] = false,
						["debuffType"] = "HELPFUL",
						["type"] = "spell",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "Killing Spree",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["subeventPrefix"] = "SPELL",
						["use_genericShowOn"] = true,
						["use_track"] = true,
						["spellName"] = 51690,
					},
					["untrigger"] = {
						["genericShowOn"] = "showAlways",
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["class_and_spec"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["use_class"] = true,
				["use_spellknown"] = true,
				["zoneIds"] = "",
				["use_spec"] = true,
				["spec"] = {
					["single"] = 2,
					["multi"] = {
						[3] = true,
					},
				},
				["use_never"] = false,
				["spellknown"] = 51690,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "oef1vFwrg8o",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = false,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "buttonOverlay",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -1,
						["variable"] = "incombat",
						["value"] = 0,
					},
					["changes"] = {
						{
							["property"] = "sub.3.glow",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [3]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "Pixel",
							["property"] = "sub.3.glowType",
						}, -- [2]
						{
							["property"] = "desaturate",
						}, -- [3]
						{
							["property"] = "inverse",
						}, -- [4]
						{
							["value"] = true,
							["property"] = "cooldownEdge",
						}, -- [5]
					},
				}, -- [4]
			},
			["parent"] = "Core - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Killing Spree",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["displayIcon"] = "",
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Poison - Off Hand"] = {
			["iconSource"] = 6,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["enchant"] = "",
						["itemName"] = 6265,
						["use_count"] = false,
						["auranames"] = {
							"465", -- [1]
							"7294", -- [2]
							"19746", -- [3]
							"19876", -- [4]
							"19888", -- [5]
							"19891", -- [6]
							"32223", -- [7]
						},
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["names"] = {
						},
						["unitExists"] = true,
						["use_weapon"] = true,
						["use_unit"] = true,
						["use_enchant"] = false,
						["matchesShowOn"] = "showAlways",
						["debuffType"] = "HELPFUL",
						["spellName"] = 0,
						["subeventPrefix"] = "SPELL",
						["type"] = "item",
						["unevent"] = "auto",
						["subeventSuffix"] = "_CAST_START",
						["use_showOn"] = true,
						["event"] = "Weapon Enchant",
						["use_itemName"] = true,
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["useName"] = true,
						["showOn"] = "showOnActive",
						["duration"] = "1",
						["use_track"] = true,
						["weapon"] = "off",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["enchant"] = "",
						["auranames"] = {
							"465", -- [1]
							"7294", -- [2]
							"19746", -- [3]
							"19876", -- [4]
							"19888", -- [5]
							"19891", -- [6]
							"32223", -- [7]
						},
						["duration"] = "1",
						["remaining"] = "300",
						["use_weapon"] = true,
						["spellName"] = 0,
						["subeventSuffix"] = "_CAST_START",
						["use_showOn"] = true,
						["use_itemName"] = true,
						["use_track"] = true,
						["itemName"] = 6265,
						["use_count"] = false,
						["genericShowOn"] = "showOnCooldown",
						["subeventPrefix"] = "SPELL",
						["unitExists"] = true,
						["use_unit"] = true,
						["debuffType"] = "HELPFUL",
						["use_enchant"] = false,
						["use_remaining"] = true,
						["matchesShowOn"] = "showAlways",
						["unevent"] = "auto",
						["names"] = {
						},
						["type"] = "item",
						["remaining_operator"] = "<=",
						["useName"] = true,
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["unit"] = "player",
						["showOn"] = "showOnActive",
						["use_genericShowOn"] = true,
						["event"] = "Weapon Enchant",
						["weapon"] = "off",
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["enchant"] = "",
						["itemName"] = 6265,
						["use_count"] = false,
						["auranames"] = {
							"465", -- [1]
							"7294", -- [2]
							"19746", -- [3]
							"19876", -- [4]
							"19888", -- [5]
							"19891", -- [6]
							"32223", -- [7]
						},
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["names"] = {
						},
						["unitExists"] = true,
						["use_weapon"] = true,
						["use_unit"] = true,
						["use_enchant"] = false,
						["matchesShowOn"] = "showAlways",
						["debuffType"] = "HELPFUL",
						["spellName"] = 0,
						["subeventPrefix"] = "SPELL",
						["type"] = "item",
						["unevent"] = "auto",
						["subeventSuffix"] = "_CAST_START",
						["use_showOn"] = true,
						["event"] = "Weapon Enchant",
						["use_itemName"] = true,
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["useName"] = true,
						["showOn"] = "showOnMissing",
						["duration"] = "1",
						["use_track"] = true,
						["weapon"] = "off",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["use_resting"] = true,
						["use_incombat"] = false,
						["debuffType"] = "HELPFUL",
						["type"] = "unit",
						["unit"] = "player",
						["event"] = "Conditions",
						["use_unit"] = true,
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["type"] = "custom",
						["custom"] = "function()\n    if LWA and LWA.Init then\n        LWA.Init()\n    end\nend",
						["custom_type"] = "event",
						["debuffType"] = "HELPFUL",
						["events"] = "OPTIONS",
						["unit"] = "player",
						["custom_hide"] = "custom",
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["itemName"] = 0,
						["use_genericShowOn"] = true,
						["use_itemName"] = true,
						["unit"] = "player",
						["use_itemSlot"] = true,
						["itemSlot"] = 17,
						["event"] = "Cooldown Progress (Equipment Slot)",
						["type"] = "item",
						["genericShowOn"] = "showAlways",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [6]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(t)\n    if t[4] then -- If in Rested Area\n        return false\n    end\n    \n    local behavior = aura_env.config.maintenance.poison.behavior\n    \n    if behavior == 1 then -- Show if Applied\n        return t[1]\n    elseif behavior == 2 then -- Show if Missing\n        return t[2] or t[3]\n    else -- Always Show\n        return true\n    end\nend\n\n",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_level"] = true,
				["talent"] = {
					["single"] = 68,
					["multi"] = {
						[68] = true,
					},
				},
				["level_operator"] = {
					">=", -- [1]
				},
				["use_class"] = true,
				["use_spellknown"] = false,
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["level"] = {
					"20", -- [1]
				},
				["use_never"] = false,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "dfyj9uMj)E3",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
				{
					["subOptions"] = {
						{
							["useName"] = true,
							["type"] = "header",
							["text"] = "Behavior",
							["noMerge"] = false,
							["width"] = 1,
						}, -- [1]
						{
							["subOptions"] = {
								{
									["text"] = "Poison",
									["type"] = "description",
									["fontSize"] = "large",
									["width"] = 1,
								}, -- [1]
								{
									["type"] = "select",
									["default"] = 2,
									["values"] = {
										"Show if Applied", -- [1]
										"Show if Missing", -- [2]
										"Always Show", -- [3]
									},
									["name"] = "Behavior",
									["useDesc"] = false,
									["key"] = "behavior",
									["width"] = 1,
								}, -- [2]
							},
							["hideReorder"] = true,
							["useDesc"] = false,
							["nameSource"] = 0,
							["name"] = "Poison",
							["width"] = 1,
							["useCollapse"] = false,
							["noMerge"] = false,
							["collapse"] = false,
							["type"] = "group",
							["limitType"] = "none",
							["groupType"] = "simple",
							["key"] = "poison",
							["size"] = 10,
						}, -- [2]
					},
					["hideReorder"] = true,
					["useDesc"] = false,
					["nameSource"] = 0,
					["name"] = "Maintenance Icons",
					["width"] = 1,
					["useCollapse"] = true,
					["noMerge"] = false,
					["collapse"] = true,
					["type"] = "group",
					["limitType"] = "none",
					["groupType"] = "simple",
					["key"] = "maintenance",
					["size"] = 10,
				}, -- [1]
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								0.5, -- [4]
							},
							["property"] = "color",
						}, -- [1]
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [2]
					},
				}, -- [1]
			},
			["parent"] = "Maintenance - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Poison - Off Hand",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
				["maintenance"] = {
					["poison"] = {
						["behavior"] = 2,
					},
				},
			},
			["inverse"] = false,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["displayIcon"] = "",
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Class Options - Rogue"] = {
			["iconSource"] = 0,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "custom",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "GTFO",
						["unit"] = "player",
						["debuffType"] = "HELPFUL",
						["custom"] = "function ()\n    local LWA = LWA[aura_env.CLASS]\n    \n    if LWA.ThrottledInit then\n        LWA.ThrottledInit()\n    end\nend",
						["events"] = "OPTIONS",
						["custom_type"] = "event",
						["names"] = {
						},
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["custom_hide"] = "timed",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["customTriggerLogic"] = "",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = false,
			["selfPoint"] = "TOP",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
			},
			["height"] = 1,
			["load"] = {
				["use_class"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["uid"] = "dc5hB4j919y",
			["authorOptions"] = {
				{
					["subOptions"] = {
						{
							["subOptions"] = {
								{
									["type"] = "space",
									["variableWidth"] = true,
									["height"] = 2,
									["useHeight"] = true,
									["width"] = 2,
								}, -- [1]
								{
									["softMin"] = 5,
									["type"] = "range",
									["bigStep"] = 1,
									["max"] = 50,
									["step"] = 1,
									["width"] = 1.25,
									["min"] = 5,
									["key"] = "height",
									["softMax"] = 50,
									["default"] = 20,
									["name"] = "Resource Height",
									["useDesc"] = false,
								}, -- [2]
								{
									["type"] = "space",
									["variableWidth"] = true,
									["height"] = 2,
									["useHeight"] = true,
									["width"] = 2,
								}, -- [3]
								{
									["useName"] = true,
									["type"] = "header",
									["text"] = "Default Color",
									["noMerge"] = true,
									["width"] = 1,
								}, -- [4]
								{
									["type"] = "color",
									["default"] = {
										1, -- [1]
										0.74901960784314, -- [2]
										0.16078431372549, -- [3]
										1, -- [4]
									},
									["key"] = "color1",
									["name"] = "Color 1",
									["useDesc"] = false,
									["width"] = 1,
								}, -- [5]
								{
									["type"] = "color",
									["default"] = {
										1, -- [1]
										0.85490196078431, -- [2]
										0.41960784313725, -- [3]
										1, -- [4]
									},
									["key"] = "color2",
									["name"] = "Color 2",
									["useDesc"] = false,
									["width"] = 1,
								}, -- [6]
								{
									["type"] = "select",
									["default"] = 1,
									["values"] = {
										"Horizontal", -- [1]
										"Vertical", -- [2]
										"None", -- [3]
									},
									["name"] = "Gradient Direction",
									["useDesc"] = false,
									["key"] = "gradient",
									["width"] = 1,
								}, -- [7]
								{
									["type"] = "space",
									["variableWidth"] = true,
									["height"] = 2,
									["useHeight"] = true,
									["width"] = 2,
								}, -- [8]
							},
							["hideReorder"] = true,
							["useDesc"] = false,
							["nameSource"] = 0,
							["width"] = 1,
							["useCollapse"] = true,
							["name"] = "Energy Bar",
							["collapse"] = true,
							["type"] = "group",
							["limitType"] = "none",
							["groupType"] = "simple",
							["key"] = "energy_bar",
							["size"] = 10,
						}, -- [1]
						{
							["subOptions"] = {
								{
									["type"] = "space",
									["variableWidth"] = true,
									["height"] = 2,
									["useHeight"] = true,
									["width"] = 2,
								}, -- [1]
								{
									["softMin"] = 5,
									["type"] = "range",
									["bigStep"] = 1,
									["max"] = 50,
									["step"] = 1,
									["width"] = 1.25,
									["min"] = 5,
									["key"] = "height",
									["softMax"] = 50,
									["default"] = 15,
									["name"] = "Resource Height",
									["useDesc"] = false,
								}, -- [2]
								{
									["type"] = "space",
									["variableWidth"] = true,
									["height"] = 2,
									["useHeight"] = true,
									["width"] = 2,
								}, -- [3]
								{
									["useName"] = true,
									["type"] = "header",
									["text"] = "Default Color",
									["noMerge"] = true,
									["width"] = 1,
								}, -- [4]
								{
									["type"] = "color",
									["default"] = {
										0.83137254901961, -- [1]
										0.14901960784314, -- [2]
										0, -- [3]
										1, -- [4]
									},
									["key"] = "color1",
									["name"] = "Color 1",
									["useDesc"] = false,
									["width"] = 1,
								}, -- [5]
								{
									["type"] = "color",
									["default"] = {
										1, -- [1]
										0.34117647058824, -- [2]
										0.27843137254902, -- [3]
										1, -- [4]
									},
									["key"] = "color2",
									["name"] = "Color 2",
									["useDesc"] = false,
									["width"] = 1,
								}, -- [6]
								{
									["type"] = "select",
									["default"] = 1,
									["values"] = {
										"Horizontal", -- [1]
										"Vertical", -- [2]
										"None", -- [3]
									},
									["name"] = "Gradient Direction",
									["useDesc"] = false,
									["key"] = "gradient",
									["width"] = 1,
								}, -- [7]
								{
									["useName"] = true,
									["type"] = "header",
									["text"] = "Highlight",
									["noMerge"] = true,
									["width"] = 1,
								}, -- [8]
								{
									["type"] = "color",
									["default"] = {
										0.25098039215686, -- [1]
										0.69019607843137, -- [2]
										0.18823529411765, -- [3]
										1, -- [4]
									},
									["key"] = "highlight_color1",
									["name"] = "Color 1",
									["useDesc"] = false,
									["width"] = 1,
								}, -- [9]
								{
									["type"] = "color",
									["default"] = {
										0.49019607843137, -- [1]
										0.94509803921569, -- [2]
										0.42745098039216, -- [3]
										1, -- [4]
									},
									["key"] = "highlight_color2",
									["name"] = "Color 2",
									["useDesc"] = false,
									["width"] = 1,
								}, -- [10]
								{
									["type"] = "select",
									["default"] = 1,
									["values"] = {
										"Horizontal", -- [1]
										"Vertical", -- [2]
										"None", -- [3]
									},
									["name"] = "Gradient Direction",
									["useDesc"] = false,
									["key"] = "highlight_gradient",
									["width"] = 1,
								}, -- [11]
								{
									["useName"] = true,
									["type"] = "header",
									["text"] = "Full",
									["noMerge"] = true,
									["width"] = 1,
								}, -- [12]
								{
									["type"] = "color",
									["default"] = {
										1, -- [1]
										1, -- [2]
										1, -- [3]
										0.80000001192093, -- [4]
									},
									["key"] = "full_color1",
									["name"] = "Color 1",
									["useDesc"] = false,
									["width"] = 1,
								}, -- [13]
								{
									["type"] = "color",
									["default"] = {
										1, -- [1]
										1, -- [2]
										1, -- [3]
										1, -- [4]
									},
									["key"] = "full_color2",
									["name"] = "Color 2",
									["useDesc"] = false,
									["width"] = 1,
								}, -- [14]
								{
									["type"] = "select",
									["default"] = 1,
									["values"] = {
										"Horizontal", -- [1]
										"Vertical", -- [2]
										"None", -- [3]
									},
									["name"] = "Gradient Direction",
									["useDesc"] = false,
									["key"] = "full_gradient",
									["width"] = 1,
								}, -- [15]
								{
									["type"] = "space",
									["variableWidth"] = true,
									["height"] = 2,
									["useHeight"] = true,
									["width"] = 2,
								}, -- [16]
							},
							["hideReorder"] = true,
							["useDesc"] = false,
							["nameSource"] = 0,
							["width"] = 1,
							["useCollapse"] = true,
							["name"] = "Combo Points",
							["collapse"] = true,
							["type"] = "group",
							["limitType"] = "none",
							["groupType"] = "simple",
							["key"] = "combo_points",
							["size"] = 10,
						}, -- [2]
					},
					["hideReorder"] = true,
					["useDesc"] = false,
					["nameSource"] = 0,
					["name"] = "Resources",
					["width"] = 1,
					["useCollapse"] = false,
					["noMerge"] = false,
					["collapse"] = false,
					["type"] = "group",
					["limitType"] = "none",
					["groupType"] = "simple",
					["key"] = "resources",
					["size"] = 10,
				}, -- [1]
			},
			["color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
			},
			["regionType"] = "icon",
			["cooldown"] = false,
			["conditions"] = {
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
					["custom"] = "aura_env.CLASS = aura_env.id:gsub(\"Class Options %- \", \"\")\n\nLWA = LWA or {}\nLWA[aura_env.CLASS] = LWA[aura_env.CLASS] or {}\n\nlocal LWA = LWA[aura_env.CLASS]\n\nLWA.configs = LWA.configs or {}\nLWA.configs[\"class\"] = aura_env.config\n\n",
					["do_custom"] = true,
				},
			},
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 0,
			["zoom"] = 0,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Class Options - Rogue",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 1,
			["cooldownTextDisabled"] = false,
			["config"] = {
				["resources"] = {
					["energy_bar"] = {
						["height"] = 20,
						["gradient"] = 1,
						["color2"] = {
							1, -- [1]
							0.85490196078431, -- [2]
							0.41960784313725, -- [3]
							1, -- [4]
						},
						["color1"] = {
							1, -- [1]
							0.74901960784314, -- [2]
							0.16078431372549, -- [3]
							1, -- [4]
						},
					},
					["combo_points"] = {
						["full_gradient"] = 1,
						["highlight_gradient"] = 1,
						["color1"] = {
							0.83137254901961, -- [1]
							0.14901960784314, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["color2"] = {
							1, -- [1]
							0.34117647058824, -- [2]
							0.27843137254902, -- [3]
							1, -- [4]
						},
						["height"] = 15,
						["full_color2"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["full_color1"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							0.80000001192093, -- [4]
						},
						["gradient"] = 1,
						["highlight_color1"] = {
							0.25098039215686, -- [1]
							0.69019607843137, -- [2]
							0.18823529411765, -- [3]
							1, -- [4]
						},
						["highlight_color2"] = {
							0.49019607843137, -- [1]
							0.94509803921569, -- [2]
							0.42745098039216, -- [3]
							1, -- [4]
						},
					},
				},
			},
			["inverse"] = false,
			["parent"] = "Luxthos - Rogue",
			["displayIcon"] = 134520,
			["information"] = {
				["forceEvents"] = true,
			},
			["desc"] = "Made by Luxthos - twitch.tv/luxthos",
		},
		["Combo Point 2 - Rogue"] = {
			["sparkWidth"] = 10,
			["iconSource"] = -1,
			["authorOptions"] = {
			},
			["adjustedMax"] = "2",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["sparkRotation"] = 0,
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["backgroundColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.34336978197098, -- [4]
			},
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["enableGradient"] = false,
			["selfPoint"] = "TOP",
			["barColor"] = {
				0.85882352941176, -- [1]
				0.14509803921569, -- [2]
				0.050980392156863, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["sparkOffsetY"] = 0,
			["gradientOrientation"] = "HORIZONTAL",
			["load"] = {
				["use_class"] = true,
				["use_petbattle"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 3,
					["multi"] = {
						[3] = true,
					},
				},
				["zoneIds"] = "",
			},
			["smoothProgress"] = false,
			["useAdjustededMin"] = true,
			["regionType"] = "aurabar",
			["texture"] = "Solid",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["auto"] = true,
			["tocversion"] = 30401,
			["alpha"] = 1,
			["config"] = {
			},
			["colorState"] = "",
			["sparkOffsetX"] = 0,
			["wagoID"] = "foIUC5_yM",
			["parent"] = "Combo Points - Rogue",
			["adjustedMin"] = "1",
			["sparkRotationMode"] = "AUTO",
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "unit",
						["names"] = {
						},
						["unevent"] = "auto",
						["use_unit"] = true,
						["duration"] = "1",
						["event"] = "Power",
						["subeventPrefix"] = "SPELL",
						["subeventSuffix"] = "_CAST_START",
						["powertype"] = 4,
						["spellIds"] = {
						},
						["use_power"] = false,
						["unit"] = "player",
						["use_absorbMode"] = true,
						["use_powertype"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = 1,
			},
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["isPrimaryResource"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["type"] = "subforeground",
				}, -- [2]
				{
					["border_size"] = 2,
					["border_anchor"] = "bar",
					["type"] = "subborder",
					["border_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
					},
					["border_visible"] = false,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [3]
			},
			["height"] = 20,
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = true,
			["source"] = "import",
			["xOffset"] = 0,
			["icon_side"] = "RIGHT",
			["preferToUpdate"] = false,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["sparkHeight"] = 30,
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["icon"] = false,
			["configGroup"] = "combo_points",
			["semver"] = "2.0.23",
			["spark"] = false,
			["sparkHidden"] = "NEVER",
			["zoom"] = 0,
			["frameStrata"] = 1,
			["width"] = 56,
			["id"] = "Combo Point 2 - Rogue",
			["anchorFrameType"] = "SCREEN",
			["inverse"] = false,
			["uid"] = "UdxCo4N6tMe",
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "<=",
						["value"] = "3",
						["variable"] = "power",
					},
					["changes"] = {
						{
							["value"] = {
								["custom"] = "aura_env.region.colorState = \"\"\nWeakAuras.ScanEvents(\"LWA_UPDATE_BAR\", aura_env, 2, 5)",
							},
							["property"] = "customcode",
						}, -- [1]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "==",
						["value"] = "4",
						["variable"] = "power",
					},
					["linked"] = true,
					["changes"] = {
						{
							["value"] = {
								["custom"] = "aura_env.region.colorState = \"highlight\"\nWeakAuras.ScanEvents(\"LWA_UPDATE_BAR\", aura_env, 2, 5)",
							},
							["property"] = "customcode",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "==",
						["value"] = "5",
						["variable"] = "power",
					},
					["linked"] = true,
					["changes"] = {
						{
							["value"] = {
								["custom"] = "aura_env.region.colorState = \"full\"\nWeakAuras.ScanEvents(\"LWA_UPDATE_BAR\", aura_env, 2, 5)",
							},
							["property"] = "customcode",
						}, -- [1]
					},
				}, -- [3]
			},
			["barColor2"] = {
				1, -- [1]
				1, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
					["custom"] = "aura_env.region.configGroup = \"combo_points\"",
					["do_custom"] = true,
				},
			},
		},
		["Nameplate range check 20 "] = {
			["iconSource"] = 0,
			["displayText_format_1.minRange_realm_name"] = "never",
			["xOffset"] = 0,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["yOffset"] = 0,
			["anchorPoint"] = "RIGHT",
			["displayText_format_p_time_format"] = 0,
			["url"] = "https://wago.io/YP6nljWXe/7",
			["icon"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "LEFT",
			["displayText_format_destUnit_color"] = "class",
			["desc"] = "Checks nearest 20 nameplates and shows a starfall icon if they are in range of starfall (36 yrds). \n\nHelps you make any decisions about using starfall and to stop any ninja pulls. \n\nIf you want more nameplates you can simply duplicate one of the weak auras in the group and add a number to the trigger. \n\nIf anyone finds an easier way to make this kind of a weak aura let me know as this was made editing a pre existing weak aura with a similar function.",
			["font"] = "PT Sans Narrow",
			["load"] = {
				["use_never"] = false,
				["class"] = {
					["single"] = "DRUID",
					["multi"] = {
						["DRUID"] = true,
					},
				},
				["use_encounterid"] = false,
				["use_class"] = true,
				["use_itemequiped"] = false,
				["zoneIds"] = "",
				["use_not_item_bonusid_equipped"] = false,
				["talent2"] = {
					["multi"] = {
						[20] = false,
					},
				},
				["use_zoneIds"] = false,
				["item_bonusid_equipped"] = "62080",
				["spec"] = {
					["multi"] = {
					},
				},
				["not_item_bonusid_equipped"] = "62080",
				["use_talent"] = false,
				["use_spellknown"] = false,
				["talent"] = {
					["multi"] = {
						[24] = true,
					},
				},
				["itemequiped"] = {
					62080, -- [1]
				},
				["size"] = {
					["multi"] = {
					},
				},
				["use_exact_spellknown"] = false,
				["use_item_bonusid_equipped"] = false,
				["itemtypeequipped"] = {
				},
			},
			["displayText_format_1.maxRange_format"] = "none",
			["shadowXOffset"] = 1,
			["displayText_format_1.minRange_abbreviate"] = false,
			["regionType"] = "icon",
			["displayText_format_destUnit_abbreviate_max"] = 8,
			["zoom"] = 0,
			["displayText_format_destUnit_format"] = "Unit",
			["tocversion"] = 30401,
			["alpha"] = 1,
			["config"] = {
			},
			["fixedWidth"] = 200,
			["outline"] = "OUTLINE",
			["wagoID"] = "YP6nljWXe",
			["parent"] = "Starfall Range Check on Nameplate",
			["shadowYOffset"] = -1,
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "event",
			["automaticWidth"] = "Auto",
			["triggers"] = {
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "35",
						["unit"] = "nameplate20",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [1]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "20",
						["unit"] = "nameplate20",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = false,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [6]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "15",
						["unit"] = "nameplate20",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [7]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate20",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [8]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [9]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [10]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate20",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [11]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    if trigger[1] and trigger[3] and trigger[5] then\n        return true\n    elseif trigger[2] and trigger[4] and trigger[5] then\n        return true\n    elseif trigger[3] and trigger[8] and trigger[6] then\n        return true\n    elseif trigger[4] and trigger[7] and trigger[6] then\n        return true\n    elseif trigger[4] and (trigger[9] and trigger[10]) and trigger[7] then\n        return true\n    elseif trigger[3] and (trigger[9] and trigger[10]) and trigger[11] then\n        return true\n    end\nend",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["version"] = 7,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%maxRange",
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = false,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_text_format_p_time_mod_rate"] = true,
					["anchorXOffset"] = 0,
					["text_text_format_minRange_format"] = "none",
					["type"] = "subtext",
					["text_text_format_maxRange_format"] = "none",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_text_format_p_time_format"] = 0,
					["text_shadowYOffset"] = 0,
					["text_fontType"] = "OUTLINE",
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "CENTER",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["anchorYOffset"] = 0,
					["text_fontSize"] = 12,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_text_format_p_time_precision"] = 1,
				}, -- [2]
			},
			["height"] = 25,
			["displayText_format_destUnit_realm_name"] = "never",
			["preferToUpdate"] = false,
			["information"] = {
				["forceEvents"] = true,
			},
			["displayText_format_1.minRange_color"] = true,
			["source"] = "import",
			["conditions"] = {
			},
			["displayIcon"] = 236168,
			["cooldownTextDisabled"] = false,
			["displayText_format_1.minRange_round_type"] = "ceil",
			["authorOptions"] = {
			},
			["desaturate"] = false,
			["wordWrap"] = "WordWrap",
			["anchorFrameType"] = "NAMEPLATE",
			["useCooldownModRate"] = true,
			["displayText_format_destUnit_abbreviate"] = false,
			["displayText_format_1.minRange_format"] = "Number",
			["displayText_format_p_time_precision"] = 1,
			["color"] = {
				0.97647058823529, -- [1]
				1, -- [2]
				0.97647058823529, -- [3]
				1, -- [4]
			},
			["justify"] = "LEFT",
			["uid"] = "UF3tnr1Atb3",
			["semver"] = "1.0.6",
			["displayText"] = "%1.maxRange",
			["id"] = "Nameplate range check 20 ",
			["anchorFrameParent"] = false,
			["frameStrata"] = 1,
			["width"] = 25,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["fontSize"] = 16,
			["inverse"] = false,
			["displayText_format_1.minRange_abbreviate_max"] = 8,
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["displayText_format_1.minRange_decimal_precision"] = 0,
			["cooldown"] = false,
			["cooldownEdge"] = false,
		},
		["Stealth"] = {
			["iconSource"] = -1,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["useMatch_count"] = true,
						["match_countOperator"] = ">",
						["auranames"] = {
							"1784", -- [1]
						},
						["ownOnly"] = true,
						["event"] = "Health",
						["unit"] = "player",
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["spellIds"] = {
						},
						["subeventPrefix"] = "SPELL",
						["match_count"] = "0",
						["type"] = "aura2",
						["useName"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["track"] = "auto",
						["use_matchedRune"] = false,
						["duration"] = "1",
						["genericShowOn"] = "showOnCooldown",
						["names"] = {
						},
						["use_showgcd"] = true,
						["debuffType"] = "HELPFUL",
						["type"] = "spell",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "Stealth",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["subeventPrefix"] = "SPELL",
						["use_genericShowOn"] = true,
						["use_track"] = true,
						["spellName"] = 1784,
					},
					["untrigger"] = {
						["genericShowOn"] = "showAlways",
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["class_and_spec"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["use_class"] = true,
				["use_spellknown"] = true,
				["zoneIds"] = "",
				["use_spec"] = true,
				["spec"] = {
					["single"] = 2,
					["multi"] = {
						[3] = true,
					},
				},
				["use_never"] = false,
				["spellknown"] = 1784,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "wPf4Ow30Njz",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = false,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "buttonOverlay",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = -1,
						["variable"] = "incombat",
						["value"] = 0,
					},
					["changes"] = {
						{
							["property"] = "sub.3.glow",
						}, -- [1]
					},
				}, -- [3]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "Pixel",
							["property"] = "sub.3.glowType",
						}, -- [2]
						{
							["value"] = false,
							["property"] = "desaturate",
						}, -- [3]
						{
							["property"] = "inverse",
						}, -- [4]
						{
							["value"] = true,
							["property"] = "cooldownEdge",
						}, -- [5]
					},
				}, -- [4]
			},
			["parent"] = "Maintenance - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Stealth",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["displayIcon"] = "",
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Nameplate range check 7 "] = {
			["iconSource"] = 0,
			["displayText_format_1.minRange_realm_name"] = "never",
			["xOffset"] = 0,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["yOffset"] = 0,
			["anchorPoint"] = "RIGHT",
			["displayText_format_p_time_format"] = 0,
			["url"] = "https://wago.io/YP6nljWXe/7",
			["icon"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "LEFT",
			["displayText_format_destUnit_color"] = "class",
			["desc"] = "Checks nearest 20 nameplates and shows a starfall icon if they are in range of starfall (36 yrds). \n\nHelps you make any decisions about using starfall and to stop any ninja pulls. \n\nIf you want more nameplates you can simply duplicate one of the weak auras in the group and add a number to the trigger. \n\nIf anyone finds an easier way to make this kind of a weak aura let me know as this was made editing a pre existing weak aura with a similar function.",
			["font"] = "PT Sans Narrow",
			["load"] = {
				["use_never"] = false,
				["class"] = {
					["single"] = "DRUID",
					["multi"] = {
						["DRUID"] = true,
					},
				},
				["use_encounterid"] = false,
				["use_class"] = true,
				["use_itemequiped"] = false,
				["zoneIds"] = "",
				["use_not_item_bonusid_equipped"] = false,
				["talent2"] = {
					["multi"] = {
						[20] = false,
					},
				},
				["use_zoneIds"] = false,
				["item_bonusid_equipped"] = "62080",
				["spec"] = {
					["multi"] = {
					},
				},
				["not_item_bonusid_equipped"] = "62080",
				["use_talent"] = false,
				["use_spellknown"] = false,
				["talent"] = {
					["multi"] = {
						[24] = true,
					},
				},
				["itemequiped"] = {
					62080, -- [1]
				},
				["size"] = {
					["multi"] = {
					},
				},
				["use_exact_spellknown"] = false,
				["use_item_bonusid_equipped"] = false,
				["itemtypeequipped"] = {
				},
			},
			["displayText_format_1.maxRange_format"] = "none",
			["shadowXOffset"] = 1,
			["displayText_format_1.minRange_abbreviate"] = false,
			["regionType"] = "icon",
			["displayText_format_destUnit_abbreviate_max"] = 8,
			["zoom"] = 0,
			["displayText_format_destUnit_format"] = "Unit",
			["tocversion"] = 30401,
			["alpha"] = 1,
			["config"] = {
			},
			["fixedWidth"] = 200,
			["outline"] = "OUTLINE",
			["wagoID"] = "YP6nljWXe",
			["parent"] = "Starfall Range Check on Nameplate",
			["shadowYOffset"] = -1,
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "event",
			["automaticWidth"] = "Auto",
			["triggers"] = {
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "35",
						["unit"] = "nameplate7",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [1]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "20",
						["unit"] = "nameplate7",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 62080,
						["use_inverse"] = false,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_exact_spellName"] = true,
						["event"] = "Spell Known",
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [6]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "15",
						["unit"] = "nameplate7",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [7]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate7",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [8]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16820,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [9]
				{
					["trigger"] = {
						["type"] = "spell",
						["use_genericShowOn"] = true,
						["genericShowOn"] = "showOnCooldown",
						["unit"] = "player",
						["realSpellName"] = 0,
						["use_spellName"] = true,
						["spellName"] = 16819,
						["use_inverse"] = true,
						["event"] = "Spell Known",
						["use_exact_spellName"] = true,
						["use_track"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [10]
				{
					["trigger"] = {
						["duration"] = "1",
						["range"] = "30",
						["unit"] = "nameplate7",
						["range_operator"] = "<=",
						["debuffType"] = "HELPFUL",
						["classification"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Range Check",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["type"] = "unit",
						["spellIds"] = {
						},
						["use_range"] = true,
						["use_absorbMode"] = true,
						["unevent"] = "auto",
						["use_unit"] = true,
						["use_specific_unit"] = true,
					},
					["untrigger"] = {
						["unit"] = "nameplate1",
						["use_specific_unit"] = true,
					},
				}, -- [11]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    if trigger[1] and trigger[3] and trigger[5] then\n        return true\n    elseif trigger[2] and trigger[4] and trigger[5] then\n        return true\n    elseif trigger[3] and trigger[8] and trigger[6] then\n        return true\n    elseif trigger[4] and trigger[7] and trigger[6] then\n        return true\n    elseif trigger[4] and (trigger[9] and trigger[10]) and trigger[7] then\n        return true\n    elseif trigger[3] and (trigger[9] and trigger[10]) and trigger[11] then\n        return true\n    end\nend",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["version"] = 7,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%maxRange",
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = false,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_text_format_p_time_mod_rate"] = true,
					["anchorXOffset"] = 0,
					["text_text_format_minRange_format"] = "none",
					["type"] = "subtext",
					["text_text_format_maxRange_format"] = "none",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_text_format_p_time_format"] = 0,
					["text_shadowYOffset"] = 0,
					["text_fontType"] = "OUTLINE",
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "CENTER",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["anchorYOffset"] = 0,
					["text_fontSize"] = 12,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_text_format_p_time_precision"] = 1,
				}, -- [2]
			},
			["height"] = 25,
			["displayText_format_destUnit_realm_name"] = "never",
			["preferToUpdate"] = false,
			["information"] = {
				["forceEvents"] = true,
			},
			["displayText_format_1.minRange_color"] = true,
			["source"] = "import",
			["conditions"] = {
			},
			["displayIcon"] = 236168,
			["cooldownTextDisabled"] = false,
			["displayText_format_1.minRange_round_type"] = "ceil",
			["authorOptions"] = {
			},
			["desaturate"] = false,
			["wordWrap"] = "WordWrap",
			["anchorFrameType"] = "NAMEPLATE",
			["useCooldownModRate"] = true,
			["displayText_format_destUnit_abbreviate"] = false,
			["displayText_format_1.minRange_format"] = "Number",
			["displayText_format_p_time_precision"] = 1,
			["color"] = {
				0.97647058823529, -- [1]
				1, -- [2]
				0.97647058823529, -- [3]
				1, -- [4]
			},
			["justify"] = "LEFT",
			["uid"] = "YUdEt6j0(39",
			["semver"] = "1.0.6",
			["displayText"] = "%1.maxRange",
			["id"] = "Nameplate range check 7 ",
			["anchorFrameParent"] = false,
			["frameStrata"] = 1,
			["width"] = 25,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["fontSize"] = 16,
			["inverse"] = false,
			["displayText_format_1.minRange_abbreviate_max"] = 8,
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["displayText_format_1.minRange_decimal_precision"] = 0,
			["cooldown"] = false,
			["cooldownEdge"] = false,
		},
		["Premeditation"] = {
			["iconSource"] = 2,
			["wagoID"] = "foIUC5_yM",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["ownOnly"] = true,
						["useName"] = false,
						["spellId"] = {
							"14183", -- [1]
						},
						["auranames"] = {
						},
						["unit"] = "player",
						["duration"] = "20",
						["event"] = "Combat Log",
						["subeventPrefix"] = "SPELL",
						["subeventSuffix"] = "_CAST_SUCCESS",
						["use_spellId"] = true,
						["spellIds"] = {
						},
						["use_sourceUnit"] = true,
						["names"] = {
						},
						["type"] = "combatlog",
						["sourceUnit"] = "player",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["track"] = "auto",
						["use_matchedRune"] = false,
						["duration"] = "1",
						["genericShowOn"] = "showAlways",
						["names"] = {
						},
						["use_showgcd"] = false,
						["debuffType"] = "HELPFUL",
						["type"] = "spell",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Cooldown Progress (Spell)",
						["unit"] = "player",
						["realSpellName"] = "Premeditation",
						["use_spellName"] = true,
						["spellIds"] = {
						},
						["unevent"] = "auto",
						["subeventPrefix"] = "SPELL",
						["use_genericShowOn"] = true,
						["use_track"] = true,
						["spellName"] = 14183,
					},
					["untrigger"] = {
						["genericShowOn"] = "showAlways",
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 70,
			["keepAspectRatio"] = true,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["border_size"] = 2,
					["type"] = "subborder",
					["border_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [2]
				{
					["glowFrequency"] = 0.25,
					["type"] = "subglow",
					["glowDuration"] = 1,
					["glowType"] = "buttonOverlay",
					["glowLength"] = 10,
					["glowYOffset"] = 0,
					["glowColor"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["useGlowColor"] = false,
					["glowXOffset"] = 0,
					["glowScale"] = 1,
					["glowThickness"] = 1,
					["glow"] = false,
					["glowLines"] = 8,
					["glowBorder"] = false,
				}, -- [3]
			},
			["height"] = 48,
			["load"] = {
				["use_petbattle"] = false,
				["class_and_spec"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["use_class"] = true,
				["use_spellknown"] = true,
				["zoneIds"] = "",
				["use_spec"] = true,
				["spec"] = {
					["single"] = 2,
					["multi"] = {
						[3] = true,
					},
				},
				["use_never"] = false,
				["spellknown"] = 14183,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["source"] = "import",
			["auto"] = true,
			["uid"] = "RuNDEQDdVvs",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["regionType"] = "icon",
			["cooldown"] = true,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = false,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "buttonOverlay",
							["property"] = "sub.3.glowType",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -1,
						["variable"] = "incombat",
						["value"] = 0,
					},
					["changes"] = {
						{
							["property"] = "sub.3.glow",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "onCooldown",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [3]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "sub.3.glow",
						}, -- [1]
						{
							["value"] = "Pixel",
							["property"] = "sub.3.glowType",
						}, -- [2]
						{
							["property"] = "desaturate",
						}, -- [3]
						{
							["property"] = "inverse",
						}, -- [4]
						{
							["value"] = true,
							["property"] = "cooldownEdge",
						}, -- [5]
					},
				}, -- [4]
			},
			["parent"] = "Core - Rogue",
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["zoom"] = 0.3,
			["semver"] = "2.0.23",
			["tocversion"] = 30401,
			["id"] = "Premeditation",
			["frameStrata"] = 1,
			["useCooldownModRate"] = true,
			["width"] = 48,
			["cooldownTextDisabled"] = false,
			["config"] = {
			},
			["inverse"] = true,
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["displayIcon"] = "",
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Combo Point 3 - Rogue"] = {
			["sparkWidth"] = 10,
			["iconSource"] = -1,
			["authorOptions"] = {
			},
			["adjustedMax"] = "3",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["sparkRotation"] = 0,
			["url"] = "https://wago.io/LuxthosRogueWrath/25",
			["backgroundColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.34336978197098, -- [4]
			},
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["enableGradient"] = false,
			["selfPoint"] = "TOP",
			["barColor"] = {
				0.85882352941176, -- [1]
				0.14509803921569, -- [2]
				0.050980392156863, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["sparkOffsetY"] = 0,
			["gradientOrientation"] = "HORIZONTAL",
			["load"] = {
				["use_class"] = true,
				["use_petbattle"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "ROGUE",
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 3,
					["multi"] = {
						[3] = true,
					},
				},
				["zoneIds"] = "",
			},
			["smoothProgress"] = false,
			["useAdjustededMin"] = true,
			["regionType"] = "aurabar",
			["texture"] = "Solid",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["auto"] = true,
			["tocversion"] = 30401,
			["alpha"] = 1,
			["config"] = {
			},
			["colorState"] = "",
			["sparkOffsetX"] = 0,
			["wagoID"] = "foIUC5_yM",
			["parent"] = "Combo Points - Rogue",
			["adjustedMin"] = "2",
			["sparkRotationMode"] = "AUTO",
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "unit",
						["names"] = {
						},
						["unevent"] = "auto",
						["use_unit"] = true,
						["duration"] = "1",
						["event"] = "Power",
						["subeventPrefix"] = "SPELL",
						["subeventSuffix"] = "_CAST_START",
						["powertype"] = 4,
						["spellIds"] = {
						},
						["use_power"] = false,
						["unit"] = "player",
						["use_absorbMode"] = true,
						["use_powertype"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = 1,
			},
			["internalVersion"] = 70,
			["animation"] = {
				["start"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["easeStrength"] = 3,
					["type"] = "none",
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["isPrimaryResource"] = false,
			["version"] = 25,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["type"] = "subforeground",
				}, -- [2]
				{
					["border_size"] = 2,
					["border_anchor"] = "bar",
					["type"] = "subborder",
					["border_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
					},
					["border_visible"] = false,
					["border_edge"] = "Square Full White",
					["border_offset"] = 0,
				}, -- [3]
			},
			["height"] = 20,
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = true,
			["source"] = "import",
			["xOffset"] = 0,
			["icon_side"] = "RIGHT",
			["preferToUpdate"] = false,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["sparkHeight"] = 30,
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["icon"] = false,
			["configGroup"] = "combo_points",
			["semver"] = "2.0.23",
			["spark"] = false,
			["sparkHidden"] = "NEVER",
			["zoom"] = 0,
			["frameStrata"] = 1,
			["width"] = 56,
			["id"] = "Combo Point 3 - Rogue",
			["anchorFrameType"] = "SCREEN",
			["inverse"] = false,
			["uid"] = "J5fx7RpCcYG",
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "<=",
						["value"] = "3",
						["variable"] = "power",
					},
					["changes"] = {
						{
							["value"] = {
								["custom"] = "aura_env.region.colorState = \"\"\nWeakAuras.ScanEvents(\"LWA_UPDATE_BAR\", aura_env, 3, 5)",
							},
							["property"] = "customcode",
						}, -- [1]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "==",
						["value"] = "4",
						["variable"] = "power",
					},
					["linked"] = true,
					["changes"] = {
						{
							["value"] = {
								["custom"] = "aura_env.region.colorState = \"highlight\"\nWeakAuras.ScanEvents(\"LWA_UPDATE_BAR\", aura_env, 3, 5)",
							},
							["property"] = "customcode",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "==",
						["value"] = "5",
						["variable"] = "power",
					},
					["linked"] = true,
					["changes"] = {
						{
							["value"] = {
								["custom"] = "aura_env.region.colorState = \"full\"\nWeakAuras.ScanEvents(\"LWA_UPDATE_BAR\", aura_env, 3, 5)",
							},
							["property"] = "customcode",
						}, -- [1]
					},
				}, -- [3]
			},
			["barColor2"] = {
				1, -- [1]
				1, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
					["custom"] = "aura_env.region.configGroup = \"combo_points\"",
					["do_custom"] = true,
				},
			},
		},
	},
	["registered"] = {
	},
	["login_squelch_time"] = 10,
	["editor_theme"] = "Monokai",
}
