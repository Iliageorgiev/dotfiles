
PlaterDB = {
	["captured_spells"] = {
		[42771] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Dragonflayer Ironhelm",
			["npcID"] = 23961,
		},
		[59211] = {
			["isChanneled"] = false,
			["source"] = "Azure Ring Guardian",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27638,
		},
		[6136] = {
			["source"] = "Maleki the Pallid",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 10438,
		},
		[61514] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Raging Construct",
			["npcID"] = 27970,
		},
		[57484] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Unknown",
			["npcID"] = 3619,
		},
		[53454] = {
			["encounterName"] = "Anub'arak",
			["source"] = "Anub'arak",
			["encounterID"] = 218,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29120,
		},
		[16564] = {
			["isChanneled"] = false,
			["source"] = "Wrathstrike Gargoyle",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31040,
		},
		[14443] = {
			["isChanneled"] = false,
			["source"] = "Captain Aerthas Firehawk",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 35090,
		},
		[59851] = {
			["encounterName"] = "Sjonnir the Ironshaper",
			["source"] = "Forged Iron Dwarf",
			["npcID"] = 27982,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 569,
		},
		[47697] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Alliance Cleric",
			["npcID"] = 26805,
		},
		[33624] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Undercity Mage",
			["npcID"] = 18971,
		},
		[33688] = {
			["isChanneled"] = false,
			["source"] = "Raging Colossus",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 19188,
		},
		[58508] = {
			["isChanneled"] = false,
			["source"] = "Portal Guardian",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30660,
		},
		[56525] = {
			["source"] = "Freed Crusader",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 30274,
		},
		[34392] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Sapphire Hive Wasp",
			["npcID"] = 28086,
		},
		[59020] = {
			["isChanneled"] = false,
			["source"] = "Spitting Cobra",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29774,
		},
		[48849] = {
			["encounterName"] = "King Dred",
			["source"] = "King Dred",
			["encounterID"] = 373,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27483,
		},
		[36631] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Nexus Drake Hatchling",
			["npcID"] = 26127,
		},
		[59212] = {
			["isChanneled"] = false,
			["source"] = "Azure Spellbinder",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27635,
		},
		[59276] = {
			["isChanneled"] = false,
			["source"] = "Ring-Lord Conjurer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27640,
		},
		[67729] = {
			["encounterName"] = "The Black Knight",
			["source"] = "Risen Champion",
			["npcID"] = 35590,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 340,
		},
		[43348] = {
			["isChanneled"] = false,
			["source"] = "Firjus the Soul Crusher",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 24213,
		},
		[59852] = {
			["encounterName"] = "Sjonnir the Ironshaper",
			["source"] = "Forged Iron Trogg",
			["npcID"] = 27979,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 569,
		},
		[47698] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Crystalline Protector",
			["npcID"] = 26792,
		},
		[33625] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Gold Shaman",
			["npcID"] = 32340,
		},
		[45971] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Fizzcrank Bomber",
			["npcID"] = 25765,
		},
		[48082] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Crystalline Frayer",
			["npcID"] = 26793,
		},
		[34073] = {
			["source"] = "Bleeding Hollow Necrolyte",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 19422,
		},
		[18100] = {
			["isChanneled"] = false,
			["source"] = "Harbinger of Horror",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32278,
		},
		[50833] = {
			["encounterName"] = "Krystallus",
			["type"] = "DEBUFF",
			["source"] = "Treant",
			["npcID"] = 1964,
			["event"] = "SPELL_AURA_APPLIED",
			["encounterID"] = 563,
		},
		[24529] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Unknown",
			["npcID"] = 11789,
		},
		[49106] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Ymirjar Berserker",
			["npcID"] = 26696,
		},
		[49170] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Ymirjar Dusk Shaman",
			["npcID"] = 26694,
		},
		[32858] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Auchenai Soulpriest",
			["npcID"] = 18493,
		},
		[53520] = {
			["encounterName"] = "Anub'arak",
			["source"] = "Anub'arak",
			["encounterID"] = 218,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29120,
		},
		[16565] = {
			["isChanneled"] = false,
			["source"] = "Baroness Anastari",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10436,
		},
		[47699] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Crystalline Keeper",
			["npcID"] = 26782,
		},
		[15547] = {
			["isChanneled"] = false,
			["source"] = "Fordragon Sentinel",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27576,
		},
		[27024] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Mage Hunter Ascendant",
			["npcID"] = 26727,
		},
		[33626] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Stormwind Soldier",
			["npcID"] = 18948,
		},
		[70291] = {
			["isChanneled"] = false,
			["source"] = "Ymirjar Skycaller",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31260,
		},
		[50578] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Frozen Sphere",
			["npcID"] = 28066,
		},
		[58830] = {
			["encounterName"] = "Chrono-Lord Epoch",
			["source"] = "Chrono-Lord Epoch",
			["npcID"] = 26532,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 295,
		},
		[17205] = {
			["source"] = "Winterfall Ursa",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 7438,
		},
		[69012] = {
			["encounterName"] = "Krick",
			["source"] = "Krick",
			["encounterID"] = 835,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36477,
		},
		[59214] = {
			["source"] = "Centrifuge Construct",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 27641,
		},
		[59278] = {
			["isChanneled"] = false,
			["source"] = "Ring-Lord Sorceress",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27639,
		},
		[388378] = {
			["isChanneled"] = false,
			["source"] = "Pebble",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 194870,
		},
		[34842] = {
			["isChanneled"] = false,
			["source"] = "Uncontrolled Voidwalker",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 16975,
		},
		[69780] = {
			["encounterName"] = "Escaped from Arthas",
			["source"] = "The Lich King",
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36954,
		},
		[70292] = {
			["isChanneled"] = false,
			["source"] = "Ymirjar Skycaller",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31260,
		},
		[25809] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Viper",
			["npcID"] = 19921,
		},
		[35290] = {
			["isChanneled"] = false,
			["source"] = "Ray",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 3100,
		},
		[47700] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Crystalline Keeper",
			["npcID"] = 26782,
		},
		[58127] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Argent Paladin",
			["npcID"] = 30704,
		},
		[21971] = {
			["isChanneled"] = false,
			["source"] = "Spirit of Koosu",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29034,
		},
		[50131] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Mage Slayer",
			["npcID"] = 26730,
		},
		[50195] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Mage Hunter Ascendant",
			["npcID"] = 26727,
		},
		[54417] = {
			["source"] = "Moragg",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 29316,
		},
		[18101] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Harbinger of Horror",
			["npcID"] = 32278,
		},
		[70421] = {
			["encounterName"] = "Overlrod Tyrannus",
			["source"] = "Freed Horde Slave",
			["encounterID"] = 837,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 37579,
		},
		[59023] = {
			["source"] = "Unyielding Constrictor",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 29768,
		},
		[59215] = {
			["isChanneled"] = false,
			["source"] = "Greater Ley-Whelp",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28276,
		},
		[61326] = {
			["isChanneled"] = false,
			["source"] = "Azure Scale-Binder",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26735,
		},
		[59343] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Anub'ar Champion",
			["encounterID"] = 216,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29062,
		},
		[3589] = {
			["isChanneled"] = false,
			["source"] = "Shrieking Banshee",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10463,
		},
		[53330] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Anub'ar Crypt Fiend",
			["encounterID"] = 216,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29097,
		},
		[57488] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Wailing Winds",
			["npcID"] = 30450,
		},
		[59599] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dragonflayer Bonecrusher",
			["npcID"] = 24069,
		},
		[51475] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dark Rune Elementalist",
			["npcID"] = 27962,
		},
		[59727] = {
			["encounterName"] = "Maiden of Grief",
			["source"] = "Maiden of Grief",
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27975,
		},
		[51859] = {
			["isChanneled"] = false,
			["source"] = "Eye of Acherus",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28511,
		},
		[33564] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Justinius the Harbinger",
			["npcID"] = 18966,
		},
		[60239] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Gargoyle Ambusher",
			["npcID"] = 32769,
		},
		[69527] = {
			["isChanneled"] = false,
			["source"] = "Iceborn Proto-Drake",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36891,
		},
		[54290] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Anub'ar Webspinner",
			["encounterID"] = 216,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29335,
		},
		[50324] = {
			["source"] = "Malefic Necromancer",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 31155,
		},
		[52435] = {
			["isChanneled"] = false,
			["source"] = "Scarlet Cannon",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28833,
		},
		[34076] = {
			["isChanneled"] = false,
			["source"] = "Worg Master Kruush",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 19442,
		},
		[72342] = {
			["isChanneled"] = false,
			["source"] = "Phantom Mage",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38172,
		},
		[56785] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Scourge Hulk",
			["npcID"] = 26555,
		},
		[17174] = {
			["isChanneled"] = false,
			["source"] = "Wavecrest Mariner",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 35098,
		},
		[50836] = {
			["encounterName"] = "Krystallus",
			["type"] = "DEBUFF",
			["source"] = "Treant",
			["npcID"] = 1964,
			["event"] = "SPELL_AURA_APPLIED",
			["encounterID"] = 563,
		},
		[38618] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Alliance Commander",
			["npcID"] = 27949,
		},
		[59152] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dark Rune Theurgist",
			["npcID"] = 27963,
		},
		[59280] = {
			["isChanneled"] = false,
			["source"] = "Snowflake",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28153,
		},
		[69528] = {
			["isChanneled"] = false,
			["source"] = "Ymirjar Deathbringer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36892,
		},
		[72215] = {
			["isChanneled"] = false,
			["source"] = "Tortured Rifleman",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38176,
		},
		[72343] = {
			["source"] = "Phantom Mage",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 38172,
		},
		[25810] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Viper",
			["npcID"] = 19921,
		},
		[49749] = {
			["isChanneled"] = false,
			["source"] = "Iron Rune Worker",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 23672,
		},
		[69017] = {
			["encounterName"] = "Krick",
			["source"] = "Exploding Orb",
			["encounterID"] = 835,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36610,
		},
		[13005] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Green Paladin",
			["npcID"] = 32342,
		},
		[47958] = {
			["encounterName"] = "Ormorok the Tree-Shaper",
			["source"] = "Ormorok the Tree-Shaper",
			["npcID"] = 26794,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 524,
		},
		[52372] = {
			["isChanneled"] = false,
			["source"] = "Unworthy Initiate",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29566,
		},
		[52436] = {
			["source"] = "Scarlet Cannon",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 28833,
		},
		[72344] = {
			["isChanneled"] = false,
			["source"] = "Phantom Hallucination",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38567,
		},
		[70425] = {
			["encounterName"] = "Overlrod Tyrannus",
			["source"] = "Freed Horde Slave",
			["encounterID"] = 837,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 37578,
		},
		[15244] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Mage Hunter Ascendant",
			["npcID"] = 26727,
		},
		[59025] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dark Rune Elementalist",
			["npcID"] = 27962,
		},
		[38619] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Alliance Commander",
			["npcID"] = 27949,
		},
		[59217] = {
			["encounterName"] = "Mage-Lord Urom",
			["source"] = "Phantasmal Cloudscraper",
			["encounterID"] = 532,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27645,
		},
		[49110] = {
			["isChanneled"] = false,
			["source"] = "Wyrmrest Guardian",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26933,
		},
		[59601] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dragonflayer Forge Master",
			["npcID"] = 24079,
		},
		[35229] = {
			["source"] = "Sporeggar Spawn",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 18358,
		},
		[35293] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Boar",
			["npcID"] = 3100,
		},
		[15532] = {
			["isChanneled"] = false,
			["source"] = "Gold Mage",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32341,
		},
		[69019] = {
			["encounterName"] = "Krick",
			["source"] = "Exploding Orb",
			["encounterID"] = 835,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36610,
		},
		[58130] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Ebon Blade Champion",
			["npcID"] = 30703,
		},
		[69275] = {
			["encounterName"] = "Overlrod Tyrannus",
			["source"] = "Scourgelord Tyrannus",
			["encounterID"] = 837,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36658,
		},
		[50198] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Mage Hunter Initiate",
			["npcID"] = 26728,
		},
		[67868] = {
			["encounterName"] = "Grand Champions",
			["type"] = "DEBUFF",
			["source"] = "Ambrose Boltspark's Mount",
			["npcID"] = 35633,
			["event"] = "SPELL_AURA_APPLIED",
			["encounterID"] = 334,
		},
		[70043] = {
			["encounterName"] = "Bronjahm",
			["source"] = "Bronjahm",
			["encounterID"] = 829,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36497,
		},
		[15708] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Baron Rivendare",
			["npcID"] = 29109,
		},
		[58770] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dark Necromancer",
			["npcID"] = 28200,
		},
		[60945] = {
			["isChanneled"] = false,
			["source"] = "Ebon Blade Reaper",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31316,
		},
		[23380] = {
			["source"] = "Taunka Windfury",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 27571,
		},
		[69148] = {
			["isChanneled"] = false,
			["source"] = "Spectral Warden",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36666,
		},
		[31664] = {
			["isChanneled"] = false,
			["source"] = "Frenzied Gargoyle",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27691,
		},
		[49111] = {
			["isChanneled"] = false,
			["source"] = "Azure Dragon",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27608,
		},
		[53333] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Anub'ar Necromancer",
			["encounterID"] = 216,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29098,
		},
		[7992] = {
			["source"] = "Venom Belcher",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 10417,
		},
		[35294] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Boar",
			["npcID"] = 3100,
		},
		[23828] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Unknown",
			["npcID"] = 416,
		},
		[59986] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30622,
		},
		[69021] = {
			["encounterName"] = "Krick",
			["source"] = "Ick",
			["encounterID"] = 835,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36476,
		},
		[43930] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Dragonflayer Forge Master",
			["npcID"] = 24079,
		},
		[52182] = {
			["source"] = "Jaloot",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 28667,
		},
		[16172] = {
			["isChanneled"] = false,
			["source"] = "Ghoul Ravener",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10406,
		},
		[52566] = {
			["isChanneled"] = false,
			["source"] = "Scarlet Fleet Defender",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28834,
		},
		[52630] = {
			["isChanneled"] = false,
			["source"] = "Runic Battle Golem",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26284,
		},
		[38557] = {
			["isChanneled"] = false,
			["source"] = "Kvaldir Berserker",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 34947,
		},
		[8160] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Foulweald Shaman",
			["npcID"] = 3748,
		},
		[18327] = {
			["isChanneled"] = false,
			["source"] = "Baroness Anastari",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10436,
		},
		[34655] = {
			["encounterName"] = "Overlrod Tyrannus",
			["type"] = "DEBUFF",
			["source"] = "Viper",
			["encounterID"] = 837,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 19921,
		},
		[34719] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Conqueror Krenna",
			["npcID"] = 27727,
		},
		[16380] = {
			["isChanneled"] = false,
			["source"] = "Eye of Naxxramas",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10411,
		},
		[53334] = {
			["isChanneled"] = false,
			["source"] = "Anub'ar Necromancer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29064,
		},
		[47257] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Anub'ar Cultist",
			["npcID"] = 26319,
		},
		[59603] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dragonflayer Heartsplitter",
			["npcID"] = 24071,
		},
		[43291] = {
			["isChanneled"] = false,
			["source"] = "Dragonflayer Berserker",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 24216,
		},
		[70302] = {
			["isChanneled"] = false,
			["source"] = "Wrathbone Laborer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36830,
		},
		[49560] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Ebon Blade Vindicator",
			["npcID"] = 32488,
		},
		[51799] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dark Rune Scholar",
			["npcID"] = 27964,
		},
		[68895] = {
			["isChanneled"] = false,
			["source"] = "Spiteful Apparition",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36551,
		},
		[43803] = {
			["isChanneled"] = false,
			["source"] = "Gjalerbron Gargoyle",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 24440,
		},
		[33632] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Ironforge Paladin",
			["npcID"] = 18986,
		},
		[16856] = {
			["isChanneled"] = false,
			["source"] = "Scourge Brute",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26623,
		},
		[50328] = {
			["isChanneled"] = false,
			["source"] = "Emerald Drake",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27692,
		},
		[72222] = {
			["isChanneled"] = false,
			["source"] = "Tortured Rifleman",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38176,
		},
		[69024] = {
			["encounterName"] = "Krick",
			["source"] = "Krick",
			["encounterID"] = 835,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36477,
		},
		[67233] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Argent Monk",
			["npcID"] = 35305,
		},
		[49113] = {
			["isChanneled"] = false,
			["source"] = "Wyrmrest Temple Drake",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26925,
		},
		[61459] = {
			["isChanneled"] = false,
			["source"] = "Plague Walker",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30283,
		},
		[67745] = {
			["encounterName"] = "The Black Knight",
			["source"] = "The Black Knight",
			["npcID"] = 35451,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 340,
		},
		[53399] = {
			["isChanneled"] = false,
			["source"] = "Scarlet Infantryman",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28609,
		},
		[59604] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dragonflayer Heartsplitter",
			["npcID"] = 24071,
		},
		[70176] = {
			["encounterName"] = "Escaped from Arthas",
			["type"] = "DEBUFF",
			["source"] = "Lumbering Abomination",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 37069,
		},
		[23829] = {
			["source"] = "Unknown",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 416,
		},
		[49753] = {
			["isChanneled"] = false,
			["source"] = "Iron Rune Runemaster",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 23675,
		},
		[15037] = {
			["isChanneled"] = false,
			["source"] = "Scorching Totem",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 9637,
		},
		[49945] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Scavenge-bot 004-A8",
			["npcID"] = 25752,
		},
		[69409] = {
			["encounterName"] = "Escaped from Arthas",
			["source"] = "The Lich King",
			["encounterID"] = 843,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36954,
		},
		[48090] = {
			["source"] = "Unknown",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 17252,
		},
		[38047] = {
			["isChanneled"] = false,
			["source"] = "Azure Spellbinder",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27635,
		},
		[66083] = {
			["encounterName"] = "Grand Champions",
			["source"] = "Jaelyne Evensong",
			["encounterID"] = 334,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 34657,
		},
		[57046] = {
			["isChanneled"] = false,
			["source"] = "Crazed Mana-Surge",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26737,
		},
		[67235] = {
			["isChanneled"] = false,
			["source"] = "Argent Monk",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 35305,
		},
		[59349] = {
			["encounterName"] = "Anub'arak",
			["source"] = "Anub'ar Darter",
			["encounterID"] = 218,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29213,
		},
		[61460] = {
			["source"] = "Plague Walker",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 30283,
		},
		[53400] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Hadronox",
			["encounterID"] = 216,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28921,
		},
		[59605] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dragonflayer Heartsplitter",
			["npcID"] = 24071,
		},
		[70306] = {
			["isChanneled"] = false,
			["source"] = "Frostblade",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 37670,
		},
		[6713] = {
			["isChanneled"] = false,
			["source"] = "Gold Warrior",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32322,
		},
		[59861] = {
			["encounterName"] = "Sjonnir the Ironshaper",
			["source"] = "Sjonnir The Ironshaper",
			["npcID"] = 27978,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 569,
		},
		[15501] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Torgg Thundertotem",
			["npcID"] = 27716,
		},
		[68771] = {
			["encounterName"] = "Forgemaster Garfrost",
			["source"] = "Forgemaster Garfrost",
			["encounterID"] = 833,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36494,
		},
		[20823] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Legashi Hellcaller",
			["npcID"] = 6202,
		},
		[69155] = {
			["encounterName"] = "Overlrod Tyrannus",
			["source"] = "Scourgelord Tyrannus",
			["encounterID"] = 837,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36658,
		},
		[33634] = {
			["source"] = "Bloodmage",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 19258,
		},
		[64595] = {
			["isChanneled"] = false,
			["source"] = "Campaign Warhorse",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 33531,
		},
		[54424] = {
			["source"] = "Unknown",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 417,
		},
		[66085] = {
			["encounterName"] = "Grand Champions",
			["type"] = "BUFF",
			["source"] = "Jaelyne Evensong",
			["encounterID"] = 334,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 34657,
		},
		[50522] = {
			["source"] = "Gorloc Mud Splasher",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 25699,
		},
		[52633] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Infinite Adversary",
			["npcID"] = 28340,
		},
		[42526] = {
			["isChanneled"] = false,
			["source"] = "Spore",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 23876,
		},
		[56919] = {
			["encounterName"] = "Frozen Commander",
			["source"] = "Alliance Cleric",
			["encounterID"] = 519,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26805,
		},
		[69028] = {
			["encounterName"] = "Krick",
			["source"] = "Krick",
			["encounterID"] = 835,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36477,
		},
		[61269] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Scalesworn Elite",
			["npcID"] = 32534,
		},
		[51162] = {
			["encounterName"] = "Ley-Guardian Eregos",
			["source"] = "Ley-Guardian Eregos",
			["encounterID"] = 534,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27656,
		},
		[61461] = {
			["isChanneled"] = false,
			["source"] = "Frostbringer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30286,
		},
		[49243] = {
			["source"] = "Wyrmrest Defender",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 27629,
		},
		[53401] = {
			["isChanneled"] = false,
			["source"] = "Wolfgang",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 17669,
		},
		[59606] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dragonflayer Ironhelm",
			["npcID"] = 23961,
		},
		[53529] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Bear",
			["npcID"] = 1186,
		},
		[59734] = {
			["encounterName"] = "Ingvar the Plunderer",
			["source"] = "Ingvar the Plunderer",
			["npcID"] = 23954,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 575,
		},
		[15981] = {
			["isChanneled"] = false,
			["source"] = "Grove Walker",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31228,
		},
		[32018] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Storm Revenant",
			["npcID"] = 28858,
		},
		[47772] = {
			["encounterName"] = "Grand Magus Telestra",
			["source"] = "Grand Magus Telestra",
			["npcID"] = 26731,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 520,
		},
		[4962] = {
			["isChanneled"] = false,
			["source"] = "Crypt Beast",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10413,
		},
		[60182] = {
			["isChanneled"] = false,
			["source"] = "Azure Sorcerer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30667,
		},
		[69413] = {
			["isChanneled"] = false,
			["source"] = "Krick",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36477,
		},
		[54361] = {
			["isChanneled"] = false,
			["source"] = "Zuramat the Obliterator",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29314,
		},
		[58519] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Orgrimmar Grunt",
			["npcID"] = 3296,
		},
		[52442] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Arthas",
			["npcID"] = 26499,
		},
		[34083] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Scalding Whelp",
			["npcID"] = 2725,
		},
		[54681] = {
			["source"] = "Fabi",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 6498,
		},
		[60950] = {
			["isChanneled"] = false,
			["source"] = "Death Knight Adept",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31318,
		},
		[68774] = {
			["encounterName"] = "Forgemaster Garfrost",
			["source"] = "Forgemaster Garfrost",
			["encounterID"] = 833,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36494,
		},
		[55065] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Shadow Vault Abomination",
			["npcID"] = 31438,
		},
		[59223] = {
			["encounterName"] = "Mage-Lord Urom",
			["source"] = "Phantasmal Cloudscraper",
			["encounterID"] = 532,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27645,
		},
		[55193] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Shardhorn Rhino",
			["npcID"] = 28009,
		},
		[38881] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Azure Scale-Binder",
			["npcID"] = 26735,
		},
		[61462] = {
			["isChanneled"] = false,
			["source"] = "Frostbringer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30286,
		},
		[67751] = {
			["encounterName"] = "The Black Knight",
			["source"] = "The Black Knight",
			["npcID"] = 35451,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 340,
		},
		[59607] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dragonflayer Ironhelm",
			["npcID"] = 23961,
		},
		[59735] = {
			["encounterName"] = "Ingvar the Plunderer",
			["source"] = "Ingvar the Plunderer",
			["npcID"] = 23954,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 575,
		},
		[30931] = {
			["isChanneled"] = false,
			["source"] = "Hyldnir Overseer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29426,
		},
		[59863] = {
			["encounterName"] = "Tribunal of Ages",
			["source"] = "Dark Rune Stormcaller",
			["npcID"] = 27984,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 567,
		},
		[20792] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Windshear Geomancer",
			["npcID"] = 4003,
		},
		[47773] = {
			["encounterName"] = "Grand Magus Telestra",
			["source"] = "Grand Magus Telestra",
			["npcID"] = 26731,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 520,
		},
		[56153] = {
			["encounterName"] = "Elder Nadox",
			["type"] = "BUFF",
			["source"] = "Ahn'kahar Guardian",
			["encounterID"] = 212,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 30176,
		},
		[58456] = {
			["isChanneled"] = false,
			["source"] = "Azure Binder",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31007,
		},
		[38370] = {
			["isChanneled"] = false,
			["source"] = "North Fleet Marksman",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 23946,
		},
		[60951] = {
			["isChanneled"] = false,
			["source"] = "Death Knight Adept",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31318,
		},
		[55066] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Servant of Freya",
			["npcID"] = 29036,
		},
		[23511] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Stormwind Soldier",
			["npcID"] = 18948,
		},
		[59352] = {
			["isChanneled"] = false,
			["source"] = "Anub'ar Prime Guard",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29128,
		},
		[61463] = {
			["isChanneled"] = false,
			["source"] = "Eye of Taldaram",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30285,
		},
		[53403] = {
			["source"] = "Wolfgang",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 17669,
		},
		[59608] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dragonflayer Metalworker",
			["npcID"] = 24078,
		},
		[51484] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dark Rune Theurgist",
			["npcID"] = 27963,
		},
		[59864] = {
			["encounterName"] = "Tribunal of Ages",
			["source"] = "Dark Rune Stormcaller",
			["npcID"] = 27984,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 567,
		},
		[32019] = {
			["isChanneled"] = false,
			["source"] = "Island Shoveltusk",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 24681,
		},
		[59992] = {
			["encounterName"] = "Overlrod Tyrannus",
			["source"] = "Freed Horde Slave",
			["encounterID"] = 837,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 37577,
		},
		[39586] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Gold Shaman",
			["npcID"] = 32340,
		},
		[58137] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Intrepid Ghoul",
			["npcID"] = 31015,
		},
		[48094] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Keristrasza",
			["npcID"] = 26723,
		},
		[50461] = {
			["source"] = "Anti-Magic Zone",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 28306,
		},
		[72360] = {
			["encounterName"] = "Marwyn",
			["source"] = "Marwyn",
			["encounterID"] = 839,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38113,
		},
		[52636] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Infinite Hunter",
			["npcID"] = 27743,
		},
		[58841] = {
			["encounterName"] = "Meathook",
			["source"] = "Meathook",
			["npcID"] = 26529,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 293,
		},
		[56858] = {
			["isChanneled"] = false,
			["source"] = "Twilight Worshipper",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30111,
		},
		[68778] = {
			["encounterName"] = "Forgemaster Garfrost",
			["source"] = "Forgemaster Garfrost",
			["encounterID"] = 833,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36494,
		},
		[59033] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dark Rune Scholar",
			["npcID"] = 27964,
		},
		[57050] = {
			["isChanneled"] = false,
			["source"] = "Crystalline Protector",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26792,
		},
		[55067] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Servant of Freya",
			["npcID"] = 29036,
		},
		[61272] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Scalesworn Elite",
			["npcID"] = 32534,
		},
		[53148] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Boar",
			["npcID"] = 3100,
		},
		[59417] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Hadronox",
			["encounterID"] = 216,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28921,
		},
		[61528] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Lightning Construct",
			["npcID"] = 27972,
		},
		[53468] = {
			["encounterName"] = "Anub'arak",
			["type"] = "DEBUFF",
			["source"] = "Anub'arak",
			["encounterID"] = 218,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 29120,
		},
		[53532] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Felix",
			["npcID"] = 822,
		},
		[55643] = {
			["isChanneled"] = false,
			["source"] = "Ruins Dweller",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29920,
		},
		[20793] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Venture Co. Deforester",
			["npcID"] = 3991,
		},
		[20825] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Wastewander Shadow Mage",
			["npcID"] = 5617,
		},
		[15550] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Mammoth Calf",
			["npcID"] = 24613,
		},
		[56091] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Wyrmrest Skytalon",
			["npcID"] = 32535,
		},
		[21049] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Alliance Berserker",
			["npcID"] = 26800,
		},
		[48287] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Infesting Jormungar",
			["npcID"] = 30148,
		},
		[34086] = {
			["isChanneled"] = false,
			["source"] = "Maiden of Pain",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 19408,
		},
		[72362] = {
			["encounterName"] = "Marwyn",
			["source"] = "Marwyn",
			["encounterID"] = 839,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38113,
		},
		[52701] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Stormforged Pillager",
			["npcID"] = 29586,
		},
		[31540] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Angrathar Aberration",
			["npcID"] = 27631,
		},
		[59034] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dark Rune Shaper",
			["npcID"] = 27965,
		},
		[57051] = {
			["isChanneled"] = false,
			["source"] = "Crystalline Protector",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26792,
		},
		[21401] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Gold Shaman",
			["npcID"] = 32340,
		},
		[55196] = {
			["isChanneled"] = false,
			["source"] = "Runed Giant",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26417,
		},
		[59354] = {
			["isChanneled"] = false,
			["source"] = "Anub'ar Prime Guard",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29128,
		},
		[17435] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Baron Rivendare",
			["npcID"] = 29109,
		},
		[59482] = {
			["encounterName"] = "Elder Nadox",
			["type"] = "DEBUFF",
			["source"] = "Ahn'kahar Guardian",
			["encounterID"] = 212,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 30176,
		},
		[70188] = {
			["source"] = "Lady Sylvanas Windrunner",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 37554,
		},
		[72363] = {
			["encounterName"] = "Marwyn",
			["source"] = "Marwyn",
			["encounterID"] = 839,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38113,
		},
		[23768] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Sayge",
			["npcID"] = 14822,
		},
		[23832] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Unknown",
			["npcID"] = 417,
		},
		[59994] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30622,
		},
		[55964] = {
			["encounterName"] = "Prince Taldaram",
			["source"] = "Prince Taldaram",
			["encounterID"] = 213,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29308,
		},
		[56092] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Wyrmrest Skytalon",
			["npcID"] = 32535,
		},
		[45985] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Bloodspore Firestarter",
			["npcID"] = 25470,
		},
		[48096] = {
			["encounterName"] = "Keristrasza",
			["source"] = "Keristrasza",
			["npcID"] = 26723,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 526,
		},
		[52318] = {
			["isChanneled"] = false,
			["source"] = "Silverbrook Defender",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27676,
		},
		[69933] = {
			["encounterName"] = "Escaped from Arthas",
			["source"] = "Spiritual Reflection",
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 37068,
		},
		[52446] = {
			["isChanneled"] = false,
			["source"] = "Skittering Infector",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28736,
		},
		[56860] = {
			["isChanneled"] = false,
			["source"] = "Mage Hunter Initiate",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26728,
		},
		[59035] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dark Rune Warrior",
			["npcID"] = 27960,
		},
		[57052] = {
			["isChanneled"] = false,
			["source"] = "Crystalline Keeper",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26782,
		},
		[67247] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Argent Lightwielder",
			["npcID"] = 35309,
		},
		[51103] = {
			["encounterName"] = "Mage-Lord Urom",
			["source"] = "Mage-Lord Urom",
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27655,
		},
		[61402] = {
			["isChanneled"] = false,
			["source"] = "Ring-Lord Sorceress",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27639,
		},
		[59419] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Hadronox",
			["encounterID"] = 216,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28921,
		},
		[53406] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Hadronox",
			["encounterID"] = 216,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28921,
		},
		[59611] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dragonflayer Overseer",
			["npcID"] = 24085,
		},
		[30933] = {
			["isChanneled"] = false,
			["source"] = "North Fleet Marksman",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 23946,
		},
		[49696] = {
			["encounterName"] = "Trollgore",
			["source"] = "Risen Drakkari Soulmage",
			["encounterID"] = 369,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26636,
		},
		[59995] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30621,
		},
		[20826] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Wastewander Shadow Mage",
			["npcID"] = 5617,
		},
		[69167] = {
			["encounterName"] = "Overlrod Tyrannus",
			["source"] = "Scourgelord Tyrannus",
			["encounterID"] = 837,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36658,
		},
		[12544] = {
			["isChanneled"] = false,
			["source"] = "Magister Surdiel",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32170,
		},
		[33832] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Crazed Mana-Wraith",
			["npcID"] = 26746,
		},
		[33896] = {
			["isChanneled"] = false,
			["source"] = "Stonescythe Whelp",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 16927,
		},
		[38182] = {
			["isChanneled"] = false,
			["source"] = "Gryphon Rider Guard",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 15241,
		},
		[68272] = {
			["isChanneled"] = false,
			["source"] = "The Black Brewmaiden",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36024,
		},
		[56733] = {
			["isChanneled"] = false,
			["source"] = "Eye of Taldaram",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30285,
		},
		[54878] = {
			["encounterName"] = "Drakkari Colossus",
			["source"] = "Drakkari Elemental",
			["encounterID"] = 385,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29573,
		},
		[68912] = {
			["encounterName"] = "Devourer of Souls",
			["source"] = "Devourer of Souls",
			["encounterID"] = 831,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36502,
		},
		[42724] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dark Rune Warrior",
			["npcID"] = 27960,
		},
		[59420] = {
			["isChanneled"] = false,
			["source"] = "Hadronox",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28921,
		},
		[67761] = {
			["encounterName"] = "The Black Knight",
			["source"] = "The Black Knight",
			["npcID"] = 35451,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 340,
		},
		[19579] = {
			["source"] = "Unknown",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 20773,
		},
		[55582] = {
			["isChanneled"] = false,
			["source"] = "Drakkari Medicine Man",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29826,
		},
		[19643] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Converted Hero",
			["npcID"] = 32255,
		},
		[59868] = {
			["encounterName"] = "Tribunal of Ages",
			["source"] = "Dark Matter",
			["npcID"] = 28235,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 567,
		},
		[68785] = {
			["encounterName"] = "Forgemaster Garfrost",
			["source"] = "Forgemaster Garfrost",
			["encounterID"] = 833,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36494,
		},
		[70960] = {
			["isChanneled"] = false,
			["source"] = "The Damned",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 37011,
		},
		[33641] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Justinius the Harbinger",
			["npcID"] = 18966,
		},
		[43940] = {
			["source"] = "Valgarde Paladin",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 24103,
		},
		[33833] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Crazed Mana-Wraith",
			["npcID"] = 26746,
		},
		[58461] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Azure Invader",
			["npcID"] = 30961,
		},
		[54559] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "K3 Perimeter Turret",
			["npcID"] = 29483,
		},
		[72368] = {
			["encounterName"] = "Marwyn",
			["source"] = "Marwyn",
			["encounterID"] = 839,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38113,
		},
		[58845] = {
			["encounterName"] = "Salram the Fleshcrafter",
			["source"] = "Salramm the Fleshcrafter",
			["npcID"] = 26530,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 294,
		},
		[56862] = {
			["isChanneled"] = false,
			["source"] = "Bound Water Elemental",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30419,
		},
		[68786] = {
			["encounterName"] = "Forgemaster Garfrost",
			["type"] = "DEBUFF",
			["source"] = "Forgemaster Garfrost",
			["encounterID"] = 833,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 36494,
		},
		[66867] = {
			["encounterName"] = "Argent Champion",
			["source"] = "Eadric the Pure",
			["npcID"] = 35119,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 338,
		},
		[57054] = {
			["encounterName"] = "Ormorok the Tree-Shaper",
			["source"] = "Crystalline Tender",
			["encounterID"] = 524,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28231,
		},
		[55071] = {
			["source"] = "Primordial Drake",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 28378,
		},
		[32693] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dark Rune Elementalist",
			["npcID"] = 27962,
		},
		[59357] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Anub'ar Shadowcaster",
			["encounterID"] = 216,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28733,
		},
		[41062] = {
			["isChanneled"] = false,
			["source"] = "Frostblade",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 37670,
		},
		[57566] = {
			["source"] = "Unknown",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 417,
		},
		[70194] = {
			["encounterName"] = "Escaped from Arthas",
			["source"] = "Lady Sylvanas Windrunner",
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 37554,
		},
		[15471] = {
			["isChanneled"] = false,
			["source"] = "Crypt Crawler",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10412,
		},
		[20795] = {
			["isChanneled"] = false,
			["source"] = "Boulderfist Mage",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 17137,
		},
		[47779] = {
			["encounterName"] = "Grand Magus Telestra",
			["source"] = "Steward",
			["npcID"] = 26729,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 520,
		},
		[18812] = {
			["isChanneled"] = false,
			["source"] = "Winterskorn Defender",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 24015,
		},
		[33642] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Melgromm Highmountain",
			["npcID"] = 18969,
		},
		[58270] = {
			["isChanneled"] = false,
			["source"] = "Unbound Corrupter",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30868,
		},
		[48291] = {
			["encounterName"] = "King Ymiron",
			["source"] = "King Ymiron",
			["npcID"] = 26861,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 583,
		},
		[58782] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Tomb Stalker",
			["npcID"] = 28199,
		},
		[50658] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Beryl Treasure Hunter",
			["npcID"] = 25353,
		},
		[68788] = {
			["encounterName"] = "Forgemaster Garfrost",
			["source"] = "Forgemaster Garfrost",
			["encounterID"] = 833,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36494,
		},
		[59038] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Lightning Construct",
			["npcID"] = 27972,
		},
		[59102] = {
			["isChanneled"] = false,
			["source"] = "Ahn'kahar Spell Flinger",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30278,
		},
		[69172] = {
			["encounterName"] = "Overlrod Tyrannus",
			["source"] = "Scourgelord Tyrannus",
			["encounterID"] = 837,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36658,
		},
		[51170] = {
			["encounterName"] = "Ley-Guardian Eregos",
			["source"] = "Ley-Guardian Eregos",
			["encounterID"] = 534,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27656,
		},
		[53345] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Hearthglen Crusader",
			["npcID"] = 29102,
		},
		[59614] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dragonflayer Overseer",
			["npcID"] = 24085,
		},
		[59742] = {
			["encounterName"] = "Krystallus",
			["source"] = "Krystallus",
			["npcID"] = 27977,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 563,
		},
		[63900] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Boar",
			["npcID"] = 3100,
		},
		[21787] = {
			["source"] = "Spirit of Atha",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 29033,
		},
		[59998] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30621,
		},
		[47780] = {
			["encounterName"] = "Grand Magus Telestra",
			["source"] = "Steward",
			["npcID"] = 26729,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 520,
		},
		[14032] = {
			["isChanneled"] = false,
			["source"] = "Gold Priest",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32325,
		},
		[33643] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Melgromm Highmountain",
			["npcID"] = 18969,
		},
		[16143] = {
			["source"] = "Mangled Cadaver",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 10382,
		},
		[54369] = {
			["isChanneled"] = false,
			["source"] = "Zuramat the Obliterator",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29314,
		},
		[12097] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Decomposed Ghoul",
			["npcID"] = 31812,
		},
		[56736] = {
			["isChanneled"] = false,
			["source"] = "Bonegrinder",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30284,
		},
		[58975] = {
			["encounterName"] = "Drakkari Colossus",
			["source"] = "Drakkari Golem",
			["encounterID"] = 385,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29832,
		},
		[59039] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Unrelenting Construct",
			["npcID"] = 27971,
		},
		[59103] = {
			["isChanneled"] = false,
			["source"] = "Ahn'kahar Spell Flinger",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30278,
		},
		[22427] = {
			["isChanneled"] = false,
			["source"] = "Sergeant Gorth",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 24027,
		},
		[67255] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Argent Monk",
			["npcID"] = 35305,
		},
		[5115] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dark Iron Taskmaster",
			["npcID"] = 5846,
		},
		[59359] = {
			["encounterName"] = "Anub'arak",
			["source"] = "Anub'ar Venomancer",
			["encounterID"] = 218,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29217,
		},
		[67767] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Knight of the Ebon Blade",
			["npcID"] = 38505,
		},
		[51363] = {
			["encounterName"] = "Novos the Summoner",
			["source"] = "Risen Shadowcaster",
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27600,
		},
		[49380] = {
			["encounterName"] = "Trollgore",
			["source"] = "Trollgore",
			["encounterID"] = 369,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26630,
		},
		[70326] = {
			["isChanneled"] = false,
			["source"] = "Forgemaster Garfrost",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36494,
		},
		[59999] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30621,
		},
		[51875] = {
			["isChanneled"] = false,
			["source"] = "Tundra Scavenger",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27294,
		},
		[22907] = {
			["isChanneled"] = false,
			["source"] = "Alliance Ranger",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26802,
		},
		[52067] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Crystalline Frayer",
			["npcID"] = 26793,
		},
		[50084] = {
			["isChanneled"] = false,
			["source"] = "Storm Giant",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 24812,
		},
		[46182] = {
			["isChanneled"] = false,
			["source"] = "Hyldnir Overseer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29426,
		},
		[52451] = {
			["encounterName"] = "Salram the Fleshcrafter",
			["source"] = "Salramm the Fleshcrafter",
			["npcID"] = 26530,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 294,
		},
		[56737] = {
			["isChanneled"] = false,
			["source"] = "Bonegrinder",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30284,
		},
		[66489] = {
			["isChanneled"] = false,
			["source"] = "Kvaldir Harpooner",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 34907,
		},
		[52835] = {
			["isChanneled"] = false,
			["source"] = "Scarlet Lord Borugh",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28964,
		},
		[59040] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Unrelenting Construct",
			["npcID"] = 27971,
		},
		[12737] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Mage Hunter Ascendant",
			["npcID"] = 26727,
		},
		[27577] = {
			["isChanneled"] = false,
			["source"] = "Gold Warrior",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32322,
		},
		[49317] = {
			["isChanneled"] = false,
			["source"] = "Azure Drake",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27682,
		},
		[59616] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dragonflayer Runecaster",
			["npcID"] = 23960,
		},
		[19645] = {
			["isChanneled"] = false,
			["source"] = "Wailing Banshee",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10464,
		},
		[31991] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Torgg Thundertotem",
			["npcID"] = 27716,
		},
		[49701] = {
			["encounterName"] = "Trollgore",
			["source"] = "Risen Drakkari Soulmage",
			["encounterID"] = 369,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26636,
		},
		[68793] = {
			["encounterName"] = "Bronjahm",
			["source"] = "Bronjahm",
			["encounterID"] = 829,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36497,
		},
		[68921] = {
			["encounterName"] = "Bronjahm",
			["type"] = "DEBUFF",
			["source"] = "Bronjahm",
			["encounterID"] = 829,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 36497,
		},
		[54051] = {
			["isChanneled"] = false,
			["source"] = "Khaatom",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 417,
		},
		[75446] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Mortis",
			["npcID"] = 5823,
		},
		[46119] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Arch Druid Lathorius",
			["npcID"] = 25809,
		},
		[8995] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dark Iron Rifleman",
			["npcID"] = 6523,
		},
		[58529] = {
			["isChanneled"] = false,
			["source"] = "Portal Keeper",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30695,
		},
		[24187] = {
			["isChanneled"] = false,
			["source"] = "Dreadsaber",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28001,
		},
		[68282] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Argent Battleworg",
			["npcID"] = 36558,
		},
		[15232] = {
			["isChanneled"] = false,
			["source"] = "Thuzadin Shadowcaster",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10398,
		},
		[52772] = {
			["encounterName"] = "Chrono-Lord Epoch",
			["source"] = "Chrono-Lord Epoch",
			["npcID"] = 26532,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 295,
		},
		[58977] = {
			["encounterName"] = "Drakkari Colossus",
			["source"] = "Drakkari Golem",
			["encounterID"] = 385,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29832,
		},
		[59105] = {
			["source"] = "Azure Manabeast",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 31404,
		},
		[59169] = {
			["isChanneled"] = false,
			["source"] = "Bound Air Elemental",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30418,
		},
		[75447] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Wolf",
			["npcID"] = 8959,
		},
		[69562] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Soulguard Bonecaster",
			["npcID"] = 36564,
		},
		[53348] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Hearthglen Crusader",
			["npcID"] = 29102,
		},
		[32942] = {
			["source"] = "Warp Hunter",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 18465,
		},
		[59617] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dragonflayer Runecaster",
			["npcID"] = 23960,
		},
		[55715] = {
			["isChanneled"] = false,
			["source"] = "Earthen Elite",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29980,
		},
		[37548] = {
			["isChanneled"] = false,
			["source"] = "Dragonflayer Prisoner",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 24253,
		},
		[69051] = {
			["encounterName"] = "Devourer of Souls",
			["source"] = "Devourer of Souls",
			["encounterID"] = 831,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36502,
		},
		[54052] = {
			["isChanneled"] = false,
			["source"] = "Czaanhym",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 417,
		},
		[15616] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Orgrimmar Shaman",
			["npcID"] = 18972,
		},
		[19134] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Green Warrior",
			["npcID"] = 32321,
		},
		[60833] = {
			["isChanneled"] = false,
			["source"] = "Forgotten One",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30414,
		},
		[58850] = {
			["encounterName"] = "Mal'ganis",
			["source"] = "Mal'Ganis",
			["npcID"] = 26533,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 296,
		},
		[56867] = {
			["isChanneled"] = false,
			["source"] = "Savage Cave Beast",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30329,
		},
		[59106] = {
			["isChanneled"] = false,
			["source"] = "Ahn'kahar Web Winder",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30276,
		},
		[69564] = {
			["isChanneled"] = false,
			["source"] = "Soulguard Adept",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36620,
		},
		[17439] = {
			["isChanneled"] = false,
			["source"] = "Black Guard Sentry",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10394,
		},
		[32943] = {
			["source"] = "Warp Hunter",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 18465,
		},
		[61665] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "The Chieftain's Totem",
			["npcID"] = 30444,
		},
		[51494] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dark Rune Giant",
			["npcID"] = 27969,
		},
		[55652] = {
			["isChanneled"] = false,
			["source"] = "Ruins Dweller",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29920,
		},
		[55716] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Victorious Challenger",
			["npcID"] = 30012,
		},
		[49639] = {
			["encounterName"] = "Trollgore",
			["source"] = "Trollgore",
			["encounterID"] = 369,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26630,
		},
		[11922] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Thistleshrub Dew Collector",
			["npcID"] = 5481,
		},
		[47784] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Mage Hunter Ascendant",
			["npcID"] = 26727,
		},
		[69053] = {
			["isChanneled"] = false,
			["source"] = "Soulguard Watchman",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36478,
		},
		[1006] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Alexandra Blazen",
			["npcID"] = 8378,
		},
		[69565] = {
			["encounterName"] = "Overlrod Tyrannus",
			["source"] = "Freed Horde Slave",
			["encounterID"] = 837,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 37577,
		},
		[54309] = {
			["isChanneled"] = false,
			["source"] = "Anub'ar Prime Guard",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29128,
		},
		[67774] = {
			["encounterName"] = "The Black Knight",
			["source"] = "Risen Jaeren Sunsworn",
			["npcID"] = 35545,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 340,
		},
		[58531] = {
			["isChanneled"] = false,
			["source"] = "Portal Keeper",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30695,
		},
		[14145] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Acolyte",
			["npcID"] = 27731,
		},
		[50535] = {
			["source"] = "Azure Spellbinder",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 27635,
		},
		[70589] = {
			["isChanneled"] = false,
			["source"] = "Image of Morlen Coldgrip",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 37845,
		},
		[59107] = {
			["isChanneled"] = false,
			["source"] = "Bonegrinder",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30284,
		},
		[55077] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Savage Worg",
			["npcID"] = 29735,
		},
		[69566] = {
			["encounterName"] = "Overlrod Tyrannus",
			["source"] = "Freed Horde Slave",
			["encounterID"] = 837,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 37577,
		},
		[16448] = {
			["source"] = "Plagued Rat",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 10441,
		},
		[1032] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Patrick Mills",
			["npcID"] = 8382,
		},
		[49576] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Ebon Blade Vindicator",
			["npcID"] = 32488,
		},
		[49704] = {
			["isChanneled"] = false,
			["source"] = "Darkweb Recluse",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26625,
		},
		[60003] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30623,
		},
		[12466] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Mage Hunter Ascendant",
			["npcID"] = 26727,
		},
		[60195] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Sunreaver Agent",
			["npcID"] = 36776,
		},
		[50024] = {
			["source"] = "Amber Drake",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 27755,
		},
		[60451] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Guardian of Time",
			["npcID"] = 32281,
		},
		[50280] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Oil-stained Wolf",
			["npcID"] = 25791,
		},
		[50344] = {
			["encounterName"] = "Ley-Guardian Eregos",
			["source"] = "Emerald Drake",
			["encounterID"] = 534,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27692,
		},
		[6307] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Unknown",
			["npcID"] = 416,
		},
		[52519] = {
			["isChanneled"] = false,
			["source"] = "Gothik the Harvester",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28658,
		},
		[58852] = {
			["encounterName"] = "Mal'ganis",
			["source"] = "Mal'Ganis",
			["npcID"] = 26533,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 296,
		},
		[63010] = {
			["isChanneled"] = false,
			["source"] = "Boneguard Lieutenant",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 33429,
		},
		[56933] = {
			["isChanneled"] = false,
			["source"] = "Alliance Ranger",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26802,
		},
		[59108] = {
			["isChanneled"] = false,
			["source"] = "Deep Crawler",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30279,
		},
		[55078] = {
			["source"] = "Rune Weapon",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 27893,
		},
		[51112] = {
			["encounterName"] = "Mage-Lord Urom",
			["source"] = "Mage-Lord Urom",
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27655,
		},
		[59364] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Watcher Silthik",
			["encounterID"] = 216,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28731,
		},
		[51240] = {
			["isChanneled"] = false,
			["source"] = "Risen Drakkari Death Knight",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26830,
		},
		[70080] = {
			["encounterName"] = "Escaped from Arthas",
			["source"] = "Risen Witch Doctor",
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36941,
		},
		[19615] = {
			["source"] = "Fabi",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 6498,
		},
		[29882] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Crazed Mana-Surge",
			["npcID"] = 26737,
		},
		[33393] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Pit Commander",
			["npcID"] = 18945,
		},
		[55974] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Vladof the Butcher",
			["npcID"] = 30022,
		},
		[51944] = {
			["isChanneled"] = false,
			["source"] = "Injured Mammoth",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26711,
		},
		[35696] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Krimkazul",
			["npcID"] = 17252,
		},
		[50089] = {
			["encounterName"] = "Novos the Summoner",
			["source"] = "Novos the Summoner",
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26631,
		},
		[69569] = {
			["encounterName"] = "Overlrod Tyrannus",
			["source"] = "Freed Horde Slave",
			["encounterID"] = 837,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 37578,
		},
		[32281] = {
			["source"] = "Lantresor of the Blade",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 18261,
		},
		[33905] = {
			["source"] = "Goliathon",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 19305,
		},
		[38063] = {
			["isChanneled"] = false,
			["source"] = "Air Force Alarm Bot (Alliance)",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 2614,
		},
		[52712] = {
			["encounterName"] = "Salram the Fleshcrafter",
			["type"] = "BUFF",
			["source"] = "Salramm the Fleshcrafter",
			["npcID"] = 26530,
			["event"] = "SPELL_AURA_APPLIED",
			["encounterID"] = 294,
		},
		[56934] = {
			["encounterName"] = "Grand Magus Telestra",
			["source"] = "Grand Magus Telestra",
			["encounterID"] = 520,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26731,
		},
		[57062] = {
			["encounterName"] = "Anomalus",
			["source"] = "Anomalus",
			["encounterID"] = 522,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26763,
		},
		[55079] = {
			["isChanneled"] = false,
			["source"] = "Goretalon Roc",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28004,
		},
		[59237] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Ymirjar Savage",
			["npcID"] = 26669,
		},
		[69570] = {
			["encounterName"] = "Overlrod Tyrannus",
			["source"] = "Freed Horde Slave",
			["encounterID"] = 837,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 37579,
		},
		[59685] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dragonflayer Strategist",
			["npcID"] = 23956,
		},
		[55847] = {
			["isChanneled"] = false,
			["source"] = "Risen Drakkari Soulmage",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26636,
		},
		[47723] = {
			["encounterName"] = "Grand Magus Telestra",
			["source"] = "Grand Magus Telestra",
			["npcID"] = 26928,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 520,
		},
		[11443] = {
			["isChanneled"] = false,
			["source"] = "Thuzadin Shadowcaster",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10398,
		},
		[56103] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Infesting Jormungar",
			["npcID"] = 30148,
		},
		[33906] = {
			["source"] = "Goliathon",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 19305,
		},
		[58534] = {
			["isChanneled"] = false,
			["source"] = "Portal Keeper",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30695,
		},
		[38384] = {
			["isChanneled"] = false,
			["source"] = "Mage Hunter Ascendant",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26727,
		},
		[50730] = {
			["encounterName"] = "Mage-Lord Urom",
			["source"] = "Phantasmal Ogre",
			["encounterID"] = 532,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27647,
		},
		[13730] = {
			["isChanneled"] = false,
			["source"] = "Conquest Hold Marauder",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27424,
		},
		[57063] = {
			["encounterName"] = "Anomalus",
			["source"] = "Anomalus",
			["encounterID"] = 522,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26763,
		},
		[13810] = {
			["source"] = "Tortured Rifleman",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 38176,
		},
		[69572] = {
			["isChanneled"] = false,
			["source"] = "Wrathbone Laborer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36830,
		},
		[59430] = {
			["encounterName"] = "Anub'arak",
			["source"] = "Anub'arak",
			["encounterID"] = 218,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29120,
		},
		[47468] = {
			["isChanneled"] = false,
			["source"] = "Risen Ghoul",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26125,
		},
		[49643] = {
			["source"] = "Iron Rune Guardian",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 24212,
		},
		[59942] = {
			["isChanneled"] = false,
			["source"] = "Scourge Banner-Bearer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31900,
		},
		[16033] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Torgg Thundertotem",
			["npcID"] = 27716,
		},
		[11971] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Victorious Challenger",
			["npcID"] = 30012,
		},
		[75330] = {
			["encounterName"] = "Overlrod Tyrannus",
			["source"] = "Wrathbone Sorcerer",
			["encounterID"] = 837,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 37728,
		},
		[50155] = {
			["encounterName"] = "Keristrasza",
			["source"] = "Keristrasza",
			["npcID"] = 26723,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 526,
		},
		[33907] = {
			["isChanneled"] = false,
			["source"] = "Thornvine Creeper",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 23874,
		},
		[50411] = {
			["source"] = "Treant",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 1964,
		},
		[52586] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Krik'thir the Gatewatcher",
			["encounterID"] = 216,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28684,
		},
		[50731] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Brittle Revenant",
			["npcID"] = 30160,
		},
		[50795] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Zul'Drak Gateway Trigger",
			["npcID"] = 28181,
		},
		[59047] = {
			["isChanneled"] = false,
			["source"] = "Val'kyr Taskmistress",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31396,
		},
		[59111] = {
			["isChanneled"] = false,
			["source"] = "Eye of Taldaram",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30285,
		},
		[59239] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Ymirjar Savage",
			["npcID"] = 26669,
		},
		[69574] = {
			["isChanneled"] = false,
			["source"] = "Wrathbone Coldwraith",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36842,
		},
		[59431] = {
			["encounterName"] = "Anub'arak",
			["type"] = "DEBUFF",
			["source"] = "Anub'arak",
			["encounterID"] = 218,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 29120,
		},
		[53418] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Hadronox",
			["encounterID"] = 216,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28921,
		},
		[59687] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Ticking Time Bomb",
			["npcID"] = 32246,
		},
		[57832] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30622,
		},
		[49708] = {
			["isChanneled"] = false,
			["source"] = "Darkweb Recluse",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26625,
		},
		[47789] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Mage Hunter Ascendant",
			["npcID"] = 26727,
		},
		[47981] = {
			["encounterName"] = "Ormorok the Tree-Shaper",
			["source"] = "Ormorok the Tree-Shaper",
			["npcID"] = 26794,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 524,
		},
		[16866] = {
			["isChanneled"] = false,
			["source"] = "Venom Belcher",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10417,
		},
		[33844] = {
			["isChanneled"] = false,
			["source"] = "Ancient Watcher",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31229,
		},
		[46190] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Acolyte",
			["npcID"] = 27731,
		},
		[58536] = {
			["isChanneled"] = false,
			["source"] = "Portal Keeper",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30893,
		},
		[12611] = {
			["isChanneled"] = false,
			["source"] = "Gold Mage",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32341,
		},
		[50476] = {
			["encounterName"] = "Mage-Lord Urom",
			["source"] = "Mage-Lord Urom",
			["encounterID"] = 532,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27655,
		},
		[72390] = {
			["encounterName"] = "Falric",
			["source"] = "Falric",
			["encounterID"] = 841,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38112,
		},
		[42544] = {
			["isChanneled"] = false,
			["source"] = "Ember Clutch Ancient",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 23870,
		},
		[56937] = {
			["encounterName"] = "Grand Magus Telestra",
			["source"] = "Grand Magus Telestra",
			["encounterID"] = 520,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26930,
		},
		[66889] = {
			["encounterName"] = "Argent Champion",
			["type"] = "BUFF",
			["source"] = "Eadric the Pure",
			["npcID"] = 35119,
			["event"] = "SPELL_AURA_APPLIED",
			["encounterID"] = 338,
		},
		[12739] = {
			["isChanneled"] = false,
			["source"] = "Twilight Darkcaster",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30319,
		},
		[61287] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Corastrasza",
			["npcID"] = 32548,
		},
		[31707] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Water Elemental",
			["npcID"] = 510,
		},
		[67529] = {
			["encounterName"] = "Grand Champions",
			["source"] = "Colosos",
			["encounterID"] = 334,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 34701,
		},
		[49453] = {
			["isChanneled"] = false,
			["source"] = "Howling Wolvar Trainer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26823,
		},
		[72391] = {
			["encounterName"] = "Falric",
			["source"] = "Falric",
			["encounterID"] = 841,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38112,
		},
		[57833] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Stormpeak Wyrm",
			["npcID"] = 29753,
		},
		[51820] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Arcanimus",
			["npcID"] = 26370,
		},
		[58025] = {
			["encounterName"] = "Mage-Lord Urom",
			["type"] = "DEBUFF",
			["source"] = "Mage-Lord Urom",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 27655,
		},
		[58153] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Reanimated Crusader",
			["npcID"] = 30202,
		},
		[47982] = {
			["isChanneled"] = false,
			["source"] = "Noktai",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 416,
		},
		[15090] = {
			["isChanneled"] = false,
			["source"] = "Green Priest",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32343,
		},
		[69577] = {
			["isChanneled"] = false,
			["source"] = "Deathwhisper Necrolyte",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36788,
		},
		[52268] = {
			["isChanneled"] = false,
			["source"] = "Havenshire Mare",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28606,
		},
		[38067] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Air Force Alarm Bot (Horde)",
			["npcID"] = 2615,
		},
		[58729] = {
			["source"] = "Taunka Spirit Guide",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 31841,
		},
		[52716] = {
			["isChanneled"] = false,
			["source"] = "Citizen of New Avalon",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28942,
		},
		[58921] = {
			["source"] = "Father Kamaros",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 31279,
		},
		[56938] = {
			["encounterName"] = "Grand Magus Telestra",
			["source"] = "Grand Magus Telestra",
			["encounterID"] = 520,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26928,
		},
		[52972] = {
			["isChanneled"] = false,
			["source"] = "Moodle",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28122,
		},
		[59241] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Ymirjar Flesh Hunter",
			["npcID"] = 26670,
		},
		[59305] = {
			["encounterName"] = "King Ymiron",
			["source"] = "King Ymiron",
			["npcID"] = 26861,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 583,
		},
		[69578] = {
			["isChanneled"] = false,
			["source"] = "Deathwhisper Necrolyte",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36788,
		},
		[59433] = {
			["encounterName"] = "Anub'arak",
			["source"] = "Anub'arak",
			["encounterID"] = 218,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29120,
		},
		[34933] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Mage Hunter Ascendant",
			["npcID"] = 26727,
		},
		[65868] = {
			["encounterName"] = "Grand Champions",
			["source"] = "Jaelyne Evensong",
			["encounterID"] = 334,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 34657,
		},
		[51437] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Smoldering Skeleton",
			["npcID"] = 27360,
		},
		[72393] = {
			["encounterName"] = "Falric",
			["source"] = "Falric",
			["encounterID"] = 841,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38112,
		},
		[49710] = {
			["isChanneled"] = false,
			["source"] = "Drakkari Gutripper",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26641,
		},
		[11428] = {
			["isChanneled"] = false,
			["source"] = "Raging Colossus",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 19188,
		},
		[49838] = {
			["isChanneled"] = false,
			["source"] = "Amber Drake",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27755,
		},
		[58154] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Reanimated Crusader",
			["npcID"] = 30202,
		},
		[47983] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Unknown",
			["npcID"] = 416,
		},
		[16867] = {
			["isChanneled"] = false,
			["source"] = "Baroness Anastari",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10436,
		},
		[69579] = {
			["isChanneled"] = false,
			["source"] = "Fallen Warrior",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36841,
		},
		[52461] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Enraging Ghoul",
			["npcID"] = 27729,
		},
		[36213] = {
			["encounterName"] = "Overlrod Tyrannus",
			["source"] = "Greater Earth Elemental",
			["encounterID"] = 837,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 15352,
		},
		[1460] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Dalar Dawnweaver",
			["npcID"] = 1938,
		},
		[56939] = {
			["encounterName"] = "Grand Magus Telestra",
			["source"] = "Grand Magus Telestra",
			["encounterID"] = 520,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26928,
		},
		[52909] = {
			["source"] = "Librarian Garren",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 25291,
		},
		[69068] = {
			["isChanneled"] = false,
			["source"] = "Soulguard Adept",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36620,
		},
		[61353] = {
			["isChanneled"] = false,
			["source"] = "Dagna Flintlock",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29476,
		},
		[69580] = {
			["isChanneled"] = false,
			["source"] = "Fallen Warrior",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36841,
		},
		[54508] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Zilikraksha",
			["npcID"] = 17252,
		},
		[3149] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Bonechewer Riding Wolf",
			["npcID"] = 18706,
		},
		[53549] = {
			["isChanneled"] = false,
			["source"] = "Disciple of Frost",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28490,
		},
		[68301] = {
			["encounterName"] = "Grand Champions",
			["source"] = "Marshal Jacob Alerius",
			["npcID"] = 34705,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 334,
		},
		[32723] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Bonechewer Raider",
			["npcID"] = 16925,
		},
		[31996] = {
			["isChanneled"] = false,
			["source"] = "Deathshadow Archon",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 22343,
		},
		[49711] = {
			["isChanneled"] = false,
			["source"] = "Risen Drakkari Handler",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26637,
		},
		[60010] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30622,
		},
		[55980] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Enormos",
			["npcID"] = 30021,
		},
		[69069] = {
			["isChanneled"] = false,
			["source"] = "Soulguard Bonecaster",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36564,
		},
		[52576] = {
			["isChanneled"] = false,
			["source"] = "Scarlet Cannon",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28833,
		},
		[52262] = {
			["isChanneled"] = false,
			["source"] = "Citizen of Havenshire",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28576,
		},
		[33463] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Undercity Mage",
			["npcID"] = 18971,
		},
		[69581] = {
			["isChanneled"] = false,
			["source"] = "Plagueborn Horror",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36879,
		},
		[52270] = {
			["isChanneled"] = false,
			["source"] = "Frenzyheart Hunter",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28079,
		},
		[3019] = {
			["isChanneled"] = false,
			["source"] = "Kvaldir Berserker",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 34947,
		},
		[58514] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Orgrimmar Grunt",
			["npcID"] = 3296,
		},
		[52006] = {
			["isChanneled"] = false,
			["source"] = "Eye of Acherus",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28511,
		},
		[72268] = {
			["isChanneled"] = false,
			["source"] = "Tortured Rifleman",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38176,
		},
		[58702] = {
			["isChanneled"] = false,
			["source"] = "Searing Totem X",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31165,
		},
		[60842] = {
			["isChanneled"] = false,
			["source"] = "Cult Conspirator",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 33537,
		},
		[413172] = {
			["source"] = "Immortal Crusher Tentacle",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 206038,
		},
		[8139] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Bonepicker",
			["npcID"] = 5983,
		},
		[65128] = {
			["isChanneled"] = false,
			["source"] = "Cultist Bombardier",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 33695,
		},
		[53801] = {
			["isChanneled"] = false,
			["source"] = "Anub'ar Crusher",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28922,
		},
		[52974] = {
			["isChanneled"] = false,
			["source"] = "Sparktouched Warrior",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28111,
		},
		[44178] = {
			["isChanneled"] = false,
			["source"] = "Green Mage",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32324,
		},
		[59243] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Ymirjar Flesh Hunter",
			["npcID"] = 26670,
		},
		[52375] = {
			["isChanneled"] = false,
			["source"] = "Unworthy Initiate",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29566,
		},
		[59371] = {
			["encounterName"] = "Varos Cloudstrider",
			["source"] = "Varos Cloudstrider",
			["encounterID"] = 530,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27447,
		},
		[34871] = {
			["isChanneled"] = false,
			["source"] = "Umbrafen Witchdoctor",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 20115,
		},
		[10277] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Venture Co. Logger",
			["npcID"] = 3989,
		},
		[52206] = {
			["isChanneled"] = false,
			["source"] = "Acherus Geist",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28709,
		},
		[17434] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Baron Rivendare",
			["npcID"] = 29109,
		},
		[59691] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Enslaved Proto-Drake",
			["npcID"] = 24083,
		},
		[49758] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Hardknuckle Charger",
			["npcID"] = 28096,
		},
		[16612] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Mangletooth",
			["npcID"] = 3430,
		},
		[12420] = {
			["isChanneled"] = false,
			["source"] = "Thuzadin Necromancer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10400,
		},
		[49712] = {
			["isChanneled"] = false,
			["source"] = "Risen Drakkari Handler",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26637,
		},
		[47729] = {
			["encounterName"] = "Grand Magus Telestra",
			["source"] = "Grand Magus Telestra",
			["npcID"] = 26930,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 520,
		},
		[8374] = {
			["isChanneled"] = false,
			["source"] = "Jlarborn the Strategist",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 24215,
		},
		[17843] = {
			["isChanneled"] = false,
			["source"] = "Gold Priest",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32325,
		},
		[62250] = {
			["encounterName"] = "Ley-Guardian Eregos",
			["source"] = "Greater Ley-Whelp",
			["encounterID"] = 534,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28276,
		},
		[52374] = {
			["isChanneled"] = false,
			["source"] = "Death Knight Initiate",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28406,
		},
		[6268] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Saltspittle Puddlejumper",
			["npcID"] = 3737,
		},
		[69583] = {
			["isChanneled"] = false,
			["source"] = "Ymirjar Flamebearer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36893,
		},
		[10690] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Bloodmage Lynnore",
			["npcID"] = 7506,
		},
		[49807] = {
			["isChanneled"] = false,
			["source"] = "Frenzyheart Ravager",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28078,
		},
		[58540] = {
			["source"] = "Eidolon Watcher",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 30947,
		},
		[12612] = {
			["isChanneled"] = false,
			["source"] = "Ember Clutch Ancient",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 23870,
		},
		[59978] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Herald Volazj",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29311,
		},
		[53550] = {
			["isChanneled"] = false,
			["source"] = "Disciple of Frost",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28490,
		},
		[34232] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "High Elf Mage-Priest",
			["npcID"] = 27747,
		},
		[52719] = {
			["isChanneled"] = false,
			["source"] = "Westfall Brigade Marine",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27501,
		},
		[53536] = {
			["isChanneled"] = false,
			["source"] = "Disciple of Frost",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28490,
		},
		[65129] = {
			["isChanneled"] = false,
			["source"] = "Time Bomb",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 34307,
		},
		[70961] = {
			["isChanneled"] = false,
			["source"] = "The Damned",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 37011,
		},
		[59116] = {
			["isChanneled"] = false,
			["source"] = "Savage Cave Beast",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30329,
		},
		[52373] = {
			["isChanneled"] = false,
			["source"] = "Unworthy Initiate",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29566,
		},
		[59244] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Ymirjar Flesh Hunter",
			["npcID"] = 26670,
		},
		[32093] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Emperor Cobra",
			["npcID"] = 28011,
		},
		[69584] = {
			["isChanneled"] = false,
			["source"] = "Ymirjar Flamebearer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36893,
		},
		[1604] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Sinewy Wolf",
			["npcID"] = 31233,
		},
		[57453] = {
			["source"] = "Unknown",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 1108,
		},
		[55973] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Vladof the Butcher",
			["npcID"] = 30022,
		},
		[47346] = {
			["isChanneled"] = false,
			["source"] = "Novos the Summoner",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26631,
		},
		[59692] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Enslaved Proto-Drake",
			["npcID"] = 24083,
		},
		[414207] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Scarlet Commander",
			["npcID"] = 28936,
		},
		[57483] = {
			["source"] = "Unknown",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 1108,
		},
		[31997] = {
			["source"] = "Deathshadow Archon",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 22343,
		},
		[61995] = {
			["isChanneled"] = false,
			["source"] = "Minigob Manabonk",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32838,
		},
		[55918] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Erathius, King of Dirt",
			["npcID"] = 30025,
		},
		[55982] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Enormos",
			["npcID"] = 30021,
		},
		[15043] = {
			["isChanneled"] = false,
			["source"] = "Gold Mage",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32341,
		},
		[67725] = {
			["encounterName"] = "The Black Knight",
			["source"] = "The Black Knight",
			["encounterID"] = 340,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 35451,
		},
		[59750] = {
			["encounterName"] = "Krystallus",
			["source"] = "Krystallus",
			["npcID"] = 27977,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 563,
		},
		[69516] = {
			["isChanneled"] = false,
			["source"] = "Ymirjar Deathbringer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36892,
		},
		[38682] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Alliance Berserker",
			["npcID"] = 26800,
		},
		[13787] = {
			["isChanneled"] = false,
			["source"] = "Skeletal Guardian",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10390,
		},
		[23102] = {
			["isChanneled"] = false,
			["source"] = "Shadow Vault Boneguard",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30312,
		},
		[60588] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Infinite Corruptor",
			["npcID"] = 32273,
		},
		[1126] = {
			["source"] = "Thundris Windweaver",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 3649,
		},
		[15786] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Gold Shaman",
			["npcID"] = 32340,
		},
		[55886] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Fiend of Earth",
			["npcID"] = 30043,
		},
		[11986] = {
			["isChanneled"] = false,
			["source"] = "Twilight Apostle",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30179,
		},
		[58861] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Spirit Wolf",
			["npcID"] = 29264,
		},
		[17139] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Alliance Cleric",
			["npcID"] = 26805,
		},
		[65130] = {
			["isChanneled"] = false,
			["source"] = "Cultist Bombardier",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 33695,
		},
		[56715] = {
			["isChanneled"] = false,
			["source"] = "Plundering Geist",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30287,
		},
		[53030] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Hadronox",
			["encounterID"] = 216,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28921,
		},
		[63275] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Fishspeaker Irtusk",
			["npcID"] = 194795,
		},
		[60949] = {
			["isChanneled"] = false,
			["source"] = "Ebon Blade Reaper",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31316,
		},
		[59350] = {
			["encounterName"] = "Anub'arak",
			["source"] = "Anub'ar Guardian",
			["encounterID"] = 218,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29216,
		},
		[34809] = {
			["isChanneled"] = false,
			["source"] = "Scarlet Preacher",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28594,
		},
		[6668] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Sentry-bot 57-K",
			["npcID"] = 25753,
		},
		[61548] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Ymirjar Berserker",
			["npcID"] = 26696,
		},
		[58511] = {
			["source"] = "Orgrimmar Grunt",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 3296,
		},
		[61676] = {
			["isChanneled"] = false,
			["source"] = "Wolfgang",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 17669,
		},
		[53032] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Soo-holu",
			["npcID"] = 28115,
		},
		[51946] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Goretalon Matriarch",
			["npcID"] = 29044,
		},
		[67530] = {
			["encounterName"] = "Grand Champions",
			["source"] = "Colosos",
			["encounterID"] = 334,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 34701,
		},
		[13444] = {
			["isChanneled"] = false,
			["source"] = "Rockwing Gargoyle",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10408,
		},
		[48920] = {
			["encounterName"] = "King Dred",
			["source"] = "King Dred",
			["encounterID"] = 373,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27483,
		},
		[60013] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30623,
		},
		[66081] = {
			["encounterName"] = "Grand Champions",
			["source"] = "Jaelyne Evensong",
			["encounterID"] = 334,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 34657,
		},
		[54028] = {
			["source"] = "Silver Covenant Guardian Mage",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 29254,
		},
		[51917] = {
			["isChanneled"] = false,
			["source"] = "Ghoul Tormentor",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26621,
		},
		[15587] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Cult Researcher",
			["npcID"] = 32297,
		},
		[3391] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Centipaar Stinger",
			["npcID"] = 5456,
		},
		[49806] = {
			["encounterName"] = "Hadronox",
			["source"] = "Anub'ar Warrior",
			["encounterID"] = 217,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28732,
		},
		[48179] = {
			["encounterName"] = "Keristrasza",
			["source"] = "Keristrasza",
			["encounterID"] = 526,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26723,
		},
		[55970] = {
			["encounterName"] = "Prince Taldaram",
			["type"] = "BUFF",
			["source"] = "Prince Taldaram",
			["encounterID"] = 213,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 29308,
		},
		[16997] = {
			["isChanneled"] = false,
			["source"] = "Rockwing Screecher",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10409,
		},
		[54512] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Vargul Runelord",
			["npcID"] = 29450,
		},
		[15498] = {
			["isChanneled"] = false,
			["source"] = "Scarlet Medic",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28608,
		},
		[53479] = {
			["source"] = "Crab",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 23929,
		},
		[60845] = {
			["isChanneled"] = false,
			["source"] = "Forgotten One",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30414,
		},
		[34298] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Ironhide",
			["npcID"] = 27715,
		},
		[45525] = {
			["source"] = "Warsong Hold Mage",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 25420,
		},
		[68820] = {
			["encounterName"] = "Devourer of Souls",
			["source"] = "Devourer of Souls",
			["encounterID"] = 831,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36502,
		},
		[388121] = {
			["isChanneled"] = false,
			["source"] = "Pebble",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 194870,
		},
		[52977] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Moodle",
			["npcID"] = 28122,
		},
		[50994] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Crystalline Tender",
			["npcID"] = 28231,
		},
		[55216] = {
			["isChanneled"] = false,
			["source"] = "Disturbed Glacial Revenant",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36874,
		},
		[388122] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Pebble",
			["npcID"] = 194870,
		},
		[9734] = {
			["isChanneled"] = false,
			["source"] = "Dragonflayer Prisoner",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 24255,
		},
		[58905] = {
			["isChanneled"] = false,
			["source"] = "Shadow Vault Assaulter",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31266,
		},
		[53361] = {
			["isChanneled"] = false,
			["source"] = "Frenzyheart Ravager",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28078,
		},
		[388123] = {
			["source"] = "Pebble",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 194870,
		},
		[51442] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Sparkling Hare",
			["npcID"] = 28371,
		},
		[59694] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Proto-Drake Handler",
			["npcID"] = 24082,
		},
		[35194] = {
			["source"] = "Ango'rosh Souleater",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 18121,
		},
		[55499] = {
			["isChanneled"] = false,
			["source"] = "Fabi",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 6498,
		},
		[59886] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "TOP",
			["npcID"] = 7431,
		},
		[47668] = {
			["isChanneled"] = false,
			["source"] = "Drakkari Guardian",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26620,
		},
		[45987] = {
			["source"] = "Bloodspore Harvester",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 25467,
		},
		[60004] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30625,
		},
		[54235] = {
			["isChanneled"] = false,
			["source"] = "Lavanthor",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29312,
		},
		[26017] = {
			["source"] = "Immortal Crusher Tentacle",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 206038,
		},
		[35706] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Krimkazul",
			["npcID"] = 17252,
		},
		[388126] = {
			["isChanneled"] = false,
			["source"] = "Pebble",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 194870,
		},
		[67542] = {
			["encounterName"] = "Grand Champions",
			["source"] = "Marshal Jacob Alerius",
			["npcID"] = 34705,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 334,
		},
		[24339] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Razzashi Raptor",
			["npcID"] = 14821,
		},
		[63661] = {
			["source"] = "Thunder Bluff Kodo",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 33322,
		},
		[60590] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Infinite Corruptor",
			["npcID"] = 32273,
		},
		[68054] = {
			["isChanneled"] = false,
			["source"] = "Jeeves",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 35642,
		},
		[57056] = {
			["isChanneled"] = false,
			["source"] = "Crystalline Frayer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26793,
		},
		[57762] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30623,
		},
		[388128] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Pebble",
			["npcID"] = 194870,
		},
		[388131] = {
			["isChanneled"] = false,
			["source"] = "Pebble",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 194870,
		},
		[40504] = {
			["encounterName"] = "Trollgore",
			["source"] = "Wretched Belcher",
			["encounterID"] = 369,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26624,
		},
		[58991] = {
			["isChanneled"] = false,
			["source"] = "Drakkari Rhino",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29838,
		},
		[68950] = {
			["encounterName"] = "Bronjahm",
			["source"] = "Bronjahm",
			["encounterID"] = 829,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36497,
		},
		[61166] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Coldarra Wyrmkin",
			["npcID"] = 25728,
		},
		[50995] = {
			["source"] = "Thassarian",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 198875,
		},
		[10326] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Argent Crusader",
			["npcID"] = 28029,
		},
		[50335] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Hulking Abomination",
			["npcID"] = 31140,
		},
		[16001] = {
			["isChanneled"] = false,
			["source"] = "Risen Drakkari Bat Rider",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26638,
		},
		[397342] = {
			["encounterName"] = "Chrono-Lord Epoch",
			["source"] = "Chrono-Lord Epoch",
			["npcID"] = 26532,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 295,
		},
		[18501] = {
			["isChanneled"] = false,
			["source"] = "Sparktouched Warrior",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28111,
		},
		[53426] = {
			["isChanneled"] = false,
			["source"] = "Raptor",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 3122,
		},
		[5568] = {
			["isChanneled"] = false,
			["source"] = "Ramstein the Gorger",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10439,
		},
		[59695] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Proto-Drake Handler",
			["npcID"] = 24082,
		},
		[16790] = {
			["isChanneled"] = false,
			["source"] = "Shadow Vault Abomination",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31438,
		},
		[388132] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Pebble",
			["npcID"] = 194870,
		},
		[39207] = {
			["isChanneled"] = false,
			["source"] = "Bound Water Elemental",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30419,
		},
		[55087] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Aqueous Spirit",
			["npcID"] = 28862,
		},
		[60181] = {
			["isChanneled"] = false,
			["source"] = "Azure Sorcerer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30667,
		},
		[388133] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Pebble",
			["npcID"] = 194870,
		},
		[51805] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dark Rune Controller",
			["npcID"] = 27966,
		},
		[50253] = {
			["encounterName"] = "Ley-Guardian Eregos",
			["source"] = "Ruby Drake",
			["encounterID"] = 534,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27756,
		},
		[51218] = {
			["isChanneled"] = false,
			["source"] = "Proto-Whelp",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 23750,
		},
		[25058] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Mage Hunter Initiate",
			["npcID"] = 26728,
		},
		[12549] = {
			["isChanneled"] = false,
			["source"] = "Sparktouched Oracle",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28112,
		},
		[51507] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dark Rune Controller",
			["npcID"] = 27966,
		},
		[53472] = {
			["encounterName"] = "Anub'arak",
			["source"] = "Anub'arak",
			["encounterID"] = 218,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29120,
		},
		[66863] = {
			["encounterName"] = "Argent Champion",
			["source"] = "Eadric the Pure",
			["npcID"] = 35119,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 338,
		},
		[50420] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Stinkbeard",
			["npcID"] = 30017,
		},
		[59363] = {
			["isChanneled"] = false,
			["source"] = "Skittering Infector",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28736,
		},
		[35708] = {
			["isChanneled"] = false,
			["source"] = "Unknown",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 17252,
		},
		[49805] = {
			["encounterName"] = "Trollgore",
			["source"] = "Scourge Reanimator",
			["encounterID"] = 369,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26626,
		},
		[54770] = {
			["isChanneled"] = false,
			["source"] = "Bonescythe Ravager",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28108,
		},
		[8599] = {
			["isChanneled"] = false,
			["source"] = "Bonegrinder",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30284,
		},
		[58992] = {
			["isChanneled"] = false,
			["source"] = "Drakkari Rhino",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29931,
		},
		[56490] = {
			["isChanneled"] = false,
			["source"] = "Iron Sentinel",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29984,
		},
		[69080] = {
			["isChanneled"] = false,
			["source"] = "Soulguard Bonecaster",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36564,
		},
		[62563] = {
			["isChanneled"] = false,
			["source"] = "Campaign Warhorse",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 33531,
		},
		[67289] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Argent Priestess",
			["npcID"] = 35307,
		},
		[55218] = {
			["encounterName"] = "Gal'darah",
			["source"] = "Gal'darah",
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29306,
		},
		[59376] = {
			["encounterName"] = "Mage-Lord Urom",
			["source"] = "Mage-Lord Urom",
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27655,
		},
		[57941] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Herald Volazj",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29311,
		},
		[31807] = {
			["source"] = "Keleth",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 17901,
		},
		[49555] = {
			["encounterName"] = "Trollgore",
			["source"] = "Trollgore",
			["encounterID"] = 369,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26630,
		},
		[14916] = {
			["isChanneled"] = false,
			["source"] = "Ray",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 3100,
		},
		[59696] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Proto-Drake Handler",
			["npcID"] = 24082,
		},
		[57648] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30621,
		},
		[59824] = {
			["encounterName"] = "Gal'darah",
			["source"] = "Gal'darah",
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29306,
		},
		[57777] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30624,
		},
		[49717] = {
			["isChanneled"] = false,
			["source"] = "Runed Giant",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26417,
		},
		[62575] = {
			["isChanneled"] = false,
			["source"] = "Forsaken Warhorse",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 33324,
		},
		[57949] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Herald Volazj",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29311,
		},
		[52207] = {
			["isChanneled"] = false,
			["source"] = "Converted Hero",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31251,
		},
		[10966] = {
			["isChanneled"] = false,
			["source"] = "Warmaul Brute",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 18065,
		},
		[33661] = {
			["encounterName"] = "Tribunal of Ages",
			["source"] = "Iron Golem Custodian",
			["npcID"] = 27985,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 567,
		},
		[48054] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Crazed Mana-Surge",
			["npcID"] = 26737,
		},
		[64494] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Wolf",
			["npcID"] = 29358,
		},
		[55859] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Yggdras",
			["npcID"] = 30014,
		},
		[54387] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Carrion Eater",
			["npcID"] = 28022,
		},
		[53617] = {
			["encounterName"] = "Anub'arak",
			["source"] = "Anub'ar Venomancer",
			["encounterID"] = 218,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29217,
		},
		[48374] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Snowblind Digger",
			["npcID"] = 29413,
		},
		[52532] = {
			["encounterName"] = "Hadronox",
			["source"] = "Anub'ar Warrior",
			["encounterID"] = 217,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28732,
		},
		[24259] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Thoomon",
			["npcID"] = 417,
		},
		[60848] = {
			["isChanneled"] = false,
			["source"] = "Forgotten One",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30414,
		},
		[52711] = {
			["encounterName"] = "Salram the Fleshcrafter",
			["type"] = "DEBUFF",
			["source"] = "Salramm the Fleshcrafter",
			["npcID"] = 26530,
			["event"] = "SPELL_AURA_APPLIED",
			["encounterID"] = 294,
		},
		[11972] = {
			["isChanneled"] = false,
			["source"] = "Drakkari Guardian",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26620,
		},
		[58993] = {
			["isChanneled"] = false,
			["source"] = "Living Mojo",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29830,
		},
		[15284] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Azure Enforcer",
			["npcID"] = 26734,
		},
		[42745] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Korrak the Bloodrager",
			["npcID"] = 30023,
		},
		[50997] = {
			["encounterName"] = "Keristrasza",
			["source"] = "Keristrasza",
			["npcID"] = 26723,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 526,
		},
		[51499] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dark Rune Worker",
			["npcID"] = 27961,
		},
		[34080] = {
			["source"] = "Warlord Morkh",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 16964,
		},
		[59377] = {
			["encounterName"] = "Mage-Lord Urom",
			["source"] = "Mage-Lord Urom",
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27655,
		},
		[51253] = {
			["encounterName"] = "Mage-Lord Urom",
			["source"] = "Phantasmal Mammoth",
			["encounterID"] = 532,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27642,
		},
		[57458] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Wolf",
			["npcID"] = 8959,
		},
		[56969] = {
			["isChanneled"] = false,
			["source"] = "Azure Scale-Binder",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26735,
		},
		[59362] = {
			["encounterName"] = "Hadronox",
			["source"] = "Anub'ar Webspinner",
			["encounterID"] = 217,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29335,
		},
		[31808] = {
			["source"] = "Ashyen",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 17900,
		},
		[16583] = {
			["isChanneled"] = false,
			["source"] = "Scourge Banner-Bearer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31900,
		},
		[59825] = {
			["encounterName"] = "Gal'darah",
			["type"] = "DEBUFF",
			["source"] = "Gal'darah",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 29306,
		},
		[56777] = {
			["isChanneled"] = false,
			["source"] = "Azure Warder",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26716,
		},
		[49718] = {
			["source"] = "Runed Giant",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 26417,
		},
		[60017] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30623,
		},
		[16868] = {
			["isChanneled"] = false,
			["source"] = "Shrieking Banshee",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10463,
		},
		[72326] = {
			["isChanneled"] = false,
			["source"] = "Shadowy Mercenary",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38177,
		},
		[15572] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Horgrenn Hellcleave",
			["npcID"] = 27718,
		},
		[72198] = {
			["isChanneled"] = false,
			["source"] = "Spectral Footman",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38173,
		},
		[7804] = {
			["source"] = "Bizkol",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 416,
		},
		[64495] = {
			["isChanneled"] = false,
			["source"] = "Wolfgang",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 17669,
		},
		[36093] = {
			["isChanneled"] = false,
			["source"] = "Risen Drakkari Warrior",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26635,
		},
		[52496] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Crypt Fiend",
			["npcID"] = 27734,
		},
		[47736] = {
			["isChanneled"] = false,
			["source"] = "Grand Magus Telestra",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26929,
		},
		[52469] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Watcher Narjil",
			["encounterID"] = 216,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28729,
		},
		[38204] = {
			["isChanneled"] = false,
			["source"] = "Unbound Seer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 33422,
		},
		[50550] = {
			["source"] = "Amber Drake",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 27755,
		},
		[47731] = {
			["encounterName"] = "Grand Magus Telestra",
			["source"] = "Grand Magus Telestra",
			["encounterID"] = 520,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26929,
		},
		[62960] = {
			["isChanneled"] = false,
			["source"] = "Thunder Bluff Kodo",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 33322,
		},
		[51750] = {
			["encounterName"] = "King Ymiron",
			["source"] = "King Ymiron",
			["npcID"] = 26861,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 583,
		},
		[58994] = {
			["isChanneled"] = false,
			["source"] = "Living Mojo",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29830,
		},
		[17255] = {
			["isChanneled"] = false,
			["source"] = "Ray",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 3100,
		},
		[42746] = {
			["isChanneled"] = false,
			["source"] = "Ahn'kahar Watcher",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31104,
		},
		[744] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Hazzali Wasp",
			["npcID"] = 5441,
		},
		[60231] = {
			["isChanneled"] = false,
			["source"] = "Converted Hero",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32255,
		},
		[11766] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Unknown",
			["npcID"] = 416,
		},
		[25603] = {
			["isChanneled"] = false,
			["source"] = "Azure Spellbreaker",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31009,
		},
		[57395] = {
			["isChanneled"] = false,
			["source"] = "Exhausted Vrykul",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30146,
		},
		[34942] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Argent Priestess",
			["npcID"] = 35307,
		},
		[49172] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Ymirjar Dusk Shaman",
			["npcID"] = 26694,
		},
		[61834] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Minigob Manabonk",
			["npcID"] = 32838,
		},
		[24452] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Unknown",
			["npcID"] = 2042,
		},
		[49527] = {
			["encounterName"] = "The Prophet Tharon'ja",
			["source"] = "The Prophet Tharon'ja",
			["encounterID"] = 375,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26632,
		},
		[59826] = {
			["encounterName"] = "Gal'darah",
			["source"] = "Gal'darah",
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29306,
		},
		[68284] = {
			["encounterName"] = "Grand Champions",
			["type"] = "BUFF",
			["source"] = "Argent Battleworg",
			["npcID"] = 36558,
			["event"] = "SPELL_AURA_APPLIED",
			["encounterID"] = 334,
		},
		[23844] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Unknown",
			["npcID"] = 1860,
		},
		[60018] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30622,
		},
		[62129] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Cult Researcher",
			["npcID"] = 32297,
		},
		[11974] = {
			["isChanneled"] = false,
			["source"] = "Gold Priest",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32325,
		},
		[72335] = {
			["isChanneled"] = false,
			["source"] = "Shadowy Mercenary",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38177,
		},
		[52086] = {
			["encounterName"] = "Hadronox",
			["source"] = "Anub'ar Webspinner",
			["encounterID"] = 217,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29335,
		},
		[58291] = {
			["isChanneled"] = false,
			["source"] = "Azure Saboteur",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31079,
		},
		[54261] = {
			["isChanneled"] = false,
			["source"] = "Gold Mage",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32341,
		},
		[12054] = {
			["isChanneled"] = false,
			["source"] = "Silverbrook Defender",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27676,
		},
		[57047] = {
			["isChanneled"] = false,
			["source"] = "Crazed Mana-Surge",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26737,
		},
		[50132] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Mage Slayer",
			["npcID"] = 26730,
		},
		[52470] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Watcher Gashra",
			["encounterID"] = 216,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28730,
		},
		[52534] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Anub'ar Shadowcaster",
			["encounterID"] = 216,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28733,
		},
		[55625] = {
			["isChanneled"] = false,
			["source"] = "Drakkari God Hunter",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29820,
		},
		[16244] = {
			["isChanneled"] = false,
			["source"] = "Illidari Taskmaster",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 17058,
		},
		[58867] = {
			["encounterName"] = "Mage-Lord Urom",
			["source"] = "Spirit Wolf",
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29264,
		},
		[8269] = {
			["isChanneled"] = false,
			["source"] = "Drakkari Commander",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27431,
		},
		[58995] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Hulking Abomination",
			["npcID"] = 31140,
		},
		[59110] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dappled Stag",
			["npcID"] = 31236,
		},
		[57076] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Yggdras",
			["npcID"] = 30014,
		},
		[55093] = {
			["encounterName"] = "Slad'ran",
			["source"] = "Slad'ran Constrictor",
			["encounterID"] = 383,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29713,
		},
		[53110] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Frostbrood Vanquisher",
			["npcID"] = 28670,
		},
		[32736] = {
			["isChanneled"] = false,
			["source"] = "Gold Warrior",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32322,
		},
		[56728] = {
			["isChanneled"] = false,
			["source"] = "Eye of Taldaram",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30285,
		},
		[61490] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30623,
		},
		[67719] = {
			["encounterName"] = "The Black Knight",
			["type"] = "DEBUFF",
			["source"] = "The Black Knight",
			["encounterID"] = 340,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 35451,
		},
		[69060] = {
			["isChanneled"] = false,
			["source"] = "Soulguard Reaper",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36499,
		},
		[30849] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Mage Slayer",
			["npcID"] = 26730,
		},
		[52791] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Primordial Drake",
			["npcID"] = 28378,
		},
		[47481] = {
			["isChanneled"] = false,
			["source"] = "Stonebasher",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26125,
		},
		[49592] = {
			["isChanneled"] = false,
			["source"] = "Amber Drake",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27755,
		},
		[49703] = {
			["encounterName"] = "Trollgore",
			["source"] = "Wretched Belcher",
			["encounterID"] = 369,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26624,
		},
		[56855] = {
			["encounterName"] = "Jedoga Shadowseeker",
			["source"] = "Jedoga Shadowseeker",
			["encounterID"] = 214,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29310,
		},
		[60019] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30623,
		},
		[12470] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Gold Shaman",
			["npcID"] = 32340,
		},
		[46441] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Scavenge-bot 004-A8",
			["npcID"] = 25752,
		},
		[60211] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dragonflayer Forge Master",
			["npcID"] = 24079,
		},
		[47993] = {
			["encounterName"] = "Falric",
			["source"] = "Haagoril",
			["npcID"] = 17252,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 841,
		},
		[49840] = {
			["isChanneled"] = false,
			["source"] = "Amber Drake",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27755,
		},
		[12550] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Living Storm",
			["npcID"] = 9397,
		},
		[50232] = {
			["isChanneled"] = false,
			["source"] = "Ruby Drake",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27756,
		},
		[414266] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Unknown",
			["npcID"] = 26125,
		},
		[57942] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Herald Volazj",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29311,
		},
		[52471] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Giz",
			["npcID"] = 682,
		},
		[52535] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Anub'ar Shadowcaster",
			["encounterID"] = 216,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28733,
		},
		[68899] = {
			["encounterName"] = "Devourer of Souls",
			["source"] = "Devourer of Souls",
			["encounterID"] = 831,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36502,
		},
		[60851] = {
			["isChanneled"] = false,
			["source"] = "Forgotten One",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30414,
		},
		[7162] = {
			["isChanneled"] = false,
			["source"] = "Brother Malach",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 5661,
		},
		[48697] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Scourge Hulk",
			["npcID"] = 26555,
		},
		[56776] = {
			["isChanneled"] = false,
			["source"] = "Azure Magus",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26722,
		},
		[50872] = {
			["encounterName"] = "Chrono-Lord Epoch",
			["type"] = "BUFF",
			["source"] = "Raptor",
			["encounterID"] = 295,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 3122,
		},
		[69088] = {
			["isChanneled"] = false,
			["source"] = "Soul Horror",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36522,
		},
		[28131] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Patchwerk",
			["npcID"] = 31099,
		},
		[58470] = {
			["isChanneled"] = false,
			["source"] = "Azure Stalker",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32191,
		},
		[54537] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Improved Land Mine",
			["npcID"] = 29475,
		},
		[50379] = {
			["encounterName"] = "Trollgore",
			["source"] = "Scourge Reanimator",
			["encounterID"] = 369,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26626,
		},
		[61491] = {
			["encounterName"] = "Herald Volazj",
			["type"] = "DEBUFF",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 30623,
		},
		[52362] = {
			["isChanneled"] = false,
			["source"] = "Acherus Deathcharger",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28782,
		},
		[59021] = {
			["isChanneled"] = false,
			["source"] = "Unyielding Constrictor",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29768,
		},
		[59613] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dragonflayer Overseer",
			["npcID"] = 24085,
		},
		[37361] = {
			["isChanneled"] = false,
			["source"] = "Skeletal Guardian",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10390,
		},
		[47482] = {
			["isChanneled"] = false,
			["source"] = "Stonebasher",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26125,
		},
		[59828] = {
			["encounterName"] = "Gal'darah",
			["source"] = "Gal'darah",
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29306,
		},
		[43516] = {
			["isChanneled"] = false,
			["source"] = "Dragonflayer Prisoner",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 24255,
		},
		[49721] = {
			["isChanneled"] = false,
			["source"] = "Risen Drakkari Death Knight",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26830,
		},
		[52792] = {
			["source"] = "Primordial Drake Egg",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 28408,
		},
		[9128] = {
			["isChanneled"] = false,
			["source"] = "Gold Warrior",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32322,
		},
		[12674] = {
			["isChanneled"] = false,
			["source"] = "Bloodmage",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 19258,
		},
		[60212] = {
			["isChanneled"] = false,
			["source"] = "Scourge Converter",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32257,
		},
		[47994] = {
			["isChanneled"] = false,
			["source"] = "Ikzilgoril",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 17252,
		},
		[50105] = {
			["isChanneled"] = false,
			["source"] = "Storm Giant",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 24812,
		},
		[50169] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Whisker",
			["npcID"] = 30113,
		},
		[54429] = {
			["isChanneled"] = false,
			["source"] = "Sparktouched Warrior",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28111,
		},
		[6253] = {
			["isChanneled"] = false,
			["source"] = "Risen Drakkari Handler",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26637,
		},
		[50361] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Festering Ghoul",
			["npcID"] = 25660,
		},
		[52472] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "TOP",
			["npcID"] = 7431,
		},
		[56630] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Unknown",
			["npcID"] = 18133,
		},
		[66019] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Knight of the Ebon Blade",
			["npcID"] = 38505,
		},
		[9080] = {
			["isChanneled"] = false,
			["source"] = "Gold Warrior",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32322,
		},
		[48878] = {
			["encounterName"] = "King Dred",
			["source"] = "King Dred",
			["encounterID"] = 373,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27483,
		},
		[44604] = {
			["isChanneled"] = false,
			["source"] = "Snowflake",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28153,
		},
		[20295] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Timbermaw Shaman",
			["npcID"] = 6188,
		},
		[39376] = {
			["isChanneled"] = false,
			["source"] = "Mage Hunter Ascendant",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26727,
		},
		[24453] = {
			["isChanneled"] = false,
			["source"] = "Cat",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28404,
		},
		[51001] = {
			["encounterName"] = "Tribunal of Ages",
			["source"] = "Dark Matter",
			["npcID"] = 28235,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 567,
		},
		[69058] = {
			["isChanneled"] = false,
			["source"] = "Soulguard Reaper",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36499,
		},
		[15580] = {
			["isChanneled"] = false,
			["source"] = "Drakkari Inciter",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29874,
		},
		[59381] = {
			["encounterName"] = "Ley-Guardian Eregos",
			["source"] = "Ley-Guardian Eregos",
			["encounterID"] = 534,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27656,
		},
		[32064] = {
			["isChanneled"] = false,
			["source"] = "Vengeance Bringer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 23865,
		},
		[61556] = {
			["encounterName"] = "Ormorok the Tree-Shaper",
			["type"] = "DEBUFF",
			["source"] = "Crystalline Tangler",
			["encounterID"] = 524,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 32665,
		},
		[53432] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Harold Lane",
			["npcID"] = 25804,
		},
		[61684] = {
			["isChanneled"] = false,
			["source"] = "Wolfgang",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 17669,
		},
		[13398] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Bonechewer Scavenger",
			["npcID"] = 18952,
		},
		[52473] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Boar",
			["npcID"] = 3100,
		},
		[59829] = {
			["encounterName"] = "Gal'darah",
			["source"] = "Gal'darah",
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29306,
		},
		[13446] = {
			["isChanneled"] = false,
			["source"] = "Ravaged Cadaver",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10381,
		},
		[55968] = {
			["encounterName"] = "Prince Taldaram",
			["source"] = "Prince Taldaram",
			["encounterID"] = 213,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29308,
		},
		[52317] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Lordaeron Footman",
			["npcID"] = 27745,
		},
		[49974] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Tsszz",
			["npcID"] = 18133,
		},
		[55240] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Shadow Vault Abomination",
			["npcID"] = 31438,
		},
		[17289] = {
			["isChanneled"] = false,
			["source"] = "Eye of Taldaram",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30285,
		},
		[69347] = {
			["isChanneled"] = false,
			["source"] = "Scourgelord Tyrannus",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36794,
		},
		[50106] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Plague Drenched Ghoul",
			["npcID"] = 32176,
		},
		[69603] = {
			["isChanneled"] = false,
			["source"] = "Ymirjar Wrathbringer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36840,
		},
		[57647] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30621,
		},
		[47774] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Alliance Berserker",
			["npcID"] = 26800,
		},
		[42702] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Tunneling Ghoul",
			["npcID"] = 24084,
		},
		[66021] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Knight of the Ebon Blade",
			["npcID"] = 38505,
		},
		[34114] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Bonechewer Mutant",
			["npcID"] = 16876,
		},
		[59367] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Krik'thir the Gatewatcher",
			["encounterID"] = 216,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28684,
		},
		[34370] = {
			["isChanneled"] = false,
			["source"] = "Spirit of Ha-Khalan",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29018,
		},
		[46604] = {
			["isChanneled"] = false,
			["source"] = "Green Mage",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32324,
		},
		[44605] = {
			["source"] = "Snowflake",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 28153,
		},
		[58822] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Arthas",
			["npcID"] = 26499,
		},
		[58758] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Devouring Ghoul",
			["npcID"] = 28249,
		},
		[9672] = {
			["isChanneled"] = false,
			["source"] = "Skeletal Guardian",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10390,
		},
		[51002] = {
			["encounterName"] = "Varos Cloudstrider",
			["source"] = "Varos Cloudstrider",
			["encounterID"] = 530,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27447,
		},
		[59254] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Ymirjar Necromancer",
			["npcID"] = 28368,
		},
		[53177] = {
			["isChanneled"] = false,
			["source"] = "Hadronox",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28921,
		},
		[6917] = {
			["isChanneled"] = false,
			["source"] = "Thornfang Venomspitter",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 19350,
		},
		[59446] = {
			["encounterName"] = "Anub'arak",
			["source"] = "Anub'arak",
			["encounterID"] = 218,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29120,
		},
		[72322] = {
			["isChanneled"] = false,
			["source"] = "Ghostly Priest",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38175,
		},
		[11831] = {
			["isChanneled"] = false,
			["source"] = "Dragonflayer Prisoner",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 24254,
		},
		[72163] = {
			["isChanneled"] = false,
			["source"] = "Phantom Mage",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38172,
		},
		[49528] = {
			["encounterName"] = "The Prophet Tharon'ja",
			["source"] = "The Prophet Tharon'ja",
			["encounterID"] = 375,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26632,
		},
		[50378] = {
			["isChanneled"] = false,
			["source"] = "Scourge Reanimator",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26626,
		},
		[60009] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30624,
		},
		[67716] = {
			["encounterName"] = "Grand Champions",
			["source"] = "Marshal Jacob Alerius",
			["npcID"] = 34705,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 334,
		},
		[49723] = {
			["isChanneled"] = false,
			["source"] = "Risen Drakkari Death Knight",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26830,
		},
		[52474] = {
			["isChanneled"] = false,
			["source"] = "Wolfgang",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 17669,
		},
		[67778] = {
			["encounterName"] = "The Black Knight",
			["source"] = "The Black Knight",
			["npcID"] = 35451,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 340,
		},
		[17307] = {
			["isChanneled"] = false,
			["source"] = "Ramstein the Gorger",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10439,
		},
		[4974] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Witherbark Troll",
			["npcID"] = 2552,
		},
		[47996] = {
			["isChanneled"] = false,
			["source"] = "Ikzilgoril",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 17252,
		},
		[12023] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Crystalweb Spitter",
			["npcID"] = 29412,
		},
		[59346] = {
			["isChanneled"] = false,
			["source"] = "Anub'ar Crusher",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28922,
		},
		[16170] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Orgrimmar Shaman",
			["npcID"] = 18972,
		},
		[32674] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Reanimated Crusader",
			["npcID"] = 30202,
		},
		[69350] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Coliseum Champion",
			["npcID"] = 37584,
		},
		[66023] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Knight of the Ebon Blade",
			["npcID"] = 38505,
		},
		[56632] = {
			["isChanneled"] = false,
			["source"] = "Ahn'kahar Web Winder",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30276,
		},
		[16458] = {
			["isChanneled"] = false,
			["source"] = "Plague Ghoul",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10405,
		},
		[69029] = {
			["encounterName"] = "Krick",
			["type"] = "BUFF",
			["source"] = "Ick",
			["encounterID"] = 835,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 36476,
		},
		[22766] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Syndicate Highwayman",
			["npcID"] = 2586,
		},
		[59638] = {
			["encounterName"] = "Drakos the Interrogator",
			["source"] = "Mirror Image",
			["encounterID"] = 528,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31216,
		},
		[49482] = {
			["isChanneled"] = false,
			["source"] = "Fordragon Gryphon Rider",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27521,
		},
		[52922] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "High Inquisitor Valroth",
			["npcID"] = 29001,
		},
		[68839] = {
			["encounterName"] = "Bronjahm",
			["source"] = "Bronjahm",
			["encounterID"] = 829,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36497,
		},
		[69222] = {
			["encounterName"] = "Escaped from Arthas",
			["source"] = "Frostsworn General",
			["encounterID"] = 843,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36723,
		},
		[20424] = {
			["isChanneled"] = false,
			["source"] = "Green Paladin",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32342,
		},
		[7165] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Dunemaul Ogre",
			["npcID"] = 5471,
		},
		[59348] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Anub'ar Crypt Fiend",
			["encounterID"] = 216,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29063,
		},
		[28747] = {
			["encounterName"] = "Sjonnir the Ironshaper",
			["source"] = "Sjonnir The Ironshaper",
			["npcID"] = 27978,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 569,
		},
		[61558] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dark Necromancer",
			["npcID"] = 28200,
		},
		[59575] = {
			["encounterName"] = "Skarvold & Dalronn",
			["source"] = "Dalronn the Controller",
			["npcID"] = 24201,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 573,
		},
		[52766] = {
			["encounterName"] = "Chrono-Lord Epoch",
			["source"] = "Chrono-Lord Epoch",
			["npcID"] = 26532,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 295,
		},
		[53114] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Frostbrood Vanquisher",
			["npcID"] = 28670,
		},
		[67237] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Argent Lightwielder",
			["npcID"] = 35309,
		},
		[49034] = {
			["encounterName"] = "Novos the Summoner",
			["source"] = "Novos the Summoner",
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26631,
		},
		[47995] = {
			["source"] = "Ikzilgoril",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 17252,
		},
		[57912] = {
			["isChanneled"] = false,
			["source"] = "Defense System",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30837,
		},
		[60023] = {
			["isChanneled"] = false,
			["source"] = "Scourge Banner-Bearer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31900,
		},
		[12471] = {
			["isChanneled"] = false,
			["source"] = "Shadow Construct",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29231,
		},
		[51963] = {
			["isChanneled"] = false,
			["source"] = "Ebon Gargoyle",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27829,
		},
		[22414] = {
			["isChanneled"] = false,
			["source"] = "Bound Air Elemental",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30418,
		},
		[54138] = {
			["isChanneled"] = false,
			["source"] = "Xevozz",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29266,
		},
		[54202] = {
			["isChanneled"] = false,
			["source"] = "Xevozz",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29266,
		},
		[58973] = {
			["isChanneled"] = false,
			["source"] = "Drakkari God Hunter",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29820,
		},
		[69056] = {
			["isChanneled"] = false,
			["source"] = "Soulguard Watchman",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36478,
		},
		[33924] = {
			["source"] = "Bleeding Hollow Tormentor",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 19424,
		},
		[54458] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Hyldsmeet Warbear",
			["npcID"] = 30174,
		},
		[72166] = {
			["isChanneled"] = false,
			["source"] = "Phantom Mage",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38172,
		},
		[31602] = {
			["isChanneled"] = false,
			["source"] = "Nerub'enkan",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10437,
		},
		[72422] = {
			["encounterName"] = "Falric",
			["source"] = "Falric",
			["encounterID"] = 841,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38112,
		},
		[58808] = {
			["isChanneled"] = false,
			["source"] = "Patchwork Construct",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27736,
		},
		[56825] = {
			["isChanneled"] = false,
			["source"] = "Mage Hunter Ascendant",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26727,
		},
		[53467] = {
			["encounterName"] = "Anub'arak",
			["source"] = "Anub'arak",
			["encounterID"] = 218,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29120,
		},
		[16324] = {
			["isChanneled"] = false,
			["source"] = "Ravaged Cadaver",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10381,
		},
		[2676] = {
			["isChanneled"] = false,
			["source"] = "Boulderfist Crusher",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 17134,
		},
		[17290] = {
			["isChanneled"] = false,
			["source"] = "Twilight Worshipper",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30111,
		},
		[55098] = {
			["encounterName"] = "Moorabi",
			["source"] = "Moorabi",
			["encounterID"] = 387,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29305,
		},
		[72320] = {
			["isChanneled"] = false,
			["source"] = "Ghostly Priest",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38175,
		},
		[59320] = {
			["encounterName"] = "King Ymiron",
			["source"] = "Spirit Fount",
			["npcID"] = 27339,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 583,
		},
		[61549] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Ymirjar Berserker",
			["npcID"] = 26696,
		},
		[70274] = {
			["isChanneled"] = false,
			["source"] = "Plagueborn Horror",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36879,
		},
		[42723] = {
			["encounterName"] = "Ingvar the Plunderer",
			["source"] = "Ingvar the Plunderer",
			["npcID"] = 23954,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 575,
		},
		[69052] = {
			["source"] = "Soulguard Watchman",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 36478,
		},
		[35076] = {
			["source"] = "A'dal",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 18481,
		},
		[31567] = {
			["isChanneled"] = false,
			["source"] = "Drakkari God Hunter",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29820,
		},
		[47791] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Mage Hunter Ascendant",
			["npcID"] = 26727,
		},
		[58981] = {
			["isChanneled"] = false,
			["source"] = "Drakkari Medicine Man",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29826,
		},
		[32003] = {
			["isChanneled"] = false,
			["source"] = "Gan'arg Servant",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 16947,
		},
		[55866] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Stinkbeard",
			["npcID"] = 30017,
		},
		[49309] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Gold Shaman",
			["npcID"] = 32340,
		},
		[32376] = {
			["isChanneled"] = false,
			["source"] = "Warmaul Chef Bufferlo",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 18440,
		},
		[9885] = {
			["source"] = "Watcher Leesa'oh",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 17831,
		},
		[49981] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Defendo-tank 66D",
			["npcID"] = 25758,
		},
		[71400] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Sunreaver Agent",
			["npcID"] = 38201,
		},
		[54459] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Warbear Matriarch",
			["npcID"] = 29918,
		},
		[32595] = {
			["source"] = "Fordragon High Priest",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 27677,
		},
		[60472] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Alumeth the Ascended",
			["npcID"] = 32300,
		},
		[32323] = {
			["encounterName"] = "Mage-Lord Urom",
			["source"] = "Phantasmal Mammoth",
			["encounterID"] = 532,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27642,
		},
		[22120] = {
			["encounterName"] = "Tribunal of Ages",
			["source"] = "Dark Rune Protector",
			["npcID"] = 27983,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 567,
		},
		[55814] = {
			["encounterName"] = "Eck the Ferocious",
			["source"] = "Eck the Ferocious",
			["encounterID"] = 1988,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29932,
		},
		[52540] = {
			["encounterName"] = "Hadronox",
			["source"] = "Anub'ar Skirmisher",
			["encounterID"] = 217,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28734,
		},
		[56698] = {
			["isChanneled"] = false,
			["source"] = "Ahn'kahar Spell Flinger",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30278,
		},
		[16832] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Vaiduoklis",
			["npcID"] = 3619,
		},
		[57959] = {
			["encounterName"] = "Ley-Guardian Eregos",
			["source"] = "Ley-Guardian Eregos",
			["encounterID"] = 534,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27656,
		},
		[48702] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dragonflayer Fanatic",
			["npcID"] = 26553,
		},
		[20297] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Frostskull Magus",
			["npcID"] = 31813,
		},
		[49481] = {
			["isChanneled"] = false,
			["source"] = "Fordragon Sentinel",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27576,
		},
		[57082] = {
			["encounterName"] = "Ormorok the Tree-Shaper",
			["source"] = "Ormorok the Tree-Shaper",
			["encounterID"] = 524,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26794,
		},
		[70144] = {
			["encounterName"] = "Escaped from Arthas",
			["source"] = "Risen Witch Doctor",
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36941,
		},
		[55163] = {
			["isChanneled"] = false,
			["source"] = "Moorabi",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29305,
		},
		[58848] = {
			["encounterName"] = "Chrono-Lord Epoch",
			["source"] = "Chrono-Lord Epoch",
			["npcID"] = 26532,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 295,
		},
		[69582] = {
			["isChanneled"] = false,
			["source"] = "Plagueborn Horror",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36879,
		},
		[16427] = {
			["source"] = "Crypt Beast",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 10413,
		},
		[59513] = {
			["encounterName"] = "Prince Taldaram",
			["source"] = "Prince Taldaram",
			["encounterID"] = 213,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29308,
		},
		[14873] = {
			["isChanneled"] = false,
			["source"] = "Cult Conspirator",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 33537,
		},
		[72169] = {
			["isChanneled"] = false,
			["source"] = "Phantom Mage",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38172,
		},
		[36094] = {
			["source"] = "Risen Drakkari Warrior",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 26635,
		},
		[14514] = {
			["isChanneled"] = false,
			["source"] = "Gold Mage",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32341,
		},
		[56891] = {
			["encounterName"] = "Jedoga Shadowseeker",
			["source"] = "Jedoga Shadowseeker",
			["encounterID"] = 214,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29310,
		},
		[6920] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Wildthorn Lurker",
			["npcID"] = 3821,
		},
		[55867] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Stinkbeard",
			["npcID"] = 30017,
		},
		[47743] = {
			["encounterName"] = "Anomalus",
			["source"] = "Anomalus",
			["npcID"] = 26763,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 522,
		},
		[64695] = {
			["source"] = "Earthbind Totem",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 2630,
		},
		[44415] = {
			["isChanneled"] = false,
			["source"] = "Gold Priest",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32325,
		},
		[11939] = {
			["isChanneled"] = false,
			["source"] = "Warmaul Warlock",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 18037,
		},
		[50046] = {
			["isChanneled"] = false,
			["source"] = "Grizzlesnout",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27523,
		},
		[7805] = {
			["source"] = "Unknown",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 416,
		},
		[52221] = {
			["isChanneled"] = false,
			["source"] = "Scarlet Captain",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28611,
		},
		[48191] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Alliance Ranger",
			["npcID"] = 26802,
		},
		[50302] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Crystalline Protector",
			["npcID"] = 26792,
		},
		[54460] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Warbear Matriarch",
			["npcID"] = 29918,
		},
		[53602] = {
			["encounterName"] = "Anub'arak",
			["source"] = "Anub'ar Darter",
			["encounterID"] = 218,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29213,
		},
		[50494] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Grand Necrolord Antiok",
			["npcID"] = 28006,
		},
		[72426] = {
			["encounterName"] = "Falric",
			["source"] = "Falric",
			["encounterID"] = 841,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38112,
		},
		[58810] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Bile Golem",
			["npcID"] = 28201,
		},
		[48639] = {
			["encounterName"] = "Skadi the Ruthless",
			["source"] = "Ymirjar Warrior",
			["npcID"] = 26690,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 581,
		},
		[17195] = {
			["isChanneled"] = false,
			["source"] = "Bound Fire Elemental",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30416,
		},
		[58849] = {
			["encounterName"] = "Mal'ganis",
			["source"] = "Mal'Ganis",
			["npcID"] = 26533,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 296,
		},
		[67546] = {
			["encounterName"] = "Grand Champions",
			["source"] = "Marshal Jacob Alerius",
			["npcID"] = 34705,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 334,
		},
		[59130] = {
			["isChanneled"] = false,
			["source"] = "Ebon Blade Vindicator",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32488,
		},
		[56709] = {
			["isChanneled"] = false,
			["source"] = "Plague Walker",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30283,
		},
		[53117] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Scarlet Ballista",
			["npcID"] = 29104,
		},
		[59322] = {
			["encounterName"] = "Skadi the Ruthless",
			["source"] = "Skadi the Ruthless",
			["npcID"] = 26693,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 581,
		},
		[59386] = {
			["encounterName"] = "Prince Keleseth",
			["source"] = "Vrykul Skeleton",
			["npcID"] = 23970,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 571,
		},
		[38980] = {
			["isChanneled"] = false,
			["source"] = "Deathshadow Warlock",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 22363,
		},
		[72318] = {
			["isChanneled"] = false,
			["source"] = "Ghostly Priest",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38175,
		},
		[56581] = {
			["isChanneled"] = false,
			["source"] = "Deep Crawler",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30279,
		},
		[72171] = {
			["isChanneled"] = false,
			["source"] = "Phantom Mage",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38172,
		},
		[59706] = {
			["encounterName"] = "Ingvar the Plunderer",
			["source"] = "Ingvar the Plunderer",
			["npcID"] = 23954,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 575,
		},
		[57723] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Unknown",
			["npcID"] = 1860,
		},
		[19647] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Thoomon",
			["npcID"] = 417,
		},
		[69900] = {
			["encounterName"] = "Escaped from Arthas",
			["source"] = "Spiritual Reflection",
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 37068,
		},
		[48053] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Crystalline Frayer",
			["npcID"] = 26793,
		},
		[43650] = {
			["encounterName"] = "Skarvold & Dalronn",
			["source"] = "Dalronn the Controller",
			["npcID"] = 24201,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 573,
		},
		[23153] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Chromaggus",
			["npcID"] = 14020,
		},
		[11976] = {
			["isChanneled"] = false,
			["source"] = "Skeletal Berserker",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10391,
		},
		[48895] = {
			["isChanneled"] = false,
			["source"] = "Drakkari Shaman",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26639,
		},
		[8053] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Bloodmage Thalnos",
			["npcID"] = 4543,
		},
		[12024] = {
			["isChanneled"] = false,
			["source"] = "Redfang Hunter",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26356,
		},
		[17238] = {
			["isChanneled"] = false,
			["source"] = "Maleki the Pallid",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10438,
		},
		[53273] = {
			["isChanneled"] = false,
			["source"] = "Brown Rabbit",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29134,
		},
		[56646] = {
			["isChanneled"] = false,
			["source"] = "Ahn'kahar Slasher",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30277,
		},
		[59358] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Anub'ar Shadowcaster",
			["encounterID"] = 216,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28733,
		},
		[59467] = {
			["encounterName"] = "Elder Nadox",
			["source"] = "Elder Nadox",
			["encounterID"] = 212,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29309,
		},
		[50495] = {
			["encounterName"] = "Mage-Lord Urom",
			["source"] = "Mage-Lord Urom",
			["encounterID"] = 532,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27655,
		},
		[70381] = {
			["encounterName"] = "Forgemaster Garfrost",
			["source"] = "Forgemaster Garfrost",
			["encounterID"] = 833,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36494,
		},
		[58811] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Acolyte",
			["npcID"] = 27731,
		},
		[58875] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Spirit Wolf",
			["npcID"] = 29264,
		},
		[54396] = {
			["isChanneled"] = false,
			["source"] = "Moragg",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29316,
		},
		[70893] = {
			["source"] = "Wolfgang",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 17669,
		},
		[52926] = {
			["isChanneled"] = false,
			["source"] = "High Inquisitor Valroth",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29001,
		},
		[59131] = {
			["isChanneled"] = false,
			["source"] = "Ebon Blade Defender",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31250,
		},
		[53766] = {
			["source"] = "Lady Alistra",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 28471,
		},
		[35234] = {
			["isChanneled"] = false,
			["source"] = "Marsh Dredger",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 18137,
		},
		[49544] = {
			["encounterName"] = "The Prophet Tharon'ja",
			["source"] = "The Prophet Tharon'ja",
			["encounterID"] = 375,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26632,
		},
		[388129] = {
			["isChanneled"] = false,
			["source"] = "Pebble",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 194870,
		},
		[67823] = {
			["encounterName"] = "The Black Knight",
			["source"] = "The Black Knight",
			["npcID"] = 35451,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 340,
		},
		[61562] = {
			["isChanneled"] = false,
			["source"] = "Twilight Darkcaster",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30319,
		},
		[20615] = {
			["source"] = "Gold Warrior",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 32322,
		},
		[59344] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Anub'ar Champion",
			["encounterID"] = 216,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29096,
		},
		[8282] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "High Inquisitor Fairbanks",
			["npcID"] = 4542,
		},
		[57724] = {
			["source"] = "EXCALIBUR",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 25675,
		},
		[28902] = {
			["isChanneled"] = false,
			["source"] = "Twilight Apostle",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30179,
		},
		[53318] = {
			["isChanneled"] = false,
			["source"] = "Anub'ar Crusher",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28922,
		},
		[48193] = {
			["encounterName"] = "Skarvold & Dalronn",
			["source"] = "Skarvald the Constructor",
			["npcID"] = 24200,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 573,
		},
		[43651] = {
			["encounterName"] = "Skarvold & Dalronn",
			["source"] = "Skarvald the Constructor",
			["npcID"] = 24200,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 573,
		},
		[59707] = {
			["encounterName"] = "Ingvar the Plunderer",
			["source"] = "Ingvar the Plunderer",
			["npcID"] = 23954,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 575,
		},
		[57083] = {
			["encounterName"] = "Ormorok the Tree-Shaper",
			["source"] = "Ormorok the Tree-Shaper",
			["encounterID"] = 524,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26794,
		},
		[27047] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Boar",
			["npcID"] = 3100,
		},
		[30633] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Crystalline Protector",
			["npcID"] = 26792,
		},
		[75593] = {
			["source"] = "Unknown",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 33776,
		},
		[45578] = {
			["isChanneled"] = false,
			["source"] = "Warsong Marksman",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 25244,
		},
		[50240] = {
			["isChanneled"] = false,
			["source"] = "Ruby Drake",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27756,
		},
		[3148] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Southsea Dock Worker",
			["npcID"] = 7857,
		},
		[23145] = {
			["source"] = "Chimaera",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 24673,
		},
		[60667] = {
			["isChanneled"] = false,
			["source"] = "Frostbrood Matriarch",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32492,
		},
		[50496] = {
			["encounterName"] = "Mage-Lord Urom",
			["source"] = "Mage-Lord Urom",
			["encounterID"] = 532,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27655,
		},
		[34019] = {
			["isChanneled"] = false,
			["source"] = "Bleeding Hollow Necrolyte",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 19422,
		},
		[69066] = {
			["isChanneled"] = false,
			["source"] = "Soulguard Adept",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36620,
		},
		[50688] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Ebon Blade Champion",
			["npcID"] = 30703,
		},
		[68872] = {
			["encounterName"] = "Bronjahm",
			["source"] = "Bronjahm",
			["encounterID"] = 829,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36497,
		},
		[49537] = {
			["encounterName"] = "The Prophet Tharon'ja",
			["source"] = "The Prophet Tharon'ja",
			["encounterID"] = 375,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26632,
		},
		[57567] = {
			["isChanneled"] = false,
			["source"] = "Sloomon",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 417,
		},
		[66514] = {
			["isChanneled"] = false,
			["source"] = "North Sea Kraken",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 34925,
		},
		[56580] = {
			["isChanneled"] = false,
			["source"] = "Deep Crawler",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30279,
		},
		[59260] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Sunreaver Agent",
			["npcID"] = 38201,
		},
		[50075] = {
			["isChanneled"] = false,
			["source"] = "Spearfang Worg",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 24677,
		},
		[67838] = {
			["isChanneled"] = false,
			["source"] = "Wormhole",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 35646,
		},
		[63546] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Pustulent Horror",
			["npcID"] = 31139,
		},
		[61563] = {
			["isChanneled"] = false,
			["source"] = "Twilight Darkcaster",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30319,
		},
		[12058] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Iron Dwarf Magus",
			["npcID"] = 29979,
		},
		[14919] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Bear",
			["npcID"] = 1186,
		},
		[59708] = {
			["encounterName"] = "Ingvar the Plunderer",
			["source"] = "Ingvar the Plunderer",
			["npcID"] = 23954,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 575,
		},
		[59772] = {
			["encounterName"] = "Maiden of Grief",
			["source"] = "Maiden of Grief",
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27975,
		},
		[70512] = {
			["isChanneled"] = false,
			["source"] = "Lady Sylvanas Windrunner",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36990,
		},
		[35336] = {
			["source"] = "Greater Sporebat",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 18129,
		},
		[49729] = {
			["isChanneled"] = false,
			["source"] = "Iron Rune Golem",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 24271,
		},
		[59109] = {
			["isChanneled"] = false,
			["source"] = "Deep Crawler",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30279,
		},
		[54131] = {
			["source"] = "Unknown",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 24128,
		},
		[46691] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Nexus Drake Hatchling",
			["npcID"] = 26127,
		},
		[15063] = {
			["isChanneled"] = false,
			["source"] = "Frostbringer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30286,
		},
		[20545] = {
			["encounterName"] = "Mage-Lord Urom",
			["source"] = "Phantasmal Air",
			["encounterID"] = 532,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27650,
		},
		[19659] = {
			["source"] = "Baron Geddon",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 12056,
		},
		[35848] = {
			["source"] = "Fordragon Battle Mage",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 27695,
		},
		[50241] = {
			["source"] = "Ruby Drake",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 27756,
		},
		[68989] = {
			["encounterName"] = "Krick",
			["source"] = "Ick",
			["encounterID"] = 835,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36476,
		},
		[4511] = {
			["isChanneled"] = false,
			["source"] = "Lazgup",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 416,
		},
		[53813] = {
			["encounterName"] = "Mage-Lord Urom",
			["source"] = "Mage-Lord Urom",
			["encounterID"] = 532,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27655,
		},
		[69573] = {
			["isChanneled"] = false,
			["source"] = "Wrathbone Coldwraith",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36842,
		},
		[56702] = {
			["isChanneled"] = false,
			["source"] = "Ahn'kahar Spell Flinger",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30278,
		},
		[54719] = {
			["encounterName"] = "Drakkari Colossus",
			["source"] = "Drakkari Colossus",
			["encounterID"] = 385,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29307,
		},
		[50689] = {
			["isChanneled"] = false,
			["source"] = "Onslaught Death Knight",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27367,
		},
		[59133] = {
			["isChanneled"] = false,
			["source"] = "Ebon Blade Defender",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31250,
		},
		[52864] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Haiphoon, the Great Tempest",
			["npcID"] = 28999,
		},
		[57795] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30622,
		},
		[57086] = {
			["encounterName"] = "Ormorok the Tree-Shaper",
			["source"] = "Ormorok the Tree-Shaper",
			["encounterID"] = 524,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26794,
		},
		[57731] = {
			["isChanneled"] = false,
			["source"] = "Hadronox",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28921,
		},
		[49026] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Bloodthirsty Tundra Wolf",
			["npcID"] = 26672,
		},
		[36808] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Mage Hunter Ascendant",
			["npcID"] = 26727,
		},
		[59389] = {
			["encounterName"] = "Prince Keleseth",
			["source"] = "Prince Keleseth",
			["npcID"] = 23953,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 571,
		},
		[56620] = {
			["isChanneled"] = false,
			["source"] = "Seething Revenant",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30387,
		},
		[61564] = {
			["encounterName"] = "Ormorok the Tree-Shaper",
			["source"] = "Ormorok the Tree-Shaper",
			["encounterID"] = 524,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26794,
		},
		[52862] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Haiphoon, the Great Tempest",
			["npcID"] = 28999,
		},
		[65918] = {
			["encounterName"] = "Grand Champions",
			["type"] = "BUFF",
			["source"] = "Marshal Jacob Alerius' Mount",
			["npcID"] = 35637,
			["event"] = "SPELL_AURA_APPLIED",
			["encounterID"] = 334,
		},
		[49474] = {
			["source"] = "Fordragon Marksman",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 27540,
		},
		[67837] = {
			["isChanneled"] = false,
			["source"] = "Wormhole",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 35646,
		},
		[57790] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30621,
		},
		[53317] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Anub'ar Champion",
			["encounterID"] = 216,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29062,
		},
		[50690] = {
			["isChanneled"] = false,
			["source"] = "Azure Inquisitor",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27633,
		},
		[6742] = {
			["isChanneled"] = false,
			["source"] = "Bleeding Hollow Dark Shaman",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 16873,
		},
		[59255] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Ymirjar Necromancer",
			["npcID"] = 28368,
		},
		[70513] = {
			["isChanneled"] = false,
			["source"] = "Lady Sylvanas Windrunner",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36990,
		},
		[72333] = {
			["isChanneled"] = false,
			["source"] = "Shadowy Mercenary",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38177,
		},
		[57091] = {
			["encounterName"] = "Keristrasza",
			["source"] = "Keristrasza",
			["encounterID"] = 526,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26723,
		},
		[57617] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Icetip Crawler",
			["npcID"] = 29461,
		},
		[59365] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Watcher Narjil",
			["encounterID"] = 216,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28729,
		},
		[8314] = {
			["source"] = "Kranal Fiss",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 5907,
		},
		[50306] = {
			["isChanneled"] = false,
			["source"] = "Garhal",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30147,
		},
		[50370] = {
			["isChanneled"] = false,
			["source"] = "Westfall Brigade Marine",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27501,
		},
		[60158] = {
			["isChanneled"] = false,
			["source"] = "Azure Raider",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30668,
		},
		[7870] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Aezneth",
			["npcID"] = 1863,
		},
		[34186] = {
			["isChanneled"] = false,
			["source"] = "Illidari Taskmaster",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 17058,
		},
		[56707] = {
			["isChanneled"] = false,
			["source"] = "Plague Walker",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30283,
		},
		[13704] = {
			["isChanneled"] = false,
			["source"] = "Gold Priest",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32325,
		},
		[60029] = {
			["encounterName"] = "Jedoga Shadowseeker",
			["source"] = "Jedoga Shadowseeker",
			["encounterID"] = 214,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29310,
		},
		[65147] = {
			["isChanneled"] = false,
			["source"] = "Boneguard Commander",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 34127,
		},
		[17261] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Boar",
			["npcID"] = 3100,
		},
		[55040] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Mage Hunter Ascendant",
			["npcID"] = 26727,
		},
		[55104] = {
			["encounterName"] = "Moorabi",
			["source"] = "Moorabi",
			["encounterID"] = 387,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29305,
		},
		[67710] = {
			["encounterName"] = "Grand Champions",
			["type"] = "DEBUFF",
			["source"] = "Lana Stouthammer",
			["npcID"] = 34703,
			["event"] = "SPELL_AURA_APPLIED",
			["encounterID"] = 334,
		},
		[49091] = {
			["encounterName"] = "Skadi the Ruthless",
			["source"] = "Ymirjar Harpooner",
			["npcID"] = 26692,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 581,
		},
		[57616] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Crystalweb Spitter",
			["npcID"] = 29412,
		},
		[67701] = {
			["encounterName"] = "Grand Champions",
			["source"] = "Lana Stouthammer",
			["npcID"] = 34703,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 334,
		},
		[13864] = {
			["isChanneled"] = false,
			["source"] = "Shattered Hand Acolyte",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 19415,
		},
		[59134] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Ebon Blade Vindicator",
			["npcID"] = 32488,
		},
		[57599] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30621,
		},
		[70388] = {
			["encounterName"] = "Overlrod Tyrannus",
			["type"] = "DEBUFF",
			["source"] = "Wrathbone Sorcerer",
			["encounterID"] = 837,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 37728,
		},
		[53633] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Rampaging Abomination",
			["npcID"] = 29115,
		},
		[57791] = {
			["encounterName"] = "Herald Volazj",
			["type"] = "BUFF",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 30623,
		},
		[50661] = {
			["source"] = "Deathwhisper Necrolyte",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 36788,
		},
		[16460] = {
			["isChanneled"] = false,
			["source"] = "Plagued Insect",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10461,
		},
		[47748] = {
			["encounterName"] = "Anomalus",
			["source"] = "Anomalus",
			["npcID"] = 26763,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 522,
		},
		[12169] = {
			["isChanneled"] = false,
			["source"] = "Jlarborn the Strategist",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 24215,
		},
		[11977] = {
			["isChanneled"] = false,
			["source"] = "Victorious Challenger",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30012,
		},
		[49987] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Defendo-tank 66D",
			["npcID"] = 25758,
		},
		[33675] = {
			["isChanneled"] = false,
			["source"] = "Dread Tactician",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 16959,
		},
		[46202] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dark Rune Worker",
			["npcID"] = 27961,
		},
		[28168] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Raging Construct",
			["npcID"] = 27970,
		},
		[68939] = {
			["encounterName"] = "Devourer of Souls",
			["source"] = "Devourer of Souls",
			["encounterID"] = 831,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36502,
		},
		[68987] = {
			["encounterName"] = "Krick",
			["source"] = "Ick",
			["encounterID"] = 835,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36476,
		},
		[71157] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Plagued Zombie",
			["npcID"] = 38104,
		},
		[72435] = {
			["encounterName"] = "Falric",
			["source"] = "Falric",
			["encounterID"] = 841,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38112,
		},
		[56640] = {
			["isChanneled"] = false,
			["source"] = "Ahn'kahar Web Winder",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30276,
		},
		[66935] = {
			["encounterName"] = "Argent Champion",
			["source"] = "Eadric the Pure",
			["npcID"] = 35119,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 338,
		},
		[57984] = {
			["encounterName"] = "Forgemaster Garfrost",
			["source"] = "Greater Fire Elemental",
			["npcID"] = 15438,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 833,
		},
		[30471] = {
			["isChanneled"] = false,
			["source"] = "Savage Cave Beast",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30329,
		},
		[44795] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Fezzix Geartwist",
			["npcID"] = 25849,
		},
		[24394] = {
			["source"] = "Fabi",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 6498,
		},
		[68982] = {
			["encounterName"] = "Devourer of Souls",
			["source"] = "Devourer of Souls",
			["encounterID"] = 831,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36502,
		},
		[55041] = {
			["source"] = "Mage Hunter Ascendant",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 26727,
		},
		[69238] = {
			["encounterName"] = "Overlrod Tyrannus",
			["source"] = "Icy Blast",
			["encounterID"] = 837,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36731,
		},
		[61374] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Haiphoon, the Great Tempest",
			["npcID"] = 28999,
		},
		[49092] = {
			["encounterName"] = "Skadi the Ruthless",
			["source"] = "Ymirjar Harpooner",
			["npcID"] = 26692,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 581,
		},
		[34827] = {
			["isChanneled"] = false,
			["source"] = "Bloodscale Wavecaller",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 20089,
		},
		[16430] = {
			["isChanneled"] = false,
			["source"] = "Thuzadin Necromancer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10400,
		},
		[66044] = {
			["encounterName"] = "Grand Champions",
			["source"] = "Ambrose Boltspark",
			["npcID"] = 34702,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 334,
		},
		[3600] = {
			["isChanneled"] = false,
			["source"] = "Earthbind Totem",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 2630,
		},
		[8267] = {
			["source"] = "Rotting Agam'ar",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 4512,
		},
		[53570] = {
			["isChanneled"] = false,
			["source"] = "Disciple of Frost",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28490,
		},
		[58459] = {
			["isChanneled"] = false,
			["source"] = "Azure Invader",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31008,
		},
		[59839] = {
			["encounterName"] = "Slad'ran",
			["source"] = "Slad'ran",
			["encounterID"] = 383,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29304,
		},
		[49668] = {
			["encounterName"] = "Novos the Summoner",
			["source"] = "Crystal Handler",
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26627,
		},
		[61568] = {
			["isChanneled"] = false,
			["source"] = "Twilight Worshipper",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30111,
		},
		[55937] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Orinoko Tuskbreaker",
			["npcID"] = 30020,
		},
		[45658] = {
			["source"] = "Kvaldir Mist Binder",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 34839,
		},
		[52931] = {
			["isChanneled"] = false,
			["source"] = "Lafoo",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28120,
		},
		[27049] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Felix",
			["npcID"] = 822,
		},
		[70516] = {
			["encounterName"] = "Overlrod Tyrannus",
			["type"] = "DEBUFF",
			["source"] = "Freed Horde Slave",
			["encounterID"] = 837,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 37579,
		},
		[59455] = {
			["encounterName"] = "Drakkari Colossus",
			["type"] = "DEBUFF",
			["source"] = "Drakkari Colossus",
			["encounterID"] = 385,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 29307,
		},
		[39945] = {
			["isChanneled"] = false,
			["source"] = "Warsong Shaman",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27678,
		},
		[46150] = {
			["isChanneled"] = false,
			["source"] = "Bound Air Elemental",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30418,
		},
		[57976] = {
			["encounterName"] = "Ley-Guardian Eregos",
			["source"] = "Planar Anomaly",
			["encounterID"] = 534,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30879,
		},
		[48017] = {
			["encounterName"] = "Ormorok the Tree-Shaper",
			["source"] = "Ormorok the Tree-Shaper",
			["npcID"] = 26794,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 524,
		},
		[57807] = {
			["encounterName"] = "Herald Volazj",
			["type"] = "DEBUFF",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 30623,
		},
		[58688] = {
			["encounterName"] = "Cyanigosa",
			["source"] = "Cyanigosa",
			["encounterID"] = 545,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31134,
		},
		[52611] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Master Necromancer",
			["npcID"] = 27732,
		},
		[58816] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Infinite Agent",
			["npcID"] = 27744,
		},
		[28913] = {
			["isChanneled"] = false,
			["source"] = "Decaying Ghoul",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28565,
		},
		[54850] = {
			["encounterName"] = "Drakkari Colossus",
			["source"] = "Drakkari Colossus",
			["encounterID"] = 385,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29307,
		},
		[59008] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Sinewy Wolf",
			["npcID"] = 31233,
		},
		[29544] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Green Warrior",
			["npcID"] = 32321,
		},
		[17503] = {
			["isChanneled"] = false,
			["source"] = "Maleki the Pallid",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10438,
		},
		[55106] = {
			["encounterName"] = "Moorabi",
			["source"] = "Moorabi",
			["encounterID"] = 387,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29305,
		},
		[56130] = {
			["encounterName"] = "Elder Nadox",
			["source"] = "Elder Nadox",
			["encounterID"] = 212,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29309,
		},
		[61375] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Haiphoon, the Great Tempest",
			["npcID"] = 28999,
		},
		[70521] = {
			["isChanneled"] = false,
			["source"] = "Sindragosa",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 37755,
		},
		[23947] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Shadow Priestess Vandis",
			["npcID"] = 11055,
		},
		[61567] = {
			["isChanneled"] = false,
			["source"] = "Twilight Worshipper",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30111,
		},
		[27268] = {
			["source"] = "Unknown",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 416,
		},
		[66042] = {
			["encounterName"] = "Grand Champions",
			["source"] = "Ambrose Boltspark",
			["npcID"] = 34702,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 334,
		},
		[59987] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30622,
		},
		[60067] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Alliance Commander",
			["npcID"] = 27949,
		},
		[59840] = {
			["encounterName"] = "Slad'ran",
			["source"] = "Slad'ran",
			["encounterID"] = 383,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29304,
		},
		[19725] = {
			["isChanneled"] = false,
			["source"] = "Scarlet Preacher",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28939,
		},
		[67834] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Wormhole",
			["npcID"] = 35646,
		},
		[60032] = {
			["encounterName"] = "Jedoga Shadowseeker",
			["source"] = "Jedoga Shadowseeker",
			["encounterID"] = 214,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29310,
		},
		[32103] = {
			["isChanneled"] = false,
			["source"] = "Fordragon Marksman",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27540,
		},
		[51972] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Crystalline Tender",
			["npcID"] = 28231,
		},
		[67194] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Argent Priestess",
			["npcID"] = 35307,
		},
		[50053] = {
			["isChanneled"] = false,
			["source"] = "Varos Cloudstrider",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27447,
		},
		[67706] = {
			["encounterName"] = "Grand Champions",
			["source"] = "Lana Stouthammer",
			["npcID"] = 34703,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 334,
		},
		[42972] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dragonflayer Strategist",
			["npcID"] = 23956,
		},
		[69753] = {
			["isChanneled"] = false,
			["source"] = "Scourgelord Tyrannus",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36794,
		},
		[52356] = {
			["isChanneled"] = false,
			["source"] = "Dark Rider of Acherus",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28768,
		},
		[59372] = {
			["encounterName"] = "Varos Cloudstrider",
			["source"] = "Varos Cloudstrider",
			["encounterID"] = 530,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27447,
		},
		[66043] = {
			["encounterName"] = "Grand Champions",
			["source"] = "Ambrose Boltspark",
			["npcID"] = 34702,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 334,
		},
		[57601] = {
			["encounterName"] = "Herald Volazj",
			["type"] = "DEBUFF",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 30621,
		},
		[57602] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30623,
		},
		[58817] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Infinite Agent",
			["npcID"] = 28341,
		},
		[17467] = {
			["isChanneled"] = false,
			["source"] = "Baron Rivendare",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10440,
		},
		[56898] = {
			["isChanneled"] = false,
			["source"] = "Twilight Darkcaster",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30319,
		},
		[69263] = {
			["encounterName"] = "Krick",
			["source"] = "Ick",
			["encounterID"] = 835,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36476,
		},
		[44423] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Wintergarde Gryphon",
			["npcID"] = 28061,
		},
		[57090] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Wyrmrest Skytalon",
			["npcID"] = 32535,
		},
		[56920] = {
			["isChanneled"] = false,
			["source"] = "Alliance Cleric",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26805,
		},
		[20812] = {
			["isChanneled"] = false,
			["source"] = "Dark Necromancer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28200,
		},
		[61376] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Haiphoon, the Great Tempest",
			["npcID"] = 28999,
		},
		[57457] = {
			["source"] = "Cat",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 3619,
		},
		[16431] = {
			["isChanneled"] = false,
			["source"] = "Thuzadin Necromancer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10400,
		},
		[67835] = {
			["isChanneled"] = false,
			["source"] = "Wormhole",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 35646,
		},
		[60030] = {
			["encounterName"] = "Jedoga Shadowseeker",
			["source"] = "Jedoga Shadowseeker",
			["encounterID"] = 214,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29310,
		},
		[37132] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Azure Magus",
			["npcID"] = 26722,
		},
		[41290] = {
			["isChanneled"] = false,
			["source"] = "Lorien Sunblaze",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 33455,
		},
		[387764] = {
			["isChanneled"] = false,
			["source"] = "Pebble",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 194870,
		},
		[57088] = {
			["encounterName"] = "Amanitar",
			["source"] = "Amanitar",
			["encounterID"] = 1989,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30258,
		},
		[15496] = {
			["isChanneled"] = false,
			["source"] = "Skeletal Berserker",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10391,
		},
		[59885] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Giz",
			["npcID"] = 682,
		},
		[47751] = {
			["encounterName"] = "Anomalus",
			["source"] = "Anomalus",
			["npcID"] = 26763,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 522,
		},
		[66940] = {
			["encounterName"] = "Argent Champion",
			["type"] = "DEBUFF",
			["source"] = "Eadric the Pure",
			["npcID"] = 35119,
			["event"] = "SPELL_AURA_APPLIED",
			["encounterID"] = 338,
		},
		[39171] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Azure Enforcer",
			["npcID"] = 26734,
		},
		[27050] = {
			["isChanneled"] = false,
			["source"] = "Snuffles",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 4512,
		},
		[42472] = {
			["source"] = "Dragonflayer Raider",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 23557,
		},
		[3436] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Plague Lurker",
			["npcID"] = 1824,
		},
		[50182] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Mage Hunter Ascendant",
			["npcID"] = 26727,
		},
		[35917] = {
			["isChanneled"] = false,
			["source"] = "Marisalira",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30254,
		},
		[67836] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Wormhole",
			["npcID"] = 35646,
		},
		[43270] = {
			["isChanneled"] = false,
			["source"] = "Iron Rune Binder",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 23796,
		},
		[66045] = {
			["encounterName"] = "Grand Champions",
			["source"] = "Ambrose Boltspark",
			["npcID"] = 34702,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 334,
		},
		[56643] = {
			["isChanneled"] = false,
			["source"] = "Ahn'kahar Watcher",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31104,
		},
		[29385] = {
			["isChanneled"] = false,
			["source"] = "Green Paladin",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32342,
		},
		[48583] = {
			["encounterName"] = "Skarvold & Dalronn",
			["source"] = "Skarvald the Constructor",
			["npcID"] = 24200,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 573,
		},
		[68340] = {
			["encounterName"] = "Grand Champions",
			["source"] = "Jaelyne Evensong",
			["encounterID"] = 334,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 34657,
		},
		[55704] = {
			["isChanneled"] = false,
			["source"] = "Earthen Warder",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29981,
		},
		[54916] = {
			["isChanneled"] = false,
			["source"] = "Sparktouched Oracle",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28112,
		},
		[68988] = {
			["encounterName"] = "Bronjahm",
			["source"] = "Bronjahm",
			["encounterID"] = 829,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36497,
		},
		[29577] = {
			["isChanneled"] = false,
			["source"] = "Longneck Grazer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28129,
		},
		[59261] = {
			["encounterName"] = "Mage-Lord Urom",
			["source"] = "Phantasmal Naga",
			["encounterID"] = 532,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27648,
		},
		[59266] = {
			["encounterName"] = "Mage-Lord Urom",
			["source"] = "Phantasmal Water",
			["encounterID"] = 532,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27653,
		},
		[58813] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Infinite Adversary",
			["npcID"] = 27742,
		},
		[47747] = {
			["encounterName"] = "Anomalus",
			["source"] = "Anomalus",
			["npcID"] = 26763,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 522,
		},
		[67709] = {
			["encounterName"] = "Grand Champions",
			["source"] = "Lana Stouthammer",
			["npcID"] = 34703,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 334,
		},
		[57475] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Wolf",
			["npcID"] = 8959,
		},
		[7966] = {
			["isChanneled"] = false,
			["source"] = "Razorfen Thornweaver",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 7874,
		},
		[57108] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Wyrmrest Skytalon",
			["npcID"] = 32535,
		},
		[52708] = {
			["encounterName"] = "Salram the Fleshcrafter",
			["source"] = "Salramm the Fleshcrafter",
			["npcID"] = 26530,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 294,
		},
		[47496] = {
			["isChanneled"] = false,
			["source"] = "Stonebasher",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26125,
		},
		[59842] = {
			["encounterName"] = "Slad'ran",
			["source"] = "Slad'ran",
			["encounterID"] = 383,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29304,
		},
		[45577] = {
			["isChanneled"] = false,
			["source"] = "Nerub'ar Corpse Harvester",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 25445,
		},
		[47688] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Chaotic Rift",
			["npcID"] = 26918,
		},
		[33423] = {
			["isChanneled"] = false,
			["source"] = "Kurenai Pitfighter",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 19141,
		},
		[49863] = {
			["isChanneled"] = false,
			["source"] = "North Fleet Sailor",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 23866,
		},
		[23948] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Shadow Priestess Vandis",
			["npcID"] = 11055,
		},
		[69245] = {
			["encounterName"] = "Overlrod Tyrannus",
			["type"] = "DEBUFF",
			["source"] = "Rimefang",
			["encounterID"] = 837,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 36661,
		},
		[57066] = {
			["encounterName"] = "Ormorok the Tree-Shaper",
			["source"] = "Ormorok the Tree-Shaper",
			["encounterID"] = 524,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26794,
		},
		[59382] = {
			["encounterName"] = "Ley-Guardian Eregos",
			["source"] = "Ley-Guardian Eregos",
			["encounterID"] = 534,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27656,
		},
		[15620] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Darnassian Archer",
			["npcID"] = 18965,
		},
		[8078] = {
			["isChanneled"] = false,
			["source"] = "Lord Klaq",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 18282,
		},
		[52358] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Soo-holu",
			["npcID"] = 28115,
		},
		[31601] = {
			["isChanneled"] = false,
			["source"] = "Crypt Crawler",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10412,
		},
		[66047] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Knight of the Ebon Blade",
			["npcID"] = 38505,
		},
		[33395] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Water Elemental",
			["npcID"] = 510,
		},
		[50047] = {
			["source"] = "Grizzlesnout",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 27523,
		},
		[66862] = {
			["encounterName"] = "Argent Champion",
			["type"] = "DEBUFF",
			["source"] = "Eadric the Pure",
			["npcID"] = 35119,
			["event"] = "SPELL_AURA_APPLIED",
			["encounterID"] = 338,
		},
		[51503] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dark Rune Controller",
			["npcID"] = 27966,
		},
		[59370] = {
			["encounterName"] = "Drakos the Interrogator",
			["source"] = "Drakos the Interrogator",
			["encounterID"] = 528,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27654,
		},
		[52870] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Haiphoon, the Great Tempest",
			["npcID"] = 28999,
		},
		[59026] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dark Rune Giant",
			["npcID"] = 27969,
		},
		[63233] = {
			["isChanneled"] = false,
			["source"] = "Boneguard Scout",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 33550,
		},
		[69246] = {
			["encounterName"] = "Overlrod Tyrannus",
			["source"] = "Rimefang",
			["encounterID"] = 837,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36661,
		},
		[32712] = {
			["isChanneled"] = false,
			["source"] = "Scourge Banner-Bearer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31900,
		},
		[59331] = {
			["encounterName"] = "Skadi the Ruthless",
			["source"] = "Skadi the Ruthless",
			["npcID"] = 26693,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 581,
		},
		[35010] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dark Rune Theurgist",
			["npcID"] = 27963,
		},
		[43083] = {
			["isChanneled"] = false,
			["source"] = "Winterskorn Rune-Seer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 23667,
		},
		[61570] = {
			["isChanneled"] = false,
			["source"] = "Twilight Apostle",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30179,
		},
		[51399] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Ebon Blade Vindicator",
			["npcID"] = 32488,
		},
		[59651] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Chief Engineer Boltwrench",
			["npcID"] = 30345,
		},
		[35361] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Grove Walker",
			["npcID"] = 31228,
		},
		[16592] = {
			["isChanneled"] = false,
			["source"] = "Kil'sorrow Cultist",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 17147,
		},
		[8316] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Unknown",
			["npcID"] = 416,
		},
		[55813] = {
			["encounterName"] = "Eck the Ferocious",
			["source"] = "Eck the Ferocious",
			["encounterID"] = 1988,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29932,
		},
		[3010] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Bear",
			["npcID"] = 1186,
		},
		[33424] = {
			["isChanneled"] = false,
			["source"] = "Kurenai Pitfighter",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 19141,
		},
		[40505] = {
			["isChanneled"] = false,
			["source"] = "Plague Ghoul",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10405,
		},
		[55931] = {
			["encounterName"] = "Prince Taldaram",
			["source"] = "Prince Taldaram",
			["encounterID"] = 213,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29308,
		},
		[60227] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dragonflayer Strategist",
			["npcID"] = 23956,
		},
		[69586] = {
			["isChanneled"] = false,
			["source"] = "Ymirjar Flamebearer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36893,
		},
		[69503] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Geist Ambusher",
			["npcID"] = 36886,
		},
		[35199] = {
			["encounterName"] = "Overlrod Tyrannus",
			["source"] = "Freed Horde Slave",
			["encounterID"] = 837,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 37578,
		},
		[66798] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "The Black Knight",
			["npcID"] = 35451,
		},
		[59637] = {
			["encounterName"] = "Varos Cloudstrider",
			["source"] = "Mirror Image",
			["encounterID"] = 530,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31216,
		},
		[15971] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Hyldsmeet Warbear",
			["npcID"] = 30174,
		},
		[25228] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Krimkazul",
			["npcID"] = 17252,
		},
		[50504] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Arcane Serpent",
			["npcID"] = 25721,
		},
		[29386] = {
			["isChanneled"] = false,
			["source"] = "Green Paladin",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32342,
		},
		[58820] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Infinite Hunter",
			["npcID"] = 28340,
		},
		[59845] = {
			["encounterName"] = "Sjonnir the Ironshaper",
			["source"] = "Sjonnir The Ironshaper",
			["npcID"] = 27978,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 569,
		},
		[56827] = {
			["isChanneled"] = false,
			["source"] = "Mage Hunter Ascendant",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26727,
		},
		[11640] = {
			["isChanneled"] = false,
			["source"] = "Gold Priest",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32325,
		},
		[72898] = {
			["isChanneled"] = false,
			["source"] = "Water Elemental",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 37994,
		},
		[12746] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Wastewander Shadow Mage",
			["npcID"] = 5617,
		},
		[38556] = {
			["isChanneled"] = false,
			["source"] = "Darkspear Spear Thrower",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27560,
		},
		[57061] = {
			["encounterName"] = "Amanitar",
			["source"] = "Poisonous Mushroom",
			["encounterID"] = 1989,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30435,
		},
		[69504] = {
			["isChanneled"] = false,
			["source"] = "Geist Ambusher",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36886,
		},
		[48894] = {
			["isChanneled"] = false,
			["source"] = "Drakkari Shaman",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26639,
		},
		[51272] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Frostbrood Vanquisher",
			["npcID"] = 28670,
		},
		[51336] = {
			["encounterName"] = "Drakos the Interrogator",
			["source"] = "Drakos the Interrogator",
			["encounterID"] = 528,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27654,
		},
		[68501] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Argent Battleworg",
			["npcID"] = 36558,
		},
		[14921] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Boar",
			["npcID"] = 3100,
		},
		[53575] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Rushey",
			["npcID"] = 4248,
		},
		[15982] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Torgg Thundertotem",
			["npcID"] = 27716,
		},
		[59844] = {
			["encounterName"] = "Sjonnir the Ironshaper",
			["source"] = "Sjonnir The Ironshaper",
			["npcID"] = 27978,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 569,
		},
		[32009] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Fel Soldier",
			["npcID"] = 18944,
		},
		[6479] = {
			["isChanneled"] = false,
			["source"] = "Razormane Hunter",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 3265,
		},
		[33425] = {
			["isChanneled"] = false,
			["source"] = "Kurenai Pitfighter",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 19141,
		},
		[35011] = {
			["isChanneled"] = false,
			["source"] = "Scourge Brute",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26623,
		},
		[50583] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Coldarra Spellbinder",
			["npcID"] = 25719,
		},
		[22273] = {
			["isChanneled"] = false,
			["source"] = "Arcanist Torseldori",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 19257,
		},
		[59225] = {
			["encounterName"] = "Mage-Lord Urom",
			["source"] = "Phantasmal Fire",
			["encounterID"] = 532,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27651,
		},
		[59114] = {
			["isChanneled"] = false,
			["source"] = "Plundering Geist",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30287,
		},
		[69633] = {
			["isChanneled"] = false,
			["source"] = "Spectral Warden",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36666,
		},
		[68504] = {
			["encounterName"] = "Grand Champions",
			["source"] = "Marshal Jacob Alerius",
			["npcID"] = 34705,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 334,
		},
		[45528] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Wind Tamer Oril",
			["npcID"] = 26725,
		},
		[32610] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Horde Field Scout",
			["npcID"] = 18564,
		},
		[70145] = {
			["encounterName"] = "Escaped from Arthas",
			["source"] = "Risen Witch Doctor",
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36941,
		},
		[58693] = {
			["encounterName"] = "Cyanigosa",
			["source"] = "Cyanigosa",
			["encounterID"] = 545,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31134,
		},
		[56710] = {
			["source"] = "Plague Walker",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 30283,
		},
		[43562] = {
			["isChanneled"] = false,
			["source"] = "Glacion",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 24019,
		},
		[57799] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30622,
		},
		[10722] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Centipaar Swarmer",
			["npcID"] = 5457,
		},
		[53434] = {
			["encounterName"] = "Forgemaster Garfrost",
			["source"] = "Wolfgang",
			["encounterID"] = 833,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 17669,
		},
		[27269] = {
			["source"] = "Unknown",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 416,
		},
		[57094] = {
			["encounterName"] = "Amanitar",
			["source"] = "Amanitar",
			["encounterID"] = 1989,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30258,
		},
		[59024] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dark Rune Elementalist",
			["npcID"] = 27962,
		},
		[59269] = {
			["encounterName"] = "Mage-Lord Urom",
			["source"] = "Phantasmal Wolf",
			["encounterID"] = 532,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27644,
		},
		[15716] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Decomposed Ghoul",
			["npcID"] = 31812,
		},
		[59397] = {
			["encounterName"] = "Prince Keleseth",
			["source"] = "Vrykul Skeleton",
			["npcID"] = 23970,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 571,
		},
		[13338] = {
			["isChanneled"] = false,
			["source"] = "Twilight Darkcaster",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30319,
		},
		[63619] = {
			["isChanneled"] = false,
			["source"] = "Shadowfiend",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 19668,
		},
		[54053] = {
			["isChanneled"] = false,
			["source"] = "Czaadom",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 417,
		},
		[55633] = {
			["encounterName"] = "Drakkari Colossus",
			["source"] = "Drakkari Golem",
			["encounterID"] = 385,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29832,
		},
		[72321] = {
			["isChanneled"] = false,
			["source"] = "Ghostly Priest",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38175,
		},
		[36589] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Sinewy Wolf",
			["npcID"] = 31233,
		},
		[57798] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30625,
		},
		[55815] = {
			["encounterName"] = "Eck the Ferocious",
			["source"] = "Eck the Ferocious",
			["encounterID"] = 1988,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29932,
		},
		[66865] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Eadric the Pure",
			["npcID"] = 35119,
		},
		[424340] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Greater Fire Elemental",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 15438,
		},
		[55798] = {
			["isChanneled"] = false,
			["source"] = "Drakkari God Hunter",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29820,
		},
		[33554] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Justinius the Harbinger",
			["npcID"] = 18966,
		},
		[47737] = {
			["encounterName"] = "Anomalus",
			["source"] = "Chaotic Rift",
			["npcID"] = 26918,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 522,
		},
		[48011] = {
			["encounterName"] = "Forgemaster Garfrost",
			["source"] = "Thooghun",
			["npcID"] = 417,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 833,
		},
		[55860] = {
			["isChanneled"] = false,
			["source"] = "Shoveltusk Stag",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 23691,
		},
		[61685] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Boar",
			["npcID"] = 3100,
		},
		[58438] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Unbound Trickster",
			["npcID"] = 30856,
		},
		[24450] = {
			["source"] = "Unknown",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 17202,
		},
		[9532] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dustbelcher Shaman",
			["npcID"] = 2718,
		},
		[72194] = {
			["isChanneled"] = false,
			["source"] = "Spectral Footman",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38173,
		},
		[56647] = {
			["source"] = "Seething Revenant",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 30387,
		},
		[17105] = {
			["isChanneled"] = false,
			["source"] = "Wailing Banshee",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10464,
		},
		[56775] = {
			["isChanneled"] = false,
			["source"] = "Azure Magus",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26722,
		},
		[34322] = {
			["isChanneled"] = false,
			["source"] = "Forgotten One",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30414,
		},
		[34386] = {
			["isChanneled"] = false,
			["source"] = "Zeth'Gor Quest Credit Marker, West Hovel",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 20816,
		},
		[13738] = {
			["isChanneled"] = false,
			["source"] = "Fleshflayer Ghoul",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10407,
		},
		[15801] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Lesser Air Elemental",
			["npcID"] = 28384,
		},
		[57095] = {
			["encounterName"] = "Amanitar",
			["source"] = "Amanitar",
			["encounterID"] = 1989,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30258,
		},
		[52537] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["type"] = "BUFF",
			["source"] = "Magma Totem VI",
			["encounterID"] = 216,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 31166,
		},
		[58966] = {
			["isChanneled"] = false,
			["source"] = "Drakkari Battle Rider",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29836,
		},
		[17393] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Baron Rivendare",
			["npcID"] = 29109,
		},
		[13903] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Ironforge Paladin",
			["npcID"] = 18986,
		},
		[32851] = {
			["source"] = "Ikzilgoril",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 17252,
		},
		[32915] = {
			["isChanneled"] = false,
			["source"] = "Scarlet Marksman",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28610,
		},
		[61044] = {
			["isChanneled"] = false,
			["source"] = "Fallen Warrior",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36841,
		},
		[58667] = {
			["isChanneled"] = false,
			["source"] = "Unbound Seer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 33422,
		},
		[16553] = {
			["isChanneled"] = false,
			["source"] = "Ghoul Ravener",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10406,
		},
		[55095] = {
			["source"] = "Rune Weapon",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 27893,
		},
		[59846] = {
			["encounterName"] = "Sjonnir the Ironshaper",
			["source"] = "Sjonnir The Ironshaper",
			["npcID"] = 27978,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 569,
		},
		[53769] = {
			["isChanneled"] = false,
			["source"] = "Lady Alistra",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28471,
		},
		[59974] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Herald Volazj",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29311,
		},
		[49637] = {
			["encounterName"] = "Trollgore",
			["source"] = "Trollgore",
			["encounterID"] = 369,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26630,
		},
		[6589] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Centipaar Swarmer",
			["npcID"] = 5457,
		},
		[35230] = {
			["isChanneled"] = false,
			["source"] = "Sporeggar Spawn",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 18358,
		},
		[67251] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Argent Monk",
			["npcID"] = 35305,
		},
		[49198] = {
			["isChanneled"] = false,
			["source"] = "Novos the Summoner",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26631,
		},
		[48058] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Crystalline Frayer",
			["npcID"] = 26793,
		},
		[59347] = {
			["isChanneled"] = false,
			["source"] = "Anub'ar Crypt Fiend",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29051,
		},
		[67718] = {
			["encounterName"] = "The Black Knight",
			["source"] = "The Black Knight",
			["npcID"] = 35451,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 340,
		},
		[32330] = {
			["isChanneled"] = false,
			["source"] = "Venomtip",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28358,
		},
		[56520] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Freed Crusader",
			["npcID"] = 30274,
		},
		[60678] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Plague Drenched Ghoul",
			["npcID"] = 32176,
		},
		[56648] = {
			["encounterName"] = "Amanitar",
			["source"] = "Healthy Mushroom",
			["encounterID"] = 1989,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30391,
		},
		[59444] = {
			["encounterName"] = "Moorabi",
			["source"] = "Moorabi",
			["encounterID"] = 387,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29305,
		},
		[58823] = {
			["encounterName"] = "Meathook",
			["source"] = "Meathook",
			["npcID"] = 26529,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 293,
		},
		[56778] = {
			["isChanneled"] = false,
			["source"] = "Azure Warder",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26716,
		},
		[57640] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30625,
		},
		[67808] = {
			["encounterName"] = "The Black Knight",
			["source"] = "The Black Knight",
			["npcID"] = 35451,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 340,
		},
		[59079] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dragonflayer Deathseeker",
			["npcID"] = 26550,
		},
		[53394] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Anub'ar Champion",
			["encounterID"] = 216,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29062,
		},
		[16345] = {
			["isChanneled"] = false,
			["source"] = "Patchwork Horror",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10414,
		},
		[32714] = {
			["isChanneled"] = false,
			["source"] = "Ahn'kahar Slasher",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30277,
		},
		[22885] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Melgromm Highmountain",
			["npcID"] = 18969,
		},
		[58980] = {
			["isChanneled"] = false,
			["source"] = "Drakkari Medicine Man",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29826,
		},
		[53322] = {
			["isChanneled"] = false,
			["source"] = "Anub'ar Crypt Fiend",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29118,
		},
		[49264] = {
			["isChanneled"] = false,
			["source"] = "Wyrmrest Defender",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27629,
		},
		[49356] = {
			["encounterName"] = "The Prophet Tharon'ja",
			["source"] = "The Prophet Tharon'ja",
			["encounterID"] = 375,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26632,
		},
		[70150] = {
			["encounterName"] = "Escaped from Arthas",
			["source"] = "Raging Ghoul",
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36940,
		},
		[70278] = {
			["isChanneled"] = false,
			["source"] = "Wrathbone Laborer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36830,
		},
		[49548] = {
			["encounterName"] = "The Prophet Tharon'ja",
			["source"] = "The Prophet Tharon'ja",
			["encounterID"] = 375,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26632,
		},
		[8317] = {
			["source"] = "Unknown",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 416,
		},
		[58967] = {
			["isChanneled"] = false,
			["source"] = "Drakkari Battle Rider",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29836,
		},
		[59975] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Herald Volazj",
			["encounterID"] = 215,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29311,
		},
		[33663] = {
			["encounterName"] = "Overlrod Tyrannus",
			["source"] = "Earth Elemental Totem",
			["encounterID"] = 837,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 15430,
		},
		[33132] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Corrupted Nova Totem",
			["npcID"] = 18179,
		},
		[56926] = {
			["encounterName"] = "Jedoga Shadowseeker",
			["source"] = "Jedoga Shadowseeker",
			["encounterID"] = 214,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29310,
		},
		[5232] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Disciple of Naralex",
			["npcID"] = 3678,
		},
		[48873] = {
			["encounterName"] = "King Dred",
			["source"] = "King Dred",
			["encounterID"] = 373,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27483,
		},
		[51876] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Stormrider",
			["npcID"] = 29624,
		},
		[54282] = {
			["isChanneled"] = false,
			["source"] = "Lavanthor",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29312,
		},
		[54314] = {
			["isChanneled"] = false,
			["source"] = "Anub'ar Prime Guard",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29128,
		},
		[58504] = {
			["isChanneled"] = false,
			["source"] = "Portal Guardian",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30660,
		},
		[56521] = {
			["source"] = "Freed Crusader",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 30274,
		},
		[52491] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Crypt Fiend",
			["npcID"] = 27734,
		},
		[31403] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Alliance Commander",
			["npcID"] = 27949,
		},
		[50572] = {
			["isChanneled"] = false,
			["source"] = "Azure Spellbinder",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27635,
		},
		[58824] = {
			["encounterName"] = "Meathook",
			["source"] = "Meathook",
			["npcID"] = 26529,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 293,
		},
		[55959] = {
			["encounterName"] = "Prince Taldaram",
			["source"] = "Prince Taldaram",
			["encounterID"] = 213,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29308,
		},
		[67541] = {
			["encounterName"] = "Grand Champions",
			["source"] = "Marshal Jacob Alerius",
			["npcID"] = 34705,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 334,
		},
		[17234] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Acolyte",
			["npcID"] = 27731,
		},
		[35735] = {
			["isChanneled"] = false,
			["source"] = "Bound Water Elemental",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30419,
		},
		[69128] = {
			["isChanneled"] = false,
			["source"] = "Soulguard Animator",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36516,
		},
		[59208] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Restless Lookout",
			["npcID"] = 31554,
		},
		[49037] = {
			["encounterName"] = "Novos the Summoner",
			["source"] = "Novos the Summoner",
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26631,
		},
		[50933] = {
			["isChanneled"] = false,
			["source"] = "Flesheating Ghoul",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27871,
		},
		[67749] = {
			["encounterName"] = "The Black Knight",
			["source"] = "Risen Jaeren Sunsworn",
			["npcID"] = 35545,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 340,
		},
		[22686] = {
			["encounterName"] = "King Dred",
			["source"] = "King Dred",
			["encounterID"] = 373,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27483,
		},
		[47781] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Steward",
			["npcID"] = 26729,
		},
		[25710] = {
			["isChanneled"] = false,
			["source"] = "Conquest Hold Marauder",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27424,
		},
		[53515] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Unknown",
			["npcID"] = 22123,
		},
		[57825] = {
			["isChanneled"] = false,
			["source"] = "Frostbringer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30286,
		},
		[52723] = {
			["encounterName"] = "Mal'ganis",
			["source"] = "Mal'Ganis",
			["npcID"] = 26533,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 296,
		},
		[59726] = {
			["encounterName"] = "Maiden of Grief",
			["source"] = "Maiden of Grief",
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27975,
		},
		[58526] = {
			["isChanneled"] = false,
			["source"] = "Portal Guardian",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30892,
		},
		[58469] = {
			["isChanneled"] = false,
			["source"] = "Azure Mage Slayer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31010,
		},
		[55946] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Orinoko Tuskbreaker",
			["npcID"] = 30020,
		},
		[59744] = {
			["encounterName"] = "Krystallus",
			["source"] = "Krystallus",
			["npcID"] = 27977,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 563,
		},
		[58517] = {
			["isChanneled"] = false,
			["source"] = "Portal Guardian",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30892,
		},
		[53463] = {
			["encounterName"] = "The Prophet Tharon'ja",
			["source"] = "The Prophet Tharon'ja",
			["encounterID"] = 375,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26632,
		},
		[8996] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dark Iron Rifleman",
			["npcID"] = 6523,
		},
		[58516] = {
			["isChanneled"] = false,
			["source"] = "Portal Guardian",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30892,
		},
		[67594] = {
			["encounterName"] = "Grand Champions",
			["type"] = "DEBUFF",
			["source"] = "Lana Stouthammer",
			["npcID"] = 34703,
			["event"] = "SPELL_AURA_APPLIED",
			["encounterID"] = 334,
		},
		[67722] = {
			["encounterName"] = "The Black Knight",
			["type"] = "DEBUFF",
			["source"] = "The Black Knight",
			["npcID"] = 35451,
			["event"] = "SPELL_AURA_APPLIED",
			["encounterID"] = 340,
		},
		[50100] = {
			["isChanneled"] = false,
			["source"] = "Storm Giant",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 24812,
		},
		[54475] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Rampaging Ghoul",
			["npcID"] = 32178,
		},
		[23600] = {
			["isChanneled"] = false,
			["source"] = "Gold Warrior",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 32322,
		},
		[9053] = {
			["isChanneled"] = false,
			["source"] = "Flamewaker Imp",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 19136,
		},
		[50573] = {
			["isChanneled"] = false,
			["source"] = "Azure Inquisitor",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27633,
		},
		[60872] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Intrepid Ghoul",
			["npcID"] = 31015,
		},
		[42648] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Warsong Peon",
			["npcID"] = 27558,
		},
		[53582] = {
			["isChanneled"] = false,
			["source"] = "Raptor",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 3122,
		},
		[32587] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Argent Shieldman",
			["npcID"] = 28028,
		},
		[59081] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dragonflayer Seer",
			["npcID"] = 26554,
		},
		[69130] = {
			["source"] = "Soulguard Animator",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 36516,
		},
		[59209] = {
			["isChanneled"] = false,
			["source"] = "Azure Inquisitor",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27633,
		},
		[28405] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Pustulent Horror",
			["npcID"] = 31139,
		},
		[56936] = {
			["encounterName"] = "Grand Magus Telestra",
			["source"] = "Grand Magus Telestra",
			["encounterID"] = 520,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26930,
		},
		[13323] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Mage Hunter Ascendant",
			["npcID"] = 26727,
		},
		[59465] = {
			["encounterName"] = "Elder Nadox",
			["source"] = "Elder Nadox",
			["encounterID"] = 212,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29309,
		},
		[57482] = {
			["source"] = "Cat",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 3619,
		},
		[32982] = {
			["encounterName"] = "Forgemaster Garfrost",
			["source"] = "Fire Elemental Totem",
			["npcID"] = 15439,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 833,
		},
		[57452] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Unknown",
			["npcID"] = 3619,
		},
		[72329] = {
			["isChanneled"] = false,
			["source"] = "Shadowy Mercenary",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38177,
		},
		[53425] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Harold Lane",
			["npcID"] = 25804,
		},
		[59849] = {
			["encounterName"] = "Sjonnir the Ironshaper",
			["type"] = "DEBUFF",
			["source"] = "Sjonnir The Ironshaper",
			["npcID"] = 27978,
			["event"] = "SPELL_AURA_APPLIED",
			["encounterID"] = 569,
		},
		[49678] = {
			["isChanneled"] = false,
			["source"] = "Ghoul Tormentor",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26621,
		},
		[49742] = {
			["isChanneled"] = false,
			["source"] = "Rampaging Earth Elemental",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 24340,
		},
		[15530] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Azure Magus",
			["npcID"] = 26722,
		},
		[18802] = {
			["isChanneled"] = false,
			["source"] = "Forsaken Crossbowman",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 23883,
		},
		[69131] = {
			["isChanneled"] = false,
			["source"] = "Soulguard Animator",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 36516,
		},
		[15578] = {
			["isChanneled"] = false,
			["source"] = "Frenzyheart Ravager",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28078,
		},
		[38240] = {
			["source"] = "Wandering Shadow",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 30842,
		},
		[61578] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Converted Hero",
			["npcID"] = 32255,
		},
		[59366] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Watcher Silthik",
			["encounterID"] = 216,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28731,
		},
		[67724] = {
			["encounterName"] = "The Black Knight",
			["source"] = "The Black Knight",
			["npcID"] = 35451,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 340,
		},
		[58506] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Brann Bronzebeard",
			["npcID"] = 28070,
		},
		[54476] = {
			["source"] = "Shadow Vault Gryphon",
			["type"] = "BUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 30335,
		},
		[52493] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Watcher Silthik",
			["encounterID"] = 216,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28731,
		},
		[6660] = {
			["isChanneled"] = false,
			["source"] = "Wavecrest Mariner",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 35098,
		},
		[58762] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "BUFF",
			["source"] = "Devouring Ghoul",
			["npcID"] = 28249,
		},
		[60873] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Intrepid Ghoul",
			["npcID"] = 31015,
		},
		[9613] = {
			["isChanneled"] = false,
			["source"] = "Skeletal Guardian",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10390,
		},
		[72208] = {
			["isChanneled"] = false,
			["source"] = "Tortured Rifleman",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38176,
		},
		[17235] = {
			["isChanneled"] = false,
			["source"] = "Nerub'enkan",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 10437,
		},
		[59082] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dragonflayer Seer",
			["npcID"] = 26554,
		},
		[59146] = {
			["isChanneled"] = false,
			["source"] = "Drakkari God Hunter",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29820,
		},
		[59210] = {
			["isChanneled"] = false,
			["source"] = "Azure Ley-Whelp",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27636,
		},
		[59274] = {
			["encounterName"] = "Mage-Lord Urom",
			["source"] = "Phantasmal Wolf",
			["encounterID"] = 532,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27644,
		},
		[61385] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Harold Lane",
			["npcID"] = 25804,
		},
		[35944] = {
			["encounterName"] = "Frozen Commander",
			["source"] = "Alliance Cleric",
			["encounterID"] = 519,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 26805,
		},
		[61513] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Unrelenting Construct",
			["npcID"] = 27971,
		},
		[32919] = {
			["isChanneled"] = false,
			["source"] = "Sinewy Wolf",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 31233,
		},
		[57547] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Val'kyr Battle-maiden",
			["npcID"] = 31095,
		},
		[72203] = {
			["isChanneled"] = false,
			["source"] = "Spectral Footman",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 38173,
		},
		[53581] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Turok",
			["npcID"] = 6505,
		},
		[43410] = {
			["isChanneled"] = false,
			["source"] = "Kvaldir Berserker",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 34947,
		},
		[27060] = {
			["event"] = "SPELL_AURA_APPLIED",
			["type"] = "DEBUFF",
			["source"] = "Unknown",
			["npcID"] = 3281,
		},
		[50341] = {
			["encounterName"] = "Ley-Guardian Eregos",
			["source"] = "Emerald Drake",
			["encounterID"] = 534,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 27692,
		},
		[47696] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Crazed Mana-Surge",
			["npcID"] = 26737,
		},
		[55948] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Korrak the Bloodrager",
			["npcID"] = 30023,
		},
		[51918] = {
			["isChanneled"] = false,
			["source"] = "Val'kyr Battle-maiden",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28534,
		},
		[54029] = {
			["source"] = "Sunreaver Guardian Mage",
			["type"] = "DEBUFF",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 29255,
		},
		[58187] = {
			["isChanneled"] = false,
			["source"] = "Unbound Corrupter",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30868,
		},
		[48016] = {
			["encounterName"] = "Ormorok the Tree-Shaper",
			["source"] = "Ormorok the Tree-Shaper",
			["npcID"] = 26794,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 524,
		},
		[6016] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Rampaging Ghoul",
			["npcID"] = 32178,
		},
		[52331] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Soo-holu",
			["npcID"] = 28115,
		},
		[52836] = {
			["isChanneled"] = false,
			["source"] = "Scarlet Lord Borugh",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 28964,
		},
		[42131] = {
			["isChanneled"] = false,
			["source"] = "Forsaken Crossbowman",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 23883,
		},
		[53278] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Volatile Ghoul",
			["npcID"] = 29136,
		},
		[48400] = {
			["encounterName"] = "Prince Keleseth",
			["type"] = "DEBUFF",
			["source"] = "Frost Tomb",
			["npcID"] = 23965,
			["event"] = "SPELL_AURA_APPLIED",
			["encounterID"] = 571,
		},
		[54226] = {
			["isChanneled"] = false,
			["source"] = "Xevozz",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29266,
		},
		[56716] = {
			["isChanneled"] = false,
			["source"] = "Frostbringer",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 30286,
		},
		[58827] = {
			["encounterName"] = "Salram the Fleshcrafter",
			["source"] = "Salramm the Fleshcrafter",
			["npcID"] = 26530,
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["encounterID"] = 294,
		},
		[33462] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Stormwind Mage",
			["npcID"] = 18949,
		},
		[33570] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Melgromm Highmountain",
			["npcID"] = 18969,
		},
		[59019] = {
			["isChanneled"] = false,
			["source"] = "Spitting Cobra",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 29774,
		},
		[59083] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Dragonflayer Seer",
			["npcID"] = 26554,
		},
		[35998] = {
			["isChanneled"] = false,
			["event"] = "SPELL_CAST_SUCCESS",
			["source"] = "Forward Commander To'arch",
			["npcID"] = 19273,
		},
	},
	["captured_casts"] = {
		[48096] = {
			["encounterName"] = "Keristrasza",
			["source"] = "Keristrasza",
			["npcID"] = 26723,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 526,
		},
		[59370] = {
			["encounterName"] = "Drakos the Interrogator",
			["source"] = "Drakos the Interrogator",
			["encounterID"] = 528,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27654,
		},
		[66043] = {
			["encounterName"] = "Grand Champions",
			["source"] = "Ambrose Boltspark",
			["npcID"] = 34702,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 334,
		},
		[53318] = {
			["source"] = "Anub'ar Crusher",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 28922,
		},
		[47729] = {
			["encounterName"] = "Grand Magus Telestra",
			["source"] = "Grand Magus Telestra",
			["npcID"] = 26930,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 520,
		},
		[60009] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30625,
		},
		[61558] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Dark Necromancer",
			["npcID"] = 28200,
		},
		[59019] = {
			["source"] = "Spitting Cobra",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29774,
		},
		[68950] = {
			["encounterName"] = "Bronjahm",
			["source"] = "Bronjahm",
			["encounterID"] = 829,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36497,
		},
		[68982] = {
			["encounterName"] = "Devourer of Souls",
			["source"] = "Devourer of Souls",
			["encounterID"] = 831,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36502,
		},
		[36631] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Nexus Drake Hatchling",
			["npcID"] = 26127,
		},
		[72208] = {
			["source"] = "Tortured Rifleman",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 38176,
		},
		[59706] = {
			["encounterName"] = "Ingvar the Plunderer",
			["source"] = "Ingvar the Plunderer",
			["npcID"] = 23954,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 575,
		},
		[59211] = {
			["source"] = "Azure Ring Guardian",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27638,
		},
		[59243] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Ymirjar Flesh Hunter",
			["npcID"] = 26670,
		},
		[9613] = {
			["source"] = "Skeletal Guardian",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 10390,
		},
		[17174] = {
			["source"] = "Wavecrest Mariner",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 35098,
		},
		[68504] = {
			["encounterName"] = "Grand Champions",
			["source"] = "Marshal Jacob Alerius",
			["npcID"] = 34705,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 334,
		},
		[67546] = {
			["encounterName"] = "Grand Champions",
			["source"] = "Marshal Jacob Alerius",
			["npcID"] = 34705,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 334,
		},
		[43562] = {
			["source"] = "Glacion",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 24019,
		},
		[54309] = {
			["source"] = "Anub'ar Prime Guard",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29128,
		},
		[43083] = {
			["source"] = "Winterskorn Rune-Seer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 23667,
		},
		[20823] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Legashi Hellcaller",
			["npcID"] = 6202,
		},
		[59994] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30621,
		},
		[15801] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Lesser Air Elemental",
			["npcID"] = 28384,
		},
		[54916] = {
			["source"] = "Sparktouched Oracle",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 28112,
		},
		[59020] = {
			["source"] = "Spitting Cobra",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29774,
		},
		[22907] = {
			["source"] = "Alliance Ranger",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26802,
		},
		[31602] = {
			["source"] = "Nerub'enkan",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 10437,
		},
		[69527] = {
			["source"] = "Iceborn Proto-Drake",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36891,
		},
		[43291] = {
			["source"] = "Dragonflayer Berserker",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 24216,
		},
		[7162] = {
			["source"] = "Brother Malach",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 5661,
		},
		[59212] = {
			["source"] = "Azure Spellbinder",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27635,
		},
		[61272] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Scalesworn Elite",
			["npcID"] = 32534,
		},
		[59244] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Ymirjar Flesh Hunter",
			["npcID"] = 26670,
		},
		[15869] = {
			["source"] = "Drakkari Witch Doctor",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27555,
		},
		[55715] = {
			["source"] = "Earthen Elite",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29980,
		},
		[57775] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30623,
		},
		[69528] = {
			["source"] = "Ymirjar Deathbringer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36892,
		},
		[59372] = {
			["encounterName"] = "Varos Cloudstrider",
			["source"] = "Varos Cloudstrider",
			["encounterID"] = 530,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27447,
		},
		[49711] = {
			["source"] = "Risen Drakkari Handler",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26637,
		},
		[46150] = {
			["source"] = "Bound Air Elemental",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30418,
		},
		[11829] = {
			["source"] = "Unyielding Sorcerer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 16905,
		},
		[47731] = {
			["encounterName"] = "Grand Magus Telestra",
			["source"] = "Grand Magus Telestra",
			["npcID"] = 26929,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 520,
		},
		[50414] = {
			["source"] = "Risen Drakkari Bat Rider",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26638,
		},
		[51963] = {
			["source"] = "Ebon Gargoyle",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27829,
		},
		[38182] = {
			["source"] = "Gryphon Rider Guard",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 15241,
		},
		[55077] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Savage Worg",
			["npcID"] = 29735,
		},
		[57648] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30621,
		},
		[59708] = {
			["encounterName"] = "Ingvar the Plunderer",
			["source"] = "Ingvar the Plunderer",
			["npcID"] = 23954,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 575,
		},
		[58702] = {
			["source"] = "Searing Totem X",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 31165,
		},
		[16001] = {
			["source"] = "Risen Drakkari Bat Rider",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26638,
		},
		[61353] = {
			["source"] = "Dagna Flintlock",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29476,
		},
		[34302] = {
			["source"] = "Collapsing Voidwalker",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 17014,
		},
		[43516] = {
			["source"] = "Dragonflayer Prisoner",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 24255,
		},
		[69051] = {
			["encounterName"] = "Devourer of Souls",
			["source"] = "Devourer of Souls",
			["encounterID"] = 831,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36502,
		},
		[42526] = {
			["source"] = "Spore",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 23876,
		},
		[16033] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Torgg Thundertotem",
			["npcID"] = 27716,
		},
		[47668] = {
			["source"] = "Drakkari Guardian",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26620,
		},
		[15530] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Azure Magus",
			["npcID"] = 26722,
		},
		[56898] = {
			["source"] = "Twilight Darkcaster",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30319,
		},
		[61513] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Unrelenting Construct",
			["npcID"] = 27971,
		},
		[60012] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30623,
		},
		[15043] = {
			["source"] = "Gold Mage",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 32341,
		},
		[70425] = {
			["encounterName"] = "Overlrod Tyrannus",
			["source"] = "Freed Horde Slave",
			["encounterID"] = 837,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 37578,
		},
		[68988] = {
			["encounterName"] = "Bronjahm",
			["source"] = "Bronjahm",
			["encounterID"] = 829,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36497,
		},
		[59102] = {
			["source"] = "Ahn'kahar Spell Flinger",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30278,
		},
		[60667] = {
			["encounterName"] = "Hadronox",
			["source"] = "Frostbrood Skytalon",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 31137,
		},
		[15586] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Azure Scale-Binder",
			["npcID"] = 26735,
		},
		[50495] = {
			["source"] = "Mage-Lord Urom",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27655,
		},
		[59246] = {
			["encounterName"] = "Skadi the Ruthless",
			["source"] = "Ymirjar Witch Doctor",
			["npcID"] = 26691,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 581,
		},
		[31707] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Water Elemental",
			["npcID"] = 510,
		},
		[49106] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Ymirjar Berserker",
			["npcID"] = 26696,
		},
		[68989] = {
			["encounterName"] = "Krick",
			["source"] = "Ick",
			["encounterID"] = 835,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36476,
		},
		[70043] = {
			["encounterName"] = "Bronjahm",
			["source"] = "Bronjahm",
			["encounterID"] = 829,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36497,
		},
		[69564] = {
			["source"] = "Soulguard Adept",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36620,
		},
		[53322] = {
			["source"] = "Anub'ar Crypt Fiend",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29118,
		},
		[17503] = {
			["source"] = "Maleki the Pallid",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 10438,
		},
		[32330] = {
			["source"] = "Venomtip",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 28358,
		},
		[61562] = {
			["source"] = "Twilight Darkcaster",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30319,
		},
		[15498] = {
			["source"] = "Scarlet Medic",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 28608,
		},
		[51805] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Dark Rune Controller",
			["npcID"] = 27966,
		},
		[20297] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Frostskull Magus",
			["npcID"] = 31813,
		},
		[57091] = {
			["encounterName"] = "Keristrasza",
			["source"] = "Keristrasza",
			["encounterID"] = 526,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26723,
		},
		[59723] = {
			["encounterName"] = "Maiden of Grief",
			["event"] = "SPELL_CAST_START",
			["source"] = "Maiden of Grief",
			["npcID"] = 27975,
		},
		[50335] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Hulking Abomination",
			["npcID"] = 31140,
		},
		[50496] = {
			["source"] = "Mage-Lord Urom",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27655,
		},
		[58688] = {
			["encounterName"] = "Cyanigosa",
			["source"] = "Cyanigosa",
			["encounterID"] = 545,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 31134,
		},
		[69246] = {
			["encounterName"] = "Overlrod Tyrannus",
			["source"] = "Rimefang",
			["encounterID"] = 837,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36661,
		},
		[59742] = {
			["encounterName"] = "Krystallus",
			["source"] = "Krystallus",
			["npcID"] = 27977,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 563,
		},
		[30933] = {
			["source"] = "North Fleet Marksman",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 23946,
		},
		[51918] = {
			["source"] = "Val'kyr Battle-maiden",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 28534,
		},
		[51103] = {
			["encounterName"] = "Mage-Lord Urom",
			["source"] = "Mage-Lord Urom",
			["encounterID"] = 532,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27655,
		},
		[68895] = {
			["source"] = "Spiteful Apparition",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36551,
		},
		[49091] = {
			["encounterName"] = "Skadi the Ruthless",
			["source"] = "Ymirjar Harpooner",
			["npcID"] = 26692,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 581,
		},
		[116] = {
			["npcID"] = 188027,
		},
		[41056] = {
			["source"] = "Azure Captain",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30666,
		},
		[59359] = {
			["encounterName"] = "Anub'arak",
			["source"] = "Anub'ar Venomancer",
			["encounterID"] = 218,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29217,
		},
		[45578] = {
			["source"] = "Warsong Marksman",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 25244,
		},
		[55814] = {
			["encounterName"] = "Eck the Ferocious",
			["source"] = "Eck the Ferocious",
			["encounterID"] = 1988,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29932,
		},
		[20793] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Bristleback Geomancer",
			["npcID"] = 3263,
		},
		[20801] = {
			["source"] = "Imp Minion",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 12922,
		},
		[57076] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Yggdras",
			["npcID"] = 30014,
		},
		[55633] = {
			["encounterName"] = "Drakkari Colossus",
			["source"] = "Drakkari Golem",
			["encounterID"] = 385,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29832,
		},
		[20825] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Haldarr Felsworn",
			["npcID"] = 6127,
		},
		[59152] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Dark Rune Theurgist",
			["npcID"] = 27963,
		},
		[69172] = {
			["encounterName"] = "Overlrod Tyrannus",
			["source"] = "Scourgelord Tyrannus",
			["encounterID"] = 837,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36658,
		},
		[60030] = {
			["encounterName"] = "Jedoga Shadowseeker",
			["source"] = "Jedoga Shadowseeker",
			["encounterID"] = 214,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29310,
		},
		[59024] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Dark Rune Elementalist",
			["npcID"] = 27962,
		},
		[33634] = {
			["source"] = "Bloodmage",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 19258,
		},
		[59146] = {
			["source"] = "Drakkari God Hunter",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29820,
		},
		[22414] = {
			["source"] = "Bound Air Elemental",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30418,
		},
		[53467] = {
			["encounterName"] = "Anub'arak",
			["source"] = "Anub'arak",
			["encounterID"] = 218,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29120,
		},
		[9734] = {
			["source"] = "Dragonflayer Prisoner",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 24255,
		},
		[70589] = {
			["source"] = "Image of Morlen Coldgrip",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 37845,
		},
		[52493] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Watcher Silthik",
			["encounterID"] = 216,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 28731,
		},
		[32674] = {
			["source"] = "Reanimated Crusader",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 31043,
		},
		[51503] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Dark Rune Controller",
			["npcID"] = 27966,
		},
		[62250] = {
			["encounterName"] = "Ley-Guardian Eregos",
			["source"] = "Greater Ley-Whelp",
			["encounterID"] = 534,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 28276,
		},
		[48894] = {
			["source"] = "Drakkari Shaman",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26639,
		},
		[59727] = {
			["encounterName"] = "Maiden of Grief",
			["event"] = "SPELL_CAST_START",
			["source"] = "Maiden of Grief",
			["npcID"] = 27975,
		},
		[6917] = {
			["source"] = "Thornfang Venomspitter",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 19350,
		},
		[54138] = {
			["source"] = "Xevozz",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29266,
		},
		[49555] = {
			["encounterName"] = "Trollgore",
			["source"] = "Trollgore",
			["encounterID"] = 369,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26630,
		},
		[59280] = {
			["source"] = "Snowflake",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 28153,
		},
		[13323] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Mage Hunter Ascendant",
			["npcID"] = 26727,
		},
		[48878] = {
			["encounterName"] = "King Dred",
			["source"] = "King Dred",
			["encounterID"] = 373,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27483,
		},
		[58817] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Stratholme Resident",
			["npcID"] = 28341,
		},
		[56837] = {
			["source"] = "Mage Hunter Ascendant",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26727,
		},
		[58849] = {
			["encounterName"] = "Mal'ganis",
			["source"] = "Mal'Ganis",
			["npcID"] = 26533,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 296,
		},
		[10277] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Venture Co. Logger",
			["npcID"] = 3989,
		},
		[54282] = {
			["source"] = "Lavanthor",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29312,
		},
		[49537] = {
			["encounterName"] = "The Prophet Tharon'ja",
			["source"] = "The Prophet Tharon'ja",
			["encounterID"] = 375,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26632,
		},
		[52270] = {
			["source"] = "Frenzyheart Hunter",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 28079,
		},
		[58667] = {
			["source"] = "Unbound Seer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 33422,
		},
		[67289] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Argent Priestess",
			["npcID"] = 35307,
		},
		[59726] = {
			["encounterName"] = "Maiden of Grief",
			["event"] = "SPELL_CAST_START",
			["source"] = "Maiden of Grief",
			["npcID"] = 27975,
		},
		[56933] = {
			["source"] = "Alliance Ranger",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26802,
		},
		[67745] = {
			["encounterName"] = "The Black Knight",
			["source"] = "The Black Knight",
			["npcID"] = 35451,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 340,
		},
		[58462] = {
			["source"] = "Azure Spellbreaker",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 31009,
		},
		[49712] = {
			["source"] = "Risen Drakkari Handler",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26637,
		},
		[12471] = {
			["source"] = "Shadow Construct",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29231,
		},
		[54850] = {
			["encounterName"] = "Drakkari Colossus",
			["source"] = "Drakkari Colossus",
			["encounterID"] = 385,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29307,
		},
		[59433] = {
			["encounterName"] = "Anub'arak",
			["source"] = "Anub'arak",
			["encounterID"] = 218,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29120,
		},
		[49708] = {
			["source"] = "Darkweb Recluse",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26625,
		},
		[22686] = {
			["encounterName"] = "King Dred",
			["source"] = "King Dred",
			["encounterID"] = 373,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27483,
		},
		[70080] = {
			["encounterName"] = "Escaped from Arthas",
			["source"] = "Risen Witch Doctor",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36941,
		},
		[49668] = {
			["encounterName"] = "Novos the Summoner",
			["source"] = "Crystal Handler",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26627,
		},
		[69633] = {
			["source"] = "Spectral Warden",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36666,
		},
		[59169] = {
			["source"] = "Bound Air Elemental",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30418,
		},
		[59696] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Proto-Drake Handler",
			["npcID"] = 24082,
		},
		[15982] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Torgg Thundertotem",
			["npcID"] = 27716,
		},
		[60239] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Gargoyle Ambusher",
			["npcID"] = 32769,
		},
		[70291] = {
			["source"] = "Ymirjar Skycaller",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 31260,
		},
		[47496] = {
			["source"] = "Stonebasher",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26125,
		},
		[50578] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Frozen Sphere",
			["npcID"] = 28066,
		},
		[55704] = {
			["source"] = "Earthen Warder",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29981,
		},
		[68899] = {
			["encounterName"] = "Devourer of Souls",
			["source"] = "Devourer of Souls",
			["encounterID"] = 831,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36502,
		},
		[48895] = {
			["source"] = "Drakkari Shaman",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26639,
		},
		[59260] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Sunreaver Agent",
			["npcID"] = 38201,
		},
		[70512] = {
			["source"] = "Lady Sylvanas Windrunner",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36990,
		},
		[58850] = {
			["encounterName"] = "Mal'ganis",
			["source"] = "Mal'Ganis",
			["npcID"] = 26533,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 296,
		},
		[59377] = {
			["encounterName"] = "Mage-Lord Urom",
			["source"] = "Mage-Lord Urom",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27655,
		},
		[38370] = {
			["source"] = "North Fleet Marksman",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 23946,
		},
		[70145] = {
			["encounterName"] = "Escaped from Arthas",
			["source"] = "Risen Witch Doctor",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36941,
		},
		[38618] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Alliance Commander",
			["npcID"] = 27949,
		},
		[11443] = {
			["source"] = "Thuzadin Shadowcaster",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 10398,
		},
		[34019] = {
			["source"] = "Bleeding Hollow Necrolyte",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 19422,
		},
		[61374] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Haiphoon, the Great Tempest",
			["npcID"] = 28999,
		},
		[47736] = {
			["source"] = "Grand Magus Telestra",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26929,
		},
		[15547] = {
			["source"] = "Fordragon Sentinel",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27576,
		},
		[59362] = {
			["encounterName"] = "Hadronox",
			["source"] = "Anub'ar Webspinner",
			["encounterID"] = 217,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29335,
		},
		[49317] = {
			["source"] = "Azure Drake",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27682,
		},
		[49111] = {
			["source"] = "Azure Dragon",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27608,
		},
		[52926] = {
			["source"] = "High Inquisitor Valroth",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29001,
		},
		[18327] = {
			["source"] = "Baroness Anastari",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 10436,
		},
		[57046] = {
			["source"] = "Crazed Mana-Surge",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26737,
		},
		[59617] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Dragonflayer Runecaster",
			["npcID"] = 23960,
		},
		[34083] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Scalding Whelp",
			["npcID"] = 2725,
		},
		[61269] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Scalesworn Elite",
			["npcID"] = 32534,
		},
		[15587] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Cult Researcher",
			["npcID"] = 32297,
		},
		[72222] = {
			["source"] = "Tortured Rifleman",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 38176,
		},
		[55098] = {
			["encounterName"] = "Moorabi",
			["source"] = "Moorabi",
			["encounterID"] = 387,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29305,
		},
		[55625] = {
			["source"] = "Drakkari God Hunter",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29820,
		},
		[16866] = {
			["source"] = "Venom Belcher",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 10417,
		},
		[70306] = {
			["source"] = "Frostblade",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 37670,
		},
		[17393] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Baron Rivendare",
			["npcID"] = 29109,
		},
		[59266] = {
			["encounterName"] = "Mage-Lord Urom",
			["source"] = "Phantasmal Water",
			["encounterID"] = 532,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27653,
		},
		[61326] = {
			["source"] = "Azure Scale-Binder",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26735,
		},
		[52566] = {
			["source"] = "Scarlet Fleet Defender",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 28834,
		},
		[72268] = {
			["source"] = "Tortured Rifleman",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 38176,
		},
		[49110] = {
			["source"] = "Wyrmrest Guardian",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26933,
		},
		[12058] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Iron Dwarf Magus",
			["npcID"] = 29979,
		},
		[8996] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Dark Iron Rifleman",
			["npcID"] = 6523,
		},
		[67528] = {
			["encounterName"] = "Grand Champions",
			["source"] = "Colosos",
			["encounterID"] = 334,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 34701,
		},
		[51218] = {
			["source"] = "Proto-Whelp",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 23750,
		},
		[53278] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Volatile Ghoul",
			["npcID"] = 29136,
		},
		[23102] = {
			["source"] = "Shadow Vault Boneguard",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30312,
		},
		[52534] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Anub'ar Shadowcaster",
			["encounterID"] = 216,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 28733,
		},
		[12549] = {
			["source"] = "Sparktouched Oracle",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 28112,
		},
		[56919] = {
			["encounterName"] = "Frozen Commander",
			["source"] = "Alliance Cleric",
			["encounterID"] = 519,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26805,
		},
		[68774] = {
			["encounterName"] = "Forgemaster Garfrost",
			["source"] = "Forgemaster Garfrost",
			["encounterID"] = 833,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36494,
		},
		[69573] = {
			["source"] = "Wrathbone Coldwraith",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36842,
		},
		[69080] = {
			["source"] = "Soulguard Bonecaster",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36564,
		},
		[35010] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Dark Rune Theurgist",
			["npcID"] = 27963,
		},
		[58532] = {
			["source"] = "Portal Keeper",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30695,
		},
		[65868] = {
			["encounterName"] = "Grand Champions",
			["source"] = "Jaelyne Evensong",
			["encounterID"] = 334,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 34657,
		},
		[42723] = {
			["encounterName"] = "Ingvar the Plunderer",
			["source"] = "Ingvar the Plunderer",
			["npcID"] = 23954,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 575,
		},
		[57047] = {
			["source"] = "Crazed Mana-Surge",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26737,
		},
		[55815] = {
			["encounterName"] = "Eck the Ferocious",
			["source"] = "Eck the Ferocious",
			["encounterID"] = 1988,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29932,
		},
		[67529] = {
			["encounterName"] = "Grand Champions",
			["source"] = "Colosos",
			["encounterID"] = 334,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 34701,
		},
		[52496] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Crypt Fiend",
			["npcID"] = 27734,
		},
		[19645] = {
			["source"] = "Wailing Banshee",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 10464,
		},
		[69570] = {
			["encounterName"] = "Overlrod Tyrannus",
			["source"] = "Freed Horde Slave",
			["encounterID"] = 837,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 37579,
		},
		[56632] = {
			["source"] = "Ahn'kahar Web Winder",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30276,
		},
		[56580] = {
			["source"] = "Deep Crawler",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30279,
		},
		[34842] = {
			["source"] = "Uncontrolled Voidwalker",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 16975,
		},
		[61375] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Haiphoon, the Great Tempest",
			["npcID"] = 28999,
		},
		[35234] = {
			["source"] = "Marsh Dredger",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 18137,
		},
		[15232] = {
			["source"] = "Thuzadin Shadowcaster",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 10398,
		},
		[60848] = {
			["source"] = "Forgotten One",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30414,
		},
		[59346] = {
			["source"] = "Anub'ar Crusher",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 28922,
		},
		[19725] = {
			["source"] = "Scarlet Preacher",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 28939,
		},
		[59842] = {
			["encounterName"] = "Slad'ran",
			["source"] = "Slad'ran",
			["encounterID"] = 383,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29304,
		},
		[59347] = {
			["source"] = "Anub'ar Crypt Fiend",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29051,
		},
		[39945] = {
			["source"] = "Warsong Shaman",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27678,
		},
		[69574] = {
			["source"] = "Wrathbone Coldwraith",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36842,
		},
		[59999] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30621,
		},
		[33844] = {
			["source"] = "Ancient Watcher",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 31229,
		},
		[16997] = {
			["source"] = "Rockwing Screecher",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 10409,
		},
		[65128] = {
			["source"] = "Cultist Bombardier",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 33695,
		},
		[68872] = {
			["encounterName"] = "Bronjahm",
			["source"] = "Bronjahm",
			["encounterID"] = 829,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36497,
		},
		[59986] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30621,
		},
		[58980] = {
			["source"] = "Drakkari Medicine Man",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29826,
		},
		[38556] = {
			["source"] = "Darkspear Spear Thrower",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27560,
		},
		[32093] = {
			["source"] = "Emperor Cobra",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 28011,
		},
		[51363] = {
			["encounterName"] = "Novos the Summoner",
			["source"] = "Risen Shadowcaster",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27600,
		},
		[17290] = {
			["source"] = "Twilight Worshipper",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30111,
		},
		[57061] = {
			["encounterName"] = "Amanitar",
			["source"] = "Poisonous Mushroom",
			["encounterID"] = 1989,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30435,
		},
		[11986] = {
			["source"] = "Twilight Apostle",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30179,
		},
		[59603] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Dragonflayer Heartsplitter",
			["npcID"] = 24071,
		},
		[59108] = {
			["source"] = "Deep Crawler",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30279,
		},
		[54290] = {
			["source"] = "Anub'ar Webspinner",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29335,
		},
		[51475] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Dark Rune Elementalist",
			["npcID"] = 27962,
		},
		[56775] = {
			["source"] = "Azure Magus",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26722,
		},
		[51507] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Dark Rune Controller",
			["npcID"] = 27966,
		},
		[12737] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Mage Hunter Ascendant",
			["npcID"] = 26727,
		},
		[72898] = {
			["source"] = "Water Elemental",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 37994,
		},
		[6660] = {
			["source"] = "Wavecrest Mariner",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 35098,
		},
		[58973] = {
			["source"] = "Drakkari God Hunter",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29820,
		},
		[59252] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Ymirjar Dusk Shaman",
			["npcID"] = 26694,
		},
		[49987] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Defendo-tank 66D",
			["npcID"] = 25758,
		},
		[58827] = {
			["encounterName"] = "Salram the Fleshcrafter",
			["source"] = "Salramm the Fleshcrafter",
			["npcID"] = 26530,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 294,
		},
		[60833] = {
			["source"] = "Forgotten One",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30414,
		},
		[59038] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Lightning Construct",
			["npcID"] = 27972,
		},
		[57799] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30622,
		},
		[56969] = {
			["source"] = "Azure Scale-Binder",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26735,
		},
		[48873] = {
			["encounterName"] = "King Dred",
			["source"] = "King Dred",
			["encounterID"] = 373,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27483,
		},
		[38557] = {
			["source"] = "Kvaldir Berserker",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 34947,
		},
		[50198] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Mage Hunter Initiate",
			["npcID"] = 26728,
		},
		[61568] = {
			["source"] = "Twilight Worshipper",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30111,
		},
		[72322] = {
			["source"] = "Ghostly Priest",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 38175,
		},
		[61747] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Harbinger of Horror",
			["npcID"] = 32278,
		},
		[58438] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Unbound Trickster",
			["npcID"] = 30856,
		},
		[47723] = {
			["encounterName"] = "Grand Magus Telestra",
			["source"] = "Grand Magus Telestra",
			["npcID"] = 26928,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 520,
		},
		[60003] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Twisted Visage",
			["encounterID"] = 215,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30623,
		},
		[55931] = {
			["encounterName"] = "Prince Taldaram",
			["source"] = "Prince Taldaram",
			["encounterID"] = 213,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29308,
		},
		[66798] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "The Black Knight",
			["npcID"] = 35451,
		},
		[69577] = {
			["source"] = "Deathwhisper Necrolyte",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36788,
		},
		[49544] = {
			["encounterName"] = "The Prophet Tharon'ja",
			["source"] = "The Prophet Tharon'ja",
			["encounterID"] = 375,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26632,
		},
		[10326] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Argent Crusader",
			["npcID"] = 28029,
		},
		[61402] = {
			["source"] = "Ring-Lord Sorceress",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27639,
		},
		[53472] = {
			["encounterName"] = "Anub'arak",
			["source"] = "Anub'arak",
			["encounterID"] = 218,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29120,
		},
		[69583] = {
			["source"] = "Ymirjar Flamebearer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36893,
		},
		[16564] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Wrathstrike Gargoyle",
			["npcID"] = 30482,
		},
		[58535] = {
			["source"] = "Portal Keeper",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30893,
		},
		[72321] = {
			["source"] = "Ghostly Priest",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 38175,
		},
		[69131] = {
			["source"] = "Soulguard Animator",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36516,
		},
		[60211] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Dragonflayer Forge Master",
			["npcID"] = 24079,
		},
		[60227] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Dragonflayer Strategist",
			["npcID"] = 23956,
		},
		[17235] = {
			["source"] = "Nerub'enkan",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 10437,
		},
		[49528] = {
			["encounterName"] = "The Prophet Tharon'ja",
			["source"] = "The Prophet Tharon'ja",
			["encounterID"] = 375,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26632,
		},
		[56698] = {
			["source"] = "Ahn'kahar Spell Flinger",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30278,
		},
		[58537] = {
			["source"] = "Portal Keeper",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30893,
		},
		[54878] = {
			["encounterName"] = "Drakkari Colossus",
			["source"] = "Drakkari Elemental",
			["encounterID"] = 385,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29573,
		},
		[65130] = {
			["source"] = "Cultist Bombardier",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 33695,
		},
		[68939] = {
			["encounterName"] = "Devourer of Souls",
			["source"] = "Devourer of Souls",
			["encounterID"] = 831,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36502,
		},
		[49113] = {
			["source"] = "Wyrmrest Temple Drake",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26925,
		},
		[53425] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Harold Lane",
			["npcID"] = 25804,
		},
		[17195] = {
			["source"] = "Bound Fire Elemental",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30416,
		},
		[59381] = {
			["encounterName"] = "Ley-Guardian Eregos",
			["source"] = "Ley-Guardian Eregos",
			["encounterID"] = 534,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27656,
		},
		[56862] = {
			["source"] = "Bound Water Elemental",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30419,
		},
		[56858] = {
			["source"] = "Twilight Worshipper",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30111,
		},
		[52836] = {
			["source"] = "Scarlet Lord Borugh",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 28964,
		},
		[12466] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Mage Hunter Ascendant",
			["npcID"] = 26727,
		},
		[12470] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Gold Shaman",
			["npcID"] = 32340,
		},
		[58966] = {
			["source"] = "Drakkari Battle Rider",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29836,
		},
		[67247] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Argent Lightwielder",
			["npcID"] = 35309,
		},
		[38047] = {
			["source"] = "Azure Spellbinder",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27635,
		},
		[47772] = {
			["encounterName"] = "Grand Magus Telestra",
			["source"] = "Grand Magus Telestra",
			["npcID"] = 26731,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 520,
		},
		[59254] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Ymirjar Necromancer",
			["npcID"] = 28368,
		},
		[55980] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Enormos",
			["npcID"] = 30021,
		},
		[56938] = {
			["encounterName"] = "Grand Magus Telestra",
			["source"] = "Grand Magus Telestra",
			["encounterID"] = 520,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26928,
		},
		[36594] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Thunderhead Consort",
			["npcID"] = 6380,
		},
		[52451] = {
			["encounterName"] = "Salram the Fleshcrafter",
			["source"] = "Salramm the Fleshcrafter",
			["npcID"] = 26530,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 294,
		},
		[54369] = {
			["source"] = "Zuramat the Obliterator",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29314,
		},
		[69068] = {
			["source"] = "Soulguard Adept",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36620,
		},
		[72166] = {
			["source"] = "Phantom Mage",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 38172,
		},
		[30633] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Crystalline Protector",
			["npcID"] = 26792,
		},
		[33624] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Undercity Mage",
			["npcID"] = 18971,
		},
		[49034] = {
			["encounterName"] = "Novos the Summoner",
			["source"] = "Novos the Summoner",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26631,
		},
		[34871] = {
			["source"] = "Umbrafen Witchdoctor",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 20115,
		},
		[16868] = {
			["source"] = "Shrieking Banshee",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 10463,
		},
		[53617] = {
			["encounterName"] = "Anub'arak",
			["source"] = "Anub'ar Venomancer",
			["encounterID"] = 218,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29217,
		},
		[52611] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Master Necromancer",
			["npcID"] = 27732,
		},
		[50583] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Coldarra Spellbinder",
			["npcID"] = 25719,
		},
		[15620] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Darnassian Archer",
			["npcID"] = 18965,
		},
		[59839] = {
			["encounterName"] = "Slad'ran",
			["source"] = "Slad'ran",
			["encounterID"] = 383,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29304,
		},
		[42131] = {
			["source"] = "Forsaken Crossbowman",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 23883,
		},
		[17435] = {
			["source"] = "Baron Rivendare",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 10440,
		},
		[69516] = {
			["source"] = "Ymirjar Deathbringer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36892,
		},
		[59366] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Watcher Silthik",
			["encounterID"] = 216,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 28731,
		},
		[66514] = {
			["source"] = "North Sea Kraken",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 34925,
		},
		[33417] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Stormwind Mage",
			["npcID"] = 18949,
		},
		[67729] = {
			["encounterName"] = "The Black Knight",
			["source"] = "Risen Champion",
			["npcID"] = 35590,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 340,
		},
		[59430] = {
			["encounterName"] = "Anub'arak",
			["source"] = "Anub'arak",
			["encounterID"] = 218,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29120,
		},
		[424340] = {
			["encounterName"] = "Herald Volazj",
			["source"] = "Greater Fire Elemental",
			["encounterID"] = 215,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 15438,
		},
		[9532] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Dustbelcher Shaman",
			["npcID"] = 2718,
		},
		[58967] = {
			["source"] = "Drakkari Battle Rider",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29836,
		},
		[33641] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Justinius the Harbinger",
			["npcID"] = 18966,
		},
		[52356] = {
			["source"] = "Dark Rider of Acherus",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 28768,
		},
		[47773] = {
			["encounterName"] = "Grand Magus Telestra",
			["source"] = "Grand Magus Telestra",
			["npcID"] = 26731,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 520,
		},
		[59638] = {
			["encounterName"] = "Drakos the Interrogator",
			["source"] = "Mirror Image",
			["encounterID"] = 528,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 31216,
		},
		[58536] = {
			["source"] = "Portal Keeper",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30893,
		},
		[52931] = {
			["source"] = "Lafoo",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 28120,
		},
		[9053] = {
			["source"] = "Flamewaker Imp",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 19136,
		},
		[50504] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Arcane Serpent",
			["npcID"] = 25721,
		},
		[43270] = {
			["source"] = "Iron Rune Binder",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 23796,
		},
		[16565] = {
			["source"] = "Baroness Anastari",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 10436,
		},
		[47981] = {
			["encounterName"] = "Ormorok the Tree-Shaper",
			["source"] = "Ormorok the Tree-Shaper",
			["npcID"] = 26794,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 524,
		},
		[51494] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Dark Rune Giant",
			["npcID"] = 27969,
		},
		[58153] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Reanimated Crusader",
			["npcID"] = 30202,
		},
		[75330] = {
			["encounterName"] = "Overlrod Tyrannus",
			["source"] = "Wrathbone Sorcerer",
			["encounterID"] = 837,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 37728,
		},
		[59734] = {
			["encounterName"] = "Ingvar the Plunderer",
			["source"] = "Ingvar the Plunderer",
			["npcID"] = 23954,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 575,
		},
		[59223] = {
			["encounterName"] = "Mage-Lord Urom",
			["source"] = "Phantasmal Cloudscraper",
			["encounterID"] = 532,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27645,
		},
		[68272] = {
			["source"] = "The Black Brewmaiden",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36024,
		},
		[59255] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Ymirjar Necromancer",
			["npcID"] = 28368,
		},
		[34232] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "High Elf Mage-Priest",
			["npcID"] = 27747,
		},
		[50089] = {
			["encounterName"] = "Novos the Summoner",
			["source"] = "Novos the Summoner",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26631,
		},
		[66867] = {
			["encounterName"] = "Argent Champion",
			["source"] = "Eadric the Pure",
			["npcID"] = 35119,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 338,
		},
		[49753] = {
			["source"] = "Iron Rune Runemaster",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 23675,
		},
		[65147] = {
			["source"] = "Stormwind Champion",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 33747,
		},
		[37361] = {
			["source"] = "Skeletal Guardian",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 10390,
		},
		[59852] = {
			["encounterName"] = "Sjonnir the Ironshaper",
			["source"] = "Forged Iron Trogg",
			["npcID"] = 27979,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 569,
		},
		[69582] = {
			["source"] = "Plagueborn Horror",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36879,
		},
		[72169] = {
			["source"] = "Phantom Mage",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 38172,
		},
		[56860] = {
			["source"] = "Mage Hunter Initiate",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26728,
		},
		[69167] = {
			["encounterName"] = "Overlrod Tyrannus",
			["source"] = "Scourgelord Tyrannus",
			["encounterID"] = 837,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36658,
		},
		[59685] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Dragonflayer Strategist",
			["npcID"] = 23956,
		},
		[55886] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Fiend of Earth",
			["npcID"] = 30043,
		},
		[69263] = {
			["encounterName"] = "Krick",
			["source"] = "Ick",
			["encounterID"] = 835,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36476,
		},
		[72163] = {
			["source"] = "Phantom Mage",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 38172,
		},
		[9672] = {
			["source"] = "Skeletal Guardian",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 10390,
		},
		[70381] = {
			["encounterName"] = "Forgemaster Garfrost",
			["source"] = "Forgemaster Garfrost",
			["encounterID"] = 833,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36494,
		},
		[32103] = {
			["source"] = "Fordragon Marksman",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27540,
		},
		[55982] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Enormos",
			["npcID"] = 30021,
		},
		[59575] = {
			["encounterName"] = "Skarvold & Dalronn",
			["source"] = "Dalronn the Controller",
			["npcID"] = 24201,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 573,
		},
		[57547] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Val'kyr Battle-maiden",
			["npcID"] = 31095,
		},
		[59365] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Watcher Narjil",
			["encounterID"] = 216,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 28729,
		},
		[53345] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Tirisfal Crusader",
			["npcID"] = 29103,
		},
		[17843] = {
			["source"] = "Gold Priest",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 32325,
		},
		[49704] = {
			["source"] = "Darkweb Recluse",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26625,
		},
		[61528] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Lightning Construct",
			["npcID"] = 27972,
		},
		[31664] = {
			["source"] = "Frenzied Gargoyle",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27691,
		},
		[33642] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Melgromm Highmountain",
			["npcID"] = 18969,
		},
		[21971] = {
			["source"] = "Spirit of Koosu",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29034,
		},
		[16869] = {
			["source"] = "Maleki the Pallid",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 10438,
		},
		[68785] = {
			["encounterName"] = "Forgemaster Garfrost",
			["source"] = "Forgemaster Garfrost",
			["encounterID"] = 833,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36494,
		},
		[56937] = {
			["encounterName"] = "Grand Magus Telestra",
			["source"] = "Grand Magus Telestra",
			["encounterID"] = 520,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26930,
		},
		[38204] = {
			["source"] = "Unbound Seer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 33422,
		},
		[51112] = {
			["encounterName"] = "Mage-Lord Urom",
			["source"] = "Mage-Lord Urom",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27655,
		},
		[50690] = {
			["source"] = "Azure Inquisitor",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27633,
		},
		[48054] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Crazed Mana-Surge",
			["npcID"] = 26737,
		},
		[17434] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Baron Rivendare",
			["npcID"] = 29109,
		},
		[59863] = {
			["encounterName"] = "Tribunal of Ages",
			["source"] = "Dark Rune Stormcaller",
			["npcID"] = 27984,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 567,
		},
		[12739] = {
			["source"] = "Twilight Darkcaster",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30319,
		},
		[55643] = {
			["source"] = "Ruins Dweller",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29920,
		},
		[72171] = {
			["source"] = "Phantom Mage",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 38172,
		},
		[51240] = {
			["source"] = "Risen Drakkari Death Knight",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26830,
		},
		[48920] = {
			["encounterName"] = "King Dred",
			["source"] = "King Dred",
			["encounterID"] = 373,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27483,
		},
		[59215] = {
			["source"] = "Greater Ley-Whelp",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 28276,
		},
		[69056] = {
			["source"] = "Soulguard Watchman",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36478,
		},
		[53348] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Hearthglen Crusader",
			["npcID"] = 29102,
		},
		[59357] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Anub'ar Shadowcaster",
			["encounterID"] = 216,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 28733,
		},
		[51336] = {
			["encounterName"] = "Drakos the Interrogator",
			["source"] = "Drakos the Interrogator",
			["encounterID"] = 528,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27654,
		},
		[59331] = {
			["encounterName"] = "Skadi the Ruthless",
			["source"] = "Skadi the Ruthless",
			["npcID"] = 26693,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 581,
		},
		[59033] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Dark Rune Scholar",
			["npcID"] = 27964,
		},
		[68987] = {
			["encounterName"] = "Krick",
			["source"] = "Ick",
			["encounterID"] = 835,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36476,
		},
		[50378] = {
			["source"] = "Scourge Reanimator",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26626,
		},
		[59081] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Dragonflayer Seer",
			["npcID"] = 26554,
		},
		[8995] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Dark Iron Rifleman",
			["npcID"] = 6523,
		},
		[57088] = {
			["encounterName"] = "Amanitar",
			["source"] = "Amanitar",
			["encounterID"] = 1989,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30258,
		},
		[59376] = {
			["encounterName"] = "Mage-Lord Urom",
			["source"] = "Mage-Lord Urom",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27655,
		},
		[63233] = {
			["source"] = "Boneguard Scout",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 33550,
		},
		[50476] = {
			["source"] = "Mage-Lord Urom",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27655,
		},
		[14443] = {
			["source"] = "Captain Aerthas Firehawk",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 35090,
		},
		[33643] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Melgromm Highmountain",
			["npcID"] = 18969,
		},
		[59209] = {
			["source"] = "Azure Inquisitor",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27633,
		},
		[59225] = {
			["encounterName"] = "Mage-Lord Urom",
			["source"] = "Phantasmal Fire",
			["encounterID"] = 532,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27651,
		},
		[59241] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Ymirjar Flesh Hunter",
			["npcID"] = 26670,
		},
		[49037] = {
			["encounterName"] = "Novos the Summoner",
			["source"] = "Novos the Summoner",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26631,
		},
		[67751] = {
			["encounterName"] = "The Black Knight",
			["source"] = "The Black Knight",
			["npcID"] = 35451,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 340,
		},
		[69028] = {
			["encounterName"] = "Krick",
			["source"] = "Krick",
			["encounterID"] = 835,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36477,
		},
		[59305] = {
			["encounterName"] = "King Ymiron",
			["source"] = "King Ymiron",
			["npcID"] = 26861,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 583,
		},
		[38881] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Azure Scale-Binder",
			["npcID"] = 26735,
		},
		[66935] = {
			["encounterName"] = "Argent Champion",
			["source"] = "Eadric the Pure",
			["npcID"] = 35119,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 338,
		},
		[56934] = {
			["encounterName"] = "Grand Magus Telestra",
			["source"] = "Grand Magus Telestra",
			["encounterID"] = 520,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26731,
		},
		[4962] = {
			["source"] = "Crypt Beast",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 10413,
		},
		[69562] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Soulguard Bonecaster",
			["npcID"] = 36564,
		},
		[59389] = {
			["encounterName"] = "Prince Keleseth",
			["source"] = "Prince Keleseth",
			["npcID"] = 23953,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 571,
		},
		[61461] = {
			["source"] = "Frostbringer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30286,
		},
		[20295] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Timbermaw Shaman",
			["npcID"] = 6188,
		},
		[47696] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Crazed Mana-Surge",
			["npcID"] = 26737,
		},
		[53333] = {
			["encounterName"] = "Krik'thir the Gatewatcher",
			["source"] = "Anub'ar Necromancer",
			["encounterID"] = 216,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29064,
		},
		[59616] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Dragonflayer Runecaster",
			["npcID"] = 23960,
		},
		[68788] = {
			["encounterName"] = "Forgemaster Garfrost",
			["source"] = "Forgemaster Garfrost",
			["encounterID"] = 833,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36494,
		},
		[18802] = {
			["source"] = "Forsaken Crossbowman",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 23883,
		},
		[49309] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Gold Shaman",
			["npcID"] = 32340,
		},
		[59034] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Dark Rune Shaper",
			["npcID"] = 27965,
		},
		[31601] = {
			["source"] = "Crypt Crawler",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 10412,
		},
		[50379] = {
			["encounterName"] = "Trollgore",
			["source"] = "Scourge Reanimator",
			["encounterID"] = 369,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26626,
		},
		[70513] = {
			["source"] = "Lady Sylvanas Windrunner",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36990,
		},
		[69012] = {
			["encounterName"] = "Krick",
			["source"] = "Krick",
			["encounterID"] = 835,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36477,
		},
		[66489] = {
			["source"] = "Kvaldir Harpooner",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 34907,
		},
		[49696] = {
			["encounterName"] = "Trollgore",
			["source"] = "Risen Drakkari Soulmage",
			["encounterID"] = 369,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 26636,
		},
		[66042] = {
			["encounterName"] = "Grand Champions",
			["source"] = "Ambrose Boltspark",
			["npcID"] = 34702,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 334,
		},
		[60158] = {
			["source"] = "Azure Raider",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30668,
		},
		[70194] = {
			["encounterName"] = "Escaped from Arthas",
			["source"] = "Lady Sylvanas Windrunner",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 37554,
		},
		[57825] = {
			["source"] = "Frostbringer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 30286,
		},
		[59210] = {
			["source"] = "Azure Ley-Whelp",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27636,
		},
		[67229] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Argent Priestess",
			["npcID"] = 35307,
		},
		[25054] = {
			["source"] = "Fordragon High Priest",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 27677,
		},
		[69780] = {
			["encounterName"] = "Escaped from Arthas",
			["source"] = "The Lich King",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 36954,
		},
		[31713] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Scarlet Commander Rodrick",
			["npcID"] = 29000,
		},
		[59083] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Dragonflayer Seer",
			["npcID"] = 26554,
		},
		[55218] = {
			["encounterName"] = "Gal'darah",
			["source"] = "Gal'darah",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 29306,
		},
		[55937] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Orinoko Tuskbreaker",
			["npcID"] = 30020,
		},
		[45577] = {
			["source"] = "Nerub'ar Corpse Harvester",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 25445,
		},
	},
	["profileKeys"] = {
		["Ggspot - Mirage Raceway"] = "Default",
		["Azuradra - Mirage Raceway"] = "Default",
		["Buddahla - Mirage Raceway"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["script_data"] = {
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --creates a glow around the icon\n    envTable.buffIconGlow = envTable.buffIconGlow or Plater.CreateIconGlow (self, scriptTable.config.glowColor)\n    \nend",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (scriptTable.config.glowEnabled) then\n        envTable.buffIconGlow:Hide()\n    end\n    \n    if (scriptTable.config.dotsEnabled) then\n        Plater.StopDotAnimation(self, envTable.dotAnimation)\n    end\n    \n    \nend",
					["ScriptType"] = 1,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    \n    \n    \nend",
					["Time"] = 1669327144,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\icon_aura",
					["Enabled"] = true,
					["Revision"] = 632,
					["semver"] = "",
					["Author"] = "Tercioo-Sylvanas",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Add the buff name in the trigger box.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						398151, -- [1]
						377738, -- [2]
						378149, -- [3]
					},
					["PlaterCore"] = 1,
					["Name"] = "Aura - Buff Alert [Plater]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Enter the spell name or spellID of the Buff in the Add Trigger box and hit \"Add\".",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option3",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 4,
							["Name"] = "Glow Enabled",
							["Value"] = false,
							["Key"] = "glowEnabled",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 1,
							["Name"] = "Glow Color",
							["Value"] = {
								0.403921568627451, -- [1]
								0.00392156862745098, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "glowColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [5]
						{
							["Type"] = 6,
							["Key"] = "option3",
							["Value"] = 0,
							["Name"] = "Blank Space",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [6]
						{
							["Type"] = 4,
							["Name"] = "Dots Enabled",
							["Value"] = true,
							["Key"] = "dotsEnabled",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [7]
						{
							["Type"] = 1,
							["Key"] = "dotsColor",
							["Value"] = {
								1, -- [1]
								0.3215686274509804, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Dots Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [8]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (scriptTable.config.glowEnabled) then\n        envTable.buffIconGlow:Show()\n    end\n    \n    if (scriptTable.config.dotsEnabled) then\n        envTable.dotAnimation = Plater.PlayDotAnimation(self, 6, scriptTable.config.dotsColor, 6, 3) \n    end\n    \nend\n\n\n\n\n",
				}, -- [1]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    \n    --set the castbar config\n    envTable.configAltCastBar = {\n        iconTexture = \"\",\n        iconTexcoord = {0.1, 0.9, 0.1, 0.9},\n        iconAlpha = 1,\n        iconSize = 14,\n        \n        text = \"Boom!\",\n        textSize = 9,\n        \n        texture = [[Interface\\AddOns\\Plater\\images\\bar_background]],\n        color = \"silver\",\n        \n        isChanneling = false,\n        canInterrupt = false,\n        \n        height = 2,\n        width = Plater.db.profile.plate_config.enemynpc.health_incombat[1],\n        \n        spellNameAnchor = {side = 3, x = 0, y = -2},\n        timerAnchor = {side = 5, x = 0, y = -2},\n    }    \n    \n    function envTable.ShowAltCastBar(npcInfo, unitFrame, unitId, customTime, customStart)\n        --show the cast bar\n        if (npcInfo.timerId) then\n            local barObject = Plater.GetBossTimer(npcInfo.timerId)\n            if (barObject) then\n                if (npcInfo.remaining) then\n                    local timeLeft = barObject.timer + barObject.start - GetTime()\n                    if (timeLeft > npcInfo.remaining) then\n                        return\n                    end\n                end\n                \n                config.text = npcInfo.name\n                \n                if (npcInfo.spellIcon) then\n                    local _, _, iconTexture = GetSpellInfo(npcInfo.spellIcon)\n                    config.iconTexture = iconTexture\n                else\n                    config.iconTexture = \"\"\n                end\n                \n                Plater.SetAltCastBar(unitFrame.PlateFrame, config, barObject.timer, customStart or barObject.start, npcInfo.altCastId)\n            end\n        else\n            Plater.SetAltCastBar(unitFrame.PlateFrame, config, customTime or npcInfo.timer, customStart, npcInfo.altCastId)            \n        end    \n        \n        \n    end\nend\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    if (envTable._SpellID == 191284) then\n        Plater.SetAltCastBar(unitFrame.PlateFrame, envTable.configAltCastBar, 4.70, GetTime(), 191284)\n        \n        C_Timer.After(4.75, function()\n                Plater.SetAltCastBar(unitFrame.PlateFrame, envTable.configAltCastBar, 5.30, GetTime(), 191284)\n        end)\n        \n        C_Timer.After(4.75 + 5.30, function()\n                Plater.SetAltCastBar(unitFrame.PlateFrame, envTable.configAltCastBar, 4.30, GetTime(), 191284)\n                C_Timer.After(4.50, function() unitFrame.castBar2:Hide() end)\n        end)\n    end\n    \nend",
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Time"] = 1671066705,
					["url"] = "",
					["Icon"] = 134229,
					["Enabled"] = true,
					["Revision"] = 37,
					["semver"] = "",
					["Author"] = "Huugg-Valdrakken",
					["Initialization"] = "		function (scriptTable)\n			--insert code here\n			\n		end\n	",
					["Desc"] = "Start extra cast bars for effects after the cast is done. Setup the effect on On Hide script.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						191284, -- [1]
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - Effect After Cast [P]",
					["version"] = -1,
					["Options"] = {
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
				}, -- [2]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --settings\n    envTable.NameplateSizeOffset = scriptTable.config.castBarHeight\n    envTable.ShowArrow = scriptTable.config.showArrow\n    envTable.ArrowAlpha = scriptTable.config.arrowAlpha\n    \n    --creates the spark to show the cast progress inside the health bar\n    envTable.overlaySpark = envTable.overlaySpark or Plater:CreateImage (unitFrame.healthBar)\n    envTable.overlaySpark:SetBlendMode (\"ADD\")\n    envTable.overlaySpark.width = 16\n    envTable.overlaySpark.height = 36\n    envTable.overlaySpark.alpha = .9\n    envTable.overlaySpark.texture = [[Interface\\AddOns\\Plater\\images\\spark3]]\n    \n    envTable.topArrow = envTable.topArrow or Plater:CreateImage (unitFrame.healthBar)\n    envTable.topArrow:SetBlendMode (\"ADD\")\n    envTable.topArrow.width = scriptTable.config.arrowWidth\n    envTable.topArrow.height = scriptTable.config.arrowHeight\n    envTable.topArrow.alpha = envTable.ArrowAlpha\n    envTable.topArrow.texture = [[Interface\\BUTTONS\\Arrow-Down-Up]]\n    \n    --scale animation\n    envTable.smallScaleAnimation = envTable.smallScaleAnimation or Plater:CreateAnimationHub (unitFrame.healthBar)\n    Plater:CreateAnimation (envTable.smallScaleAnimation, \"SCALE\", 1, 0.075, 1, 1, 1.08, 1.08)\n    Plater:CreateAnimation (envTable.smallScaleAnimation, \"SCALE\", 2, 0.075, 1, 1, 0.95, 0.95)    \n    --envTable.smallScaleAnimation:Play() --envTable.smallScaleAnimation:Stop()\n    \nend\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    Plater.StopDotAnimation(unitFrame.healthBar, envTable.dotAnimation)\n    \n    envTable.overlaySpark:Hide()\n    envTable.topArrow:Hide()\n    \n    Plater.RefreshNameplateColor (unitFrame)\n    \n    envTable.smallScaleAnimation:Stop()\n    \n    --increase the nameplate size\n    local nameplateHeight = Plater.db.profile.plate_config.enemynpc.health_incombat [2]\n    unitFrame.healthBar:SetHeight (nameplateHeight)\n    \n    Plater.DenyColorChange(unitFrame, false)\nend\n\n\n",
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --update the percent\n    envTable.overlaySpark:SetPoint (\"left\", unitFrame.healthBar:GetWidth() * (envTable._CastPercent / 100)-9, 0)\n    \n    envTable.topArrow:SetPoint (\"bottomleft\", unitFrame.healthBar, \"topleft\", unitFrame.healthBar:GetWidth() * (envTable._CastPercent / 100) - 4, 2 )\n    \n    --forces the script to run the update as fast as the game framerate\n    self.ThrottleUpdate = 0\n    \n    if (scriptTable.config.useNameplateColor) then\n        Plater.SetNameplateColor(unitFrame, envTable.NameplateColor)\n    end\n    \n    local dotSpeed = abs(envTable._Duration - envTable._RemainingTime) + 1.5\n    envTable.dotAnimation.textureInfo.speedMultiplier = dotSpeed\nend\n\n\n\n\n",
					["Time"] = 1670201853,
					["url"] = "",
					["Icon"] = 2175503,
					["Enabled"] = true,
					["Revision"] = 533,
					["semver"] = "",
					["Author"] = "Bombad�o-Azralon",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Apply several animations when the explosion orb cast starts on a Mythic Dungeon with Explosion Affix",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						240446, -- [1]
						385339, -- [2]
						198077, -- [3]
						210261, -- [4]
						360857, -- [5]
					},
					["PlaterCore"] = 1,
					["Name"] = "Explosion Affix M+ [Plater]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 2,
							["Max"] = 6,
							["Desc"] = "Increases the cast bar height by this value",
							["Min"] = 0,
							["Fraction"] = false,
							["Value"] = 3,
							["Key"] = "castBarHeight",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Cast Bar Height Mod",
						}, -- [1]
						{
							["Type"] = 1,
							["Name"] = "Cast Bar Color",
							["Value"] = {
								1, -- [1]
								0.5843137254901961, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "castBarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Changes the cast bar color to this one.",
						}, -- [2]
						{
							["Type"] = 6,
							["Name"] = "Option 7",
							["Value"] = 0,
							["Key"] = "option7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 5,
							["Name"] = "Arrow:",
							["Value"] = "Arrow:",
							["Key"] = "option6",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 4,
							["Name"] = "Show Arrow",
							["Value"] = true,
							["Key"] = "showArrow",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Show an arrow above the nameplate showing the cast bar progress.",
						}, -- [5]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Arrow alpha.",
							["Min"] = 0,
							["Fraction"] = true,
							["Value"] = 1,
							["Key"] = "arrowAlpha",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Arrow Alpha",
						}, -- [6]
						{
							["Type"] = 2,
							["Max"] = 12,
							["Desc"] = "Arrow Width.",
							["Min"] = 4,
							["Name"] = "Arrow Width",
							["Value"] = 8,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "arrowWidth",
						}, -- [7]
						{
							["Type"] = 2,
							["Max"] = 12,
							["Desc"] = "Arrow Height.",
							["Min"] = 4,
							["Fraction"] = false,
							["Value"] = 8,
							["Key"] = "arrowHeight",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Arrow Height",
						}, -- [8]
						{
							["Type"] = 6,
							["Name"] = "Option 13",
							["Value"] = 0,
							["Key"] = "option13",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [9]
						{
							["Type"] = 5,
							["Name"] = "Dot Animation:",
							["Value"] = "Dot Animation:",
							["Key"] = "option12",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [10]
						{
							["Type"] = 1,
							["Name"] = "Dot Color",
							["Value"] = {
								1, -- [1]
								0.615686274509804, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "dotColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Adjust the color of the dot animation.",
						}, -- [11]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Dot X Offset",
							["Min"] = -10,
							["Name"] = "Dot X Offset",
							["Value"] = 4,
							["Key"] = "xOffset",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [12]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Dot Y Offset",
							["Min"] = -10,
							["Key"] = "yOffset",
							["Value"] = 3,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Dot Y Offset",
						}, -- [13]
						{
							["Type"] = 6,
							["Key"] = "option18",
							["Value"] = 0,
							["Name"] = "Option 18",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [14]
						{
							["Type"] = 5,
							["Key"] = "option17",
							["Value"] = "Nameplate Color",
							["Name"] = "Nameplate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [15]
						{
							["Type"] = 4,
							["Name"] = "Change Nameplate Color",
							["Value"] = false,
							["Key"] = "useNameplateColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Change Nameplate Color",
						}, -- [16]
						{
							["Type"] = 1,
							["Key"] = "healthBarColor",
							["Value"] = {
								1, -- [1]
								0.1843137294054031, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Nameplate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Health Bar Color",
						}, -- [17]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.overlaySpark:Show()\n    \n    if (envTable.ShowArrow) then\n        envTable.topArrow:Show()\n    end\n    \n    Plater.FlashNameplateBorder (unitFrame, 0.05)   \n    Plater.FlashNameplateBody (unitFrame, \"\", 0.075)\n    \n    envTable.smallScaleAnimation:Play()\n    \n    --increase the nameplate size\n    local nameplateHeight = Plater.db.profile.plate_config.enemynpc.health_incombat [2]\n    unitFrame.healthBar:SetHeight (nameplateHeight + envTable.NameplateSizeOffset)\n    \n    envTable.overlaySpark.height = nameplateHeight + 5\n    \n    envTable.dotAnimation = Plater.PlayDotAnimation(unitFrame.healthBar, 2, scriptTable.config.dotColor, scriptTable.config.xOffset, scriptTable.config.yOffset)\n    \n    Plater.SetCastBarColorForScript(self, true, scriptTable.config.castBarColor, envTable)\n    \n    if (scriptTable.config.useNameplateColor) then\n        envTable.NameplateColor = Plater.GetColorByPriority(unitFrame, scriptTable.config.healthBarColor)\n        Plater.DenyColorChange(unitFrame, true)\n    end       \nend\n\n\n\n\n\n\n",
				}, -- [3]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --creates a glow around the icon\n    envTable.buffIconGlow = envTable.buffIconGlow or Plater.CreateIconGlow (self, scriptTable.config.glowColor)\n    \nend\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (scriptTable.config.glowEnabled) then\n        envTable.buffIconGlow:Hide()\n    end\n    \n    if (scriptTable.config.dotsEnabled) then\n        Plater.StopDotAnimation(self, envTable.dotAnimation)\n    end\n    \n    \nend\n\n\n",
					["ScriptType"] = 1,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    \nend\n\n\n",
					["Time"] = 1669327144,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\icon_aura",
					["Enabled"] = true,
					["Revision"] = 368,
					["semver"] = "",
					["Author"] = "Tercioo-Sylvanas",
					["Desc"] = "Add the debuff name in the trigger box.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Aura - Debuff Alert [Plater]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Enter the spell name or spellID of the Buff in the Add Trigger box and hit \"Add\".",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option3",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 4,
							["Name"] = "Glow Enabled",
							["Value"] = false,
							["Key"] = "glowEnabled",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 1,
							["Name"] = "Glow Color",
							["Value"] = {
								0.403921568627451, -- [1]
								0.00392156862745098, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "glowColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [5]
						{
							["Type"] = 6,
							["Key"] = "option3",
							["Value"] = 0,
							["Name"] = "Blank Space",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [6]
						{
							["Type"] = 4,
							["Name"] = "Dots Enabled",
							["Value"] = true,
							["Key"] = "dotsEnabled",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [7]
						{
							["Type"] = 1,
							["Key"] = "dotsColor",
							["Value"] = {
								1, -- [1]
								0.3215686274509804, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Dots Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [8]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    if (scriptTable.config.glowEnabled) then\n        envTable.buffIconGlow:Show()\n    end\n    \n    if (scriptTable.config.dotsEnabled) then\n        envTable.dotAnimation = Plater.PlayDotAnimation(self, 6, scriptTable.config.dotsColor, 6, 3) \n    end\nend\n\n\n",
				}, -- [4]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --castbar color (when can be interrupted)\n    envTable.CastbarColor = scriptTable.config.castbarColor\n    \n    --flash duration\n    local CONFIG_BACKGROUND_FLASH_DURATION = scriptTable.config.flashDuration\n    \n    --add this value to the cast bar height\n    envTable.CastBarHeightAdd = scriptTable.config.castBarHeight\n    \n    --create a fast flash above the cast bar\n    envTable.FullBarFlash = envTable.FullBarFlash or Plater.CreateFlash (self, 0.05, 1, \"white\")\n    \n    --create a camera shake for the nameplate\n    envTable.FrameShake = Plater:CreateFrameShake (unitFrame, scriptTable.config.shakeDuration, scriptTable.config.shakeAmplitude, scriptTable.config.shakeFrequency, false, false, 0, 1, 0.05, 0.1, Plater.GetPoints (unitFrame))\n    \n    --create a texture to use for a flash behind the cast bar\n    local backGroundFlashTexture = Plater:CreateImage (self, [[Interface\\ACHIEVEMENTFRAME\\UI-Achievement-Alert-Glow]], self:GetWidth()+60, self:GetHeight()+50, \"background\", {0, 400/512, 0, 170/256})\n    backGroundFlashTexture:SetBlendMode (\"ADD\", 7)\n    backGroundFlashTexture:SetDrawLayer(\"OVERLAY\", 7)\n    backGroundFlashTexture:SetPoint (\"center\", self, \"center\")\n    backGroundFlashTexture:Hide()\n    \n    --create the animation hub to hold the flash animation sequence\n    envTable.BackgroundFlash = envTable.BackgroundFlash or Plater:CreateAnimationHub (backGroundFlashTexture, \n        function()\n            backGroundFlashTexture:Show()\n        end,\n        function()\n            backGroundFlashTexture:Hide()\n        end\n    )\n    \n    --create the flash animation sequence\n    envTable.BackgroundFlash.fadeIn = envTable.BackgroundFlash.fadeIn or Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 1, CONFIG_BACKGROUND_FLASH_DURATION/2, 0, .75)\n    envTable.BackgroundFlash.fadeIn:SetDuration(CONFIG_BACKGROUND_FLASH_DURATION/2)\n    \n    envTable.BackgroundFlash.fadeOut = envTable.BackgroundFlash.fadeOut or Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 2, CONFIG_BACKGROUND_FLASH_DURATION/2, 1, 0)    \n    envTable.BackgroundFlash.fadeOut:SetDuration(CONFIG_BACKGROUND_FLASH_DURATION/2)\n    \n    --envTable.BackgroundFlash:Play() --envTable.BackgroundFlash:Stop()    \n    \n    \n    \n    \n    \nend\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    unitFrame.castBar:SetHeight (envTable._DefaultHeight)\n    \n    --stop the camera shake\n    unitFrame:StopFrameShake (envTable.FrameShake)\n    \n    envTable.FullBarFlash:Stop()\n    envTable.BackgroundFlash:Stop()\n    \n    unitFrame.castBar.Spark:SetHeight(unitFrame.castBar:GetHeight())\n    \n    --check if there's a timer for this spell\n    local timer = scriptTable.config.timerList[tostring(envTable._SpellID)]\n    \n    if (timer) then\n        --insert code here\n        \n        --set the castbar config\n        local config = {\n            iconTexture = \"\",\n            iconTexcoord = {0.1, 0.9, 0.1, 0.9},\n            iconAlpha = 1,\n            iconSize = 14,\n            \n            text = \"Spikes Incoming!\",\n            textSize = 8,\n            \n            texture = [[Interface\\AddOns\\Plater\\images\\bar_background]],\n            color = {.6, .6, .6, 0.8},\n            \n            isChanneling = false,\n            canInterrupt = false,\n            \n            height = 5,\n            width = Plater.db.profile.plate_config.enemynpc.health_incombat[1],\n            \n            spellNameAnchor = {side = 3, x = 0, y = -2},\n            timerAnchor = {side = 5, x = 0, y = -2},\n        }\n        \n        Plater.SetAltCastBar(unitFrame.PlateFrame, config, timer, nil, nil)\n        local castBar2 = unitFrame.castBar2\n        castBar2.Text:ClearAllPoints()\n        castBar2.Text:SetPoint (\"topleft\", castBar2, \"bottomleft\", 0, 0)\n        castBar2.percentText:ClearAllPoints()\n        castBar2.percentText:SetPoint (\"topright\", castBar2, \"bottomright\", 0, 0)\n        Plater:SetFontSize(castBar2.percentText, 8)\n    end\n    \nend\n\n\n\n\n\n\n\n",
					["OptionsValues"] = {
					},
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \nend\n\n\n",
					["Time"] = 1670203758,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_orange",
					["Enabled"] = true,
					["Revision"] = 1213,
					["semver"] = "",
					["Author"] = "Tercioo-Sylvanas",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend",
					["Desc"] = "Player an animation when the cast start. Start a timer when the cast finishes. Set the time in the options.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						350421, -- [1]
						355787, -- [2]
						348513, -- [3]
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - Alert + Timer [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Name"] = "Blank Line",
							["Value"] = 0,
							["Key"] = "option1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Cast start animation settings",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 4,
							["Name"] = "Cast Bar Color Enabled",
							["Value"] = true,
							["Key"] = "useCastbarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "When enabled, changes the cast bar color,",
						}, -- [4]
						{
							["Type"] = 1,
							["Name"] = "Cast Bar Color",
							["Value"] = {
								1, -- [1]
								0.4313725490196079, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "castbarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Color of the cast bar.",
						}, -- [5]
						{
							["Type"] = 6,
							["Name"] = "Blank Line",
							["Value"] = 0,
							["Key"] = "option7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [6]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "When the cast starts it flash rapidly, adjust how fast it flashes. Value is milliseconds.",
							["Min"] = 0.05,
							["Key"] = "flashDuration",
							["Value"] = 0.4,
							["Name"] = "Flash Duration",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [7]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Increases the cast bar height by this value",
							["Min"] = 0,
							["Key"] = "castBarHeight",
							["Value"] = 5,
							["Name"] = "Cast Bar Height Mod",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [8]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "When the cast starts, there's a small shake in the nameplate, this settings controls how long it takes.",
							["Min"] = 0.1,
							["Key"] = "shakeDuration",
							["Value"] = 0.2,
							["Name"] = "Shake Duration",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [9]
						{
							["Type"] = 2,
							["Max"] = 100,
							["Desc"] = "How strong is the shake.",
							["Min"] = 2,
							["Key"] = "shakeAmplitude",
							["Value"] = 8,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Shake Amplitude",
						}, -- [10]
						{
							["Type"] = 2,
							["Max"] = 80,
							["Desc"] = "How fast the shake moves.",
							["Min"] = 1,
							["Key"] = "shakeFrequency",
							["Value"] = 40,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Shake Frequency",
						}, -- [11]
						{
							["Type"] = 7,
							["Key"] = "timerList",
							["Value"] = {
							},
							["Name"] = "Timer (Key is SpellId and Value is Time)",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_list",
							["Desc"] = "Key is the spellId and value is the amount of time of the Timer",
						}, -- [12]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --play flash animations\n    envTable.FullBarFlash:Play()\n    \n    --envTable.currentHeight = unitFrame.castBar:GetHeight()\n    \n    --restoring the default size (not required since it already restore in the hide script)\n    if (envTable.OriginalHeight) then\n        self:SetHeight (envTable.OriginalHeight)\n    end\n    \n    --increase the cast bar size\n    local height = self:GetHeight()\n    envTable.OriginalHeight = height\n    \n    self:SetHeight (height + envTable.CastBarHeightAdd)\n    \n    Plater.SetCastBarBorderColor (self, 1, .2, .2, 0.4)\n    \n    unitFrame:PlayFrameShake (envTable.FrameShake)\n    \n    Plater.SetCastBarColorForScript(self, scriptTable.config.useCastbarColor, scriptTable.config.castbarColor, envTable)\n    \n    envTable.BackgroundFlash:Play()\n    \n    unitFrame.castBar.Spark:SetHeight(unitFrame.castBar:GetHeight())\n    \nend\n\n\n\n\n\n\n\n\n\n\n",
				}, -- [5]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --settings\n    envTable.NameplateSizeOffset = scriptTable.config.castBarHeight\n    envTable.ShowArrow = scriptTable.config.showArrow\n    envTable.ArrowAlpha = scriptTable.config.arrowAlpha\n    \n    --creates the spark to show the cast progress inside the health bar\n    envTable.overlaySpark = envTable.overlaySpark or Plater:CreateImage (unitFrame.healthBar)\n    envTable.overlaySpark:SetBlendMode (\"ADD\")\n    envTable.overlaySpark.width = 16\n    envTable.overlaySpark.height = 36\n    envTable.overlaySpark.alpha = .9\n    envTable.overlaySpark.texture = [[Interface\\AddOns\\Plater\\images\\spark3]]\n    \n    envTable.topArrow = envTable.topArrow or Plater:CreateImage (unitFrame.healthBar)\n    envTable.topArrow:SetBlendMode (\"ADD\")\n    envTable.topArrow.width = scriptTable.config.arrowWidth\n    envTable.topArrow.height = scriptTable.config.arrowHeight\n    envTable.topArrow.alpha = envTable.ArrowAlpha\n    envTable.topArrow.texture = [[Interface\\BUTTONS\\Arrow-Down-Up]]\n    \n    --scale animation\n    envTable.smallScaleAnimation = envTable.smallScaleAnimation or Plater:CreateAnimationHub (unitFrame.healthBar)\n    Plater:CreateAnimation (envTable.smallScaleAnimation, \"SCALE\", 1, 0.075, 1, 1, 1.08, 1.08)\n    Plater:CreateAnimation (envTable.smallScaleAnimation, \"SCALE\", 2, 0.075, 1, 1, 0.95, 0.95)    \n    --envTable.smallScaleAnimation:Play() --envTable.smallScaleAnimation:Stop()\n    \n    --create a camera shake for the nameplate\n    envTable.FrameShake = Plater:CreateFrameShake (unitFrame, scriptTable.config.shakeDuration, scriptTable.config.shakeAmplitude, scriptTable.config.shakeFrequency, false, false, 0, 1, 0.05, 0.1, Plater.GetPoints (unitFrame))    \n    \n    --update the config for the skake here so it wont need a /reload\n    envTable.FrameShake.OriginalAmplitude = scriptTable.config.shakeAmplitude\n    envTable.FrameShake.OriginalDuration = scriptTable.config.shakeDuration\n    envTable.FrameShake.OriginalFrequency = scriptTable.config.shakeFrequency\nend\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    Plater.StopDotAnimation(unitFrame.healthBar, envTable.dotAnimation)\n    \n    envTable.overlaySpark:Hide()\n    envTable.topArrow:Hide()\n    \n    Plater.RefreshNameplateColor (unitFrame)\n    \n    envTable.smallScaleAnimation:Stop()\n    \n    --increase the nameplate size\n    local nameplateHeight = Plater.db.profile.plate_config.enemynpc.health_incombat [2]\n    unitFrame.healthBar:SetHeight (nameplateHeight)\n    \n    Plater.DenyColorChange(unitFrame, false)\nend\n\n\n",
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --update the percent\n    envTable.overlaySpark:SetPoint (\"left\", unitFrame.healthBar:GetWidth() * (envTable._CastPercent / 100)-9, 0)\n    \n    envTable.topArrow:SetPoint (\"bottomleft\", unitFrame.healthBar, \"topleft\", unitFrame.healthBar:GetWidth() * (envTable._CastPercent / 100) - 4, 2 )\n    \n    --forces the script to update on a 60Hz base\n    self.ThrottleUpdate = 0\n    \n    if (scriptTable.config.useNameplateColor) then\n        Plater.SetNameplateColor(unitFrame, envTable.NameplateColor)\n    end\n    \nend\n\n\n\n\n",
					["Time"] = 1670790652,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_red",
					["Enabled"] = true,
					["Revision"] = 694,
					["semver"] = "",
					["Author"] = "Bombad�o-Azralon",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Used on casts that make the mob explode or transform if the cast passes.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						383823, -- [1]
						382670, -- [2]
						388537, -- [3]
						372851, -- [4]
						200682, -- [5]
						192307, -- [6]
						196838, -- [7]
						193827, -- [8]
						194043, -- [9]
						209410, -- [10]
						211464, -- [11]
						361180, -- [12]
						156718, -- [13]
						395859, -- [14]
						358320, -- [15]
						374045, -- [16]
						386757, -- [17]
						367500, -- [18]
						370225, -- [19]
						376200, -- [20]
						372107, -- [21]
						388923, -- [22]
						376934, -- [23]
						384899, -- [24]
						373960, -- [25]
						374724, -- [26]
						385551, -- [27]
						259732, -- [28]
						373424, -- [29]
						373084, -- [30]
						87618, -- [31]
						255041, -- [32]
						428926, -- [33]
						76634, -- [34]
						200050, -- [35]
						197546, -- [36]
						198079, -- [37]
						199193, -- [38]
						266181, -- [39]
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - Ultra Important [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Key"] = "option1",
							["Value"] = 0,
							["Name"] = "Option 1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Key"] = "option2",
							["Value"] = "Plays a special animation showing the explosion time.",
							["Name"] = "Option 2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 6,
							["Key"] = "option3",
							["Value"] = 0,
							["Name"] = "Option 3",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 2,
							["Max"] = 6,
							["Desc"] = "Increases the health bar height by this value",
							["Min"] = 0,
							["Key"] = "castBarHeight",
							["Value"] = 3,
							["Name"] = "Health Bar Height Mod",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [4]
						{
							["Type"] = 4,
							["Key"] = "useNameplateColor",
							["Value"] = true,
							["Name"] = "Change Nameplate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Change Nameplate Color",
						}, -- [5]
						{
							["Type"] = 1,
							["Key"] = "healthBarColor",
							["Value"] = {
								1, -- [1]
								0.5843137254901961, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Nameplate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Nameplate Color",
						}, -- [6]
						{
							["Type"] = 6,
							["Key"] = "option7",
							["Value"] = 0,
							["Name"] = "Option 7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [7]
						{
							["Type"] = 4,
							["Name"] = "Use Cast Bar Color",
							["Value"] = true,
							["Key"] = "useCastbarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Show an arrow above Use Cast Bar Color",
						}, -- [8]
						{
							["Type"] = 1,
							["Name"] = "Cast Bar Color",
							["Value"] = {
								1, -- [1]
								0.431372, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "castBarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Cast Bar Color",
						}, -- [9]
						{
							["Type"] = 6,
							["Name"] = "Option 7",
							["Value"] = 0,
							["Key"] = "option7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [10]
						{
							["Type"] = 5,
							["Key"] = "option6",
							["Value"] = "Arrow:",
							["Name"] = "Arrow:",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [11]
						{
							["Type"] = 4,
							["Name"] = "Show Arrow",
							["Value"] = true,
							["Key"] = "showArrow",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Show an arrow above the nameplate showing the cast bar progress.",
						}, -- [12]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Arrow alpha.",
							["Min"] = 0,
							["Key"] = "arrowAlpha",
							["Value"] = 0.5,
							["Name"] = "Arrow Alpha",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [13]
						{
							["Type"] = 2,
							["Max"] = 12,
							["Desc"] = "Arrow Width.",
							["Min"] = 4,
							["Fraction"] = false,
							["Value"] = 8,
							["Key"] = "arrowWidth",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Arrow Width",
						}, -- [14]
						{
							["Type"] = 2,
							["Max"] = 12,
							["Desc"] = "Arrow Height.",
							["Min"] = 4,
							["Key"] = "arrowHeight",
							["Value"] = 8,
							["Name"] = "Arrow Height",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [15]
						{
							["Type"] = 6,
							["Key"] = "option13",
							["Value"] = 0,
							["Name"] = "Option 13",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [16]
						{
							["Type"] = 5,
							["Key"] = "option12",
							["Value"] = "Dot Animation:",
							["Name"] = "Dot Animation:",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [17]
						{
							["Type"] = 1,
							["Key"] = "dotColor",
							["Value"] = {
								1, -- [1]
								0.615686274509804, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Dot Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Adjust the color of the dot animation.",
						}, -- [18]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Dot X Offset",
							["Min"] = -10,
							["Key"] = "xOffset",
							["Value"] = 4,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Dot X Offset",
						}, -- [19]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Dot Y Offset",
							["Min"] = -10,
							["Fraction"] = false,
							["Value"] = 3,
							["Name"] = "Dot Y Offset",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "yOffset",
						}, -- [20]
						{
							["Type"] = 7,
							["Key"] = "castColor",
							["Value"] = {
								{
									"200682", -- [1]
									"darkslateblue", -- [2]
								}, -- [1]
								{
									"192307", -- [1]
									"goldenrod", -- [2]
								}, -- [2]
								{
									"196838", -- [1]
									"maroon", -- [2]
								}, -- [3]
								{
									"193827", -- [1]
									"darkgreen", -- [2]
								}, -- [4]
								{
									"194043", -- [1]
									"darkgreen", -- [2]
								}, -- [5]
								{
									"156718", -- [1]
									"DRUID", -- [2]
								}, -- [6]
								{
									"395859", -- [1]
									"ROGUE", -- [2]
								}, -- [7]
							},
							["Name"] = "Color List by SpellId",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_list",
							["Desc"] = "Insert the spellId in the Key, and the color name in the Value",
						}, -- [21]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    envTable.overlaySpark:Show()\n    \n    if (envTable.ShowArrow) then\n        envTable.topArrow:Show()\n    else\n        envTable.topArrow:Hide()\n    end\n    \n    Plater.FlashNameplateBorder (unitFrame, 0.05)   \n    Plater.FlashNameplateBody (unitFrame, \"\", 0.075)\n    \n    envTable.smallScaleAnimation:Play()\n    \n    --increase the nameplate size\n    local nameplateHeight = Plater.db.profile.plate_config.enemynpc.health_incombat [2]\n    unitFrame.healthBar:SetHeight (nameplateHeight + envTable.NameplateSizeOffset)\n    \n    envTable.overlaySpark.height = nameplateHeight + 5\n    \n    envTable.dotAnimation = Plater.PlayDotAnimation(unitFrame.healthBar, 2, scriptTable.config.dotColor, scriptTable.config.xOffset, scriptTable.config.yOffset)\n    \n    local customColor = scriptTable.config.castColor[tostring(envTable._SpellID)]\n    \n    Plater.SetCastBarColorForScript(self, scriptTable.config.useCastbarColor, customColor or scriptTable.config.castBarColor, envTable)\n    \n    if (scriptTable.config.useNameplateColor) then\n        local npcIdString = tostring(envTable._NpcID)\n        envTable.NameplateColor = Plater.GetColorByPriority(unitFrame, scriptTable.config.healthBarColor)        \n        Plater.DenyColorChange(unitFrame, true)            \n    end\n    \nend",
				}, -- [6]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    envTable.lifePercent = { --dragonflight\n        [197697] = {50}, --Flamegullet\n        [59544] = {50}, --The Nodding Tiger\n        [186227] = {20}, --Monstrous Decay\n        [184020] = {40}, -- Hulking Berserker\n        [91005] = {20}, --Naraxas\n    }\n    \n    \n    function envTable.CreateMarker(unitFrame)\n        unitFrame.healthMarker = unitFrame.healthBar:CreateTexture(nil, \"overlay\")\n        unitFrame.healthMarker:SetColorTexture(1, 1, 1)\n        unitFrame.healthMarker:SetSize(1, unitFrame.healthBar:GetHeight())\n        \n        unitFrame.healthOverlay = unitFrame.healthBar:CreateTexture(nil, \"overlay\")\n        unitFrame.healthOverlay:SetColorTexture(1, 1, 1)\n        unitFrame.healthOverlay:SetSize(1, unitFrame.healthBar:GetHeight())\n    end\n    \n    function envTable.UpdateMarkers(unitFrame)\n        local markersTable = envTable.lifePercent[envTable._NpcID]\n        if (markersTable) then\n            local unitLifePercent = envTable._HealthPercent / 100\n            for i, percent in ipairs(markersTable) do\n                percent = percent / 100\n                if (unitLifePercent > percent) then\n                    if (not unitFrame.healthMarker) then\n                        envTable.CreateMarker(unitFrame)\n                    end\n                    \n                    unitFrame.healthMarker:Show()\n                    local width = unitFrame.healthBar:GetWidth()\n                    unitFrame.healthMarker:SetPoint(\"left\", unitFrame.healthBar, \"left\", width*percent, 0)\n                    \n                    local overlaySize = width * (unitLifePercent - percent)\n                    unitFrame.healthOverlay:SetWidth(overlaySize)\n                    unitFrame.healthOverlay:SetPoint(\"left\", unitFrame.healthMarker, \"right\", 0, 0)\n                    \n                    unitFrame.healthMarker:SetVertexColor(Plater:ParseColors(scriptTable.config.indicatorColor))\n                    unitFrame.healthMarker:SetAlpha(scriptTable.config.indicatorAlpha)\n                    \n                    unitFrame.healthOverlay:SetVertexColor(Plater:ParseColors(scriptTable.config.fillColor))\n                    unitFrame.healthOverlay:SetAlpha(scriptTable.config.fillAlpha)\n                    \n                    return\n                end\n            end --end for\n            \n            if (unitFrame.healthMarker and unitFrame.healthMarker:IsShown()) then\n                unitFrame.healthMarker:Hide()\n                unitFrame.healthOverlay:Hide()\n            end\n        end\n    end\nend      \n\n\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    if (unitFrame.healthMarker) then\n        unitFrame.healthMarker:Hide()\n        unitFrame.healthOverlay:Hide()\n    end\nend\n\n\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    envTable.UpdateMarkers(unitFrame)\nend\n\n\n",
					["Time"] = 1683596223,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\health_indicator",
					["Enabled"] = true,
					["Revision"] = 146,
					["semver"] = "",
					["Author"] = "Aelerolor-Torghast",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Place a marker into the health bar to indicate when the unit will change phase or cast an important spell.",
					["NpcNames"] = {
						"197697", -- [1]
						"59544", -- [2]
						"186227", -- [3]
						"184020", -- [4]
						"91005", -- [5]
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Add - Health Markers [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 5,
							["Name"] = "Option 1",
							["Value"] = "Add markers into the health bar to remind you about boss abilities at life percent.",
							["Key"] = "option1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 6,
							["Name"] = "blank line",
							["Value"] = 0,
							["Key"] = "",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 1,
							["Name"] = "Vertical Line Color",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Key"] = "indicatorColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Indicator color.",
						}, -- [3]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Indicator alpha.",
							["Min"] = 0.1,
							["Key"] = "indicatorAlpha",
							["Value"] = 0.79,
							["Name"] = "Vertical Line Alpha",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [4]
						{
							["Type"] = 6,
							["Key"] = "",
							["Value"] = 0,
							["Name"] = "blank line",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [5]
						{
							["Type"] = 1,
							["Key"] = "fillColor",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Name"] = "Fill Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Fill color.",
						}, -- [6]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Fill alpha.",
							["Min"] = 0,
							["Name"] = "Fill Alpha",
							["Value"] = 0.2,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "fillAlpha",
						}, -- [7]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    envTable.UpdateMarkers(unitFrame)\nend\n\n\n",
				}, -- [7]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --flash duration\n    local CONFIG_FLASH_DURATION = scriptTable.config.flashDuration\n    \n    --manually create a new texture for the flash animation\n    if (not envTable.SmallFlashTexture) then\n        envTable.SmallFlashTexture = envTable.SmallFlashTexture or Plater:CreateImage (unitFrame.castBar)\n        envTable.SmallFlashTexture:SetColorTexture (1, 1, 1)\n        envTable.SmallFlashTexture:SetAllPoints()\n    end\n    \n    --manually create a flash animation using the framework\n    if (not envTable.SmallFlashAnimationHub) then \n        \n        local onPlay = function()\n            envTable.SmallFlashTexture:Show()\n        end\n        \n        local onFinished = function()\n            envTable.SmallFlashTexture:Hide()\n        end\n        \n        local animationHub = Plater:CreateAnimationHub (envTable.SmallFlashTexture, onPlay, onFinished)\n        envTable.flashIn = Plater:CreateAnimation (animationHub, \"Alpha\", 1, CONFIG_FLASH_DURATION/2, 0, .6)\n        envTable.flashOut = Plater:CreateAnimation (animationHub, \"Alpha\", 2, CONFIG_FLASH_DURATION/2, 1, 0)\n        \n        envTable.SmallFlashAnimationHub = animationHub\n    end\n    \n    envTable.flashIn:SetDuration(scriptTable.config.flashDuration / 2)\n    envTable.flashOut:SetDuration(scriptTable.config.flashDuration / 2)\n    envTable.SmallFlashTexture:SetColorTexture (Plater:ParseColors(scriptTable.config.flashColor))\n    \nend\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    envTable.SmallFlashAnimationHub:Stop()\n    \nend\n\n\n",
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    \n    \nend\n\n\n",
					["Time"] = 1669325410,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar",
					["Enabled"] = true,
					["Revision"] = 662,
					["semver"] = "",
					["Author"] = "Tercioo-Sylvanas",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Flashes the Cast Bar when a spell in the trigger list is Cast. Add spell in the Add Trigger field.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						376851, -- [1]
						396044, -- [2]
						381517, -- [3]
						373932, -- [4]
						397801, -- [5]
						208165, -- [6]
						392576, -- [7]
						198750, -- [8]
						387843, -- [9]
						387411, -- [10]
						211299, -- [11]
						198595, -- [12]
						198934, -- [13]
						198962, -- [14]
						156722, -- [15]
						350554, -- [16]
						348513, -- [17]
						351779, -- [18]
						328180, -- [19]
						319898, -- [20]
						281420, -- [21]
						274383, -- [22]
						259092, -- [23]
						367521, -- [24]
						374544, -- [25]
						385039, -- [26]
						382474, -- [27]
						369823, -- [28]
						377500, -- [29]
						260879, -- [30]
						186269, -- [31]
						378818, -- [32]
						371875, -- [33]
						372225, -- [34]
						200658, -- [35]
						266036, -- [36]
						265407, -- [37]
						164965, -- [38]
						429176, -- [39]
						428526, -- [40]
						418200, -- [41]
						407124, -- [42]
						415437, -- [43]
						264050, -- [44]
						267824, -- [45]
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - Small Alert [Plater]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Name"] = "Option 1",
							["Value"] = 0,
							["Key"] = "option1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Plays a small animation when the cast start.",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 5,
							["Key"] = "option2",
							["Value"] = "Enter the spell name or spellID of the Spell in the Add Trigger box and hit \"Add\".",
							["Name"] = "Option 2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 6,
							["Name"] = "Option 3",
							["Value"] = 0,
							["Key"] = "option3",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 2,
							["Max"] = 1.2,
							["Desc"] = "How long is the flash played when the cast starts.",
							["Min"] = 0.1,
							["Name"] = "Flash Duration",
							["Value"] = 0.6,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "flashDuration",
						}, -- [5]
						{
							["Type"] = 1,
							["Name"] = "Flash Color",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Key"] = "flashColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Color of the Flash",
						}, -- [6]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    envTable.SmallFlashAnimationHub:Play()\n    \nend\n\n\n",
				}, -- [8]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.NameplateColor = scriptTable.config.nameplateColor\n    envTable.NameplateSizeOffset = scriptTable.config.nameplateSizeOffset\n    \n    unitFrame.UnitImportantSkullTexture = unitFrame.UnitImportantSkullTexture or unitFrame:CreateTexture(nil, \"background\")\n    \n    unitFrame.UnitImportantSkullTexture:Hide()\nend\n\n--[=[\n\n154564 - debug\n\nUsing spellIDs for multi-language support\n\n196548 = ancient branch (academy dungeon)\n195580, 195821, 195820 = nokhub saboteur\n189886 = blazebound firestorm\n75966 = Defiled Spirit\n102019 = Stormforged Obliterator\n    187159 = Shrieking Whelp\n194897 = stormsurge totem\n104251 = duskwatch sentry\n101326 = honored ancestor\n189669 = binding speakl netharius\n192464 = raging ember neltharius\n--]=]\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable)\n    Plater.StopDotAnimation(unitFrame.healthBar, envTable.dotAnimation)   \n    \n    --restore the nameplate size\n    local nameplateHeight = Plater.db.profile.plate_config.enemynpc.health_incombat [2]\n    unitFrame.healthBar:SetHeight (nameplateHeight)    \n    \n    unitFrame.UnitImportantSkullTexture:Hide()\n    Plater.DenyColorChange(unitFrame, false)\nend\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --check if can change the nameplate color\n    if (scriptTable.config.changeNameplateColor) then\n        Plater.SetNameplateColor(unitFrame, envTable.NameplateColor)\n    end\n    \nend\n\n\n\n\n",
					["Time"] = 1670423785,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\media\\skullbones_64",
					["Enabled"] = true,
					["Revision"] = 572,
					["semver"] = "",
					["Author"] = "Izimode-Azralon",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Change the color and highlight a nameplate of an important Add. Add the unit name or NpcID into the trigger box to add more.",
					["NpcNames"] = {
						"196548", -- [1]
						"195580", -- [2]
						"195820", -- [3]
						"195821", -- [4]
						"189886", -- [5]
						"75966", -- [6]
						"102019", -- [7]
						"187159", -- [8]
						"194897", -- [9]
						"104251", -- [10]
						"101326", -- [11]
						"189669", -- [12]
						"192464", -- [13]
						190381, -- [14]
						92538, -- [15]
						192464, -- [16]
						131009, -- [17]
						127315, -- [18]
						133361, -- [19]
						136330, -- [20]
						214117, -- [21]
						212483, -- [22]
						101008, -- [23]
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Add - Important [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Key"] = "option4",
							["Value"] = 0,
							["Name"] = "Blank Space",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Key"] = "option6",
							["Value"] = "Enter the npc name or npcId in the \"Add Trigger\" box and hit \"Add\".",
							["Name"] = "Option 6",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 4,
							["Key"] = "changeNameplateColor",
							["Value"] = true,
							["Name"] = "Change Nameplate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "change to true to change the color",
						}, -- [4]
						{
							["Type"] = 1,
							["Key"] = "nameplateColor",
							["Value"] = {
								1, -- [1]
								0, -- [2]
								0.5254901960784314, -- [3]
								1, -- [4]
							},
							["Name"] = "Nameplate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Nameplate Color",
						}, -- [5]
						{
							["Type"] = 2,
							["Max"] = 6,
							["Desc"] = "increase the nameplate height by this value",
							["Min"] = 0,
							["Name"] = "Nameplate Size Offset",
							["Value"] = 3,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "nameplateSizeOffset",
						}, -- [6]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [7]
						{
							["Type"] = 1,
							["Key"] = "dotsColor",
							["Value"] = {
								1, -- [1]
								0.7137255072593689, -- [2]
								0, -- [3]
								0.5631310641765594, -- [4]
							},
							["Name"] = "Dot Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Dot Color",
						}, -- [8]
						{
							["Type"] = 6,
							["Key"] = "option4",
							["Value"] = 0,
							["Name"] = "Blank Space",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [9]
						{
							["Type"] = 5,
							["Key"] = "option10",
							["Value"] = "Extra Texture",
							["Name"] = "Extra Texture",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "Extra Texture",
						}, -- [10]
						{
							["Type"] = 4,
							["Name"] = "Show Extra Texture",
							["Value"] = false,
							["Key"] = "showExtraTexture",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Show Extra Texture",
						}, -- [11]
						{
							["Type"] = 1,
							["Key"] = "skullColor",
							["Value"] = {
								1, -- [1]
								0.4627450980392157, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Texture Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Texture Color",
						}, -- [12]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Alpha",
							["Min"] = 0,
							["Fraction"] = true,
							["Value"] = 0.2,
							["Name"] = "Alpha",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "skullAlpha",
						}, -- [13]
						{
							["Type"] = 2,
							["Max"] = 2,
							["Desc"] = "Scale",
							["Min"] = 0.4,
							["Name"] = "Scale",
							["Value"] = 0.6,
							["Key"] = "skullScale",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [14]
						{
							["Type"] = 7,
							["Name"] = "Npc Color By NpcID",
							["Value"] = {
								{
									"196548", -- [1]
									"forestgreen", -- [2]
								}, -- [1]
								{
									"195580", -- [1]
									"forestgreen", -- [2]
								}, -- [2]
								{
									"195820", -- [1]
									"forestgreen", -- [2]
								}, -- [3]
								{
									"195821", -- [1]
									"forestgreen", -- [2]
								}, -- [4]
								{
									"189886", -- [1]
									"forestgreen", -- [2]
								}, -- [5]
								{
									"75966", -- [1]
									"forestgreen", -- [2]
								}, -- [6]
								{
									"102019 ", -- [1]
									"forestgreen", -- [2]
								}, -- [7]
								{
									"187159", -- [1]
									"forestgreen", -- [2]
								}, -- [8]
								{
									"194897", -- [1]
									"forestgreen", -- [2]
								}, -- [9]
								{
									"104251", -- [1]
									"forestgreen", -- [2]
								}, -- [10]
							},
							["Key"] = "npcColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_list",
							["Desc"] = "Key is the npcID, value is the color name",
						}, -- [15]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    if (envTable.dotAnimation) then\n        Plater.StopDotAnimation(unitFrame.healthBar, envTable.dotAnimation)\n    end\n    \n    envTable.dotAnimation = Plater.PlayDotAnimation(unitFrame.healthBar, 2, scriptTable.config.dotsColor, 3, 4) \n    \n    --increase the nameplate size\n    local nameplateHeight = Plater.db.profile.plate_config.enemynpc.health_incombat [2]\n    unitFrame.healthBar:SetHeight (nameplateHeight + envTable.NameplateSizeOffset)\n    \n    unitFrame.UnitImportantSkullTexture:Show()\n    \n    --color priority:\n    local npcIdString = tostring(envTable._NpcID)\n    envTable.NameplateColor = Plater.GetColorByPriority(unitFrame, scriptTable.config.npcColor[npcIdString], scriptTable.config.nameplateColor)    \n    \n    if (scriptTable.config.showExtraTexture) then\n        unitFrame.UnitImportantSkullTexture:SetVertexColor(Plater:ParseColors(scriptTable.config.skullColor))\n        unitFrame.UnitImportantSkullTexture:SetAlpha(scriptTable.config.skullAlpha)\n        unitFrame.UnitImportantSkullTexture:SetScale(scriptTable.config.skullScale)\n        unitFrame.UnitImportantSkullTexture:SetTexture([[Interface/AddOns/Plater/media/x_64]])\n        unitFrame.UnitImportantSkullTexture:ClearAllPoints()\n        unitFrame.UnitImportantSkullTexture:SetPoint(\"right\", unitFrame.healthBar, \"left\", -2, 0)\n        unitFrame.UnitImportantSkullTexture:SetSize(28, 28)\n        unitFrame.UnitImportantSkullTexture:Show()\n    else\n        unitFrame.UnitImportantSkullTexture:Hide()\n    end\n    \n    --rules for some npcs\n    if (envTable._NpcID == 194895) then --unstable squall (explode at dying\n        unitFrame.UnitImportantSkullTexture:Hide()\n        Plater.StopDotAnimation(unitFrame.healthBar, envTable.dotAnimation) \n    end\n    \n    if (scriptTable.config.changeNameplateColor) then\n        local npcIdString = tostring(envTable._NpcID)\n        \n        envTable.NameplateColor = Plater.GetColorByPriority(unitFrame, scriptTable.config.npcColor[npcIdString], scriptTable.config.nameplateColor)        \n        \n        Plater.DenyColorChange(unitFrame, true)\n    end\n    \nend\n\n\n\n\n",
				}, -- [9]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --settings (require a /reload after editing any setting)\n    do\n        --blink and glow\n        envTable.BlinkEnabled = scriptTable.config.blinkEnabled\n        envTable.GlowEnabled = scriptTable.config.glowEnabled \n        envTable.ChangeNameplateColor = scriptTable.config.changeNameplateColor;\n        envTable.TimeLeftToBlink = scriptTable.config.timeleftToBlink;\n        envTable.BlinkSpeed = scriptTable.config.blinkSpeed; \n        envTable.BlinkColor = scriptTable.config.blinkColor; \n        envTable.BlinkMaxAlpha = scriptTable.config.blinkMaxAlpha; \n        envTable.NameplateColor = scriptTable.config.nameplateColor; \n        \n        --text color\n        envTable.TimerColorEnabled = scriptTable.config.timerColorEnabled \n        envTable.TimeLeftWarning = scriptTable.config.timeLeftWarning;\n        envTable.TimeLeftCritical = scriptTable.config.timeLeftCritical;\n        envTable.TextColor_Warning = scriptTable.config.warningColor; \n        envTable.TextColor_Critical = scriptTable.config.criticalColor; \n        \n        --list of spellIDs to ignore\n        envTable.IgnoredSpellID = {\n            [12] = true, --use a simple comma here\n            [13] = true,\n        }\n    end\n    \n    \n    --private\n    do\n        --if not envTable.blinkTexture then\n        envTable.blinkTexture = Plater:CreateImage (self, \"\", 1, 1, \"overlay\")\n        envTable.blinkTexture:SetPoint ('center', 0, 0)\n        envTable.blinkTexture:Hide()\n        \n        local onPlay = function()\n            envTable.blinkTexture:Show() \n            envTable.blinkTexture.color = envTable.BlinkColor\n        end\n        local onStop = function()\n            envTable.blinkTexture:Hide()  \n        end\n        envTable.blinkAnimation = Plater:CreateAnimationHub (envTable.blinkTexture, onPlay, onStop)\n        Plater:CreateAnimation (envTable.blinkAnimation, \"ALPHA\", 1, envTable.BlinkSpeed / 2, 0, envTable.BlinkMaxAlpha)\n        Plater:CreateAnimation (envTable.blinkAnimation, \"ALPHA\", 2, envTable.BlinkSpeed / 2, envTable.BlinkMaxAlpha, 0)\n        --end\n        \n        envTable.glowEffect = envTable.glowEffect or self.overlay or Plater.CreateIconGlow (self)\n        --envTable.glowEffect = envTable.glowEffect or Plater.CreateIconGlow (self)\n        --envTable.glowEffect:Show() --envTable.glowEffect:Hide()\n        \n    end\n    \nend\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.blinkAnimation:Stop()\n    envTable.blinkTexture:Hide()\n    envTable.blinkAnimation:Stop()\n    envTable.glowEffect:Stop()\n    Plater:SetFontColor (self.Cooldown.Timer, Plater.db.profile.aura_timer_text_color)\nend\n\n\n",
					["ScriptType"] = 1,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    local timeLeft = envTable._RemainingTime\n    \n    --check if the spellID isn't being ignored\n    if (envTable.IgnoredSpellID [envTable._SpellID]) then\n        return\n    end\n    \n    --check the time left and start or stop the blink animation and also check if the time left is > zero\n    if ((envTable.BlinkEnabled or envTable.GlowEnabled) and timeLeft > 0) then\n        if (timeLeft < envTable.TimeLeftToBlink) then\n            --blink effect\n            if (envTable.BlinkEnabled) then\n                if (not envTable.blinkAnimation:IsPlaying()) then\n                    envTable.blinkAnimation:Play()\n                end\n            end\n            --glow effect\n            if (envTable.GlowEnabled) then\n                envTable.glowEffect:Show()\n            end\n            --nameplate color\n            if (envTable.ChangeNameplateColor) then\n                Plater.SetNameplateColor (unitFrame, envTable.NameplateColor)\n            end\n        else\n            --blink effect\n            if (envTable.blinkAnimation:IsPlaying()) then\n                envTable.blinkAnimation:Stop()\n            end\n            --glow effect\n            if (envTable.GlowEnabled and envTable.glowEffect:IsShown()) then\n                envTable.glowEffect:Hide()\n            end\n        end\n    end\n    \n    --timer color\n    if (envTable.TimerColorEnabled and timeLeft > 0) then\n        if (timeLeft < envTable.TimeLeftCritical) then\n            Plater:SetFontColor (self.Cooldown.Timer, envTable.TextColor_Critical)\n        elseif (timeLeft < envTable.TimeLeftWarning) then\n            Plater:SetFontColor (self.Cooldown.Timer, envTable.TextColor_Warning)        \n        else\n            Plater:SetFontColor (self.Cooldown.Timer, Plater.db.profile.aura_timer_text_color)\n        end\n    end\n    \nend",
					["Time"] = 1626382829,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\icon_aura_blink",
					["Enabled"] = true,
					["Revision"] = 375,
					["semver"] = "",
					["Author"] = "Izimode-Azralon",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Blink, change the number and nameplate color. Add the debuffs int he trigger box. Set settings on constructor script.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Aura - Blink by Time Left [Plater]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Key"] = "option10",
							["Value"] = 0,
							["Name"] = "Blank Space",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Key"] = "option17",
							["Value"] = "Enter the spell name or spellID in the Add Trigger box and hit \"Add\".",
							["Name"] = "Option 17",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option10",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 4,
							["Key"] = "blinkEnabled",
							["Value"] = true,
							["Name"] = "Blink Enabled",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "set to 'false' to disable blink",
						}, -- [4]
						{
							["Type"] = 4,
							["Key"] = "glowEnabled",
							["Value"] = true,
							["Name"] = "Glow Enabled",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "set to 'false' to disable glows",
						}, -- [5]
						{
							["Type"] = 4,
							["Key"] = "changeNameplateColor",
							["Value"] = false,
							["Name"] = "Change NamePlate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "set to 'true' to enable nameplate color change",
						}, -- [6]
						{
							["Type"] = 2,
							["Max"] = 20,
							["Desc"] = "in seconds, affects the blink effect only",
							["Min"] = 1,
							["Fraction"] = true,
							["Value"] = 3,
							["Key"] = "timeleftToBlink",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Timeleft to Blink",
						}, -- [7]
						{
							["Type"] = 2,
							["Max"] = 3,
							["Desc"] = "time to complete a blink loop",
							["Min"] = 0.5,
							["Fraction"] = true,
							["Value"] = 1,
							["Key"] = "blinkSpeed",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Blink Speed",
						}, -- [8]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "max transparency in the animation loop (1.0 is full opaque)",
							["Min"] = 0.1,
							["Fraction"] = true,
							["Value"] = 0.6,
							["Key"] = "blinkMaxAlpha",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Blink Max Alpha",
						}, -- [9]
						{
							["Type"] = 1,
							["Key"] = "blinkColor",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Name"] = "Blink Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "color of the blink",
						}, -- [10]
						{
							["Type"] = 1,
							["Key"] = "nameplateColor",
							["Value"] = {
								0.2862745098039216, -- [1]
								0.00392156862745098, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Nameplate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "nameplate color if ChangeNameplateColor is true",
						}, -- [11]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option10",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [12]
						{
							["Type"] = 4,
							["Key"] = "timerColorEnabled",
							["Value"] = true,
							["Name"] = "Timer Color Enabled",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "set to 'false' to disable changes in the color of the time left text",
						}, -- [13]
						{
							["Type"] = 2,
							["Max"] = 20,
							["Desc"] = "in seconds, affects the color of the text",
							["Min"] = 1,
							["Name"] = "Time Left Warning",
							["Value"] = 8,
							["Key"] = "timeLeftWarning",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [14]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "in seconds, affects the color of the text",
							["Min"] = 1,
							["Name"] = "Time Left Critical",
							["Value"] = 3,
							["Key"] = "timeLeftCritical",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [15]
						{
							["Type"] = 1,
							["Key"] = "warningColor",
							["Value"] = {
								1, -- [1]
								0.8705882352941177, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Warning Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "color when the time left entered in a warning zone",
						}, -- [16]
						{
							["Type"] = 1,
							["Key"] = "criticalColor",
							["Value"] = {
								1, -- [1]
								0.07450980392156863, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Critical Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "color when the time left is critical",
						}, -- [17]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    envTable.blinkTexture:SetSize (self:GetSize())\n    \nend\n\n\n",
				}, -- [10]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (unitFrame.AddSpawnIDTexture) then\n        unitFrame.AddSpawnIDTexture:Hide()\n        unitFrame.AddIcon:Hide()\n        unitFrame.AddNumber:Hide()\n    end\n    \nend\n\n\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Time"] = 1669340442,
					["url"] = "",
					["Icon"] = "interface/addons/plater/images/add_id_icon",
					["Enabled"] = false,
					["Revision"] = 161,
					["semver"] = "",
					["Author"] = "Huugg-Valdrakken",
					["Initialization"] = "function (scriptTable)\n    \n    scriptTable.allAdds = {} \n    scriptTable.nextAddWave = 0\n    scriptTable.waveTime = 20\n    \n    function scriptTable.ArrangeNpcNumbers(GUID)\n        local spawnId = select(7, strsplit (\"-\", GUID))\n        spawnId = tonumber(spawnId, 16)\n        \n        if (spawnId) then\n            --check if this is a new wave of adds\n            if (GetTime() > scriptTable.nextAddWave) then\n                scriptTable.nextAddWave = GetTime() + scriptTable.waveTime\n                scriptTable.allAdds = {}\n            end\n            \n            local bIsAlreadyOnTheList = false\n            \n            for o = 1, #scriptTable.allAdds do\n                if (scriptTable.allAdds[o][1] == GUID) then\n                    bIsAlreadyOnTheList = true\n                end\n            end\n            \n            if (not bIsAlreadyOnTheList) then\n                scriptTable.allAdds[#scriptTable.allAdds+1] = {GUID, spawnId}\n            end\n        end\n        \n        table.sort(scriptTable.allAdds, function(t1, t2) return t1[2] < t2[2] end)\n        \n        --this is a \"loop\" because this is running each time a nameplate is added!\n        \n        for namePlateIndex, plateFrame in ipairs(Plater.GetAllShownPlates()) do\n            local unitFrame = plateFrame.unitFrame\n            \n            --get the unit GUID\n            local unitGUID = unitFrame.namePlateUnitGUID\n            \n            for addId = 1, #scriptTable.allAdds do\n                local addTable = scriptTable.allAdds[addId]\n                local addGUID = addTable[1]\n                \n                if (unitGUID == addGUID) then\n                    scriptTable.TagNameplate(unitFrame, unitGUID, addId)\n                    break\n                end\n            end\n            \n        end\n    end\n    \n    function scriptTable.TagNameplate(unitFrame, GUID, addId)\n        scriptTable.CreateAddWidgetsForNameplate(unitFrame, GUID, addId)\n        \n        if (addId and addId >= 1 and addId <= 8) then\n            unitFrame.AddSpawnIDTexture:Show()\n            unitFrame.AddIcon:Show()\n            unitFrame.AddNumber:Show()\n            \n            local addTexture = \"Interface\\\\TargetingFrame\\\\UI-RaidTargetingIcon_\" .. addId\n            \n            unitFrame.AddIcon:SetTexture(addTexture)\n            unitFrame.AddNumber:SetText(addId)\n        end\n    end\n    \n    function scriptTable.CreateAddWidgetsForNameplate(unitFrame, GUID, addId)\n        if (not unitFrame.AddSpawnIDTexture) then\n            local healthBar = unitFrame.healthBar\n            \n            local textureBackground = healthBar.FrameOverlay:CreateTexture(nil, \"overlay\", nil, 5)\n            local addIcon = healthBar.FrameOverlay:CreateTexture(nil, \"overlay\", nil, 6)\n            local addNumber = healthBar.FrameOverlay:CreateFontString(nil, \"overlay\", \"GameFontNormal\", 6)           \n            \n            unitFrame.AddSpawnIDTexture = textureBackground\n            unitFrame.AddIcon = addIcon\n            unitFrame.AddNumber = addNumber\n        end\n    end    \nend\n\n--Creature-0-2085-1-11042-153285-0002F8DB2B --training dummy for testing\n--195138 Detonating Crystal\n--192955 dracomoc illusion\n--190294 nokhub stormcaster\n--76518 ritual of bones\n\n\n\n\n",
					["Desc"] = "Put a number above multiples adds, numbers follow their respawn id.",
					["NpcNames"] = {
						"195138", -- [1]
						"192955", -- [2]
						"190294", -- [3]
						"76518", -- [4]
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Add - Tag Number [P]",
					["version"] = -1,
					["Options"] = {
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (unitFrame.AddSpawnIDTexture) then\n        unitFrame.AddSpawnIDTexture:Hide()\n        unitFrame.AddIcon:Hide()\n        unitFrame.AddNumber:Hide()\n    end\n    \n    scriptTable.ArrangeNpcNumbers(unitFrame.namePlateUnitGUID)\n    \n    local textureBackground = unitFrame.AddSpawnIDTexture\n    textureBackground:SetSize(22, 10)\n    textureBackground:ClearAllPoints()\n    textureBackground:SetPoint(\"bottomright\", unitFrame.healthBar, \"topright\", 0, 1)\n    \n    textureBackground:SetMask([[Interface\\AddOns\\Plater\\masks\\mask_smallrectangle_rounded1]])\n    textureBackground:SetTexture([[Interface\\AddOns\\Plater\\masks\\mask_smallrectangle_rounded1]])\n    textureBackground:SetVertexColor(0.1215, 0.1176, 0.1294, 1)\n    \n    \n    --textureBackground:SetMask([[Interface/ChatFrame/UI-ChatIcon-HotS]])\n    --    \"Interface/ChatFrame/UI-ChatIcon-HotS\"\n    \n    local addIcon = unitFrame.AddIcon\n    addIcon:ClearAllPoints()\n    addIcon:SetPoint(\"left\", textureBackground, \"left\", 2, 0)\n    addIcon:SetSize(10, 10)\n    \n    local addNumber = unitFrame.AddNumber\n    addNumber:ClearAllPoints()\n    addNumber:SetPoint(\"right\", textureBackground, \"right\", -2, 0)\n    DetailsFramework:SetFontSize(addNumber, 10)\n    \nend\n\n\n",
				}, -- [11]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    local castBar = unitFrame.castBar\n    local castBarPortion = castBar:GetWidth()/scriptTable.config.segmentsAmount\n    local castBarHeight = castBar:GetHeight()\n    \n    unitFrame.felAnimation = unitFrame.felAnimation or {}\n    \n    if (not unitFrame.felAnimation.textureStretched) then\n        unitFrame.felAnimation.textureStretched = castBar:CreateTexture(nil, \"overlay\", nil, 5)\n    end\n    \n    if (not unitFrame.felAnimation.Textures) then\n        unitFrame.felAnimation.Textures = {}\n        \n        for i = 1, 20 do --max amount of segments is 20\n            local texture = castBar:CreateTexture(nil, \"overlay\", nil, 6)\n            unitFrame.felAnimation.Textures[i] = texture            \n            \n            texture.animGroup = texture.animGroup or texture:CreateAnimationGroup()\n            local animationGroup = texture.animGroup\n            animationGroup:SetToFinalAlpha(true)            \n            animationGroup:SetLooping(\"NONE\")\n            \n            texture:SetTexture([[Interface\\COMMON\\XPBarAnim]])\n            texture:SetTexCoord(0.2990, 0.0010, 0.0010, 0.4159)\n            texture:SetBlendMode(\"ADD\")\n            \n            texture.scale = animationGroup:CreateAnimation(\"SCALE\")\n            texture.scale:SetTarget(texture)\n            \n            texture.alpha = animationGroup:CreateAnimation(\"ALPHA\")\n            texture.alpha:SetTarget(texture)\n            \n            texture.alpha2 = animationGroup:CreateAnimation(\"ALPHA\")\n            texture.alpha2:SetTarget(texture)\n        end\n    end\n    \n    \n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (unitFrame.felAnimation and unitFrame.felAnimation.Textures) then\n        for i = 1, scriptTable.config.segmentsAmount  do\n            local texture = unitFrame.felAnimation.Textures[i]\n            if (texture) then\n                texture:Hide()\n            end\n        end\n    end\n    \n    if (unitFrame.felAnimation and unitFrame.felAnimation.textureStretched) then\n        local textureStretched = unitFrame.felAnimation.textureStretched\n        if (textureStretched) then\n            textureStretched:Hide()\n        end\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (self.channeling) then\n        return \n    end\n    \n    if (not envTable.NextPercent) then\n        return\n    end\n    \n    local castBar = unitFrame.castBar\n    \n    local textures = unitFrame.felAnimation.Textures\n    \n    if (envTable._CastPercent > envTable.NextPercent) then --eeror here, compare with nil\n        local nextPercent = 100  / scriptTable.config.segmentsAmount\n        \n        textures[envTable.CurrentTexture]:Show()\n        textures[envTable.CurrentTexture].animGroup:Play()\n        envTable.NextPercent = envTable.NextPercent + nextPercent \n        envTable.CurrentTexture = envTable.CurrentTexture + 1\n        \n        if (envTable.CurrentTexture == #textures) then\n            envTable.NextPercent = 98\n        elseif (envTable.CurrentTexture > #textures) then\n            envTable.NextPercent = 999\n        end\n    end\n    \n    local normalizedPercent = envTable._CastPercent / 100\n    local textureStretched = unitFrame.felAnimation.textureStretched\n    local point = DetailsFramework:GetBezierPoint(normalizedPercent, 0, 0.001, 1)\n    textureStretched:SetPoint(\"left\", castBar, \"left\", point * envTable.castBarWidth, 0)\n    \n    self.ThrottleUpdate = 0\nend",
					["Time"] = 1672514190,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_glow",
					["Enabled"] = true,
					["Revision"] = 547,
					["semver"] = "",
					["Author"] = "Terciob",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Show a different animation for the cast bar.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						376644, -- [1]
						386781, -- [2]
						384823, -- [3]
						385536, -- [4]
						392398, -- [5]
						375596, -- [6]
						387135, -- [7]
						360850, -- [8]
						212784, -- [9]
						199033, -- [10]
						199034, -- [11]
						200969, -- [12]
						394512, -- [13]
						397881, -- [14]
						396020, -- [15]
						374430, -- [16]
						384353, -- [17]
						265376, -- [18]
						193941, -- [19]
						411002, -- [20]
						169445, -- [21]
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - Glowing [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 2,
							["Max"] = 20,
							["Desc"] = "Need a /reload",
							["Min"] = 5,
							["Key"] = "segmentsAmount",
							["Value"] = 7,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Amount of Segments",
						}, -- [1]
						{
							["Type"] = 1,
							["Key"] = "sparkColor",
							["Value"] = {
								0.9568627450980391, -- [1]
								1, -- [2]
								0.9882352941176471, -- [3]
								1, -- [4]
							},
							["Name"] = "Spark Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 1,
							["Key"] = "glowColor",
							["Value"] = {
								0.8588235294117647, -- [1]
								0.4313725490196079, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Name"] = "Glow Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 7,
							["Key"] = "castColor",
							["Value"] = {
								{
									"385536", -- [1]
									"maroon", -- [2]
								}, -- [1]
								{
									"198750", -- [1]
									"midnightblue", -- [2]
								}, -- [2]
								{
									"360850", -- [1]
									"lime", -- [2]
								}, -- [3]
								{
									"212784", -- [1]
									"deepskyblue", -- [2]
								}, -- [4]
								{
									"207980", -- [1]
									"midnightblue", -- [2]
								}, -- [5]
								{
									"199033", -- [1]
									"gold", -- [2]
								}, -- [6]
								{
									"199034", -- [1]
									"gold", -- [2]
								}, -- [7]
								{
									"200969", -- [1]
									"orange", -- [2]
								}, -- [8]
								{
									"394512", -- [1]
									"indigo", -- [2]
								}, -- [9]
								{
									"397881", -- [1]
									"deepskyblue", -- [2]
								}, -- [10]
								{
									"396020", -- [1]
									"khaki", -- [2]
								}, -- [11]
							},
							["Name"] = "Cast Color by SpellID",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_list",
							["Desc"] = "Insert the Spell ID in the to Key and a color name into the Value",
						}, -- [4]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (self.channeling) then\n        return \n    end\n    \n    local castBar = unitFrame.castBar\n    envTable.castBarWidth = castBar:GetWidth()\n    castBar.Spark:SetVertexColor(DetailsFramework:ParseColors(scriptTable.config.sparkColor))\n    \n    local textureStretched = unitFrame.felAnimation.textureStretched\n    textureStretched:Show()\n    textureStretched:SetVertexColor(DetailsFramework:ParseColors(scriptTable.config.glowColor))\n    textureStretched:SetAtlas(\"XPBarAnim-OrangeTrail\")\n    textureStretched:ClearAllPoints()\n    textureStretched:SetPoint(\"right\", castBar.Spark, \"center\", 0, 0)\n    textureStretched:SetHeight(castBar:GetHeight())\n    textureStretched:SetBlendMode(\"ADD\") \n    textureStretched:SetAlpha(0.5)\n    textureStretched:SetDrawLayer(\"overlay\", 7)\n    \n    for i = 1, scriptTable.config.segmentsAmount  do\n        local texture = unitFrame.felAnimation.Textures[i]\n        --texture:SetVertexColor(DetailsFramework:ParseColors(scriptTable.config.trailColor))\n        texture:SetVertexColor(1, 1, 1, 1)\n        texture:SetDesaturated(true)\n        \n        local castBarPortion = castBar:GetWidth()/scriptTable.config.segmentsAmount\n        \n        texture:SetSize(castBarPortion+5, castBar:GetHeight())\n        texture:SetDrawLayer(\"overlay\", 6)\n        \n        texture:ClearAllPoints()\n        if (i == scriptTable.config.segmentsAmount) then\n            texture:SetPoint(\"right\", castBar, \"right\", 0, 0)\n        else\n            texture:SetPoint(\"left\", castBar, \"left\", (i-1)*castBarPortion, 2)\n        end\n        \n        texture:SetAlpha(0)\n        texture:Hide()\n        \n        texture.scale:SetOrder(1)\n        texture.scale:SetDuration(0.5)\n        texture.scale:SetScaleFrom(0.2, 1)\n        texture.scale:SetScaleTo(1, 1.5)\n        texture.scale:SetOrigin(\"right\", 0, 0)\n        \n        local durationTime = DetailsFramework:GetBezierPoint(i / scriptTable.config.segmentsAmount, 0.2, 0.01, 0.6)\n        local duration = abs(durationTime-0.6)\n        \n        texture.alpha:SetOrder(1)\n        texture.alpha:SetDuration(0.05)\n        texture.alpha:SetFromAlpha(0)\n        texture.alpha:SetToAlpha(0.4)\n        \n        texture.alpha2:SetOrder(1)\n        texture.alpha2:SetDuration(duration) --0.6\n        texture.alpha2:SetStartDelay(duration)\n        texture.alpha2:SetFromAlpha(0.5)\n        texture.alpha2:SetToAlpha(0)\n    end\n    \n    envTable.CurrentTexture = 1\n    envTable.NextPercent  = 100  / scriptTable.config.segmentsAmount\n    \n    local customColor = scriptTable.config.castColor[tostring(envTable._SpellID)]\n    Plater.SetCastBarColorForScript(self, true, customColor or scriptTable.config.castBarColor, envTable)\nend\n\n\n\n\n\n\n\n\n\n\n\n\n",
				}, -- [12]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --create a texture to use for a flash behind the cast bar\n    \n    if (not unitFrame.backGroundFlashTextureImpTarget) then\n        unitFrame.backGroundFlashTextureImpTarget =  Plater:CreateImage (self, [[Interface\\ACHIEVEMENTFRAME\\UI-Achievement-Alert-Glow]], self:GetWidth()+40, self:GetHeight()+20, \"background\", {0, 400/512, 0, 170/256})\n    end\n    \n    local backGroundFlashTexture = unitFrame.backGroundFlashTextureImpTarget\n    backGroundFlashTexture:SetBlendMode (\"ADD\")\n    backGroundFlashTexture:SetDrawLayer(\"OVERLAY\", 7)\n    backGroundFlashTexture:SetPoint (\"center\", self, \"center\")\n    backGroundFlashTexture:Hide()\n    \n    --create the animation hub to hold the flash animation sequence\n    envTable.BackgroundFlash = envTable.BackgroundFlash or Plater:CreateAnimationHub (backGroundFlashTexture, \n        function()\n            backGroundFlashTexture:Show()\n        end,\n        function()\n            backGroundFlashTexture:Hide()\n        end\n    )\n    \n    --create the flash animation sequence\n    local fadeIn = Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 1, scriptTable.config.flashDuration/2, 0, 1)\n    local fadeOut = Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 2, scriptTable.config.flashDuration/2, 1, 0)\n    \n    --create a camera shake for the nameplate\n    envTable.FrameShake = Plater:CreateFrameShake (unitFrame, scriptTable.config.shakeDuration, scriptTable.config.shakeAmplitude, scriptTable.config.shakeFrequency, false, false, 0, 1, 0.05, 0.1, Plater.GetPoints (unitFrame))\n    \n    --update the config for the flash here so it wont need a /reload\n    fadeIn:SetDuration (scriptTable.config.flashDuration/2)\n    fadeOut:SetDuration (scriptTable.config.flashDuration/2)\n    \n    --update the config for the skake here so it wont need a /reload\n    envTable.FrameShake.OriginalAmplitude = scriptTable.config.shakeAmplitude\n    envTable.FrameShake.OriginalDuration = scriptTable.config.shakeDuration\n    envTable.FrameShake.OriginalFrequency = scriptTable.config.shakeFrequency\n    \n    --create the target unit name box\n    if (not unitFrame.targetBox) then\n        unitFrame.targetBox = CreateFrame(\"frame\", unitFrame:GetName() .. \"ScriptImportantTarget\", unitFrame, \"BackdropTemplate\")\n        unitFrame.targetBox:SetSize(80, 20)\n        unitFrame.targetBox:SetFrameStrata(\"TOOLTIP\")\n        unitFrame.targetBox:Hide()\n        unitFrame.targetBox:SetPoint(\"left\", unitFrame, \"right\", 0, 0)\n        \n        unitFrame.targetBox:SetBackdrop({edgeFile = [[Interface\\Buttons\\WHITE8X8]], edgeSize = 1, bgFile = [[Interface\\AddOns\\Details\\images\\background]], tile = true, tileSize = 16})\n        unitFrame.targetBox:SetBackdropColor(.2, .2, .2, .8)\n        unitFrame.targetBox:SetBackdropBorderColor(0, 0, 0, 1)\n        \n        unitFrame.targetBoxName = unitFrame.targetBox:CreateFontString(nil, \"artwork\", \"GameFontNormal\")\n        unitFrame.targetBoxName:SetPoint(\"center\")\n    end\n    \n    function envTable.UpdateTargetBox(unitFrame, unitId)\n        local targetUnitId = unitId .. \"target\"\n        local unitName = UnitName(targetUnitId)\n        \n        if (unitName) then\n            if (scriptTable.config.colorByClass) then\n                Plater:SetFontColor(unitFrame.targetBoxName, \"white\")\n                unitName = Plater.SetTextColorByClass(targetUnitId, unitName)\n            else\n                Plater:SetFontColor(unitFrame.targetBoxName, scriptTable.config.textColor)\n            end\n            \n            unitFrame.targetBoxName:SetText(unitName)\n            Plater:SetFontSize(unitFrame.targetBoxName, scriptTable.config.targetNameSize)\n            unitFrame.targetBox:SetBackdropColor(Plater:ParseColors(scriptTable.config.targetBgColor))\n            unitFrame.targetBox:SetBackdropBorderColor(Plater:ParseColors(scriptTable.config.targetBgBorderColor))\n            unitFrame.targetBox:Show()\n            \n            unitFrame.targetBox:SetWidth(scriptTable.config.targetFrameWidth)\n            unitFrame.targetBox:SetHeight(scriptTable.config.targetFrameHeight)\n            \n            if (not Plater.HasDotAnimationPlaying(unitFrame.targetBox)) then\n                envTable.dotAnimation = Plater.PlayDotAnimation(unitFrame.targetBox, 5, scriptTable.config.dotColor, scriptTable.config.xOffset, scriptTable.config.yOffset)\n            end\n            \n            unitFrame.backGroundFlashTextureImpTarget:SetVertexColor(Plater:ParseColors(scriptTable.config.flashColor))\n            \n            return true\n            \n        end\n    end\n    \nend",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    Plater.StopDotAnimation(unitFrame.targetBox, envTable.dotAnimation)    \n    \n    envTable.BackgroundFlash:Stop()\n    \n    unitFrame:StopFrameShake (envTable.FrameShake)    \n    \n    unitFrame.targetBox:Hide()\nend\n\n\n",
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    envTable.UpdateTargetBox(unitFrame, unitId) \n    \nend\n\n\n",
					["Time"] = 1669339628,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_target",
					["Enabled"] = true,
					["Revision"] = 878,
					["semver"] = "",
					["Author"] = "Bombad�o-Azralon",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Highlight the target name",
					["NpcNames"] = {
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - Important Target [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Key"] = "option1",
							["Value"] = 0,
							["Name"] = "Option 1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Key"] = "option2",
							["Value"] = "Shows the target name in a separate box",
							["Name"] = "Option 2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Enter the spell name or spellID of the Spell in the Add Trigger box and hit \"Add\".",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 6,
							["Key"] = "option4",
							["Value"] = 0,
							["Name"] = "Option 4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 5,
							["Key"] = "option2",
							["Value"] = "Flash:",
							["Name"] = "Flash",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [5]
						{
							["Type"] = 2,
							["Max"] = 1.2,
							["Desc"] = "How long is the flash played when the cast starts.",
							["Min"] = 0.1,
							["Name"] = "Flash Duration",
							["Value"] = 0.8,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "flashDuration",
						}, -- [6]
						{
							["Type"] = 1,
							["Key"] = "flashColor",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Name"] = "Flash Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Color of the Flash",
						}, -- [7]
						{
							["Type"] = 6,
							["Key"] = "option7",
							["Value"] = 0,
							["Name"] = "Option 7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [8]
						{
							["Type"] = 5,
							["Name"] = "Shake",
							["Value"] = "Shake:",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [9]
						{
							["Type"] = 2,
							["Max"] = 0.5,
							["Desc"] = "When the cast starts, there's a small shake in the nameplate, this settings controls how long it takes.",
							["Min"] = 0.1,
							["Name"] = "Shake Duration",
							["Value"] = 0.2,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "shakeDuration",
						}, -- [10]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "How strong is the shake.",
							["Min"] = 1,
							["Name"] = "Shake Amplitude",
							["Value"] = 5,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "shakeAmplitude",
						}, -- [11]
						{
							["Type"] = 2,
							["Max"] = 80,
							["Desc"] = "How fast the shake moves.",
							["Min"] = 1,
							["Name"] = "Shake Frequency",
							["Value"] = 40,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "shakeFrequency",
						}, -- [12]
						{
							["Type"] = 6,
							["Key"] = "option13",
							["Value"] = 0,
							["Name"] = "Option 13",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [13]
						{
							["Type"] = 5,
							["Key"] = "option14",
							["Value"] = "Dot Animation:",
							["Name"] = "Dot Animation",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [14]
						{
							["Type"] = 1,
							["Key"] = "dotColor",
							["Value"] = {
								0.5647058823529412, -- [1]
								0.5647058823529412, -- [2]
								0.5647058823529412, -- [3]
								1, -- [4]
							},
							["Name"] = "Dot Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Adjust the color of the dots around the nameplate",
						}, -- [15]
						{
							["Type"] = 2,
							["Max"] = 20,
							["Desc"] = "Adjust the width of the dots to better fit in your nameplate.",
							["Min"] = -10,
							["Fraction"] = false,
							["Value"] = 8,
							["Name"] = "Dot X Offset",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "xOffset",
						}, -- [16]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Adjust the height of the dots to better fit in your nameplate.",
							["Min"] = -10,
							["Name"] = "Dot Y Offset",
							["Value"] = 3,
							["Key"] = "yOffset",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [17]
						{
							["Type"] = 6,
							["Key"] = "option18",
							["Value"] = 0,
							["Name"] = "blank",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [18]
						{
							["Type"] = 6,
							["Name"] = "blank",
							["Value"] = 0,
							["Key"] = "option18",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [19]
						{
							["Type"] = 6,
							["Name"] = "blank",
							["Value"] = 0,
							["Key"] = "option18",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [20]
						{
							["Type"] = 6,
							["Key"] = "option18",
							["Value"] = 0,
							["Name"] = "blank",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [21]
						{
							["Type"] = 6,
							["Key"] = "option18",
							["Value"] = 0,
							["Name"] = "blank",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [22]
						{
							["Type"] = 6,
							["Name"] = "blank",
							["Value"] = 0,
							["Key"] = "option18",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [23]
						{
							["Type"] = 5,
							["Key"] = "option19",
							["Value"] = "Cast Bar",
							["Name"] = "Option 19",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [24]
						{
							["Type"] = 4,
							["Key"] = "useCastbarColor",
							["Value"] = true,
							["Name"] = "Use Cast Bar Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Use cast bar color.",
						}, -- [25]
						{
							["Type"] = 1,
							["Key"] = "castBarColor",
							["Value"] = {
								0.4117647058823529, -- [1]
								1, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Cast Bar Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Cast bar color.",
						}, -- [26]
						{
							["Type"] = 6,
							["Name"] = "Option 27",
							["Value"] = 0,
							["Key"] = "option27",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [27]
						{
							["Type"] = 5,
							["Name"] = "Option 28",
							["Value"] = "Target Options",
							["Key"] = "option28",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [28]
						{
							["Type"] = 2,
							["Max"] = 32,
							["Desc"] = "",
							["Min"] = 8,
							["Name"] = "Text Size",
							["Value"] = 14,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "targetNameSize",
						}, -- [29]
						{
							["Type"] = 4,
							["Name"] = "Use Class Color",
							["Value"] = true,
							["Key"] = "colorByClass",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [30]
						{
							["Type"] = 1,
							["Name"] = "Text Color",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Key"] = "textColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [31]
						{
							["Type"] = 1,
							["Name"] = "Background Color",
							["Value"] = {
								0, -- [1]
								0, -- [2]
								0, -- [3]
								0.9846720322966576, -- [4]
							},
							["Key"] = "targetBgColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [32]
						{
							["Type"] = 1,
							["Name"] = "Border Color",
							["Value"] = {
								0, -- [1]
								0, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "targetBgBorderColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [33]
						{
							["Type"] = 2,
							["Max"] = 160,
							["Desc"] = "",
							["Min"] = 30,
							["Name"] = "Frame Width",
							["Value"] = 90,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "targetFrameWidth",
						}, -- [34]
						{
							["Type"] = 2,
							["Max"] = 32,
							["Desc"] = "",
							["Min"] = 8,
							["Key"] = "targetFrameHeight",
							["Value"] = 20,
							["Name"] = "Frame Height",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [35]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (envTable.UpdateTargetBox(unitFrame, unitId)) then\n        \n        envTable.BackgroundFlash:Play()\n        \n        Plater.FlashNameplateBorder (unitFrame, 0.05)   \n        Plater.FlashNameplateBody (unitFrame, \"\", 0.075)\n        \n        unitFrame:PlayFrameShake (envTable.FrameShake)\n        \n        if (envTable._CanInterrupt) then\n            if (scriptTable.config.useCastbarColor) then\n                self:SetStatusBarColor (Plater:ParseColors (scriptTable.config.castBarColor))\n            end\n        end\n        \n    end\n    \nend\n\n\n\n\n\n\n",
				}, -- [13]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --castbar color (when can be interrupted)\n    envTable.CastbarColor = scriptTable.config.castbarColor\n    \n    --flash duration\n    local CONFIG_BACKGROUND_FLASH_DURATION = scriptTable.config.flashDuration\n    \n    --add this value to the cast bar height\n    envTable.CastBarHeightAdd = scriptTable.config.castBarHeight\n    \n    --create a fast flash above the cast bar\n    envTable.FullBarFlash = envTable.FullBarFlash or Plater.CreateFlash (self, 0.05, 1, \"white\")\n    \n    --create a camera shake for the nameplate\n    envTable.FrameShake = Plater:CreateFrameShake (unitFrame, scriptTable.config.shakeDuration, scriptTable.config.shakeAmplitude, scriptTable.config.shakeFrequency, false, false, 0, 1, 0.05, 0.1, Plater.GetPoints (unitFrame))\n    \n    --create a texture to use for a flash behind the cast bar\n    local backGroundFlashTexture = Plater:CreateImage (self, [[Interface\\ACHIEVEMENTFRAME\\UI-Achievement-Alert-Glow]], self:GetWidth()+60, self:GetHeight()+50, \"background\", {0, 400/512, 0, 170/256})\n    backGroundFlashTexture:SetBlendMode (\"ADD\")\n    backGroundFlashTexture:SetDrawLayer(\"OVERLAY\", 7)\n    backGroundFlashTexture:SetPoint (\"center\", self, \"center\")\n    backGroundFlashTexture:Hide()\n    \n    --create the animation hub to hold the flash animation sequence\n    envTable.BackgroundFlash = envTable.BackgroundFlash or Plater:CreateAnimationHub (backGroundFlashTexture, \n        function()\n            backGroundFlashTexture:Show()\n        end,\n        function()\n            backGroundFlashTexture:Hide()\n        end\n    )\n    \n    --create the flash animation sequence\n    envTable.BackgroundFlash.fadeIn = envTable.BackgroundFlash.fadeIn or Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 1, CONFIG_BACKGROUND_FLASH_DURATION/2, 0, .75)\n    envTable.BackgroundFlash.fadeIn:SetDuration(CONFIG_BACKGROUND_FLASH_DURATION/2)\n    \n    envTable.BackgroundFlash.fadeOut = envTable.BackgroundFlash.fadeOut or Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 2, CONFIG_BACKGROUND_FLASH_DURATION/2, 1, 0)    \n    envTable.BackgroundFlash.fadeOut:SetDuration(CONFIG_BACKGROUND_FLASH_DURATION/2)\n    \n    --envTable.BackgroundFlash:Play() --envTable.BackgroundFlash:Stop()    \n    \n    \n    \n    \n    \nend\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --don't execute on battlegrounds and arenas\n    if (Plater.ZoneInstanceType == \"arena\" or Plater.ZoneInstanceType == \"pvp\") then\n        return\n    end    \n    \n    unitFrame.castBar:SetHeight (envTable._DefaultHeight)\n    \n    --stop the camera shake\n    unitFrame:StopFrameShake (envTable.FrameShake)\n    \n    envTable.FullBarFlash:Stop()\n    envTable.BackgroundFlash:Stop()\n    \n    unitFrame.castBar.Spark:SetHeight(unitFrame.castBar:GetHeight())\n    \nend\n\n\n\n\n\n",
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \nend\n\n\n",
					["Time"] = 1669324381,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_quickflash.tga",
					["Enabled"] = true,
					["Revision"] = 887,
					["semver"] = "",
					["Author"] = "Tercioo-Sylvanas",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend",
					["Desc"] = "Play a very fast flash when the cast start",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						392640, -- [1]
						397888, -- [2]
						209033, -- [3]
						385029, -- [4]
						374563, -- [5]
						377341, -- [6]
						369675, -- [7]
						369365, -- [8]
						369411, -- [9]
						278961, -- [10]
						202108, -- [11]
						88186, -- [12]
						200630, -- [13]
						255824, -- [14]
						252781, -- [15]
						250096, -- [16]
						200248, -- [17]
						197797, -- [18]
						264520, -- [19]
						418202, -- [20]
						201839, -- [21]
						412012, -- [22]
						411958, -- [23]
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - Quick Flash [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Name"] = "Blank Line",
							["Value"] = 0,
							["Key"] = "option1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Produces a notable but fast effect in the cast bar when a spell from the 'Triggers' starts to cast.",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 5,
							["Name"] = "Option 3",
							["Value"] = "Enter the spell name or spellID of the Spell in the Add Trigger box and hit \"Add\".",
							["Key"] = "option3",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 4,
							["Name"] = "Cast Bar Color Enabled",
							["Value"] = true,
							["Key"] = "useCastbarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "When enabled, changes the cast bar color,",
						}, -- [5]
						{
							["Type"] = 1,
							["Name"] = "Cast Bar Color",
							["Value"] = {
								1, -- [1]
								0.4313725490196079, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "castBarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Color of the cast bar.",
						}, -- [6]
						{
							["Type"] = 6,
							["Name"] = "Blank Line",
							["Value"] = 0,
							["Key"] = "option7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [7]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "When the cast starts it flash rapidly, adjust how fast it flashes. Value is milliseconds.",
							["Min"] = 0.05,
							["Fraction"] = true,
							["Value"] = 0.2,
							["Key"] = "flashDuration",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Flash Duration",
						}, -- [8]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Increases the cast bar height by this value",
							["Min"] = 0,
							["Fraction"] = false,
							["Value"] = 0,
							["Key"] = "castBarHeight",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Cast Bar Height Mod",
						}, -- [9]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "When the cast starts, there's a small shake in the nameplate, this settings controls how long it takes.",
							["Min"] = 0.1,
							["Fraction"] = true,
							["Value"] = 0.1,
							["Key"] = "shakeDuration",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Shake Duration",
						}, -- [10]
						{
							["Type"] = 2,
							["Max"] = 200,
							["Desc"] = "How strong is the shake.",
							["Min"] = 10,
							["Name"] = "Shake Amplitude",
							["Value"] = 25,
							["Key"] = "shakeAmplitude",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [11]
						{
							["Type"] = 2,
							["Max"] = 80,
							["Desc"] = "How fast the shake moves.",
							["Min"] = 1,
							["Name"] = "Shake Frequency",
							["Value"] = 30,
							["Key"] = "shakeFrequency",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [12]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --don't execute on battlegrounds and arenas\n    if (Plater.ZoneInstanceType == \"arena\" or Plater.ZoneInstanceType == \"pvp\") then\n        return\n    end\n    \n    --play flash animations\n    envTable.FullBarFlash:Play()\n    \n    --envTable.currentHeight = unitFrame.castBar:GetHeight()\n    \n    --restoring the default size (not required since it already restore in the hide script)\n    if (envTable.OriginalHeight) then\n        self:SetHeight (envTable.OriginalHeight)\n    end\n    \n    --increase the cast bar size\n    local height = self:GetHeight()\n    envTable.OriginalHeight = height\n    \n    self:SetHeight (height + envTable.CastBarHeightAdd)\n    \n    Plater.SetCastBarBorderColor (self, 1, .2, .2, 0.4)\n    \n    unitFrame:PlayFrameShake (envTable.FrameShake)\n    \n    Plater.SetCastBarColorForScript(self, scriptTable.config.useCastbarColor, scriptTable.config.castBarColor, envTable)\n    \n    envTable.BackgroundFlash:Play()\n    \n    unitFrame.castBar.Spark:SetHeight(unitFrame.castBar:GetHeight())\n    \nend\n\n\n\n\n\n\n\n\n\n\n",
				}, -- [14]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    local unitPowerBar = unitFrame.powerBar\n    unitPowerBar:Hide()\nend\n\n\n",
					["ScriptType"] = 1,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (WOW_PROJECT_ID ~= WOW_PROJECT_MAINLINE) then\n        return \n    end\n    \n    local continuationToken\n    local slots\n    local foundAura = false\n    \n    repeat    \n        slots = { UnitAuraSlots(unitId, \"HELPFUL\", BUFF_MAX_DISPLAY, continuationToken) }\n        continuationToken = slots[1]\n        numSlots = #slots\n        \n        for i = 2, numSlots do\n            local slot = slots[i]\n            local name, texture, count, actualAuraType, duration, expirationTime, caster, canStealOrPurge, nameplateShowPersonal, spellId, canApplyAura, isBossDebuff, isCastByPlayer, nameplateShowAll, timeMod, auraAmount = UnitAuraBySlot(unitId, slot) \n            \n            if (spellId == envTable._SpellID) then --need to get the trigger spellId\n                --Ablative Shield\n                local unitPowerBar = unitFrame.powerBar\n                if (not unitPowerBar:IsShown()) then\n                    unitPowerBar:SetUnit(unitId)\n                end\n                \n                foundAura = true\n                return\n            end\n        end\n        \n    until continuationToken == nil\n    \n    if (not foundAura) then\n        local unitPowerBar = unitFrame.powerBar\n        if (unitPowerBar:IsShown()) then\n            unitPowerBar:Hide()\n        end\n    end\nend",
					["Time"] = 1669327146,
					["url"] = "",
					["Icon"] = 610472,
					["Enabled"] = true,
					["Revision"] = 65,
					["semver"] = "",
					["Author"] = "Keyspell-Azralon",
					["Initialization"] = "		function (scriptTable)\n			--insert code here\n			\n		end\n	",
					["Desc"] = "Show power bar where its value is the buff value (usualy shown in the buff tooltip)",
					["NpcNames"] = {
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Aura is Shield [P]",
					["version"] = -1,
					["Options"] = {
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
				}, -- [15]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n--190187 draconic image\n--189893 infused whelp\n--99922 Ebonclaw Packmate\n--104822 flames of woe",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    Plater.DenyColorChange(unitFrame, false)\n    unitFrame.onShowAddToKillFlash:Stop()\n    \nend\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    if (scriptTable.config.useNameplateColor) then\n        Plater.SetNameplateColor(unitFrame, envTable.NameplateColor)\n    end\nend\n\n\n\n\n",
					["Time"] = 1670427654,
					["url"] = "",
					["Icon"] = "interface/addons/plater/media/exclamation_64",
					["Enabled"] = true,
					["Revision"] = 162,
					["semver"] = "",
					["Author"] = "Huugg-Valdrakken",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Change the color of  add",
					["NpcNames"] = {
						"190187", -- [1]
						"189893", -- [2]
						"99922", -- [3]
						"104822", -- [4]
						129758, -- [5]
						190426, -- [6]
						186696, -- [7]
						101075, -- [8]
						100818, -- [9]
						98081, -- [10]
						52019, -- [11]
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Add - Warning [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 4,
							["Key"] = "useNameplateColor",
							["Value"] = true,
							["Name"] = "Change Nameplate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Change Nameplate Color",
						}, -- [1]
						{
							["Type"] = 1,
							["Name"] = "Nameplate Color",
							["Value"] = {
								1, -- [1]
								0.4392157196998596, -- [2]
								0.458823561668396, -- [3]
								1, -- [4]
							},
							["Key"] = "healthBarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Nameplate Color",
						}, -- [2]
						{
							["Type"] = 6,
							["Key"] = "option5",
							["Value"] = 0,
							["Name"] = "Blank Space",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 4,
							["Name"] = "Flash Nameplate",
							["Value"] = true,
							["Key"] = "useFlash",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Flash Nameplate",
						}, -- [4]
						{
							["Type"] = 7,
							["Name"] = "NpcID to Color",
							["Value"] = {
								{
									"189893", -- [1]
									"olivedrab", -- [2]
								}, -- [1]
								{
									"190187", -- [1]
									"olivedrab", -- [2]
								}, -- [2]
								{
									"99922", -- [1]
									"olivedrab", -- [2]
								}, -- [3]
								{
									"153285", -- [1]
									"olivedrab", -- [2]
								}, -- [4]
								{
									"104822", -- [1]
									"olivedrab", -- [2]
								}, -- [5]
							},
							["Key"] = "npcColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_list",
							["Desc"] = "If the npc isn't on this list, use the default color set in the Health Bar Color",
						}, -- [5]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    unitFrame.onShowAddToKillFlash = unitFrame.onShowAddToKillFlash or Plater.CreateFlash (unitFrame.healthBar, 0.25, 1, \"white\")\n    \n    if (scriptTable.config.useFlash) then\n        unitFrame.onShowAddToKillFlash:Play()\n    end\n    \n    if (scriptTable.config.useNameplateColor) then\n        local npcIdString = tostring(envTable._NpcID)\n        envTable.NameplateColor = Plater.GetColorByPriority(unitFrame, scriptTable.config.npcColor[npcIdString], scriptTable.config.healthBarColor)\n        Plater.DenyColorChange(unitFrame, true)\n    end\nend\n\n\n\n\n\n\n\n\n\n",
				}, -- [16]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \n    local plateFrame = unitFrame.PlateFrame\n    \n    if (not plateFrame.BWC_RedBackground) then\n        plateFrame.BWC_RedBackground = plateFrame:CreateTexture(nil, \"background\")\n        plateFrame.BWC_RedBackground:SetAllPoints()\n    end\n    \n    plateFrame.BWC_RedBackground:SetTexture([[Interface/AddOns/Plater/masks/mask1]])\n    plateFrame.BWC_RedBackground:Hide()\n    \n    function envTable.ShowBackground(unitFrame)\n        local plateFrame = unitFrame.PlateFrame\n        plateFrame.BWC_RedBackground:SetVertexColor(1, 0, 0, 0.4)\n        plateFrame.BWC_RedBackground:Show()\n    end\n    \n    function envTable.HideBackground(unitFrame)\n        plateFrame.BWC_RedBackground:Hide()\n    end\nend\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    envTable.HideBackground(unitFrame)\nend\n\n\n",
					["ScriptType"] = 1,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (Plater.UnitIsCasting(unitId)) then\n        envTable.ShowBackground(unitFrame)\n    else\n        envTable.HideBackground(unitFrame)\n    end\n    \nend",
					["Time"] = 1673726734,
					["url"] = "",
					["Icon"] = 236209,
					["Enabled"] = true,
					["Revision"] = 18,
					["semver"] = "",
					["Author"] = "Tiranaa-Azralon",
					["Initialization"] = "		function (scriptTable)\n			--insert code here\n			\n		end\n	",
					["Desc"] = "Highlight the nameplate of a unit when has a certain Buff (trigger) and start to cast a spell",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						372743, -- [1]
						372749, -- [2]
						384933, -- [3]
					},
					["PlaterCore"] = 1,
					["Name"] = "Aura While Casting [P]",
					["version"] = -1,
					["Options"] = {
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
				}, -- [17]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --castbar color (when can be interrupted)\n    envTable.CastbarColor = scriptTable.config.castbarColor\n    \n    --flash duration\n    local CONFIG_BACKGROUND_FLASH_DURATION = scriptTable.config.flashDuration\n    \n    --add this value to the cast bar height\n    envTable.CastBarHeightAdd = scriptTable.config.castBarHeight\n    \n    --create a fast flash above the cast bar\n    envTable.FullBarFlash = envTable.FullBarFlash or Plater.CreateFlash (self, 0.05, 1, \"white\")\n    \n    --create a camera shake for the nameplate\n    envTable.FrameShake = Plater:CreateFrameShake (unitFrame, scriptTable.config.shakeDuration, scriptTable.config.shakeAmplitude, scriptTable.config.shakeFrequency, false, false, 0, 1, 0.05, 0.1, Plater.GetPoints (unitFrame))\n    \n    --create a texture to use for a flash behind the cast bar\n    local backGroundFlashTexture = Plater:CreateImage (self, [[Interface\\ACHIEVEMENTFRAME\\UI-Achievement-Alert-Glow]], self:GetWidth()+60, self:GetHeight()+50, \"background\", {0, 400/512, 0, 170/256})\n    backGroundFlashTexture:SetBlendMode (\"ADD\", 7)\n    backGroundFlashTexture:SetDrawLayer(\"OVERLAY\", 7)\n    backGroundFlashTexture:SetPoint (\"center\", self, \"center\")\n    backGroundFlashTexture:Hide()\n    \n    --create the animation hub to hold the flash animation sequence\n    envTable.BackgroundFlash = envTable.BackgroundFlash or Plater:CreateAnimationHub (backGroundFlashTexture, \n        function()\n            backGroundFlashTexture:Show()\n        end,\n        function()\n            backGroundFlashTexture:Hide()\n        end\n    )\n    \n    --create the flash animation sequence\n    envTable.BackgroundFlash.fadeIn = envTable.BackgroundFlash.fadeIn or Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 1, CONFIG_BACKGROUND_FLASH_DURATION/2, 0, .75)\n    envTable.BackgroundFlash.fadeIn:SetDuration(CONFIG_BACKGROUND_FLASH_DURATION/2)\n    \n    envTable.BackgroundFlash.fadeOut = envTable.BackgroundFlash.fadeOut or Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 2, CONFIG_BACKGROUND_FLASH_DURATION/2, 1, 0)    \n    envTable.BackgroundFlash.fadeOut:SetDuration(CONFIG_BACKGROUND_FLASH_DURATION/2)\n    \n    --envTable.BackgroundFlash:Play() --envTable.BackgroundFlash:Stop()    \n    \n    \n    \n    \n    \nend\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (not Plater.IsShowingCastBarTest) then\n        --don't execute on battlegrounds and arenas\n        if (Plater.ZoneInstanceType == \"arena\" or Plater.ZoneInstanceType == \"pvp\" or Plater.ZoneInstanceType == \"none\") then\n            return\n        end    \n    end\n    \n    unitFrame.castBar:SetHeight (envTable._DefaultHeight)\n    \n    --stop the camera shake\n    unitFrame:StopFrameShake (envTable.FrameShake)\n    \n    envTable.FullBarFlash:Stop()\n    envTable.BackgroundFlash:Stop()\n    \n    unitFrame.castBar.Spark:SetHeight(unitFrame.castBar:GetHeight())\n    \nend\n\n\n\n\n\n\n\n",
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \nend\n\n\n",
					["Time"] = 1670203603,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_orange",
					["Enabled"] = true,
					["Revision"] = 1194,
					["semver"] = "",
					["Author"] = "Tercioo-Sylvanas",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend",
					["Desc"] = "Flash, Bounce and Red Color the CastBar border when when an important cast is happening. Add spell in the Add Trigger field.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						396640, -- [1]
						372743, -- [2]
						377389, -- [3]
						396812, -- [4]
						388392, -- [5]
						387955, -- [6]
						386546, -- [7]
						377503, -- [8]
						384808, -- [9]
						386024, -- [10]
						387615, -- [11]
						387606, -- [12]
						225100, -- [13]
						211401, -- [14]
						211470, -- [15]
						215433, -- [16]
						192563, -- [17]
						198959, -- [18]
						152818, -- [19]
						156776, -- [20]
						398206, -- [21]
						153524, -- [22]
						396073, -- [23]
						396018, -- [24]
						345202, -- [25]
						377950, -- [26]
						372223, -- [27]
						350421, -- [28]
						352158, -- [29]
						349985, -- [30]
						329239, -- [31]
						328400, -- [32]
						384194, -- [33]
						392451, -- [34]
						392924, -- [35]
						397889, -- [36]
						209413, -- [37]
						207980, -- [38]
						257397, -- [39]
						257736, -- [40]
						382787, -- [41]
						374699, -- [42]
						377402, -- [43]
						369602, -- [44]
						369465, -- [45]
						369400, -- [46]
						381593, -- [47]
						265091, -- [48]
						265433, -- [49]
						382791, -- [50]
						376780, -- [51]
						225573, -- [52]
						278444, -- [53]
						164887, -- [54]
						168082, -- [55]
						76813, -- [56]
						227913, -- [57]
						265368, -- [58]
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - Big Alert [Plater]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Name"] = "Blank Line",
							["Value"] = 0,
							["Key"] = "option1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Produces a notable effect in the cast bar when a spell from the 'Triggers' starts to cast.",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 5,
							["Name"] = "Option 3",
							["Value"] = "Enter the spell name or spellID of the Spell in the Add Trigger box and hit \"Add\".",
							["Key"] = "option3",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 4,
							["Name"] = "Cast Bar Color Enabled",
							["Value"] = true,
							["Key"] = "useCastbarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "When enabled, changes the cast bar color,",
						}, -- [5]
						{
							["Type"] = 1,
							["Name"] = "Cast Bar Color",
							["Value"] = {
								1, -- [1]
								0.4313725490196079, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "castbarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Color of the cast bar.",
						}, -- [6]
						{
							["Type"] = 6,
							["Name"] = "Blank Line",
							["Value"] = 0,
							["Key"] = "option7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [7]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "When the cast starts it flash rapidly, adjust how fast it flashes. Value is milliseconds.",
							["Min"] = 0.05,
							["Name"] = "Flash Duration",
							["Value"] = 0.4,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "flashDuration",
						}, -- [8]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Increases the cast bar height by this value",
							["Min"] = 0,
							["Name"] = "Cast Bar Height Mod",
							["Value"] = 5,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "castBarHeight",
						}, -- [9]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "When the cast starts, there's a small shake in the nameplate, this settings controls how long it takes.",
							["Min"] = 0.1,
							["Name"] = "Shake Duration",
							["Value"] = 0.2,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "shakeDuration",
						}, -- [10]
						{
							["Type"] = 2,
							["Max"] = 100,
							["Desc"] = "How strong is the shake.",
							["Min"] = 2,
							["Fraction"] = false,
							["Value"] = 8,
							["Name"] = "Shake Amplitude",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "shakeAmplitude",
						}, -- [11]
						{
							["Type"] = 2,
							["Max"] = 80,
							["Desc"] = "How fast the shake moves.",
							["Min"] = 1,
							["Fraction"] = false,
							["Value"] = 40,
							["Name"] = "Shake Frequency",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "shakeFrequency",
						}, -- [12]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --don't execute on battlegrounds and arenas\n    if (not Plater.IsShowingCastBarTest) then\n        if (Plater.ZoneInstanceType == \"arena\" or Plater.ZoneInstanceType == \"pvp\" or Plater.ZoneInstanceType == \"none\") then\n            return\n        end\n    end\n    \n    --play flash animations\n    envTable.FullBarFlash:Play()\n    \n    --envTable.currentHeight = unitFrame.castBar:GetHeight()\n    \n    --restoring the default size (not required since it already restore in the hide script)\n    if (envTable.OriginalHeight) then\n        self:SetHeight (envTable.OriginalHeight)\n    end\n    \n    --increase the cast bar size\n    local height = self:GetHeight()\n    envTable.OriginalHeight = height\n    \n    self:SetHeight (height + envTable.CastBarHeightAdd)\n    \n    Plater.SetCastBarBorderColor (self, 1, .2, .2, 0.4)\n    \n    unitFrame:PlayFrameShake (envTable.FrameShake)\n    \n    --set the color of the cast bar to dark orange (only if can be interrupted)\n    --Plater auto set this color to default when a new cast starts, no need to reset this value at OnHide.    \n    if (envTable._CanInterrupt) then\n        if (scriptTable.config.useCastbarColor) then\n            self:SetStatusBarColor (Plater:ParseColors (envTable.CastbarColor))\n        end\n    end\n    \n    Plater.SetCastBarColorForScript(self, scriptTable.config.useCastbarColor, scriptTable.config.castbarColor, envTable)\n    \n    envTable.BackgroundFlash:Play()\n    \n    unitFrame.castBar.Spark:SetHeight(unitFrame.castBar:GetHeight())\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n",
				}, -- [18]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    local castBar = unitFrame.castBar\n    local castBarPortion = castBar:GetWidth()/scriptTable.config.segmentsAmount\n    local castBarHeight = castBar:GetHeight()\n    \n    unitFrame.felAnimation = unitFrame.felAnimation or {}\n    \n    if (not unitFrame.felAnimation.textureStretched) then\n        unitFrame.felAnimation.textureStretched = castBar:CreateTexture(nil, \"overlay\", nil, 5)\n    end\n    \n    if (not unitFrame.stopCastingX) then\n        unitFrame.stopCastingX = castBar.FrameOverlay:CreateTexture(nil, \"overlay\", nil, 7)\n        unitFrame.stopCastingX:SetPoint(\"center\", unitFrame.castBar.Spark, \"center\", 0, 0)\n        unitFrame.stopCastingX:SetTexture([[Interface\\AddOns\\Plater\\Media\\stop_64]])\n        unitFrame.stopCastingX:SetSize(16, 16)\n        unitFrame.stopCastingX:Hide()\n    end\n    \n    if (not unitFrame.felAnimation.Textures) then\n        unitFrame.felAnimation.Textures = {}\n        \n        for i = 1, 20 do\n            local texture = castBar:CreateTexture(nil, \"overlay\", nil, 6)\n            unitFrame.felAnimation.Textures[i] = texture            \n            \n            texture.animGroup = texture.animGroup or texture:CreateAnimationGroup()\n            local animationGroup = texture.animGroup\n            animationGroup:SetToFinalAlpha(true)            \n            animationGroup:SetLooping(\"NONE\")\n            \n            texture:SetTexture([[Interface\\COMMON\\XPBarAnim]])\n            texture:SetTexCoord(0.2990, 0.0010, 0.0010, 0.4159)\n            texture:SetBlendMode(\"ADD\")\n            \n            texture.scale = animationGroup:CreateAnimation(\"SCALE\")\n            texture.scale:SetTarget(texture)\n            \n            texture.alpha = animationGroup:CreateAnimation(\"ALPHA\")\n            texture.alpha:SetTarget(texture)\n            \n            texture.alpha2 = animationGroup:CreateAnimation(\"ALPHA\")\n            texture.alpha2:SetTarget(texture)\n        end\n    end\n    \n    \n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    for i = 1, scriptTable.config.segmentsAmount  do\n        local texture = unitFrame.felAnimation.Textures[i]\n        texture:Hide()\n    end\n    \n    local textureStretched = unitFrame.felAnimation.textureStretched\n    textureStretched:Hide()    \n    unitFrame.stopCastingX:Hide()\n    \n    self.Text:SetDrawLayer(\"overlay\", 0)\n    self.Spark:SetDrawLayer(\"overlay\", 3)\n    self.Spark:Show()\n    \nend\n\n\n\n\n\n\n",
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    local castBar = unitFrame.castBar\n    local textures = unitFrame.felAnimation.Textures\n    \n    if (envTable._CastPercent > envTable.NextPercent) then\n        local nextPercent = 100 / scriptTable.config.segmentsAmount\n        \n        textures[envTable.CurrentTexture]:Show()\n        textures[envTable.CurrentTexture].animGroup:Play()\n        \n        envTable.NextPercent = envTable.NextPercent + nextPercent \n        envTable.CurrentTexture = envTable.CurrentTexture + 1\n        \n        --print(envTable.NextPercent, envTable.CurrentTexture)\n        \n        if (envTable.CurrentTexture == #textures) then\n            envTable.NextPercent = 98\n        elseif (envTable.CurrentTexture > #textures) then\n            envTable.NextPercent = 999\n        end\n    end\n    \n    local normalizedPercent = envTable._CastPercent / 100\n    local textureStretched = unitFrame.felAnimation.textureStretched\n    local point = DetailsFramework:GetBezierPoint(normalizedPercent, 0, 0.001, 1)\n    textureStretched:SetPoint(\"left\", castBar, \"left\", point * envTable.castBarWidth, 0)\n    \n    self.ThrottleUpdate = 0\nend",
					["Time"] = 1672514185,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\media\\stop_64",
					["Enabled"] = true,
					["Revision"] = 506,
					["semver"] = "",
					["Author"] = "Terciob",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Just stop casting",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						377004, -- [1]
						381516, -- [2]
						196543, -- [3]
						199726, -- [4]
						200291, -- [5]
						268202, -- [6]
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - Stop Casting [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 2,
							["Max"] = 20,
							["Desc"] = "Need a /reload",
							["Min"] = 5,
							["Fraction"] = false,
							["Value"] = 20,
							["Name"] = "Amount of Segments",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "segmentsAmount",
						}, -- [1]
						{
							["Type"] = 1,
							["Key"] = "sparkColor",
							["Value"] = {
								0.9568627450980391, -- [1]
								1, -- [2]
								0.9882352941176471, -- [3]
								1, -- [4]
							},
							["Name"] = "Spark Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 1,
							["Key"] = "glowColor",
							["Value"] = {
								0.8588235294117647, -- [1]
								0.4313725490196079, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Name"] = "Glow Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [3]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    local castBar = unitFrame.castBar\n    envTable.castBarWidth = castBar:GetWidth()\n    castBar.Spark:SetVertexColor(DetailsFramework:ParseColors(scriptTable.config.sparkColor))\n    \n    local textureStretched = unitFrame.felAnimation.textureStretched\n    textureStretched:Show()\n    textureStretched:SetVertexColor(DetailsFramework:ParseColors(scriptTable.config.glowColor))\n    textureStretched:SetAtlas(\"XPBarAnim-OrangeTrail\")\n    textureStretched:ClearAllPoints()\n    textureStretched:SetPoint(\"right\", castBar.Spark, \"center\", 0, 0)\n    textureStretched:SetHeight(castBar:GetHeight())\n    textureStretched:SetBlendMode(\"ADD\") \n    textureStretched:SetAlpha(0.5)\n    textureStretched:SetDrawLayer(\"overlay\", 7)\n    \n    for i = 1, scriptTable.config.segmentsAmount  do\n        local texture = unitFrame.felAnimation.Textures[i]\n        texture:SetVertexColor(1, 1, 1, 1)\n        texture:SetDesaturated(true)\n        \n        local castBarPortion = castBar:GetWidth()/scriptTable.config.segmentsAmount\n        \n        texture:SetSize(castBarPortion+5, castBar:GetHeight())\n        texture:SetDrawLayer(\"overlay\", 6)\n        \n        texture:ClearAllPoints()\n        if (i == scriptTable.config.segmentsAmount) then\n            texture:SetPoint(\"right\", castBar, \"right\", 0, 0)\n        else\n            texture:SetPoint(\"left\", castBar, \"left\", (i-1)*castBarPortion, 2)\n        end\n        \n        texture:SetAlpha(0)\n        texture:Hide()\n        \n        texture.scale:SetOrder(1)\n        texture.scale:SetDuration(0.5)\n        texture.scale:SetScaleFrom(0.2, 1)\n        texture.scale:SetScaleTo(1, 1.5)\n        texture.scale:SetOrigin(\"right\", 0, 0)\n        \n        local durationTime = DetailsFramework:GetBezierPoint(i / scriptTable.config.segmentsAmount, 0.2, 0.01, 0.6)\n        local duration = abs(durationTime-0.6)\n        --local duration = 0.6 --debug\n        \n        texture.alpha:SetOrder(1)\n        texture.alpha:SetDuration(0.05)\n        texture.alpha:SetFromAlpha(0)\n        texture.alpha:SetToAlpha(0.4)\n        \n        texture.alpha2:SetOrder(1)\n        texture.alpha2:SetDuration(duration) --0.6\n        texture.alpha2:SetStartDelay(duration)\n        texture.alpha2:SetFromAlpha(0.5)\n        texture.alpha2:SetToAlpha(0)\n    end\n    \n    unitFrame.stopCastingX:Show()\n    \n    envTable.CurrentTexture = 1\n    envTable.NextPercent  = 100  / scriptTable.config.segmentsAmount\n    \n    self.Text:SetDrawLayer(\"artwork\", 7)\n    self.Spark:SetDrawLayer(\"artwork\", 7)\n    self.Spark:Hide()\nend\n\n\n\n\n\n\n\n\n",
				}, -- [19]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \n    if (not unitFrame.spitefulTexture) then\n        unitFrame.spitefulTexture = unitFrame.healthBar:CreateTexture(nil, \"overlay\", nil, 6)\n        unitFrame.spitefulTexture:SetPoint('right', 0, 0)\n        unitFrame.spitefulTexture:SetSize(27, 14)\n        unitFrame.spitefulTexture:SetColorTexture(.3, .3, 1, .7)\n        \n        unitFrame.spitefulText = unitFrame.healthBar:CreateFontString(nil, \"overlay\", \"GameFontNormal\", 6)\n        DetailsFramework:SetFontFace (unitFrame.spitefulText, \"2002\")\n        unitFrame.spitefulText:SetPoint(\"right\", unitFrame.spitefulTexture, \"right\", -2, 0)\n        unitFrame.spitefulText:SetJustifyH(\"right\")\n        \n        unitFrame.roleIcon = unitFrame:CreateTexture(nil, \"overlay\")\n        unitFrame.roleIcon:SetPoint(\"left\", unitFrame.healthBar, \"left\", 2, 0)\n        unitFrame.targetName = unitFrame:CreateFontString(nil, \"overlay\", \"GameFontNormal\")\n        unitFrame.targetName:SetPoint(\"left\", unitFrame.roleIcon, \"right\", 2, 0)\n        \n        unitFrame.spitefulTexture:Hide()\n        unitFrame.spitefulText:Hide()\n    end\n    \n    function envTable.UpdateSpitefulWidget(unitFrame)\n        \n        local r, g, b, a = Plater:ParseColors(scriptTable.config.bgColor)\n        unitFrame.spitefulTexture:SetColorTexture(r, g, b, a)\n        unitFrame.spitefulTexture:SetSize(scriptTable.config.bgWidth, unitFrame.healthBar:GetHeight())   \n        Plater:SetFontSize(unitFrame.spitefulText, scriptTable.config.textSize)\n        Plater:SetFontColor(unitFrame.spitefulText, scriptTable.config.textColor)\n        \n        local currentHealth = unitFrame.healthBar.CurrentHealth\n        local maxHealth = unitFrame.healthBar.CurrentHealthMax\n        \n        local healthPercent = currentHealth / maxHealth * 100\n        local timeToDie = format(\"%.1fs\", healthPercent / 8)\n        unitFrame.spitefulText:SetText(timeToDie)\n        \n        unitFrame.spitefulText:Show()\n        unitFrame.spitefulTexture:Show()\n        \n        if scriptTable.config.switchTargetName then\n            local plateFrame = unitFrame.PlateFrame\n            \n            local target = UnitName(unitFrame.namePlateUnitToken .. \"target\") or UnitName(unitFrame.namePlateUnitToken)\n            \n            if (target and target ~= \"\") then\n                local _, class = UnitClass(unitFrame.namePlateUnitToken .. \"target\")\n                if (class) then\n                    target = DetailsFramework:AddClassColorToText(target, class)\n                end\n                \n                local role = UnitGroupRolesAssigned(unitFrame.namePlateUnitToken .. \"target\")\n                if (role and role ~= \"NONE\") then\n                    target = DetailsFramework:AddRoleIconToText(target, role)\n                end\n                \n                plateFrame.namePlateUnitName = target\n                Plater.UpdateUnitName(plateFrame)\n            end\n        end\n        \n        if scriptTable.config.useTargetingColor then\n            local targeted = UnitIsUnit(unitFrame.namePlateUnitToken .. \"target\", \"player\")\n            if targeted then\n                Plater.SetNameplateColor (unitFrame, scriptTable.config.targetingColor)\n            else\n                Plater.RefreshNameplateColor(unitFrame)\n            end\n        end\n    end\nend",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    if (unitFrame.spitefulTexture) then\n        unitFrame.spitefulText:Hide()\n        unitFrame.spitefulTexture:Hide()    \n        unitFrame.roleIcon:Hide()\n        unitFrame.targetName:Hide()\n    end\nend\n\n\n\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    envTable.UpdateSpitefulWidget(unitFrame)\nend\n\n\n",
					["Time"] = 1611844883,
					["url"] = "",
					["Icon"] = 135945,
					["Enabled"] = true,
					["Revision"] = 186,
					["semver"] = "",
					["Author"] = "Symantec-Azralon",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Time to die Spiteful affix",
					["NpcNames"] = {
						"174773", -- [1]
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "M+ Spiteful",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 5,
							["Key"] = "option12",
							["Value"] = "Time to Die",
							["Name"] = "Time to Die",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 2,
							["Max"] = 50,
							["Desc"] = "",
							["Min"] = 10,
							["Key"] = "bgWidth",
							["Value"] = 27,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Width",
						}, -- [2]
						{
							["Type"] = 1,
							["Key"] = "bgColor",
							["Value"] = {
								0.5058823529411764, -- [1]
								0.07058823529411765, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Name"] = "Background Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 2,
							["Max"] = 24,
							["Desc"] = "",
							["Min"] = 7,
							["Key"] = "textSize",
							["Value"] = 8,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Text Size",
						}, -- [4]
						{
							["Type"] = 1,
							["Key"] = "textColor",
							["Value"] = {
								1, -- [1]
								0.5843137254901961, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Text Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [5]
						{
							["Type"] = 6,
							["Name"] = "Option 7",
							["Value"] = 0,
							["Key"] = "option7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [6]
						{
							["Type"] = 5,
							["Key"] = "option11",
							["Value"] = "Targeting",
							["Name"] = "Targeting",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [7]
						{
							["Type"] = 4,
							["Name"] = "Show Target instead of Name",
							["Value"] = true,
							["Key"] = "switchTargetName",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [8]
						{
							["Type"] = 4,
							["Name"] = "Change Color if targeting You",
							["Value"] = true,
							["Key"] = "useTargetingColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [9]
						{
							["Type"] = 1,
							["Name"] = "Color if targeting You",
							["Value"] = {
								0.07058823529411765, -- [1]
								0.6196078431372549, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "targetingColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [10]
						{
							["Type"] = 6,
							["Key"] = "option11",
							["Value"] = 0,
							["Name"] = "Option 11",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [11]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    envTable.UpdateSpitefulWidget(unitFrame)\nend\n\n\n",
				}, -- [20]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \n    --check for marks\n    function  envTable.CheckMark (unitId, unitFrame)\n        if (not GetRaidTargetIndex(unitId)) then\n            if (scriptTable.config.onlyInCombat) then\n                if (not UnitAffectingCombat(unitId)) then\n                    return\n                end                \n            end\n            \n            SetRaidTarget(unitId, 8)\n        end       \n    end\nend\n\n\n--163520 - forsworn squad-leader\n--163618 - zolramus necromancer - The Necrotic Wake\n--164506 - anciet captain - theater of pain\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    envTable.CheckMark (unitId, unitFrame)\nend\n\n\n",
					["Time"] = 1604696441,
					["url"] = "",
					["Icon"] = "Interface\\Worldmap\\GlowSkull_64Grey",
					["Enabled"] = false,
					["Revision"] = 63,
					["semver"] = "",
					["Author"] = "Aelerolor-Torghast",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Auto set skull marker",
					["NpcNames"] = {
						"163520", -- [1]
						"163618", -- [2]
						"164506", -- [3]
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Auto Set Skull",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 5,
							["Key"] = "option1",
							["Value"] = "Auto set a raid target Skull on the unit.",
							["Name"] = "Option 1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 6,
							["Key"] = "option2",
							["Value"] = 0,
							["Name"] = "Option 2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 4,
							["Key"] = "onlyInCombat",
							["Value"] = false,
							["Name"] = "Only in Combat",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Set the mark only if the unit is in combat.",
						}, -- [3]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    envTable.CheckMark (unitId, unitFrame)\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
				}, -- [21]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.EnergyAmount = Plater:CreateLabel (unitFrame, \"\", 16, \"silver\");\n    envTable.EnergyAmount:SetPoint (\"bottom\", unitFrame, \"top\", 0, 18);    \n    \n    envTable.EnergyAmount.fontsize = scriptTable.config.fontSize\n    envTable.EnergyAmount.fontcolor = scriptTable.config.fontColor\n    envTable.EnergyAmount.outline = scriptTable.config.outline\n    \n    \nend\n\n--[=[\n\n164406 = Shriekwing\n164407 = Sludgefist\n162100 = kryxis the voracious\n162099 = general kaal - sanguine depths\n162329 = Xav the Unfallen - threater of pain\n--]=]",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.EnergyAmount:Hide()\nend\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    local currentPower = UnitPower(unitId)\n    \n    if (currentPower and currentPower > 0) then\n        local maxPower = UnitPowerMax (unitId)\n        local percent = floor (currentPower / maxPower * 100)\n        \n        envTable.EnergyAmount.text = \"\" .. percent;\n        \n        if (scriptTable.config.showLater) then\n            local alpha = (percent -80) * 5\n            alpha = alpha / 100\n            alpha = max(0, alpha)\n            envTable.EnergyAmount:SetAlpha(alpha)\n            \n        else\n            envTable.EnergyAmount:SetAlpha(1.0)\n        end\n        \n        \n    else\n        envTable.EnergyAmount.text = \"\"\n    end\nend\n\n\n\n\n\n\n\n\n",
					["Time"] = 1604357453,
					["url"] = "",
					["Icon"] = 136048,
					["Enabled"] = true,
					["Revision"] = 233,
					["semver"] = "",
					["Author"] = "Celian-Sylvanas",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Show the energy amount above the nameplate.",
					["NpcNames"] = {
						"164406", -- [1]
						"164407", -- [2]
						"162100", -- [3]
						"162099", -- [4]
						"162329", -- [5]
						"164558", -- [6]
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Unit - Show Energy [Plater]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Key"] = "option1",
							["Value"] = 0,
							["Name"] = "Option 1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Key"] = "option3",
							["Value"] = "Show the power of the unit above the nameplate.",
							["Name"] = "script desc",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 5,
							["Name"] = "add trigger",
							["Value"] = "Add the unit name or unitId in the \"Add Trigger\" field and press \"Add\".",
							["Key"] = "option3",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 6,
							["Key"] = "option2",
							["Value"] = 0,
							["Name"] = "Option 2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 4,
							["Key"] = "showLater",
							["Value"] = true,
							["Name"] = "Show at 80% of Energy",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "If enabled, the energy won't start showing until the unit has 80% energy.",
						}, -- [5]
						{
							["Type"] = 6,
							["Name"] = "Option 2",
							["Value"] = 0,
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [6]
						{
							["Type"] = 2,
							["Max"] = 32,
							["Desc"] = "Text size.",
							["Min"] = 8,
							["Name"] = "Text Size",
							["Value"] = 16,
							["Key"] = "fontSize",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [7]
						{
							["Type"] = 1,
							["Key"] = "fontColor",
							["Value"] = {
								0.803921568627451, -- [1]
								0.803921568627451, -- [2]
								0.803921568627451, -- [3]
								1, -- [4]
							},
							["Name"] = "Font Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Color of the text.",
						}, -- [8]
						{
							["Type"] = 4,
							["Key"] = "outline",
							["Value"] = true,
							["Name"] = "Enable Text Outline",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "If enabled, the text uses outline.",
						}, -- [9]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.EnergyAmount:Show()\nend\n\n\n",
				}, -- [22]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n\n--Scorchling 194622\n--Scorchling 190205\n--197398  Hungry Lasher\n--77006 corpse skitterling\n\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --restoring and color state and scale even if disabled, maybe the player disabled during the combat\n    Plater.DenyColorChange(unitFrame, false)\n    unitFrame.healthBar:SetScale(unitFrame.healthBar._savedOriginalScale)\n    \nend\n\n\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (scriptTable.config.useNameplateColor) then\n        Plater.SetNameplateColor (unitFrame, envTable.NameplateColor)\n    end\n    \nend\n\n\n",
					["Time"] = 1670427838,
					["url"] = "",
					["Icon"] = "interface/addons/plater/media/duck_64",
					["Enabled"] = true,
					["Revision"] = 111,
					["semver"] = "",
					["Author"] = "Huugg-Valdrakken",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "",
					["NpcNames"] = {
						"194622", -- [1]
						"190205", -- [2]
						"197398", -- [3]
						"77006", -- [4]
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Add - Non Elite Trash [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 4,
							["Key"] = "useNameplateColor",
							["Value"] = false,
							["Name"] = "Change Nameplate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Change Nameplate Color",
						}, -- [1]
						{
							["Type"] = 1,
							["Name"] = "Nameplate Color",
							["Value"] = {
								0.062745101749897, -- [1]
								0.062745101749897, -- [2]
								0.0941176563501358, -- [3]
								1, -- [4]
							},
							["Key"] = "nameplateColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Nameplate Color",
						}, -- [2]
						{
							["Type"] = 6,
							["Key"] = "option4",
							["Value"] = 0,
							["Name"] = "Option 4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 4,
							["Name"] = "Change Nameplate Scale",
							["Value"] = true,
							["Key"] = "useNameplateScale",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Change Nameplate Scale",
						}, -- [4]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Nameplate Scale",
							["Min"] = 0,
							["Fraction"] = true,
							["Value"] = 0.8,
							["Key"] = "scale",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Nameplate Scale",
						}, -- [5]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (scriptTable.config.useNameplateColor) then\n        envTable.NameplateColor = Plater.GetColorByPriority(unitFrame, scriptTable.config.nameplateColor)\n        Plater.DenyColorChange(unitFrame, true)\n    end    \n    \n    unitFrame.healthBar._savedOriginalScale = unitFrame.healthBar:GetScale()\n    \n    if (scriptTable.config.useNameplateScale) then\n        unitFrame.healthBar:SetScale(scriptTable.config.scale)\n    end\n    \nend\n\n\n\n\n",
				}, -- [23]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \n    local healthBar = unitFrame.healthBar\n    \n    if (not healthBar.absorbBar) then\n        healthBar.absorbBar = healthBar.FrameOverlay:CreateTexture(nil, \"overlay\")\n        healthBar.absorbBar:SetTexture([[Interface\\RaidFrame\\Shield-Fill]])\n        healthBar.absorbBar:Hide()\n    end\n    \n    if (not healthBar.absorbSpark) then\n        healthBar.absorbSpark = healthBar.FrameOverlay:CreateTexture(nil, \"overlay\")\n        healthBar.absorbSpark:SetTexture([[Interface\\CastingBar\\UI-CastingBar-Spark]])\n        healthBar.absorbSpark:SetBlendMode(\"ADD\")\n        healthBar.absorbSpark:Hide()\n    end\n    \nend\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (not UnitGetTotalAbsorbs) then\n        return\n    end\n    \n    local healthBar = unitFrame.healthBar\n    \n    healthBar.absorbBar:Hide()    \n    healthBar.absorbSpark:Hide()\n    \nend\n\n\n",
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (not UnitGetTotalAbsorbs) then\n        return\n    end\n    \n    local healthBar = unitFrame.healthBar\n    \n    healthBar.absorbBar:Show()\n    healthBar.absorbSpark:Show()\n    \n    local maxValue = healthBar.absorbBar.MaxValue\n    local currentValue = UnitGetTotalAbsorbs(unitId) or 0\n    \n    if (currentValue > 0) then\n        local minValue = 0\n        \n        local percent = currentValue / maxValue\n        healthBar.absorbBar:SetTexCoord(0, percent, 0, 1)\n        healthBar.absorbBar:SetWidth(percent * healthBar:GetWidth())\n        \n        healthBar.absorbSpark:SetPoint(\"left\", healthBar, \"left\", percent * healthBar:GetWidth() - 16, 0)\n        \n    else\n        healthBar.absorbBar:Hide()    \n        healthBar.absorbSpark:Hide()\n    end\n    \n    self.ThrottleUpdate = 0\n    \nend\n\n\n\n\n\n\n\n\n\n\n",
					["Time"] = 1669325411,
					["url"] = "",
					["Icon"] = "interface/addons/plater/images/cast_bar - absorb",
					["Enabled"] = true,
					["Revision"] = 101,
					["semver"] = "",
					["Author"] = "Huugg-Valdrakken",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "When the caster has a shield and only when the shield is removed the cast can be interrupted",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						373688, -- [1]
						391050, -- [2]
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - Shield Interrupt [P]",
					["version"] = -1,
					["Options"] = {
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    if (not UnitGetTotalAbsorbs) then\n        return\n    end\n    \n    local healthBar = unitFrame.healthBar\n    \n    healthBar.absorbBar:Show()\n    healthBar.absorbSpark:Show()\n    \n    healthBar.absorbBar:SetTexture([[Interface\\RaidFrame\\Shield-Fill]])\n    \n    healthBar.absorbBar:ClearAllPoints()    \n    healthBar.absorbBar:SetPoint(\"topleft\", healthBar, \"topleft\", 0, 0)\n    healthBar.absorbBar:SetPoint(\"bottomleft\", healthBar, \"bottomleft\", 0, 0)\n    \n    healthBar.absorbBar:SetAlpha(1)\n    \n    healthBar.absorbBar.MaxValue = UnitGetTotalAbsorbs(unitId) or 0\n    healthBar.absorbBar.MinValue = 0\nend\n\n\n",
				}, -- [24]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    function envTable.PlaySwipeAnimation(unitFrame)\n        unitFrame.CastSwipeTexture:Show()\n        unitFrame.CastSwipeAnimation:Play()\n        unitFrame.StartSwipeAnimation:Play()\n    end\n    \n    function envTable.StopSwipeAnimation(unitFrame)\n        unitFrame.EndSwipeAnimation:Play()\n        C_Timer.After(0.21, function()\n                unitFrame.CastSwipeAnimation:Stop()\n                unitFrame.CastSwipeTexture:Hide()\n        end)\n    end\n    \n    function envTable.CreateSwipeTextureAndAnimations(unitFrame)\n        if (unitFrame.CastSwipeTexture) then\n            return\n        end\n        \n        local swipeTexture = unitFrame:CreateTexture(nil, \"overlay\")\n        swipeTexture:SetTexture([[Interface\\AddOns\\Plater\\images\\circular_swipe]])\n        swipeTexture:SetPoint(\"center\", 0, 0)\n        swipeTexture:SetSize(64, 64)\n        swipeTexture:Hide()\n        \n        unitFrame.CastSwipeTexture = swipeTexture\n        \n        --rotation animation\n        unitFrame.CastSwipeAnimation = Plater:CreateAnimationHub(swipeTexture)\n        unitFrame.CastSwipeAnimation:SetLooping(\"repeat\")\n        unitFrame.CastSwipeAnimation.Rotation = Plater:CreateAnimation(unitFrame.CastSwipeAnimation, \"rotation\", 1, 1, 360)\n        \n        --starting animation\n        unitFrame.StartSwipeAnimation = Plater:CreateAnimationHub(swipeTexture, function()swipeTexture:Show() end)\n        unitFrame.StartSwipeAnimation.Alpha = Plater:CreateAnimation(unitFrame.StartSwipeAnimation, \"alpha\", 1, 0.2, 0, 1)\n        unitFrame.StartSwipeAnimation.Scale = Plater:CreateAnimation(unitFrame.StartSwipeAnimation, \"scale\", 1, 0.2, 1.3, 1.3, 1, 1)        \n        \n        --finished animation\n        unitFrame.EndSwipeAnimation = Plater:CreateAnimationHub(swipeTexture, nil, function()swipeTexture:Hide() end)\n        unitFrame.EndSwipeAnimation.Alpha = Plater:CreateAnimation(unitFrame.EndSwipeAnimation, \"alpha\", 1, 0.2, 1, 0)\n        unitFrame.EndSwipeAnimation.Scale = Plater:CreateAnimation(unitFrame.EndSwipeAnimation, \"scale\", 1, 0.2, 1, 1, 1.3, 1.3)\n    end\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.StopSwipeAnimation(unitFrame)\nend\n\n\n",
					["ScriptType"] = 2,
					["UpdateCode"] = "		function (self, unitId, unitFrame, envTable, scriptTable)\n			--insert code here\n			\n		end\n	",
					["Time"] = 1670428019,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\circular_swipe",
					["Enabled"] = true,
					["Revision"] = 162,
					["semver"] = "",
					["Author"] = "Butazzul-Valdrakken",
					["Initialization"] = "		function (scriptTable)\n			--insert code here\n			\n		end\n	",
					["Desc"] = "Play a animation when the spell effect is an circular AoE around the caster.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						385916, -- [1]
						386063, -- [2]
						388822, -- [3]
						373087, -- [4]
						397785, -- [5]
						106864, -- [6]
						193660, -- [7]
						198263, -- [8]
						387910, -- [9]
						370766, -- [10]
						375591, -- [11]
						384336, -- [12]
						209404, -- [13]
						209378, -- [14]
						210875, -- [15]
						396001, -- [16]
						397899, -- [17]
						386559, -- [18]
						382555, -- [19]
						258672, -- [20]
						258777, -- [21]
						257756, -- [22]
						257784, -- [23]
						256405, -- [24]
						256589, -- [25]
						393793, -- [26]
						388046, -- [27]
						375079, -- [28]
						390290, -- [29]
						369811, -- [30]
						369703, -- [31]
						226287, -- [32]
						410999, -- [33]
						372561, -- [34]
						256882, -- [35]
						172578, -- [36]
						412063, -- [37]
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - Circle AoE [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 2,
							["Max"] = 0.3,
							["Desc"] = "Rotation Duration",
							["Min"] = 0.1,
							["Fraction"] = true,
							["Value"] = 0.15,
							["Name"] = "Rotation Duration",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "rotationDuration",
						}, -- [1]
						{
							["Type"] = 6,
							["Name"] = "Option 5",
							["Value"] = 0,
							["Key"] = "option5",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 2,
							["Max"] = 1.5,
							["Desc"] = "Animation Start Duration",
							["Min"] = 0,
							["Name"] = "Animation Start Duration",
							["Value"] = 0.3,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "animStartDuration",
						}, -- [3]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Texture Alpha when the animation start playing, this effect in intended to catch the player attention",
							["Min"] = 0,
							["Key"] = "textureStartAlpha",
							["Value"] = 1,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Texture Start Alpha",
						}, -- [4]
						{
							["Type"] = 6,
							["Key"] = "option5",
							["Value"] = 0,
							["Name"] = "Option 5",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [5]
						{
							["Type"] = 2,
							["Max"] = 1.2,
							["Desc"] = "Texture Scale",
							["Min"] = 0.6,
							["Fraction"] = true,
							["Value"] = 0.8,
							["Name"] = "Texture Scale",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "textureScale",
						}, -- [6]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Texture Alpha",
							["Min"] = 0,
							["Fraction"] = true,
							["Value"] = 1,
							["Name"] = "Texture Alpha",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "textureAlpha",
						}, -- [7]
						{
							["Type"] = 1,
							["Name"] = "Texture Color",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Key"] = "textureColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Texture Color",
						}, -- [8]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    envTable.CreateSwipeTextureAndAnimations(unitFrame)\n    \n    local options = scriptTable.config\n    \n    local targetScale = scriptTable.config.textureScale\n    \n    --swipe rotation duration    \n    unitFrame.CastSwipeAnimation.Rotation:SetDuration(scriptTable.config.rotationDuration)\n    \n    --swipe texture settings\n    unitFrame.CastSwipeTexture:SetVertexColor(Plater:ParseColors(scriptTable.config.textureColor))\n    unitFrame.CastSwipeTexture:SetScale(targetScale)\n    unitFrame.CastSwipeTexture:SetAlpha(scriptTable.config.textureAlpha)  \n    \n    unitFrame.StartSwipeAnimation.Alpha:SetDuration(scriptTable.config.animStartDuration)\n    unitFrame.StartSwipeAnimation.Alpha:SetFromAlpha(scriptTable.config.textureStartAlpha)\n    unitFrame.StartSwipeAnimation.Alpha:SetToAlpha(scriptTable.config.textureAlpha)\n    \n    unitFrame.StartSwipeAnimation.Scale:SetDuration(scriptTable.config.animStartDuration)\n    unitFrame.StartSwipeAnimation.Scale:SetScaleTo(targetScale, targetScale)\n    \n    unitFrame.EndSwipeAnimation.Scale:SetDuration(0.1)\n    unitFrame.EndSwipeAnimation.Alpha:SetDuration(0.1)\n    \n    --start playing\n    envTable.PlaySwipeAnimation(unitFrame)    \n    \nend\n\n\n",
				}, -- [25]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --create a flash texture which keep blinking while the cast in going on\n    self.OGC_BlinkTexture = self.OGC_BlinkTexture or self:CreateTexture(nil, \"overlay\")\n    self.OGC_BlinkTexture:SetColorTexture(1, 1, 1)\n    self.OGC_BlinkTexture:SetAlpha(0)\n    \n    --create the animation group for the blinking texture\n    self.OGC_BlinkAnimation = self.OGC_BlinkAnimation or Plater:CreateAnimationHub(self.OGC_BlinkTexture, function() self.OGC_BlinkTexture:Show() end, function() self.OGC_BlinkTexture:Hide() end)\n    \n    self.OGC_BlinkAnimation.In = self.OGC_BlinkAnimation.In or Plater:CreateAnimation(self.OGC_BlinkAnimation, \"alpha\", 1, 0.5, 0.3, 1)\n    \n    self.OGC_BlinkAnimation.Out = self.OGC_BlinkAnimation.Out or Plater:CreateAnimation(self.OGC_BlinkAnimation, \"alpha\", 2, 0.5, 1, 0.2)    \n    \n    \nend\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    self.OGC_BlinkAnimation:Stop()\n    \n    Plater.StopDotAnimation(self, envTable.dotAnimation1)    \n    Plater.StopDotAnimation(self, envTable.dotAnimation2)   \n    \nend\n\n\n",
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Time"] = 1676905232,
					["url"] = "",
					["Icon"] = 4038101,
					["Enabled"] = true,
					["Revision"] = 73,
					["semver"] = "",
					["Author"] = "Ditador-Azralon",
					["Initialization"] = "		function (scriptTable)\n			--insert code here\n			\n		end\n	",
					["Desc"] = "The background of the nameplate blinks a red color indicating the cast is being performed. Useful to indicate channeling spells doing damage overtime.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						388886, -- [1]
						209676, -- [2]
						377912, -- [3]
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - On Going Cast [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 1,
							["Name"] = "Dots Color",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								0.4166216850280762, -- [4]
							},
							["Key"] = "dotColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Dots Color",
						}, -- [1]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Dots X Offset",
							["Min"] = -10,
							["Key"] = "xOffset",
							["Value"] = 0,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Dots X Offset",
						}, -- [2]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Dots Y Offset",
							["Min"] = -10,
							["Fraction"] = false,
							["Value"] = 0,
							["Name"] = "Dots Y Offset",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "yOffset",
						}, -- [3]
						{
							["Type"] = 6,
							["Key"] = "option4",
							["Value"] = 0,
							["Name"] = "Option 4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Adjust how fast the blinking occurs",
							["Min"] = 0.2,
							["Name"] = "Blink Speed",
							["Value"] = 0.4,
							["Key"] = "speed",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [5]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Min amount of transparency the blink can have",
							["Min"] = 0,
							["Name"] = "Blink Min Alpha",
							["Value"] = 0,
							["Key"] = "minAlpha",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [6]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Max amount of transparency the blink can have",
							["Min"] = 0,
							["Key"] = "maxAlpha",
							["Value"] = 0.5,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Blink Max Alpha",
						}, -- [7]
						{
							["Type"] = 1,
							["Key"] = "blinkColor",
							["Value"] = {
								1, -- [1]
								0.01960784383118153, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Blink Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Color of the blinking texture",
						}, -- [8]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    self.OGC_BlinkTexture:ClearAllPoints()\n    self.OGC_BlinkTexture:SetPoint(\"topleft\", self, \"topleft\", 0, 0)\n    self.OGC_BlinkTexture:SetPoint(\"bottomright\", self, \"bottomright\", 0, 0)\n    \n    local red, green, blue = Plater:ParseColors(scriptTable.config.blinkColor)\n    self.OGC_BlinkTexture:SetVertexColor(red, green, blue)\n    \n    local blinkSpeed = scriptTable.config.speed\n    \n    self.OGC_BlinkAnimation.In:SetDuration(blinkSpeed)\n    self.OGC_BlinkAnimation.Out:SetDuration(blinkSpeed)\n    \n    local minBlinkAlpha = scriptTable.config.minAlpha\n    local maxBlinkAlpha = scriptTable.config.maxAlpha\n    \n    self.OGC_BlinkAnimation.In:SetFromAlpha(minBlinkAlpha)\n    self.OGC_BlinkAnimation.In:SetToAlpha(maxBlinkAlpha)\n    self.OGC_BlinkAnimation.Out:SetFromAlpha(maxBlinkAlpha)    \n    self.OGC_BlinkAnimation.Out:SetToAlpha(minBlinkAlpha)\n    \n    self.OGC_BlinkAnimation:SetLooping(\"repeat\")\n    self.OGC_BlinkAnimation:Play()\n    \n    envTable.dotAnimation1 = Plater.PlayDotAnimation(self, 2, scriptTable.config.dotColor, scriptTable.config.xOffset, scriptTable.config.yOffset)\n    envTable.dotAnimation1.textureInfo.speedMultiplier = 0.3\n    \n    envTable.dotAnimation2 = Plater.PlayDotAnimation(self, 2, scriptTable.config.dotColor, scriptTable.config.xOffset, scriptTable.config.yOffset)\n    envTable.dotAnimation2.textureInfo.speedMultiplier = 1\n    \nend",
				}, -- [26]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["OnHideCode"] = "		function (self, unitId, unitFrame, envTable, scriptTable)\n			--insert code here\n			\n		end\n	",
					["ScriptType"] = 1,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    if (UnitIsUnit(unitId .. \"target\", \"player\")) then\n        Plater.SetNameplateColor(unitFrame, scriptTable.config.nameplateColor)\n    else\n        Plater.RefreshNameplateColor(unitFrame)\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n",
					["Time"] = 1668886509,
					["url"] = "",
					["Icon"] = "Interface\\ICONS\\Ability_Fixated_State_Red",
					["Enabled"] = true,
					["Revision"] = 33,
					["semver"] = "",
					["Author"] = "Ditador-Azralon",
					["Initialization"] = "		function (scriptTable)\n			--insert code here\n			\n		end\n	",
					["Desc"] = "Alert about a unit fixated on the player by using a buff on the enemy unit.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						426662, -- [1]
						426663, -- [2]
					},
					["PlaterCore"] = 1,
					["Name"] = "Fixate by Unit Buff [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 1,
							["Name"] = "Nameplate Color",
							["Value"] = {
								0, -- [1]
								0.5568627450980392, -- [2]
								0.03529411764705882, -- [3]
								1, -- [4]
							},
							["Key"] = "nameplateColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Change the enemy nameplate color to this color when fixating you!",
						}, -- [1]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
				}, -- [27]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    local movingArrowTexture = unitFrame._movingArrowTexture\n    if (not movingArrowTexture) then\n        movingArrowTexture = self:CreateTexture(nil, \"artwork\", nil, 6)\n        unitFrame._movingArrowTexture = movingArrowTexture\n    end\n    \n    envTable.movingAnimation = envTable.movingAnimation or Plater:CreateAnimationHub (unitFrame._movingArrowTexture, \n        function() \n            unitFrame._movingArrowTexture:Show() \n            unitFrame._movingArrowTexture:SetPoint(\"left\", 0, 0)\n        end, \n        function() unitFrame._movingArrowTexture:Hide() end)\n    \n    envTable.movingAnimation:SetLooping (\"REPEAT\")\n    \n    envTable.arrowAnimation = envTable.arrowAnimation or Plater:CreateAnimation (envTable.movingAnimation, \"translation\", 1, 0.20, self:GetWidth()-16, 0)\n    \n    envTable.arrowAnimation:SetDuration(scriptTable.config.animSpeed)\nend\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.movingAnimation:Stop()\nend\n\n\n",
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    unitFrame._movingArrowTexture:SetAlpha(scriptTable.config.arrowAlpha)\n    \n    local percent = envTable.movingAnimation:GetProgress()\n    \n    if (percent < 0.4) then\n        local value = Lerp(0.01, scriptTable.config.arrowAlpha, percent) or 0\n        unitFrame._movingArrowTexture:SetAlpha(Saturate(value))\n        \n    elseif (percent > 0.6) then\n        local value = Lerp(scriptTable.config.arrowAlpha, 0.01, percent) or 0\n        unitFrame._movingArrowTexture:SetAlpha(Saturate(value))\n    end\n    \n    --unitFrame._movingArrowTexture:SetAlpha(1)\n    \n    self.ThrottleUpdate = 0\nend",
					["Time"] = 1670202265,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_frontal",
					["Enabled"] = true,
					["Revision"] = 620,
					["semver"] = "",
					["Author"] = "Izimode-Azralon",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Does an animation for casts that affect the frontal area of the enemy. Add spell in the Add Trigger field.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						375943, -- [1]
						385958, -- [2]
						388623, -- [3]
						377034, -- [4]
						374361, -- [5]
						381525, -- [6]
						386660, -- [7]
						385578, -- [8]
						384699, -- [9]
						153501, -- [10]
						153686, -- [11]
						154442, -- [12]
						192018, -- [13]
						219488, -- [14]
						372087, -- [15]
						391726, -- [16]
						391723, -- [17]
						377383, -- [18]
						388976, -- [19]
						370764, -- [20]
						387067, -- [21]
						391118, -- [22]
						391136, -- [23]
						382233, -- [24]
						209027, -- [25]
						212031, -- [26]
						207261, -- [27]
						207979, -- [28]
						198888, -- [29]
						199805, -- [30]
						199050, -- [31]
						191508, -- [32]
						152792, -- [33]
						153395, -- [34]
						352833, -- [35]
						330403, -- [36]
						209495, -- [37]
						257426, -- [38]
						255952, -- [39]
						257870, -- [40]
						413147, -- [41]
						383107, -- [42]
						377559, -- [43]
						388060, -- [44]
						376170, -- [45]
						384524, -- [46]
						375351, -- [47]
						390111, -- [48]
						369791, -- [49]
						369573, -- [50]
						369563, -- [51]
						369335, -- [52]
						369061, -- [53]
						375727, -- [54]
						265016, -- [55]
						265019, -- [56]
						260793, -- [57]
						260292, -- [58]
						272457, -- [59]
						272609, -- [60]
						269843, -- [61]
						183465, -- [62]
						226296, -- [63]
						188169, -- [64]
						183088, -- [65]
						410873, -- [66]
						411012, -- [67]
						88308, -- [68]
						382708, -- [69]
						375251, -- [70]
						375439, -- [71]
						372311, -- [72]
						373742, -- [73]
						372201, -- [74]
						374533, -- [75]
						377204, -- [76]
						201226, -- [77]
						204667, -- [78]
						198379, -- [79]
						200768, -- [80]
						253239, -- [81]
						250258, -- [82]
						255567, -- [83]
						194956, -- [84]
						427510, -- [85]
						426645, -- [86]
						412505, -- [87]
						412129, -- [88]
						419351, -- [89]
						401482, -- [90]
						404916, -- [91]
						200345, -- [92]
						200261, -- [93]
						198641, -- [94]
						265372, -- [95]
						271174, -- [96]
						264694, -- [97]
						264923, -- [98]
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - Frontal Cone [Plater]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Name"] = "Option 1",
							["Value"] = 0,
							["Key"] = "option1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Produces an effect to indicate the spell will hit players in front of the enemy.",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 5,
							["Name"] = "Option 4",
							["Value"] = "Enter the spell name or spellID of the Spell in the Add Trigger box and hit \"Add\".",
							["Key"] = "option4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 6,
							["Name"] = "Option 3",
							["Value"] = 0,
							["Key"] = "option3",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Set the alpha of the moving arrow",
							["Min"] = 0,
							["Fraction"] = true,
							["Value"] = 0.73,
							["Key"] = "arrowAlpha",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Arrow Alpha",
						}, -- [5]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Time that takes for an arrow to travel from the to right.",
							["Min"] = 0,
							["Fraction"] = true,
							["Value"] = 0.2,
							["Key"] = "animSpeed",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Animation Speed",
						}, -- [6]
						{
							["Type"] = 4,
							["Name"] = "Use White Arrow",
							["Value"] = false,
							["Key"] = "desaturateArrow",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "If enabled, the arrow color will be desaturated.",
						}, -- [7]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    unitFrame._movingArrowTexture:SetTexture([[Interface\\PETBATTLES\\PetBattle-StatIcons]])\n    unitFrame._movingArrowTexture:SetSize(16, self:GetHeight() - 2)\n    unitFrame._movingArrowTexture:SetTexCoord(unpack({0, 15/32, 18/32, 30/32}))\n    unitFrame._movingArrowTexture:SetAlpha(scriptTable.config.arrowAlpha)\n    unitFrame._movingArrowTexture:SetDesaturated(scriptTable.config.desaturateArrow)    \n    \n    unitFrame._movingArrowTexture:SetParent(self.FrameOverlay)\n    unitFrame._movingArrowTexture:SetDrawLayer(\"overlay\",  7)\n    \n    envTable.arrowAnimation:SetDuration(scriptTable.config.animSpeed)\n    envTable.movingAnimation:Play()\nend\n\n\n",
				}, -- [28]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    function envTable.CreateWidgets()\n        --create a camera shake for the nameplate\n        if (not unitFrame.AddExplosionOnDieShake) then\n            unitFrame.AddExplosionOnDieShake = Plater:CreateFrameShake (unitFrame, scriptTable.config.shakeDuration, scriptTable.config.shakeAmplitude, scriptTable.config.shakeFrequency, false, false, 0, 1, 0.05, 0.1, Plater.GetPoints (unitFrame))\n        end\n        \n        if (not unitFrame.AddExplosionOnDieBackground) then\n            unitFrame.AddExplosionOnDieBackground = unitFrame.healthBar:CreateTexture(nil, \"background\")\n            unitFrame.AddExplosionOnDieBackground:SetAllPoints(unitFrame.healthBar)\n            unitFrame.AddExplosionOnDieBackground:SetColorTexture(1, 0, 0, 1)\n        end\n    end\n    \nend\n\n--194895 = unstable squall\n--105703 = mana wyrm\n--59598 = lesser sha\n--58319 = lesser sha\n\n\n\n\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \n    local healthBar = unitFrame.healthBar\n    healthBar:SetReverseFill(false)\n    \n    if (unitFrame.AddExplosionOnDieShake) then\n        unitFrame:StopFrameShake (unitFrame.AddExplosionOnDieShake)    \n    end\n    \n    if (unitFrame.AddExplosionOnDieBackground) then\n        unitFrame.AddExplosionOnDieBackground:Hide()\n    end\nend\n\n\n\n\n\n\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (envTable._HealthPercent < 50) then\n        local alpha = DetailsFramework:MapRangeClamped(0, 50, 0.5, 0, envTable._HealthPercent)\n        \n        unitFrame.AddExplosionOnDieBackground:SetAlpha(alpha)\n    else\n        unitFrame.AddExplosionOnDieBackground:SetAlpha(0)\n    end\n    \n    if (envTable._HealthPercent < 15 and scriptTable.config.useShake) then\n        local shakeAmpliture = DetailsFramework:MapRangeClamped(0.001, 15, 10, 1, envTable._HealthPercent)\n        \n        unitFrame.AddExplosionOnDieShake.OriginalAmplitude = scriptTable.config.shakeAmplitude * shakeAmpliture\n        unitFrame.AddExplosionOnDieShake.OriginalFrequency = scriptTable.config.shakeFrequency\n        \n        unitFrame:PlayFrameShake (unitFrame.AddExplosionOnDieShake)\n    end\n    \n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["Time"] = 1669340350,
					["url"] = "",
					["Icon"] = "interface/addons/plater/media/radio_64",
					["Enabled"] = true,
					["Revision"] = 106,
					["semver"] = "",
					["Author"] = "Huugg-Valdrakken",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "",
					["NpcNames"] = {
						"194895", -- [1]
						"105703", -- [2]
						"59598", -- [3]
						"58319", -- [4]
						200388, -- [5]
						189299, -- [6]
						131402, -- [7]
						135052, -- [8]
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Add - Explode on Die [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 4,
							["Key"] = "useReverse",
							["Value"] = false,
							["Name"] = "Reverse Health Bar",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 6,
							["Key"] = "option6",
							["Value"] = 0,
							["Name"] = "Option 6",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 4,
							["Key"] = "useShake",
							["Value"] = false,
							["Name"] = "Enable Shake",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "How strong is the shake.",
							["Min"] = 0.05,
							["Key"] = "shakeAmplitude",
							["Value"] = 0.2,
							["Name"] = "Shake Amplitude",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [4]
						{
							["Type"] = 2,
							["Max"] = 80,
							["Desc"] = "How fast the shake moves.",
							["Min"] = 1,
							["Key"] = "shakeFrequency",
							["Value"] = 70,
							["Name"] = "Shake Frequency",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [5]
						{
							["Type"] = 6,
							["Key"] = "option7",
							["Value"] = 0,
							["Name"] = "Option 7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [6]
						{
							["Type"] = 4,
							["Key"] = "useBackground",
							["Value"] = true,
							["Name"] = "Show Red Background",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Show Red Background",
						}, -- [7]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \n    local healthBar = unitFrame.healthBar\n    \n    if (scriptTable.config.useReverse) then\n        healthBar:SetReverseFill(true)\n    end\n    \n    --unitFrame.AddExplosionOnDieShake\n    \n    envTable.CreateWidgets()\n    \n    unitFrame.AddExplosionOnDieShake.OriginalAmplitude = scriptTable.config.shakeAmplitude\n    unitFrame.AddExplosionOnDieShake.OriginalDuration = 0.120\n    unitFrame.AddExplosionOnDieShake.OriginalFrequency = scriptTable.config.shakeFrequency\n    \n    if (scriptTable.config.useBackground) then\n        unitFrame.AddExplosionOnDieBackground:Show()\n        unitFrame.AddExplosionOnDieBackground:SetAlpha(0)\n    else\n        unitFrame.AddExplosionOnDieBackground:Hide()\n    end\nend\n\n\n\n\n\n\n",
				}, -- [29]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.FixateTarget = Plater:CreateLabel (unitFrame);\n    envTable.FixateTarget:SetPoint (\"bottom\", unitFrame.BuffFrame, \"top\", 0, 10);    \n    \n    envTable.FixateIcon = Plater:CreateImage (unitFrame, 236188, 16, 16, \"overlay\");\n    envTable.FixateIcon:SetPoint (\"bottom\", envTable.FixateTarget, \"top\", 0, 4);    \n    \n    envTable.FixateTarget:Hide()\n    envTable.FixateIcon:Hide()\nend\n\n--165560 = Gormling Larva - MTS\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable)\n    envTable.FixateTarget:Hide()\n    envTable.FixateIcon:Hide()\nend\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    local targetName = UnitName (unitId .. \"target\");\n    if (targetName) then\n        local _, class = UnitClass (unitId .. \"target\");\n        targetName = Plater.SetTextColorByClass (unitId .. \"target\", targetName);\n        envTable.FixateTarget.text = targetName;\n        \n        envTable.FixateTarget:Show();\n        envTable.FixateIcon:Show();\n    end    \nend\n\n\n",
					["Time"] = 1604239880,
					["url"] = "",
					["Icon"] = 1029718,
					["Enabled"] = true,
					["Revision"] = 269,
					["semver"] = "",
					["Author"] = "Celian-Sylvanas",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n\n\n\n\n",
					["Desc"] = "Show above the nameplate who is the player fixated",
					["NpcNames"] = {
						"165560", -- [1]
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Fixate [Plater]",
					["version"] = -1,
					["Options"] = {
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable)\n    \nend\n\n\n",
				}, -- [30]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \n    envTable.npcInfo = {\n        [164427] = {secondCastBar = true, timer = 20, timerId = 321247, altCastId = \"1\", name = \"Boom!\"}, --reanimated warrior - plaguefall\n        \n        [164414] = {secondCastBar = true, timer = 20, timerId = 321247, altCastId = \"2\", name = \"Boom!\"}, --reanimated mage - plaguefall\n        \n        [164185] = {secondCastBar = true, timer = 20, timerId = 319941, altCastId = \"3\", remaining = 5, name = GetSpellInfo(319941)}, --Echelon - Halls of Atonement\n        \n        [164567] = {secondCastBar = true, altCastId = \"dromanswrath\", debuffTimer = 323059, name = GetSpellInfo(323059), spellIcon = 323059}, --Ingra Maloch -- tirna scythe\n        \n        [165408] = {secondCastBar = true, timer = 20, timerId = 322711, altCastId = \"4\", remaining = 5, name = GetSpellInfo(322711)}, --Halkias - Refracted Sinlight - Halls of Atonement\n        \n        \n        --[154564] = {secondCastBar = true, timerId = \"Test Bar\", altCastId = \"debugcast\", remaining = 5, name = GetSpellInfo(319941), spellIcon = 319941}, --debug \"Test (1)\" BW \"Test Bar\" DBM --DEBUG\n        --[154580] = {secondCastBar = true, altCastId = \"debugcast\", debuffTimer = 204242, name = GetSpellInfo(81297), spellIcon = 81297}, --debug \"Test (1)\" BW \"Test Bar\" DBM --DEBUG\n    }\n    \n    --set the castbar config\n    local config = {\n        iconTexture = \"\",\n        iconTexcoord = {0.1, 0.9, 0.1, 0.9},\n        iconAlpha = 1,\n        iconSize = 14,\n        \n        text = \"Boom!\",\n        textSize = 9,\n        \n        texture = [[Interface\\AddOns\\Plater\\images\\bar_background]],\n        color = \"silver\",\n        \n        isChanneling = false,\n        canInterrupt = false,\n        \n        height = 2,\n        width = Plater.db.profile.plate_config.enemynpc.health_incombat[1],\n        \n        spellNameAnchor = {side = 3, x = 0, y = -2},\n        timerAnchor = {side = 5, x = 0, y = -2},\n    }    \n    \n    function envTable.ShowAltCastBar(npcInfo, unitFrame, unitId, customTime, customStart)\n        --show the cast bar\n        if (npcInfo.timerId) then\n            local barObject = Plater.GetBossTimer(npcInfo.timerId)\n            if (barObject) then\n                if (npcInfo.remaining) then\n                    local timeLeft = barObject.timer + barObject.start - GetTime()\n                    if (timeLeft > npcInfo.remaining) then\n                        return\n                    end\n                end\n                \n                config.text = npcInfo.name\n                \n                if (npcInfo.spellIcon) then\n                    local _, _, iconTexture = GetSpellInfo(npcInfo.spellIcon)\n                    config.iconTexture = iconTexture\n                else\n                    config.iconTexture = \"\"\n                end\n                \n                Plater.SetAltCastBar(unitFrame.PlateFrame, config, barObject.timer, customStart or barObject.start, npcInfo.altCastId)\n            end\n        else\n            Plater.SetAltCastBar(unitFrame.PlateFrame, config, customTime or npcInfo.timer, customStart, npcInfo.altCastId)            \n        end\n        \n        DetailsFramework:TruncateText(unitFrame.castBar2.Text, unitFrame.castBar2:GetWidth() - 16)\n    end\nend",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    Plater.ClearAltCastBar(unitFrame.PlateFrame)\nend",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    local npcInfo = envTable.npcInfo[envTable._NpcID]\n    \n    if (npcInfo and npcInfo.secondCastBar) then\n        if (npcInfo.timerId) then\n            local barObject = Plater.GetBossTimer(npcInfo.timerId)\n            if (barObject) then\n                local altCastId = Plater.GetAltCastBarAltId(unitFrame.PlateFrame)\n                if (altCastId ~= npcInfo.altCastId or not unitFrame.castBar2:IsShown()) then\n                    envTable.ShowAltCastBar(npcInfo, unitFrame, unitId)\n                end\n            end \n            \n        elseif (npcInfo.debuffTimer) then\n            if (Plater.NameplateHasAura (unitFrame, npcInfo.debuffTimer)) then\n                \n                --get the debuff timeleft\n                local name = npcInfo.name\n                local _, _, _, _, duration, expirationTime = AuraUtil.FindAuraByName(name, unitId, \"DEBUFF\")\n                local startTime = expirationTime - duration\n                \n                if (not unitFrame.castBar2:IsShown() or unitFrame.castBar2.spellStartTime < startTime) then\n                    envTable.ShowAltCastBar(npcInfo, unitFrame, unitId, duration, startTime)\n                end\n                \n            else \n                if (unitFrame.castBar2:IsShown()) then\n                    local altCastId = Plater.GetAltCastBarAltId(unitFrame.PlateFrame)\n                    if (altCastId == npcInfo.altCastId) then\n                        Plater.ClearAltCastBar(unitFrame.PlateFrame)\n                    end                   \n                end                              \n            end\n        end\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["Time"] = 1604354364,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\Images\\countdown_bar_icon",
					["Enabled"] = true,
					["Revision"] = 206,
					["semver"] = "",
					["Author"] = "Aelerolor-Torghast",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Some units has special events without a clear way to show. This script adds a second cast bar to inform the user about it.",
					["NpcNames"] = {
						"164427", -- [1]
						"164414", -- [2]
						"164185", -- [3]
						"164567", -- [4]
						"165408", -- [5]
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Countdown",
					["version"] = -1,
					["Options"] = {
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    local npcInfo = envTable.npcInfo[envTable._NpcID]\n    \n    if (npcInfo and npcInfo.secondCastBar) then\n        if (npcInfo.debuffTimer) then\n            if (Plater.NameplateHasAura (unitFrame, npcInfo.debuffTimer)) then\n                \n                local name = npcInfo.name\n                local _, _, _, _, duration, expirationTime = AuraUtil.FindAuraByName(name, unitId, \"DEBUFF\")\n                \n                envTable.ShowAltCastBar(npcInfo, unitFrame, unitId, duration, expirationTime-duration)\n            else\n                if (unitFrame.castBar2:IsShown()) then\n                    local altCastId = Plater.GetAltCastBarAltId(unitFrame.PlateFrame)\n                    if (altCastId == npcInfo.altCastId) then\n                        Plater.ClearAltCastBar(unitFrame.PlateFrame)\n                    end                   \n                end                              \n            end\n        else\n            envTable.ShowAltCastBar(npcInfo, unitFrame, unitId)\n        end\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
				}, -- [31]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --create a texture to use for a flash behind the cast bar\n    local backGroundFlashTexture = Plater:CreateImage (self, [[Interface\\ACHIEVEMENTFRAME\\UI-Achievement-Alert-Glow]], self:GetWidth()+40, self:GetHeight()+20, \"background\", {0, 400/512, 0, 170/256})\n    backGroundFlashTexture:SetBlendMode (\"ADD\")\n    backGroundFlashTexture:SetDrawLayer(\"OVERLAY\", 7)\n    backGroundFlashTexture:SetPoint (\"center\", self, \"center\")\n    backGroundFlashTexture:SetVertexColor(Plater:ParseColors(scriptTable.config.flashColor))\n    backGroundFlashTexture:Hide()\n    \n    --create the animation hub to hold the flash animation sequence\n    envTable.BackgroundFlash = envTable.BackgroundFlash or Plater:CreateAnimationHub (backGroundFlashTexture, \n        function()\n            backGroundFlashTexture:Show()\n        end,\n        function()\n            backGroundFlashTexture:Hide()\n        end\n    )\n    \n    --create the flash animation sequence\n    local fadeIn = Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 1, scriptTable.config.flashDuration/2, 0, 1)\n    local fadeOut = Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 2, scriptTable.config.flashDuration/2, 1, 0)\n    \n    --create a camera shake for the nameplate\n    envTable.FrameShake = Plater:CreateFrameShake (unitFrame, scriptTable.config.shakeDuration, scriptTable.config.shakeAmplitude, scriptTable.config.shakeFrequency, false, false, 0, 1, 0.05, 0.1, Plater.GetPoints (unitFrame))\n    \n    --update the config for the flash here so it wont need a /reload\n    fadeIn:SetDuration (scriptTable.config.flashDuration/2)\n    fadeOut:SetDuration (scriptTable.config.flashDuration/2)\n    \n    --update the config for the skake here so it wont need a /reload\n    envTable.FrameShake.OriginalAmplitude = scriptTable.config.shakeAmplitude\n    envTable.FrameShake.OriginalDuration = scriptTable.config.shakeDuration\n    envTable.FrameShake.OriginalFrequency = scriptTable.config.shakeFrequency\nend",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    Plater.StopDotAnimation(unitFrame.castBar, envTable.dotAnimation)    \n    \n    envTable.BackgroundFlash:Stop()\n    \n    unitFrame:StopFrameShake (envTable.FrameShake)    \n    \nend\n\n\n",
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \nend\n\n\n",
					["Time"] = 1673994690,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_darkorange",
					["Enabled"] = true,
					["Revision"] = 828,
					["semver"] = "",
					["Author"] = "Bombad�o-Azralon",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Highlight a very important cast applying several effects into the Cast Bar. Add spell in the Add Trigger field.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						373046, -- [1]
						372863, -- [2]
						164686, -- [3]
						153072, -- [4]
						153680, -- [5]
						196497, -- [6]
						388886, -- [7]
						387145, -- [8]
						384365, -- [9]
						152964, -- [10]
						398150, -- [11]
						152801, -- [12]
						397878, -- [13]
						397914, -- [14]
						183263, -- [15]
						3636, -- [16]
						376171, -- [17]
						350687, -- [18]
						372735, -- [19]
						373017, -- [20]
						350687, -- [21]
						392488, -- [22]
						257732, -- [23]
						256060, -- [24]
						257899, -- [25]
						384633, -- [26]
						374339, -- [27]
						395694, -- [28]
						391634, -- [29]
						372701, -- [30]
						369328, -- [31]
						265487, -- [32]
						413044, -- [33]
						183526, -- [34]
						88194, -- [35]
						87762, -- [36]
						413385, -- [37]
						411001, -- [38]
						378282, -- [39]
						384161, -- [40]
						259572, -- [41]
						255371, -- [42]
						427460, -- [43]
						429172, -- [44]
						426500, -- [45]
						413607, -- [46]
						412922, -- [47]
						417481, -- [48]
						201399, -- [49]
						411994, -- [50]
						415770, -- [51]
						260907, -- [52]
						260703, -- [53]
						260741, -- [54]
						265876, -- [55]
						263959, -- [56]
						266225, -- [57]
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - Very Important [Plater]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Key"] = "option1",
							["Value"] = 0,
							["Name"] = "Option 1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Key"] = "option2",
							["Value"] = "Plays a big animation when the cast start.",
							["Name"] = "Option 2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Enter the spell name or spellID of the Spell in the Add Trigger box and hit \"Add\".",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 6,
							["Key"] = "option4",
							["Value"] = 0,
							["Name"] = "Option 4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 5,
							["Key"] = "option2",
							["Value"] = "Flash:",
							["Name"] = "Flash",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [5]
						{
							["Type"] = 2,
							["Max"] = 1.2,
							["Desc"] = "How long is the flash played when the cast starts.",
							["Min"] = 0.1,
							["Fraction"] = true,
							["Value"] = 0.8,
							["Name"] = "Flash Duration",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "flashDuration",
						}, -- [6]
						{
							["Type"] = 1,
							["Key"] = "flashColor",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Name"] = "Flash Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Color of the Flash",
						}, -- [7]
						{
							["Type"] = 6,
							["Key"] = "option7",
							["Value"] = 0,
							["Name"] = "Option 7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [8]
						{
							["Type"] = 5,
							["Name"] = "Shake",
							["Value"] = "Shake:",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [9]
						{
							["Type"] = 2,
							["Max"] = 0.5,
							["Desc"] = "When the cast starts, there's a small shake in the nameplate, this settings controls how long it takes.",
							["Min"] = 0.1,
							["Fraction"] = true,
							["Value"] = 0.2,
							["Name"] = "Shake Duration",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "shakeDuration",
						}, -- [10]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "How strong is the shake.",
							["Min"] = 1,
							["Fraction"] = false,
							["Value"] = 5,
							["Name"] = "Shake Amplitude",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "shakeAmplitude",
						}, -- [11]
						{
							["Type"] = 2,
							["Max"] = 80,
							["Desc"] = "How fast the shake moves.",
							["Min"] = 1,
							["Fraction"] = false,
							["Value"] = 40,
							["Name"] = "Shake Frequency",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "shakeFrequency",
						}, -- [12]
						{
							["Type"] = 6,
							["Key"] = "option13",
							["Value"] = 0,
							["Name"] = "Option 13",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [13]
						{
							["Type"] = 5,
							["Key"] = "option14",
							["Value"] = "Dot Animation:",
							["Name"] = "Dot Animation",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [14]
						{
							["Type"] = 1,
							["Key"] = "dotColor",
							["Value"] = {
								0.5647058823529412, -- [1]
								0.5647058823529412, -- [2]
								0.5647058823529412, -- [3]
								1, -- [4]
							},
							["Name"] = "Dot Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Adjust the color of the dots around the nameplate",
						}, -- [15]
						{
							["Type"] = 2,
							["Max"] = 20,
							["Desc"] = "Adjust the width of the dots to better fit in your nameplate.",
							["Min"] = -10,
							["Name"] = "Dot X Offset",
							["Value"] = 8,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "xOffset",
						}, -- [16]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Adjust the height of the dots to better fit in your nameplate.",
							["Min"] = -10,
							["Key"] = "yOffset",
							["Value"] = 3,
							["Name"] = "Dot Y Offset",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [17]
						{
							["Type"] = 6,
							["Key"] = "option18",
							["Value"] = 0,
							["Name"] = "blank",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [18]
						{
							["Type"] = 6,
							["Name"] = "blank",
							["Value"] = 0,
							["Key"] = "option18",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [19]
						{
							["Type"] = 6,
							["Name"] = "blank",
							["Value"] = 0,
							["Key"] = "option18",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [20]
						{
							["Type"] = 6,
							["Key"] = "option18",
							["Value"] = 0,
							["Name"] = "blank",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [21]
						{
							["Type"] = 6,
							["Key"] = "option18",
							["Value"] = 0,
							["Name"] = "blank",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [22]
						{
							["Type"] = 6,
							["Name"] = "blank",
							["Value"] = 0,
							["Key"] = "option18",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [23]
						{
							["Type"] = 5,
							["Key"] = "option19",
							["Value"] = "Cast Bar",
							["Name"] = "Option 19",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [24]
						{
							["Type"] = 4,
							["Key"] = "useCastbarColor",
							["Value"] = true,
							["Name"] = "Use Cast Bar Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Use cast bar color.",
						}, -- [25]
						{
							["Type"] = 1,
							["Key"] = "castBarColor",
							["Value"] = {
								0.4117647058823529, -- [1]
								1, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Cast Bar Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Cast bar color.",
						}, -- [26]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.dotAnimation = Plater.PlayDotAnimation(unitFrame.castBar, 5, scriptTable.config.dotColor, scriptTable.config.xOffset, scriptTable.config.yOffset)\n    \n    envTable.BackgroundFlash:Play()\n    \n    Plater.FlashNameplateBorder (unitFrame, 0.05)   \n    Plater.FlashNameplateBody (unitFrame, \"\", 0.075)\n    \n    unitFrame:PlayFrameShake (envTable.FrameShake)\n    \n    Plater.SetCastBarColorForScript(self, scriptTable.config.useCastbarColor, scriptTable.config.castBarColor, envTable)\n    \n    --Dominator on Shadowmoon Burial Grounds\n    if (envTable._SpellID == 154327) then\n        if (UnitHealth(unitId) == UnitHealthMax(unitId)) then\n            if (envTable._Duration == 604800) then\n                Plater.SetCastBarColorForScript(self, scriptTable.config.useCastbarColor, {1, 0, 0, 1}, envTable)\n            end\n        end\n    end\nend",
				}, -- [32]
				{
					["ConstructorCode"] = "--todo: add npc ids for multilanguage support\n\nfunction (self, unitId, unitFrame, envTable)\n    \n    --settings\n    envTable.TextAboveNameplate = \"** On You **\"\n    envTable.NameplateColor = \"green\"\n    \n    --label to show the text above the nameplate\n    envTable.FixateTarget = Plater:CreateLabel (unitFrame);\n    envTable.FixateTarget:SetPoint (\"bottom\", unitFrame.healthBar, \"top\", 0, 30);\n    \n    --the spell casted by the npc in the trigger list needs to be in the list below as well\n    local spellList = {\n        [321891] = \"Freeze Tag Fixation\", --Illusionary Vulpin - MTS\n        \n    }\n    \n    --build the list with localized spell names\n    envTable.FixateDebuffs = {}\n    for spellID, enUSSpellName in pairs (spellList) do\n        local localizedSpellName = GetSpellInfo (spellID)\n        envTable.FixateDebuffs [localizedSpellName or enUSSpellName] = true\n    end\n    \n    --debug - smuggled crawg\n    envTable.FixateDebuffs [\"Jagged Maw\"] = true\n    \nend\n\n--[=[\nNpcIDs:\n136461: Spawn of G'huun (mythic uldir G'huun)\n\n--]=]\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable)\n    envTable.FixateTarget:SetText (\"\")\n    envTable.FixateTarget:Hide()\n    \n    envTable.IsFixated = false\n    \n    Plater.RefreshNameplateColor (unitFrame)\nend\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    --swap this to true when it is fixated\n    local isFixated = false\n    \n    --check the debuffs the player has and see if any of these debuffs has been placed by this unit\n    for debuffId = 1, 40 do\n        local name, texture, count, debuffType, duration, expirationTime, caster = UnitDebuff (\"player\", debuffId)\n        \n        --cancel the loop if there's no more debuffs on the player\n        if (not name) then \n            break \n        end\n        \n        --check if the owner of the debuff is this unit\n        if (envTable.FixateDebuffs [name] and caster and UnitIsUnit (caster, unitId)) then\n            --the debuff the player has, has been placed by this unit, set the name above the unit name\n            envTable.FixateTarget:SetText (envTable.TextAboveNameplate)\n            envTable.FixateTarget:Show()\n            Plater.SetNameplateColor (unitFrame,  envTable.NameplateColor)\n            isFixated = true\n            \n            if (not envTable.IsFixated) then\n                envTable.IsFixated = true\n                Plater.FlashNameplateBody (unitFrame, \"fixate\", .2)\n            end\n        end\n        \n    end\n    \n    --check if the nameplate color is changed but isn't fixated any more\n    if (not isFixated and envTable.IsFixated) then\n        --refresh the nameplate color\n        Plater.RefreshNameplateColor (unitFrame)\n        --reset the text\n        envTable.FixateTarget:SetText (\"\")\n        \n        envTable.IsFixated = false\n    end\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["Time"] = 1604087921,
					["url"] = "",
					["Icon"] = 841383,
					["Enabled"] = true,
					["Revision"] = 266,
					["semver"] = "",
					["Author"] = "Tecno-Azralon",
					["Desc"] = "When an enemy places a debuff and starts to chase you. This script changes the nameplate color and place your name above the nameplate as well.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						"spawn of g'huun", -- [1]
						"smuggled crawg", -- [2]
						"sergeant bainbridge", -- [3]
						"blacktooth scrapper", -- [4]
						"irontide grenadier", -- [5]
						"feral bloodswarmer", -- [6]
						"earthrager", -- [7]
						"crawler mine", -- [8]
						"rezan", -- [9]
					},
					["PlaterCore"] = 1,
					["Name"] = "Fixate On You [Plater]",
					["version"] = -1,
					["Options"] = {
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable)\n    \nend\n\n\n",
				}, -- [33]
			},
			["saved_cvars_last_change"] = {
				["nameplateMinAlpha"] = "[string \"=[C]\"]: ?\n[string \"=[C]\"]: in function `SetCVar'\n[string \"@Interface/AddOns/Plater/Plater.lua\"]:1542: in function <Interface/AddOns/Plater/Plater.lua:1523>\n",
				["nameplateMinAlphaDistance"] = "[string \"=[C]\"]: ?\n[string \"=[C]\"]: in function `SetCVar'\n[string \"@Interface/AddOns/Plater/Plater.lua\"]:1542: in function <Interface/AddOns/Plater/Plater.lua:1523>\n",
				["nameplateSelectedAlpha"] = "[string \"=[C]\"]: ?\n[string \"=[C]\"]: in function `SetCVar'\n[string \"@Interface/AddOns/Plater/Plater.lua\"]:1542: in function <Interface/AddOns/Plater/Plater.lua:1523>\n",
				["nameplateMaxDistance"] = "[string \"=[C]\"]: ?\n[string \"=[C]\"]: in function `SetCVar'\n[string \"@Interface/AddOns/Plater/Plater.lua\"]:1542: in function <Interface/AddOns/Plater/Plater.lua:1523>\n",
				["nameplateNotSelectedAlpha"] = "[string \"=[C]\"]: ?\n[string \"=[C]\"]: in function `SetCVar'\n[string \"@Interface/AddOns/Plater/Plater.lua\"]:1542: in function <Interface/AddOns/Plater/Plater.lua:1523>\n",
				["nameplateOverlapV"] = "[string \"=[C]\"]: ?\n[string \"=[C]\"]: in function `SetCVar'\n[string \"@Interface/AddOns/Plater/Plater.lua\"]:1542: in function <Interface/AddOns/Plater/Plater.lua:1523>\n",
				["nameplateShowEnemies"] = "[string \"=[C]\"]: ?\n[string \"=[C]\"]: in function `SetCVar'\n[string \"NAMEPLATES\"]:6: in function <[string \"NAMEPLATES\"]:1>\n",
				["nameplateShowFriends"] = "[string \"=[C]\"]: ?\n[string \"=[C]\"]: in function `SetCVar'\n[string \"ALLNAMEPLATES\"]:13: in function <[string \"ALLNAMEPLATES\"]:1>\n",
				["nameplateRemovalAnimation"] = "[string \"=[C]\"]: ?\n[string \"=[C]\"]: in function `SetCVar'\n[string \"@Interface/AddOns/Plater/Plater.lua\"]:1542: in function <Interface/AddOns/Plater/Plater.lua:1523>\n",
			},
			["aura2_y_offset"] = 5,
			["expansion_triggerwipe"] = {
				[2] = true,
			},
			["npc_cache"] = {
				[24080] = {
					"Dragonflayer Weaponsmith", -- [1]
					"Utgarde Keep", -- [2]
					"enUS", -- [3]
				},
				[36886] = {
					"Geist Ambusher", -- [1]
					"Pit of Saron", -- [2]
					"enUS", -- [3]
				},
				[29214] = {
					"Anub'ar Assassin", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[28200] = {
					"Dark Necromancer", -- [1]
					"The Culling of Stratholme", -- [2]
					"enUS", -- [3]
				},
				[26691] = {
					"Ymirjar Witch Doctor", -- [1]
					"Utgarde Pinnacle", -- [2]
					"enUS", -- [3]
				},
				[30276] = {
					"Ahn'kahar Web Winder", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[30284] = {
					"Bonegrinder", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[27737] = {
					"Risen Zombie", -- [1]
					"The Culling of Stratholme", -- [2]
					"enUS", -- [3]
				},
				[26723] = {
					"Keristrasza", -- [1]
					"The Nexus", -- [2]
					"enUS", -- [3]
				},
				[26731] = {
					"Grand Magus Telestra", -- [1]
					"The Nexus", -- [2]
					"enUS", -- [3]
				},
				[36551] = {
					"Spiteful Apparition", -- [1]
					"The Forge of Souls", -- [2]
					"enUS", -- [3]
				},
				[35545] = {
					"Risen Jaeren Sunsworn", -- [1]
					"Trial of the Champion", -- [2]
					"enUS", -- [3]
				},
				[24200] = {
					"Skarvald the Constructor", -- [1]
					"Utgarde Keep", -- [2]
					"enUS", -- [3]
				},
				[26763] = {
					"Anomalus", -- [1]
					"The Nexus", -- [2]
					"enUS", -- [3]
				},
				[28368] = {
					"Ymirjar Necromancer", -- [1]
					"Utgarde Pinnacle", -- [2]
					"enUS", -- [3]
				},
				[28384] = {
					"Lesser Air Elemental", -- [1]
					"Halls of Stone", -- [2]
					"enUS", -- [3]
				},
				[30963] = {
					"Azure Mage Slayer", -- [1]
					"Violet Hold", -- [2]
					"enUS", -- [3]
				},
				[27961] = {
					"Dark Rune Worker", -- [1]
					"Halls of Stone", -- [2]
					"enUS", -- [3]
				},
				[27969] = {
					"Dark Rune Giant", -- [1]
					"Halls of Stone", -- [2]
					"enUS", -- [3]
				},
				[27977] = {
					"Krystallus", -- [1]
					"Halls of Stone", -- [2]
					"enUS", -- [3]
				},
				[27985] = {
					"Iron Golem Custodian", -- [1]
					"Halls of Stone", -- [2]
					"enUS", -- [3]
				},
				[23953] = {
					"Prince Keleseth", -- [1]
					"Utgarde Keep", -- [2]
					"enUS", -- [3]
				},
				[23961] = {
					"Dragonflayer Ironhelm", -- [1]
					"Utgarde Keep", -- [2]
					"enUS", -- [3]
				},
				[26532] = {
					"Chrono-Lord Epoch", -- [1]
					"The Culling of Stratholme", -- [2]
					"enUS", -- [3]
				},
				[29119] = {
					"Anub'ar Necromancer", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[30660] = {
					"Portal Guardian", -- [1]
					"Violet Hold", -- [2]
					"enUS", -- [3]
				},
				[30668] = {
					"Azure Raider", -- [1]
					"Violet Hold", -- [2]
					"enUS", -- [3]
				},
				[28153] = {
					"Snowflake", -- [1]
					"The Oculus", -- [2]
					"enUS", -- [3]
				},
				[35307] = {
					"Argent Priestess", -- [1]
					"Trial of the Champion", -- [2]
					"enUS", -- [3]
				},
				[28169] = {
					"Stratholme Resident", -- [1]
					"The Culling of Stratholme", -- [2]
					"enUS", -- [3]
				},
				[32273] = {
					"Infinite Corruptor", -- [1]
					"The Culling of Stratholme", -- [2]
					"enUS", -- [3]
				},
				[28201] = {
					"Bile Golem", -- [1]
					"The Culling of Stratholme", -- [2]
					"enUS", -- [3]
				},
				[26692] = {
					"Ymirjar Harpooner", -- [1]
					"Utgarde Pinnacle", -- [2]
					"enUS", -- [3]
				},
				[35451] = {
					"The Black Knight", -- [1]
					"Trial of the Champion", -- [2]
					"enUS", -- [3]
				},
				[30285] = {
					"Eye of Taldaram", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[28249] = {
					"Devouring Ghoul", -- [1]
					"The Culling of Stratholme", -- [2]
					"enUS", -- [3]
				},
				[24201] = {
					"Dalronn the Controller", -- [1]
					"Utgarde Keep", -- [2]
					"enUS", -- [3]
				},
				[29830] = {
					"Living Mojo", -- [1]
					"Gundrak", -- [2]
					"enUS", -- [3]
				},
				[29838] = {
					"Drakkari Rhino", -- [1]
					"Gundrak", -- [2]
					"enUS", -- [3]
				},
				[29335] = {
					"Anub'ar Webspinner", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[26796] = {
					"Commander Stoutbeard", -- [1]
					"The Nexus", -- [2]
					"enUS", -- [3]
				},
				[30892] = {
					"Portal Guardian", -- [1]
					"Violet Hold", -- [2]
					"enUS", -- [3]
				},
				[34701] = {
					"Colosos", -- [1]
					"Trial of the Champion", -- [2]
					"enUS", -- [3]
				},
				[36841] = {
					"Fallen Warrior", -- [1]
					"Pit of Saron", -- [2]
					"enUS", -- [3]
				},
				[29982] = {
					"Drakkari Raider", -- [1]
					"Gundrak", -- [2]
					"enUS", -- [3]
				},
				[27962] = {
					"Dark Rune Elementalist", -- [1]
					"Halls of Stone", -- [2]
					"enUS", -- [3]
				},
				[27970] = {
					"Raging Construct", -- [1]
					"Halls of Stone", -- [2]
					"enUS", -- [3]
				},
				[27978] = {
					"Sjonnir The Ironshaper", -- [1]
					"Halls of Stone", -- [2]
					"enUS", -- [3]
				},
				[32593] = {
					"Skittering Swarmer", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[10440] = {
					"Baron Rivendare", -- [1]
					"Stratholme", -- [2]
					"enUS", -- [3]
				},
				[23954] = {
					"Ingvar the Plunderer", -- [1]
					"Utgarde Keep", -- [2]
					"enUS", -- [3]
				},
				[23970] = {
					"Vrykul Skeleton", -- [1]
					"Utgarde Keep", -- [2]
					"enUS", -- [3]
				},
				[32665] = {
					"Crystalline Tangler", -- [1]
					"The Nexus", -- [2]
					"enUS", -- [3]
				},
				[36666] = {
					"Spectral Warden", -- [1]
					"The Forge of Souls", -- [2]
					"enUS", -- [3]
				},
				[29120] = {
					"Anub'arak", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[29128] = {
					"Anub'ar Prime Guard", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[34702] = {
					"Ambrose Boltspark", -- [1]
					"Trial of the Champion", -- [2]
					"enUS", -- [3]
				},
				[27635] = {
					"Azure Spellbinder", -- [1]
					"The Oculus", -- [2]
					"enUS", -- [3]
				},
				[26621] = {
					"Ghoul Tormentor", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[27651] = {
					"Phantasmal Fire", -- [1]
					"The Oculus", -- [2]
					"enUS", -- [3]
				},
				[24082] = {
					"Proto-Drake Handler", -- [1]
					"Utgarde Keep", -- [2]
					"enUS", -- [3]
				},
				[36874] = {
					"Disturbed Glacial Revenant", -- [1]
					"Pit of Saron", -- [2]
					"enUS", -- [3]
				},
				[31260] = {
					"Ymirjar Skycaller", -- [1]
					"Pit of Saron", -- [2]
					"enUS", -- [3]
				},
				[29735] = {
					"Savage Worg", -- [1]
					"Utgarde Keep", -- [2]
					"enUS", -- [3]
				},
				[36954] = {
					"The Lich King", -- [1]
					"Halls of Reflection", -- [2]
					"enUS", -- [3]
				},
				[26693] = {
					"Skadi the Ruthless", -- [1]
					"Utgarde Pinnacle", -- [2]
					"enUS", -- [3]
				},
				[30278] = {
					"Ahn'kahar Spell Flinger", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[27731] = {
					"Acolyte", -- [1]
					"The Culling of Stratholme", -- [2]
					"enUS", -- [3]
				},
				[38567] = {
					"Phantom Hallucination", -- [1]
					"Halls of Reflection", -- [2]
					"enUS", -- [3]
				},
				[29304] = {
					"Slad'ran", -- [1]
					"Gundrak", -- [2]
					"enUS", -- [3]
				},
				[29312] = {
					"Lavanthor", -- [1]
					"Violet Hold", -- [2]
					"enUS", -- [3]
				},
				[26805] = {
					"Alliance Cleric", -- [1]
					"The Nexus", -- [2]
					"enUS", -- [3]
				},
				[34703] = {
					"Lana Stouthammer", -- [1]
					"Trial of the Champion", -- [2]
					"enUS", -- [3]
				},
				[26861] = {
					"King Ymiron", -- [1]
					"Utgarde Pinnacle", -- [2]
					"enUS", -- [3]
				},
				[28921] = {
					"Hadronox", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[24849] = {
					"Proto-Drake Rider", -- [1]
					"Utgarde Keep", -- [2]
					"enUS", -- [3]
				},
				[36891] = {
					"Iceborn Proto-Drake", -- [1]
					"Pit of Saron", -- [2]
					"enUS", -- [3]
				},
				[36907] = {
					"Wrathbone Siegesmith", -- [1]
					"Pit of Saron", -- [2]
					"enUS", -- [3]
				},
				[27963] = {
					"Dark Rune Theurgist", -- [1]
					"Halls of Stone", -- [2]
					"enUS", -- [3]
				},
				[27971] = {
					"Unrelenting Construct", -- [1]
					"Halls of Stone", -- [2]
					"enUS", -- [3]
				},
				[36476] = {
					"Ick", -- [1]
					"Pit of Saron", -- [2]
					"enUS", -- [3]
				},
				[36620] = {
					"Soulguard Adept", -- [1]
					"The Forge of Souls", -- [2]
					"enUS", -- [3]
				},
				[30111] = {
					"Twilight Worshipper", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[29097] = {
					"Anub'ar Crypt Fiend", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[26550] = {
					"Dragonflayer Deathseeker", -- [1]
					"Utgarde Pinnacle", -- [2]
					"enUS", -- [3]
				},
				[29153] = {
					"Animated Bones", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[27636] = {
					"Azure Ley-Whelp", -- [1]
					"The Oculus", -- [2]
					"enUS", -- [3]
				},
				[27644] = {
					"Phantasmal Wolf", -- [1]
					"The Oculus", -- [2]
					"enUS", -- [3]
				},
				[35311] = {
					"Fountain of Light", -- [1]
					"Trial of the Champion", -- [2]
					"enUS", -- [3]
				},
				[24083] = {
					"Enslaved Proto-Drake", -- [1]
					"Utgarde Keep", -- [2]
					"enUS", -- [3]
				},
				[36892] = {
					"Ymirjar Deathbringer", -- [1]
					"Pit of Saron", -- [2]
					"enUS", -- [3]
				},
				[29217] = {
					"Anub'ar Venomancer", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[26670] = {
					"Ymirjar Flesh Hunter", -- [1]
					"Utgarde Pinnacle", -- [2]
					"enUS", -- [3]
				},
				[36940] = {
					"Raging Ghoul", -- [1]
					"Halls of Reflection", -- [2]
					"enUS", -- [3]
				},
				[28730] = {
					"Watcher Gashra", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[26694] = {
					"Ymirjar Dusk Shaman", -- [1]
					"Utgarde Pinnacle", -- [2]
					"enUS", -- [3]
				},
				[30279] = {
					"Deep Crawler", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[30287] = {
					"Plundering Geist", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[26734] = {
					"Azure Enforcer", -- [1]
					"The Nexus", -- [2]
					"enUS", -- [3]
				},
				[37068] = {
					"Biborcho", -- [1]
					"Halls of Reflection", -- [2]
					"enUS", -- [3]
				},
				[29305] = {
					"Moorabi", -- [1]
					"Gundrak", -- [2]
					"enUS", -- [3]
				},
				[29832] = {
					"Drakkari Golem", -- [1]
					"Gundrak", -- [2]
					"enUS", -- [3]
				},
				[26782] = {
					"Crystalline Keeper", -- [1]
					"The Nexus", -- [2]
					"enUS", -- [3]
				},
				[30391] = {
					"Healthy Mushroom", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[26830] = {
					"Risen Drakkari Death Knight", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[34705] = {
					"Marshal Jacob Alerius", -- [1]
					"Trial of the Champion", -- [2]
					"enUS", -- [3]
				},
				[29920] = {
					"Ruins Dweller", -- [1]
					"Gundrak", -- [2]
					"enUS", -- [3]
				},
				[28922] = {
					"Anub'ar Crusher", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[28419] = {
					"Frenzied Geist", -- [1]
					"Utgarde Keep", -- [2]
					"enUS", -- [3]
				},
				[35328] = {
					"Stormwind Champion", -- [1]
					"Trial of the Champion", -- [2]
					"enUS", -- [3]
				},
				[36877] = {
					"Wrathbone Skeleton", -- [1]
					"Pit of Saron", -- [2]
					"enUS", -- [3]
				},
				[36893] = {
					"Ymirjar Flamebearer", -- [1]
					"Pit of Saron", -- [2]
					"enUS", -- [3]
				},
				[26918] = {
					"Chaotic Rift", -- [1]
					"The Nexus", -- [2]
					"enUS", -- [3]
				},
				[36941] = {
					"Risen Witch Doctor", -- [1]
					"Halls of Reflection", -- [2]
					"enUS", -- [3]
				},
				[27964] = {
					"Dark Rune Scholar", -- [1]
					"Halls of Stone", -- [2]
					"enUS", -- [3]
				},
				[27972] = {
					"Lightning Construct", -- [1]
					"Halls of Stone", -- [2]
					"enUS", -- [3]
				},
				[36478] = {
					"Soulguard Watchman", -- [1]
					"The Forge of Souls", -- [2]
					"enUS", -- [3]
				},
				[36494] = {
					"Forgemaster Garfrost", -- [1]
					"Pit of Saron", -- [2]
					"enUS", -- [3]
				},
				[37069] = {
					"Lumbering Abomination", -- [1]
					"Halls of Reflection", -- [2]
					"enUS", -- [3]
				},
				[23956] = {
					"Dragonflayer Strategist", -- [1]
					"Utgarde Keep", -- [2]
					"enUS", -- [3]
				},
				[30623] = {
					"Bashyo", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[29098] = {
					"Anub'ar Necromancer", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[28619] = {
					"Web Wrap", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[30176] = {
					"Ahn'kahar Guardian", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[30695] = {
					"Portal Keeper", -- [1]
					"Violet Hold", -- [2]
					"enUS", -- [3]
				},
				[36830] = {
					"Wrathbone Laborer", -- [1]
					"Pit of Saron", -- [2]
					"enUS", -- [3]
				},
				[27653] = {
					"Phantasmal Water", -- [1]
					"The Oculus", -- [2]
					"enUS", -- [3]
				},
				[24084] = {
					"Tunneling Ghoul", -- [1]
					"Utgarde Keep", -- [2]
					"enUS", -- [3]
				},
				[28731] = {
					"Watcher Silthik", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[27733] = {
					"Ghoul Minion", -- [1]
					"The Culling of Stratholme", -- [2]
					"enUS", -- [3]
				},
				[26727] = {
					"Mage Hunter Ascendant", -- [1]
					"The Nexus", -- [2]
					"enUS", -- [3]
				},
				[26735] = {
					"Azure Scale-Binder", -- [1]
					"The Nexus", -- [2]
					"enUS", -- [3]
				},
				[28276] = {
					"Greater Ley-Whelp", -- [1]
					"The Oculus", -- [2]
					"enUS", -- [3]
				},
				[29306] = {
					"Gal'darah", -- [1]
					"Gundrak", -- [2]
					"enUS", -- [3]
				},
				[29314] = {
					"Zuramat the Obliterator", -- [1]
					"Violet Hold", -- [2]
					"enUS", -- [3]
				},
				[38172] = {
					"Phantom Mage", -- [1]
					"Halls of Reflection", -- [2]
					"enUS", -- [3]
				},
				[30879] = {
					"Planar Anomaly", -- [1]
					"The Oculus", -- [2]
					"enUS", -- [3]
				},
				[28340] = {
					"Stratholme Citizen", -- [1]
					"The Culling of Stratholme", -- [2]
					"enUS", -- [3]
				},
				[30416] = {
					"Bound Fire Elemental", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[27390] = {
					"Skarvald the Constructor", -- [1]
					"Utgarde Keep", -- [2]
					"enUS", -- [3]
				},
				[27909] = {
					"Darkweb Victim", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[35330] = {
					"Exodar Champion", -- [1]
					"Trial of the Champion", -- [2]
					"enUS", -- [3]
				},
				[36879] = {
					"Plagueborn Horror", -- [1]
					"Pit of Saron", -- [2]
					"enUS", -- [3]
				},
				[31007] = {
					"Azure Binder", -- [1]
					"Violet Hold", -- [2]
					"enUS", -- [3]
				},
				[27949] = {
					"Alliance Commander", -- [1]
					"The Nexus", -- [2]
					"enUS", -- [3]
				},
				[27965] = {
					"Dark Rune Shaper", -- [1]
					"Halls of Stone", -- [2]
					"enUS", -- [3]
				},
				[27973] = {
					"Crystalline Shardling", -- [1]
					"Halls of Stone", -- [2]
					"enUS", -- [3]
				},
				[27981] = {
					"Malformed Ooze", -- [1]
					"Halls of Stone", -- [2]
					"enUS", -- [3]
				},
				[29051] = {
					"Anub'ar Crypt Fiend", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[23965] = {
					"Frost Tomb", -- [1]
					"Utgarde Keep", -- [2]
					"enUS", -- [3]
				},
				[38173] = {
					"Spectral Footman", -- [1]
					"Halls of Reflection", -- [2]
					"enUS", -- [3]
				},
				[26536] = {
					"Mindless Servant", -- [1]
					"Utgarde Pinnacle", -- [2]
					"enUS", -- [3]
				},
				[34657] = {
					"Jaelyne Evensong", -- [1]
					"Trial of the Champion", -- [2]
					"enUS", -- [3]
				},
				[27598] = {
					"Fetid Troll Corpse", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[26627] = {
					"Crystal Handler", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[30664] = {
					"Azure Mage Slayer", -- [1]
					"Violet Hold", -- [2]
					"enUS", -- [3]
				},
				[27709] = {
					"Drakkari Invader", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[31134] = {
					"Cyanigosa", -- [1]
					"Violet Hold", -- [2]
					"enUS", -- [3]
				},
				[27638] = {
					"Azure Ring Guardian", -- [1]
					"The Oculus", -- [2]
					"enUS", -- [3]
				},
				[24069] = {
					"Dragonflayer Bonecrusher", -- [1]
					"Utgarde Keep", -- [2]
					"enUS", -- [3]
				},
				[27654] = {
					"Drakos the Interrogator", -- [1]
					"The Oculus", -- [2]
					"enUS", -- [3]
				},
				[24085] = {
					"Dragonflayer Overseer", -- [1]
					"Utgarde Keep", -- [2]
					"enUS", -- [3]
				},
				[30893] = {
					"Portal Keeper", -- [1]
					"Violet Hold", -- [2]
					"enUS", -- [3]
				},
				[29271] = {
					"Ethereal Sphere", -- [1]
					"Violet Hold", -- [2]
					"enUS", -- [3]
				},
				[29266] = {
					"Xevozz", -- [1]
					"Violet Hold", -- [2]
					"enUS", -- [3]
				},
				[26672] = {
					"Bloodthirsty Tundra Wolf", -- [1]
					"Utgarde Pinnacle", -- [2]
					"enUS", -- [3]
				},
				[29209] = {
					"Carrion Beetle", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[28732] = {
					"Anub'ar Warrior", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[26696] = {
					"Ymirjar Berserker", -- [1]
					"Utgarde Pinnacle", -- [2]
					"enUS", -- [3]
				},
				[3862] = {
					"Wolf", -- [1]
					"Halls of Stone", -- [2]
					"enUS", -- [3]
				},
				[27734] = {
					"Crypt Fiend", -- [1]
					"The Culling of Stratholme", -- [2]
					"enUS", -- [3]
				},
				[27742] = {
					"Infinite Adversary", -- [1]
					"The Culling of Stratholme", -- [2]
					"enUS", -- [3]
				},
				[26728] = {
					"Mage Hunter Initiate", -- [1]
					"The Nexus", -- [2]
					"enUS", -- [3]
				},
				[30414] = {
					"Forgotten One", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[29064] = {
					"Anub'ar Necromancer", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[30329] = {
					"Savage Cave Beast", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[29826] = {
					"Drakkari Medicine Man", -- [1]
					"Gundrak", -- [2]
					"enUS", -- [3]
				},
				[29834] = {
					"Drakkari Frenzy", -- [1]
					"Gundrak", -- [2]
					"enUS", -- [3]
				},
				[35329] = {
					"Ironforge Champion", -- [1]
					"Trial of the Champion", -- [2]
					"enUS", -- [3]
				},
				[26632] = {
					"The Prophet Tharon'ja", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[26792] = {
					"Crystalline Protector", -- [1]
					"The Nexus", -- [2]
					"enUS", -- [3]
				},
				[26800] = {
					"Alliance Berserker", -- [1]
					"The Nexus", -- [2]
					"enUS", -- [3]
				},
				[37711] = {
					"Hungering Ghoul", -- [1]
					"Pit of Saron", -- [2]
					"enUS", -- [3]
				},
				[26620] = {
					"Drakkari Guardian", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[26824] = {
					"Drakkari Raptor Mount", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[26635] = {
					"Risen Drakkari Warrior", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[29573] = {
					"Drakkari Elemental", -- [1]
					"Gundrak", -- [2]
					"enUS", -- [3]
				},
				[38487] = {
					"Fallen Warrior", -- [1]
					"Pit of Saron", -- [2]
					"enUS", -- [3]
				},
				[26623] = {
					"Scourge Brute", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[27483] = {
					"King Dred", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[26628] = {
					"Drakkari Scytheclaw", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[28924] = {
					"Anub'ar Champion", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[10394] = {
					"Black Guard Sentry", -- [1]
					"Stratholme", -- [2]
					"enUS", -- [3]
				},
				[35332] = {
					"Darnassus Champion", -- [1]
					"Trial of the Champion", -- [2]
					"enUS", -- [3]
				},
				[36881] = {
					"Skeletal Slave", -- [1]
					"Pit of Saron", -- [2]
					"enUS", -- [3]
				},
				[26637] = {
					"Risen Drakkari Handler", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[27431] = {
					"Drakkari Commander", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[26928] = {
					"Grand Magus Telestra", -- [1]
					"The Nexus", -- [2]
					"enUS", -- [3]
				},
				[27447] = {
					"Varos Cloudstrider", -- [1]
					"The Oculus", -- [2]
					"enUS", -- [3]
				},
				[27966] = {
					"Dark Rune Controller", -- [1]
					"Halls of Stone", -- [2]
					"enUS", -- [3]
				},
				[27974] = {
					"Eroded Shardling", -- [1]
					"Halls of Stone", -- [2]
					"enUS", -- [3]
				},
				[27982] = {
					"Forged Iron Dwarf", -- [1]
					"Halls of Stone", -- [2]
					"enUS", -- [3]
				},
				[26638] = {
					"Risen Drakkari Bat Rider", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[27649] = {
					"Phantasmal Murloc", -- [1]
					"The Oculus", -- [2]
					"enUS", -- [3]
				},
				[26639] = {
					"Drakkari Shaman", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[29096] = {
					"Anub'ar Champion", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[28736] = {
					"Skittering Infector", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[26533] = {
					"Mal'Ganis", -- [1]
					"The Culling of Stratholme", -- [2]
					"enUS", -- [3]
				},
				[31104] = {
					"Ahn'kahar Watcher", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[27645] = {
					"Phantasmal Cloudscraper", -- [1]
					"The Oculus", -- [2]
					"enUS", -- [3]
				},
				[26529] = {
					"Meathook", -- [1]
					"The Culling of Stratholme", -- [2]
					"enUS", -- [3]
				},
				[38175] = {
					"Ghostly Priest", -- [1]
					"Halls of Reflection", -- [2]
					"enUS", -- [3]
				},
				[36658] = {
					"Scourgelord Tyrannus", -- [1]
					"Pit of Saron", -- [2]
					"enUS", -- [3]
				},
				[26630] = {
					"Trollgore", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[26553] = {
					"Dragonflayer Fanatic", -- [1]
					"Utgarde Pinnacle", -- [2]
					"enUS", -- [3]
				},
				[37728] = {
					"Wrathbone Sorcerer", -- [1]
					"Pit of Saron", -- [2]
					"enUS", -- [3]
				},
				[29307] = {
					"Drakkari Colossus", -- [1]
					"Gundrak", -- [2]
					"enUS", -- [3]
				},
				[26624] = {
					"Wretched Belcher", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[27732] = {
					"Master Necromancer", -- [1]
					"The Culling of Stratholme", -- [2]
					"enUS", -- [3]
				},
				[29822] = {
					"Drakkari Fire Weaver", -- [1]
					"Gundrak", -- [2]
					"enUS", -- [3]
				},
				[30178] = {
					"Ahn'kahar Swarmer ", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[27655] = {
					"Mage-Lord Urom", -- [1]
					"The Oculus", -- [2]
					"enUS", -- [3]
				},
				[27639] = {
					"Ring-Lord Sorceress", -- [1]
					"The Oculus", -- [2]
					"enUS", -- [3]
				},
				[27647] = {
					"Phantasmal Ogre", -- [1]
					"The Oculus", -- [2]
					"enUS", -- [3]
				},
				[24078] = {
					"Dragonflayer Metalworker", -- [1]
					"Utgarde Keep", -- [2]
					"enUS", -- [3]
				},
				[26641] = {
					"Drakkari Gutripper", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[36522] = {
					"Soul Horror", -- [1]
					"The Forge of Souls", -- [2]
					"enUS", -- [3]
				},
				[30277] = {
					"Ahn'kahar Slasher", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[30625] = {
					"Biborcho", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[29829] = {
					"Drakkari Earthshaker", -- [1]
					"Gundrak", -- [2]
					"enUS", -- [3]
				},
				[30258] = {
					"Amanitar", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[28733] = {
					"Anub'ar Shadowcaster", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[26716] = {
					"Azure Warder", -- [1]
					"The Nexus", -- [2]
					"enUS", -- [3]
				},
				[29774] = {
					"Spitting Cobra", -- [1]
					"Gundrak", -- [2]
					"enUS", -- [3]
				},
				[36499] = {
					"Soulguard Reaper", -- [1]
					"The Forge of Souls", -- [2]
					"enUS", -- [3]
				},
				[27743] = {
					"Infinite Hunter", -- [1]
					"The Culling of Stratholme", -- [2]
					"enUS", -- [3]
				},
				[26729] = {
					"Steward", -- [1]
					"The Nexus", -- [2]
					"enUS", -- [3]
				},
				[26737] = {
					"Crazed Mana-Surge", -- [1]
					"The Nexus", -- [2]
					"enUS", -- [3]
				},
				[29819] = {
					"Drakkari Lancer", -- [1]
					"Gundrak", -- [2]
					"enUS", -- [3]
				},
				[29308] = {
					"Prince Taldaram", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[30338] = {
					"Ahn'kahar Swarmer", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[26636] = {
					"Risen Drakkari Soulmage", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[26794] = {
					"Ormorok the Tree-Shaper", -- [1]
					"The Nexus", -- [2]
					"enUS", -- [3]
				},
				[38176] = {
					"Tortured Rifleman", -- [1]
					"Halls of Reflection", -- [2]
					"enUS", -- [3]
				},
				[26793] = {
					"Crystalline Frayer", -- [1]
					"The Nexus", -- [2]
					"enUS", -- [3]
				},
				[29340] = {
					"Anub'ar Brood Keeper", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[37713] = {
					"Deathwhisper Torturer", -- [1]
					"Pit of Saron", -- [2]
					"enUS", -- [3]
				},
				[37729] = {
					"Wrathbone Reaver", -- [1]
					"Pit of Saron", -- [2]
					"enUS", -- [3]
				},
				[36723] = {
					"Frostsworn General", -- [1]
					"Halls of Reflection", -- [2]
					"enUS", -- [3]
				},
				[29874] = {
					"Drakkari Inciter", -- [1]
					"Gundrak", -- [2]
					"enUS", -- [3]
				},
				[30418] = {
					"Bound Air Elemental", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[27871] = {
					"Flesheating Ghoul", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[29216] = {
					"Anub'ar Guardian", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[29931] = {
					"Drakkari Rhino", -- [1]
					"Gundrak", -- [2]
					"enUS", -- [3]
				},
				[30961] = {
					"Azure Invader", -- [1]
					"Violet Hold", -- [2]
					"enUS", -- [3]
				},
				[28925] = {
					"Anub'ar Necromancer", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[29311] = {
					"Herald Volazj", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[29820] = {
					"Drakkari God Hunter", -- [1]
					"Gundrak", -- [2]
					"enUS", -- [3]
				},
				[27729] = {
					"Enraging Ghoul", -- [1]
					"The Culling of Stratholme", -- [2]
					"enUS", -- [3]
				},
				[28341] = {
					"Stratholme Resident", -- [1]
					"The Culling of Stratholme", -- [2]
					"enUS", -- [3]
				},
				[31009] = {
					"Azure Spellbreaker", -- [1]
					"Violet Hold", -- [2]
					"enUS", -- [3]
				},
				[26929] = {
					"Grand Magus Telestra", -- [1]
					"The Nexus", -- [2]
					"enUS", -- [3]
				},
				[35309] = {
					"Argent Lightwielder", -- [1]
					"Trial of the Champion", -- [2]
					"enUS", -- [3]
				},
				[26722] = {
					"Azure Magus", -- [1]
					"The Nexus", -- [2]
					"enUS", -- [3]
				},
				[27975] = {
					"Maiden of Grief", -- [1]
					"Halls of Stone", -- [2]
					"enUS", -- [3]
				},
				[27983] = {
					"Dark Rune Protector", -- [1]
					"Halls of Stone", -- [2]
					"enUS", -- [3]
				},
				[36497] = {
					"Bronjahm", -- [1]
					"The Forge of Souls", -- [2]
					"enUS", -- [3]
				},
				[36516] = {
					"Soulguard Animator", -- [1]
					"The Forge of Souls", -- [2]
					"enUS", -- [3]
				},
				[28729] = {
					"Watcher Narjil", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[38177] = {
					"Shadowy Mercenary", -- [1]
					"Halls of Reflection", -- [2]
					"enUS", -- [3]
				},
				[36564] = {
					"Soulguard Bonecaster", -- [1]
					"The Forge of Souls", -- [2]
					"enUS", -- [3]
				},
				[38113] = {
					"Marwyn", -- [1]
					"Halls of Reflection", -- [2]
					"enUS", -- [3]
				},
				[37107] = {
					"Natham", -- [1]
					"Halls of Reflection", -- [2]
					"enUS", -- [3]
				},
				[35590] = {
					"Risen Champion", -- [1]
					"Trial of the Champion", -- [2]
					"enUS", -- [3]
				},
				[28734] = {
					"Anub'ar Skirmisher", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[26530] = {
					"Salramm the Fleshcrafter", -- [1]
					"The Culling of Stratholme", -- [2]
					"enUS", -- [3]
				},
				[30666] = {
					"Azure Captain", -- [1]
					"Violet Hold", -- [2]
					"enUS", -- [3]
				},
				[30179] = {
					"Twilight Apostle", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[26554] = {
					"Dragonflayer Seer", -- [1]
					"Utgarde Pinnacle", -- [2]
					"enUS", -- [3]
				},
				[29117] = {
					"Anub'ar Champion", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[32191] = {
					"Azure Stalker", -- [1]
					"Violet Hold", -- [2]
					"enUS", -- [3]
				},
				[27600] = {
					"Risen Shadowcaster", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[36916] = {
					"Ghoul Minion", -- [1]
					"The Forge of Souls", -- [2]
					"enUS", -- [3]
				},
				[27648] = {
					"Phantasmal Naga", -- [1]
					"The Oculus", -- [2]
					"enUS", -- [3]
				},
				[36788] = {
					"Deathwhisper Necrolyte", -- [1]
					"Pit of Saron", -- [2]
					"enUS", -- [3]
				},
				[24079] = {
					"Dragonflayer Forge Master", -- [1]
					"Utgarde Keep", -- [2]
					"enUS", -- [3]
				},
				[27640] = {
					"Ring-Lord Conjurer", -- [1]
					"The Oculus", -- [2]
					"enUS", -- [3]
				},
				[26626] = {
					"Scourge Reanimator", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[28167] = {
					"Risen Zombie", -- [1]
					"The Culling of Stratholme", -- [2]
					"enUS", -- [3]
				},
				[28684] = {
					"Krik'thir the Gatewatcher", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[27656] = {
					"Ley-Guardian Eregos", -- [1]
					"The Oculus", -- [2]
					"enUS", -- [3]
				},
				[29213] = {
					"Anub'ar Darter", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[28199] = {
					"Tomb Stalker", -- [1]
					"The Culling of Stratholme", -- [2]
					"enUS", -- [3]
				},
				[26674] = {
					"Darkweb Hatchling", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[24071] = {
					"Dragonflayer Heartsplitter", -- [1]
					"Utgarde Keep", -- [2]
					"enUS", -- [3]
				},
				[26690] = {
					"Ymirjar Warrior", -- [1]
					"Utgarde Pinnacle", -- [2]
					"enUS", -- [3]
				},
				[28231] = {
					"Crystalline Tender", -- [1]
					"The Nexus", -- [2]
					"enUS", -- [3]
				},
				[30283] = {
					"Plague Walker", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[27736] = {
					"Patchwork Construct", -- [1]
					"The Culling of Stratholme", -- [2]
					"enUS", -- [3]
				},
				[27744] = {
					"Infinite Agent", -- [1]
					"The Culling of Stratholme", -- [2]
					"enUS", -- [3]
				},
				[26730] = {
					"Mage Slayer", -- [1]
					"The Nexus", -- [2]
					"enUS", -- [3]
				},
				[30114] = {
					"Twilight Initiate", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[26746] = {
					"Crazed Mana-Wraith", -- [1]
					"The Nexus", -- [2]
					"enUS", -- [3]
				},
				[29309] = {
					"Elder Nadox", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[30385] = {
					"Twilight Volunteer", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[29836] = {
					"Drakkari Battle Rider", -- [1]
					"Gundrak", -- [2]
					"enUS", -- [3]
				},
				[35119] = {
					"Eadric the Pure", -- [1]
					"Trial of the Champion", -- [2]
					"enUS", -- [3]
				},
				[29063] = {
					"Anub'ar Crypt Fiend", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[36661] = {
					"Rimefang", -- [1]
					"Pit of Saron", -- [2]
					"enUS", -- [3]
				},
				[26802] = {
					"Alliance Ranger", -- [1]
					"The Nexus", -- [2]
					"enUS", -- [3]
				},
				[29316] = {
					"Moragg", -- [1]
					"Violet Hold", -- [2]
					"enUS", -- [3]
				},
				[38112] = {
					"Falric", -- [1]
					"Halls of Reflection", -- [2]
					"enUS", -- [3]
				},
				[27979] = {
					"Forged Iron Trogg", -- [1]
					"Halls of Stone", -- [2]
					"enUS", -- [3]
				},
				[28878] = {
					"Skeletal Minion", -- [1]
					"The Culling of Stratholme", -- [2]
					"enUS", -- [3]
				},
				[30419] = {
					"Bound Water Elemental", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[29768] = {
					"Unyielding Constrictor", -- [1]
					"Gundrak", -- [2]
					"enUS", -- [3]
				},
				[30435] = {
					"Poisonous Mushroom", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[29932] = {
					"Eck the Ferocious", -- [1]
					"Gundrak", -- [2]
					"enUS", -- [3]
				},
				[26625] = {
					"Darkweb Recluse", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[29310] = {
					"Jedoga Shadowseeker", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[29630] = {
					"Fanged Pit Viper", -- [1]
					"Gundrak", -- [2]
					"enUS", -- [3]
				},
				[35331] = {
					"Gnomeregan Champion", -- [1]
					"Trial of the Champion", -- [2]
					"enUS", -- [3]
				},
				[30622] = {
					"Buddahla", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[29680] = {
					"Slad'ran Viper", -- [1]
					"Gundrak", -- [2]
					"enUS", -- [3]
				},
				[31010] = {
					"Azure Mage Slayer", -- [1]
					"Violet Hold", -- [2]
					"enUS", -- [3]
				},
				[26930] = {
					"Grand Magus Telestra", -- [1]
					"The Nexus", -- [2]
					"enUS", -- [3]
				},
				[27960] = {
					"Dark Rune Warrior", -- [1]
					"Halls of Stone", -- [2]
					"enUS", -- [3]
				},
				[27753] = {
					"Drakkari Invader", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[36840] = {
					"Ymirjar Wrathbringer", -- [1]
					"Pit of Saron", -- [2]
					"enUS", -- [3]
				},
				[27984] = {
					"Dark Rune Stormcaller", -- [1]
					"Halls of Stone", -- [2]
					"enUS", -- [3]
				},
				[36502] = {
					"Devourer of Souls", -- [1]
					"The Forge of Souls", -- [2]
					"enUS", -- [3]
				},
				[31008] = {
					"Azure Invader", -- [1]
					"Violet Hold", -- [2]
					"enUS", -- [3]
				},
				[26631] = {
					"Novos the Summoner", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[26622] = {
					"Drakkari Bat", -- [1]
					"Drak'Tharon Keep", -- [2]
					"enUS", -- [3]
				},
				[36842] = {
					"Wrathbone Coldwraith", -- [1]
					"Pit of Saron", -- [2]
					"enUS", -- [3]
				},
				[36535] = {
					"Corrupted Soul Fragment", -- [1]
					"The Forge of Souls", -- [2]
					"enUS", -- [3]
				},
				[29062] = {
					"Anub'ar Champion", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[23960] = {
					"Dragonflayer Runecaster", -- [1]
					"Utgarde Keep", -- [2]
					"enUS", -- [3]
				},
				[26669] = {
					"Ymirjar Savage", -- [1]
					"Utgarde Pinnacle", -- [2]
					"enUS", -- [3]
				},
				[30319] = {
					"Twilight Darkcaster", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[30286] = {
					"Frostbringer", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[30624] = {
					"Buddahla", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
				[26555] = {
					"Scourge Hulk", -- [1]
					"Utgarde Pinnacle", -- [2]
					"enUS", -- [3]
				},
				[29118] = {
					"Anub'ar Crypt Fiend", -- [1]
					"Azjol-Nerub", -- [2]
					"enUS", -- [3]
				},
				[29637] = {
					"Crafty Snake", -- [1]
					"Gundrak", -- [2]
					"enUS", -- [3]
				},
				[30667] = {
					"Azure Sorcerer", -- [1]
					"Violet Hold", -- [2]
					"enUS", -- [3]
				},
				[30661] = {
					"Azure Invader", -- [1]
					"Violet Hold", -- [2]
					"enUS", -- [3]
				},
				[27642] = {
					"Phantasmal Mammoth", -- [1]
					"The Oculus", -- [2]
					"enUS", -- [3]
				},
				[27650] = {
					"Phantasmal Air", -- [1]
					"The Oculus", -- [2]
					"enUS", -- [3]
				},
				[27633] = {
					"Azure Inquisitor", -- [1]
					"The Oculus", -- [2]
					"enUS", -- [3]
				},
				[27641] = {
					"Centrifuge Construct", -- [1]
					"The Oculus", -- [2]
					"enUS", -- [3]
				},
				[35305] = {
					"Argent Monk", -- [1]
					"Trial of the Champion", -- [2]
					"enUS", -- [3]
				},
				[30621] = {
					"Parwiz", -- [1]
					"Ahn'kahet: The Old Kingdom", -- [2]
					"enUS", -- [3]
				},
			},
			["script_data_trash"] = {
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --castbar color (when can be interrupted)\n    envTable.CastbarColor = scriptTable.config.castbarColor\n    \n    --flash duration\n    local CONFIG_BACKGROUND_FLASH_DURATION = scriptTable.config.flashDuration\n    \n    --add this value to the cast bar height\n    envTable.CastBarHeightAdd = scriptTable.config.castBarHeight\n    \n    --create a fast flash above the cast bar\n    envTable.FullBarFlash = envTable.FullBarFlash or Plater.CreateFlash (self, 0.05, 1, \"white\")\n    \n    --create a camera shake for the nameplate\n    envTable.FrameShake = Plater:CreateFrameShake (unitFrame, scriptTable.config.shakeDuration, scriptTable.config.shakeAmplitude, scriptTable.config.shakeFrequency, false, false, 0, 1, 0.05, 0.1, Plater.GetPoints (unitFrame))\n    \n    --create a texture to use for a flash behind the cast bar\n    local backGroundFlashTexture = Plater:CreateImage (self, [[Interface\\ACHIEVEMENTFRAME\\UI-Achievement-Alert-Glow]], self:GetWidth()+60, self:GetHeight()+50, \"background\", {0, 400/512, 0, 170/256})\n    backGroundFlashTexture:SetBlendMode (\"ADD\", 7)\n    backGroundFlashTexture:SetDrawLayer(\"OVERLAY\", 7)\n    backGroundFlashTexture:SetPoint (\"center\", self, \"center\")\n    backGroundFlashTexture:Hide()\n    \n    --create the animation hub to hold the flash animation sequence\n    envTable.BackgroundFlash = envTable.BackgroundFlash or Plater:CreateAnimationHub (backGroundFlashTexture, \n        function()\n            backGroundFlashTexture:Show()\n        end,\n        function()\n            backGroundFlashTexture:Hide()\n        end\n    )\n    \n    --create the flash animation sequence\n    envTable.BackgroundFlash.fadeIn = envTable.BackgroundFlash.fadeIn or Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 1, CONFIG_BACKGROUND_FLASH_DURATION/2, 0, .75)\n    envTable.BackgroundFlash.fadeIn:SetDuration(CONFIG_BACKGROUND_FLASH_DURATION/2)\n    \n    envTable.BackgroundFlash.fadeOut = envTable.BackgroundFlash.fadeOut or Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 2, CONFIG_BACKGROUND_FLASH_DURATION/2, 1, 0)    \n    envTable.BackgroundFlash.fadeOut:SetDuration(CONFIG_BACKGROUND_FLASH_DURATION/2)\n    \n    --envTable.BackgroundFlash:Play() --envTable.BackgroundFlash:Stop()    \n    \n    \n    \n    \n    \nend\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    unitFrame.castBar:SetHeight (envTable._DefaultHeight)\n    \n    --stop the camera shake\n    unitFrame:StopFrameShake (envTable.FrameShake)\n    \n    envTable.FullBarFlash:Stop()\n    envTable.BackgroundFlash:Stop()\n    \n    unitFrame.castBar.Spark:SetHeight(unitFrame.castBar:GetHeight())\n    \n    --check if there's a timer for this spell\n    local timer = scriptTable.config.timerList[tostring(envTable._SpellID)]\n    \n    if (timer) then\n        --insert code here\n        \n        --set the castbar config\n        local config = {\n            iconTexture = \"\",\n            iconTexcoord = {0.1, 0.9, 0.1, 0.9},\n            iconAlpha = 1,\n            iconSize = 14,\n            \n            text = \"Spikes Incoming!\",\n            textSize = 8,\n            \n            texture = [[Interface\\AddOns\\Plater\\images\\bar_background]],\n            color = {.6, .6, .6, 0.8},\n            \n            isChanneling = false,\n            canInterrupt = false,\n            \n            height = 5,\n            width = Plater.db.profile.plate_config.enemynpc.health_incombat[1],\n            \n            spellNameAnchor = {side = 3, x = 0, y = -2},\n            timerAnchor = {side = 5, x = 0, y = -2},\n        }\n        \n        Plater.SetAltCastBar(unitFrame.PlateFrame, config, timer, nil, nil)\n        local castBar2 = unitFrame.castBar2\n        castBar2.Text:ClearAllPoints()\n        castBar2.Text:SetPoint (\"topleft\", castBar2, \"bottomleft\", 0, 0)\n        castBar2.percentText:ClearAllPoints()\n        castBar2.percentText:SetPoint (\"topright\", castBar2, \"bottomright\", 0, 0)\n        Plater:SetFontSize(castBar2.percentText, 8)\n    end\n    \nend\n\n\n\n\n\n\n\n",
					["OptionsValues"] = {
					},
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \nend\n\n\n",
					["Time"] = 1625793282,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_orange",
					["Enabled"] = true,
					["Revision"] = 1154,
					["semver"] = "",
					["Author"] = "Tercioo-Sylvanas",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend",
					["Desc"] = "Player an animation when the cast start. Start a timer when the cast finishes. Set the time in the options.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						350421, -- [1]
						355787, -- [2]
						348513, -- [3]
					},
					["Name"] = "Cast - Alert + Timer [P]",
					["PlaterCore"] = 1,
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Key"] = "option1",
							["Value"] = 0,
							["Name"] = "Blank Line",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Key"] = "option2",
							["Value"] = "Cast start animation settings",
							["Name"] = "Option 2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 6,
							["Key"] = "option4",
							["Value"] = 0,
							["Name"] = "Blank Space",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 4,
							["Key"] = "useCastbarColor",
							["Value"] = true,
							["Name"] = "Cast Bar Color Enabled",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "When enabled, changes the cast bar color,",
						}, -- [4]
						{
							["Type"] = 1,
							["Key"] = "castbarColor",
							["Value"] = {
								1, -- [1]
								0.4313725490196079, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Cast Bar Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Color of the cast bar.",
						}, -- [5]
						{
							["Type"] = 6,
							["Key"] = "option7",
							["Value"] = 0,
							["Name"] = "Blank Line",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [6]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "When the cast starts it flash rapidly, adjust how fast it flashes. Value is milliseconds.",
							["Min"] = 0.05,
							["Key"] = "flashDuration",
							["Value"] = 0.4,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Flash Duration",
						}, -- [7]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Increases the cast bar height by this value",
							["Min"] = 0,
							["Key"] = "castBarHeight",
							["Value"] = 5,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Cast Bar Height Mod",
						}, -- [8]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "When the cast starts, there's a small shake in the nameplate, this settings controls how long it takes.",
							["Min"] = 0.1,
							["Key"] = "shakeDuration",
							["Value"] = 0.2,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Shake Duration",
						}, -- [9]
						{
							["Type"] = 2,
							["Max"] = 100,
							["Desc"] = "How strong is the shake.",
							["Min"] = 2,
							["Key"] = "shakeAmplitude",
							["Value"] = 8,
							["Name"] = "Shake Amplitude",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [10]
						{
							["Type"] = 2,
							["Max"] = 80,
							["Desc"] = "How fast the shake moves.",
							["Min"] = 1,
							["Key"] = "shakeFrequency",
							["Value"] = 40,
							["Name"] = "Shake Frequency",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [11]
						{
							["Type"] = 7,
							["Name"] = "Timer (Key is SpellId and Value is Time)",
							["Value"] = {
								{
									"350421", -- [1]
									"5", -- [2]
								}, -- [1]
								{
									"355787", -- [1]
									"15", -- [2]
								}, -- [2]
								{
									"348513", -- [1]
									"14", -- [2]
								}, -- [3]
								{
									"348513", -- [1]
									"14", -- [2]
								}, -- [4]
							},
							["Key"] = "timerList",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_list",
							["Desc"] = "Key is the spellId and value is the amount of time of the Timer",
						}, -- [12]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --play flash animations\n    envTable.FullBarFlash:Play()\n    \n    --envTable.currentHeight = unitFrame.castBar:GetHeight()\n    \n    --restoring the default size (not required since it already restore in the hide script)\n    if (envTable.OriginalHeight) then\n        self:SetHeight (envTable.OriginalHeight)\n    end\n    \n    --increase the cast bar size\n    local height = self:GetHeight()\n    envTable.OriginalHeight = height\n    \n    self:SetHeight (height + envTable.CastBarHeightAdd)\n    \n    Plater.SetCastBarBorderColor (self, 1, .2, .2, 0.4)\n    \n    unitFrame:PlayFrameShake (envTable.FrameShake)\n    \n    --set the color of the cast bar to dark orange (only if can be interrupted)\n    --Plater auto set this color to default when a new cast starts, no need to reset this value at OnHide.    \n    if (envTable._CanInterrupt) then\n        if (scriptTable.config.useCastbarColor) then\n            self:SetStatusBarColor (Plater:ParseColors (envTable.CastbarColor))\n        end\n    end\n    \n    envTable.BackgroundFlash:Play()\n    \n    unitFrame.castBar.Spark:SetHeight(unitFrame.castBar:GetHeight())\n    \nend\n\n\n\n\n\n\n\n\n\n\n",
					["__TrashAt"] = 1705074585,
				}, -- [1]
			},
			["class_colors"] = {
				["DEATHKNIGHT"] = {
					["colorStr"] = "ffc31d3a",
				},
				["WARRIOR"] = {
					["colorStr"] = "ffc69a6d",
				},
				["PALADIN"] = {
					["colorStr"] = "fff48bb9",
				},
				["WARLOCK"] = {
					["colorStr"] = "ff8687ed",
				},
				["DEMONHUNTER"] = {
					["colorStr"] = "ffa22fc8",
				},
				["ROGUE"] = {
					["colorStr"] = "fffff467",
				},
				["DRUID"] = {
					["colorStr"] = "ffff7c09",
				},
				["EVOKER"] = {
					["colorStr"] = "ff33937e",
				},
				["SHAMAN"] = {
					["colorStr"] = "ff006fdd",
				},
			},
			["script_auto_imported"] = {
				["Aura - Buff Alert"] = 15,
				["Cast - Effect After Cast [P]"] = 2,
				["Cast - Circular Swipe"] = 4,
				["Aura - Debuff Alert"] = 12,
				["Cast - Castbar is Timer [P]"] = 2,
				["Cast - Ultra Important"] = 14,
				["Add - Health Markers [P]"] = 2,
				["Cast - Small Alert"] = 12,
				["Add - Important [P]"] = 4,
				["Aura - Blink Time Left"] = 13,
				["Add - Tag Number [P]"] = 2,
				["Cast - Glowing [P]"] = 10,
				["Cast - Important Target [P]"] = 2,
				["Cast - Shield Interrupt"] = 2,
				["Cast - Alert + Timer [P]"] = 4,
				["Aura is Shield [P]"] = 2,
				["Add - Warning [P]"] = 5,
				["Aura While Casting [P]"] = 1,
				["Cast - Big Alert"] = 14,
				["Unit - Show Energy"] = 11,
				["Explosion Affix M+"] = 14,
				["Auto Set Skull"] = 11,
				["Cast - Quick Flash"] = 2,
				["Add - Non Elite Trash [P]"] = 4,
				["Countdown"] = 11,
				["Add - Explode on Die [P]"] = 1,
				["Cast - Stop Casting"] = 4,
				["Fixate by Unit Buff [P]"] = 2,
				["Cast - Frontal Cone"] = 15,
				["Fixate"] = 11,
				["Cast - On Going Cast [P]"] = 2,
				["Spiteful Affix"] = 3,
				["Cast - Very Important"] = 15,
				["Fixate On You"] = 11,
			},
			["health_statusbar_texture"] = "HealBot 03",
			["hook_auto_imported"] = {
				["Reorder Nameplate"] = 4,
				["Dont Have Aura"] = 1,
				["Players Targetting Amount"] = 4,
				["Color Automation"] = 1,
				["Combo Points"] = 6,
				["Cast Bar Icon Config"] = 2,
				["Execute Range"] = 1,
				["Extra Border"] = 2,
				["Attacking Specific Unit"] = 2,
				["Target Color"] = 3,
				["Aura Reorder"] = 3,
				["Hide Neutral Units"] = 1,
			},
			["aura2_x_offset"] = 0,
			["saved_cvars"] = {
				["nameplateMinAlpha"] = "0.90135484",
				["nameplateMinAlphaDistance"] = "-158489.31924611",
				["nameplateSelectedAlpha"] = "1",
				["nameplateMaxDistance"] = "35",
				["nameplateNotSelectedAlpha"] = "1",
				["nameplateOverlapV"] = "1.6399999856949",
				["nameplateShowEnemies"] = "1",
				["nameplateShowFriends"] = "0",
				["nameplateRemovalAnimation"] = "1",
			},
			["login_counter"] = 243,
			["plate_config"] = {
				["global_health_height"] = 11,
				["friendlyplayer"] = {
					["cast"] = {
						174, -- [1]
					},
					["cast_incombat"] = {
						174, -- [1]
					},
					["health_incombat"] = {
						174, -- [1]
						11, -- [2]
					},
					["health"] = {
						174, -- [1]
						11, -- [2]
					},
				},
				["friendlynpc"] = {
					["cast"] = {
						174, -- [1]
					},
					["cast_incombat"] = {
						174, -- [1]
					},
					["health_incombat"] = {
						174, -- [1]
						11, -- [2]
					},
					["health"] = {
						174, -- [1]
						11, -- [2]
					},
				},
				["enemynpc"] = {
					["cast"] = {
						174, -- [1]
					},
					["cast_incombat"] = {
						174, -- [1]
					},
					["health_incombat"] = {
						174, -- [1]
						11, -- [2]
					},
					["health"] = {
						174, -- [1]
						11, -- [2]
					},
				},
				["enemyplayer"] = {
					["cast"] = {
						174, -- [1]
					},
					["cast_incombat"] = {
						174, -- [1]
					},
					["health_incombat"] = {
						174, -- [1]
						11, -- [2]
					},
					["health"] = {
						174, -- [1]
						11, -- [2]
					},
				},
				["global_health_width"] = 174,
			},
			["aura_y_offset"] = 5,
			["border_thickness"] = 0.1000000014901161,
			["hook_data"] = {
				{
					["Enabled"] = false,
					["Revision"] = 50,
					["semver"] = "",
					["LastHookEdited"] = "",
					["Name"] = "Color Automation [Plater]",
					["Author"] = "Kastfall-Azralon",
					["Time"] = 1547392935,
					["Desc"] = "Easy way to change the color of an unit. Open the constructor script and follow the examples.",
					["Hooks"] = {
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --list of npcs and their colors, can be inserted:\n    --name of the unit\n    --name of the unit in lower case\n    --npcID of the unit\n    \n    --color can be added as:\n    --color names: \"red\", \"yellow\"\n    --color hex: \"#FF0000\", \"#FFFF00\"\n    --color table: {1, 0, 0}, {1, 1, 0}    \n    \n    envTable.NpcColors = {\n        \n        --examples, using the unit name in lower case, regular unit name and the unitID:\n        \n        [\"Thunderlord Windreader\"] = \"red\", --using regular mob name and color it as red\n        [\"thunderlord crag-leaper\"] = {1, 1, 0}, --using lower case and coloring it yellow\n        [75790] = \"#00FF00\", --using the ID of the unit and using green as color\n        \n        --insert the new mobs here:\n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n    } --close custom color bracket\n    \nend\n\n\n\n\n",
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    \n    --attempt to get the color from the unit color list\n    local color = envTable.NpcColors [unitFrame.namePlateUnitNameLower] or envTable.NpcColors [unitFrame.namePlateUnitName] or envTable.NpcColors [unitFrame.namePlateNpcId]\n    \n    --if the color exists, set the health bar color\n    if (color) then\n        Plater.SetNameplateColor (unitFrame, color)\n    end\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n",
					},
					["version"] = -1,
					["PlaterCore"] = 1,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["race"] = {
						},
						["pvptalent"] = {
						},
						["spec"] = {
						},
						["affix"] = {
						},
						["encounter_ids"] = {
						},
						["role"] = {
						},
					},
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\color_bar",
					["HooksTemp"] = {
					},
				}, -- [1]
				{
					["Enabled"] = false,
					["Revision"] = 73,
					["semver"] = "",
					["LastHookEdited"] = "",
					["Name"] = "Hide Neutral Units [Plater]",
					["Author"] = "Izimode-Azralon",
					["Time"] = 1541606242,
					["Desc"] = "Hide neutral units, show when selected, see the constructor script for options.",
					["Hooks"] = {
						["Leave Combat"] = "function (self, unitId, unitFrame, envTable)\n    if (unitFrame.namePlateUnitReaction == envTable.REACTION_NEUTRAL) then\n        \n        --plater already handle this\n        if (unitFrame.PlayerCannotAttack) then\n            return\n        end    \n        \n        --check if is only open world\n        if (envTable.OnlyInOpenWorld and Plater.ZoneInstanceType ~= \"none\") then\n            return \n        end\n        \n        --check for only in combat\n        if (envTable.ShowInCombat) then\n            envTable.HideNameplate (unitFrame)\n        end\n    end\nend\n\n\n",
						["Nameplate Added"] = "function (self, unitId, unitFrame, envTable)\n    \n    if (unitFrame.namePlateUnitReaction == envTable.REACTION_NEUTRAL) then\n        \n        --plater already handle this\n        if (unitFrame.PlayerCannotAttack) then\n            return\n        end\n        \n        --check if is only open world\n        if (envTable.OnlyInOpenWorld and Plater.ZoneInstanceType ~= \"none\") then\n            return \n        end\n        \n        --check for only in combat\n        if (envTable.ShowInCombat and InCombatLockdown()) then\n            return\n        end\n        \n        envTable.HideNameplate (unitFrame)\n    end\n    \nend\n\n\n\n\n\n\n",
						["Target Changed"] = "function (self, unitId, unitFrame, envTable)\n    \n    if (unitFrame.namePlateUnitReaction == envTable.REACTION_NEUTRAL) then\n        \n        --plater already handle this\n        if (unitFrame.PlayerCannotAttack) then\n            return\n        end    \n        \n        --check if is only open world\n        if (envTable.OnlyInOpenWorld and Plater.ZoneInstanceType ~= \"none\") then\n            return \n        end\n        \n        --check for only in combat\n        if (envTable.ShowInCombat and InCombatLockdown()) then\n            return\n        end\n        \n        --check the unit reaction\n        if (unitFrame.namePlateIsTarget) then\n            envTable.ShowNameplate (unitFrame)\n            \n        else\n            envTable.HideNameplate (unitFrame)\n            \n        end    \n    end\n    \nend\n\n\n\n\n\n\n",
						["Nameplate Removed"] = "function (self, unitId, unitFrame, envTable)\n    \n    if (unitFrame.namePlateUnitReaction == envTable.REACTION_NEUTRAL) then\n        envTable.ShowNameplate (unitFrame)\n    end\n    \nend\n\n\n\n\n",
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    \n    --when plater finishes an update on the nameplate\n    --check within the envTable if the healthBar of this nameplate should be hidden\n    if (envTable.IsHidden) then\n        if (unitFrame.healthBar:IsShown()) then\n            envTable.HideNameplate (unitFrame)\n        end\n    end\n    \nend\n\n\n\n\n",
						["Enter Combat"] = "function (self, unitId, unitFrame, envTable)\n    \n    if (unitFrame.namePlateUnitReaction == envTable.REACTION_NEUTRAL) then\n        \n        --plater already handle this\n        if (unitFrame.PlayerCannotAttack) then\n            return\n        end    \n        \n        --check if is only open world\n        if (envTable.OnlyInOpenWorld and Plater.ZoneInstanceType ~= \"none\") then\n            return \n        end\n        \n        --check for only in combat\n        if (envTable.ShowInCombat) then\n            envTable.ShowNameplate (unitFrame)\n        end\n    end\nend\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --settings\n    envTable.OnlyInOpenWorld = true;\n    envTable.ShowInCombat = true;\n    \n    --consts\n    envTable.REACTION_NEUTRAL = 4;\n    \n    --functions to hide and show the healthBar\n    function envTable.HideNameplate (unitFrame)\n        Plater.HideHealthBar (unitFrame)\n        Plater.DisableHighlight (unitFrame)\n        envTable.IsHidden = true\n    end\n    \n    function envTable.ShowNameplate (unitFrame)\n        Plater.ShowHealthBar (unitFrame)\n        Plater.EnableHighlight (unitFrame)\n        envTable.IsHidden = false\n    end\n    \nend\n\n\n\n\n",
					},
					["version"] = -1,
					["PlaterCore"] = 1,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["spec"] = {
						},
						["affix"] = {
						},
						["encounter_ids"] = {
						},
						["race"] = {
						},
					},
					["url"] = "",
					["Icon"] = 1990989,
					["HooksTemp"] = {
					},
				}, -- [2]
				{
					["HooksTemp"] = {
					},
					["Hooks"] = {
						["Nameplate Added"] = "\n\n-- exported function Plater.UpdatePlateSize() from Plater.lua\n--this is for advanced users which wants to reorder the nameplate frame at their desire\n\n\n\nfunction (self, unitId, unitFrame, envTable)\n    \n    --check if there's a type of unit on this nameplate\n    local plateFrame = unitFrame:GetParent()\n    if (not plateFrame.actorType) then\n        return\n    end\n    \n    --get all the frames and cache some variables\n    local ACTORTYPE_ENEMY_PLAYER = \"enemyplayer\"\n    local profile = Plater.db.profile\n    local DB_PLATE_CONFIG = profile.plate_config\n    local isInCombat = Plater.IsInCombat()\n    local actorType = plateFrame.actorType\n    \n    local unitFrame = plateFrame.unitFrame\n    local healthBar = unitFrame.healthBar\n    local castBar = unitFrame.castBar\n    local powerBar = unitFrame.powerBar\n    local buffFrame1 = unitFrame.BuffFrame\n    local buffFrame2 = unitFrame.BuffFrame2\n    \n    --use in combat bars when in pvp\n    if (plateFrame.actorType == ACTORTYPE_ENEMY_PLAYER) then\n        if ((Plater.ZoneInstanceType == \"pvp\" or Plater.ZoneInstanceType == \"arena\") and DB_PLATE_CONFIG.player.pvp_always_incombat) then\n            isInCombat = true\n        end\n    end\n    \n    --get the config for this actor type\n    local plateConfigs = DB_PLATE_CONFIG [actorType]\n    --get the config key based if the player is in combat\n    local castBarConfigKey, healthBarConfigKey, manaConfigKey = Plater.GetHashKey (isInCombat)\n    \n    --get the width and height from what the user set in the options panel\n    local healthBarWidth, healthBarHeight = unitFrame.customHealthBarWidth or plateConfigs [healthBarConfigKey][1], unitFrame.customHealthBarHeight or plateConfigs [healthBarConfigKey][2]\n    local castBarWidth, castBarHeight = unitFrame.customCastBarWidth or plateConfigs [castBarConfigKey][1], unitFrame.customCastBarHeight or plateConfigs [castBarConfigKey][2]\n    local powerBarWidth, powerBarHeight = unitFrame.customPowerBarHeight or plateConfigs [manaConfigKey][1], unitFrame.customPowerBarHeight or plateConfigs [manaConfigKey][2]\n    \n    --calculate the offset for the cast bar, this is done due to the cast bar be anchored to topleft and topright\n    local castBarOffSetX = (healthBarWidth - castBarWidth) / 2\n    local castBarOffSetY = plateConfigs.castbar_offset\n    \n    --calculate offsets for the power bar\n    local powerBarOffSetX = (healthBarWidth - powerBarWidth) / 2\n    local powerBarOffSetY = 0\n    \n    --calculate the size deviation for pets\n    local unitType = Plater.GetUnitType (plateFrame)\n    if (unitType == \"pet\") then\n        healthBarHeight = healthBarHeight * Plater.db.profile.pet_height_scale\n        healthBarWidth = healthBarWidth * Plater.db.profile.pet_width_scale\n        \n    elseif (unitType == \"minus\") then\n        healthBarHeight = healthBarHeight * Plater.db.profile.minor_height_scale\n        healthBarWidth = healthBarWidth * Plater.db.profile.minor_width_scale\n    end\n    \n    --unit frame - is set to be the same size as the plateFrame\n    unitFrame:ClearAllPoints()\n    unitFrame:SetAllPoints()\n    \n    --calculates the health bar anchor points\n    --it will always be placed in the center of the nameplate area (where it accepts mouse clicks) \n    local xOffSet = (plateFrame:GetWidth() - healthBarWidth) / 2\n    local yOffSet = (plateFrame:GetHeight() - healthBarHeight) / 2\n    \n    --set the health bar point\n    healthBar:ClearAllPoints()\n    PixelUtil.SetPoint (healthBar, \"topleft\", unitFrame, \"topleft\", xOffSet + profile.global_offset_x, -yOffSet + profile.global_offset_y)\n    PixelUtil.SetPoint (healthBar, \"bottomright\", unitFrame, \"bottomright\", -xOffSet + profile.global_offset_x, yOffSet + profile.global_offset_y)\n    \n    --set the cast bar point and size\n    castBar:ClearAllPoints()\n    PixelUtil.SetPoint (castBar, \"topleft\", healthBar, \"bottomleft\", castBarOffSetX, castBarOffSetY)\n    PixelUtil.SetPoint (castBar, \"topright\", healthBar, \"bottomright\", -castBarOffSetX, castBarOffSetY)\n    PixelUtil.SetHeight (castBar, castBarHeight)\n    PixelUtil.SetSize (castBar.Icon, castBarHeight, castBarHeight)\n    PixelUtil.SetSize (castBar.BorderShield, castBarHeight * 1.4, castBarHeight * 1.4)\n    \n    --set the power bar point and size\n    powerBar:ClearAllPoints()\n    PixelUtil.SetPoint (powerBar, \"topleft\", healthBar, \"bottomleft\", powerBarOffSetX, powerBarOffSetY)\n    PixelUtil.SetPoint (powerBar, \"topright\", healthBar, \"bottomright\", -powerBarOffSetX, powerBarOffSetY)\n    PixelUtil.SetHeight (powerBar, powerBarHeight)\n    \n    --power bar are hidden by default, show it if there's a custom size for it\n    if (unitFrame.customPowerBarWidth and unitFrame.customPowerBarHeight) then\n        powerBar:SetUnit (unitFrame.unit)\n    end\n    \n    --aura frames\n    local bf1Anchor = Plater.db.profile.aura_frame1_anchor\n    Plater.SetAnchor (buffFrame1, {side = bf1Anchor.side, x = bf1Anchor.x, y = bf1Anchor.y + plateConfigs.buff_frame_y_offset}, unitFrame.healthBar, (Plater.db.profile.aura_grow_direction or 2) == 2)\n    \n    local bf2Anchor = Plater.db.profile.aura_frame2_anchor\n    Plater.SetAnchor (buffFrame2, {side = bf2Anchor.side, x = bf2Anchor.x, y = bf2Anchor.y + plateConfigs.buff_frame_y_offset}, unitFrame.healthBar, (Plater.db.profile.aura2_grow_direction or 2) == 2)\n    \nend\n\n\n",
					},
					["Time"] = 1596791840,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["race"] = {
						},
						["affix"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["url"] = "",
					["Icon"] = 574574,
					["Enabled"] = false,
					["Revision"] = 93,
					["Options"] = {
					},
					["Author"] = "Kastfall-Azralon",
					["Desc"] = "Function Plater.UpdatePlateSize from Plater.lua exported to scritps.",
					["Name"] = "Reorder Nameplate [Plater]",
					["PlaterCore"] = 1,
					["semver"] = "",
					["LastHookEdited"] = "",
					["version"] = -1,
				}, -- [3]
				{
					["Enabled"] = false,
					["Revision"] = 59,
					["semver"] = "",
					["LastHookEdited"] = "",
					["Name"] = "Don't Have Aura [Plater]",
					["Author"] = "Izimode-Azralon",
					["Time"] = 1554138845,
					["Desc"] = "Change the nameplate color when a nameplate does not have the auras set in the constructor script.",
					["Hooks"] = {
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    --Important: lines starting with double dashes are comments and are not part of the script\n    \n    --set this to true if you are not using threat colors in the health bar\n    envTable.ForceRefreshNameplateColor = true\n    \n    --if the unit does not have any of the following auras, it will be painted with the color listed below\n    --list of spells to track, can be the spell name (case-sensitive) or the spellID\n    envTable.TrackingAuras = {\n        --[\"Nightblade\"] = true, --this is an example using the spell name\n        --[195452] = true, --this is an example using the spellID\n        \n    }\n    \n    --which color the nameplate wil be changed\n    --color can be added as:\n    --color names: \"red\", \"yellow\"\n    --color hex: \"#FF0000\", \"#FFFF00\"\n    --color table: {1, 0, 0}, {1, 1, 0}    \n    --you may also use /plater colors\n    envTable.NameplateColor = \"pink\"\n    \nend",
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    \n    --do nothing if the player isn't in combat\n    if (not Plater.IsInCombat()) then\n        return \n    end\n    \n    --do nothing if the unit isn't in combat\n    if (not unitFrame.InCombat) then\n        return\n    end\n    \n    --do nothing if the unit is the player it self\n    if (unitFrame.IsSelf) then\n        return\n    end\n    \n    --check the auras\n    local hasAura = false\n    \n    for auraName, _ in pairs (envTable.TrackingAuras) do\n        if (Plater.NameplateHasAura (unitFrame, auraName)) then\n            hasAura = true\n            break\n        end\n    end\n    \n    if (not hasAura) then\n        Plater.SetNameplateColor (unitFrame, envTable.NameplateColor)\n    else\n        if (envTable.ForceRefreshNameplateColor) then\n            Plater.RefreshNameplateColor (unitFrame) \n        end\n    end    \n    \nend",
					},
					["version"] = -1,
					["PlaterCore"] = 1,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["race"] = {
						},
						["pvptalent"] = {
						},
						["role"] = {
						},
						["affix"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["url"] = "",
					["Icon"] = 136207,
					["HooksTemp"] = {
					},
				}, -- [4]
				{
					["Enabled"] = false,
					["Revision"] = 176,
					["semver"] = "",
					["LastHookEdited"] = "",
					["Name"] = "Extra Border [Plater]",
					["Author"] = "Tecno-Azralon",
					["Time"] = 1547409079,
					["Desc"] = "Add another border with more customizations. This border can also be manipulated by other scripts.",
					["Hooks"] = {
						["Nameplate Created"] = "function (self, unitId, unitFrame, envTable)\n    \n    --run constructor!\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
						["Nameplate Added"] = "function (self, unitId, unitFrame, envTable)\n    if (envTable.IsEnabled) then\n        if (unitFrame.IsSelf) then\n            if (envTable.ShowOnPersonalBar) then\n                envTable.BorderFrame:Show()\n            else\n                envTable.BorderFrame:Hide() \n            end\n        else\n            envTable.BorderFrame:Show()\n        end   \n    end\n    \nend   \n\n\n\n",
						["Nameplate Removed"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.BorderFrame:Hide()\n    \nend\n\n\n",
						["Destructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.BorderFrame:Hide()\n    \nend\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --border color\n    local borderColor = \"yellow\"\n    \n    --size of the border\n    local borderSize = 1\n    \n    --transparency\n    local borderAlpha = 1\n    \n    --enabled (set to false it you only want to use the extra border in other scripts)\n    local isEnabled = true\n    \n    --export border (allow the border to be used by other scripts)\n    --other scripts can use:\n    --unitFrame.healthBar.extraBorder:Show()\n    --unitFrame.healthBar.extraBorder:SetVertexColor (r, g, b)\n    --unitFrame.healthBar.extraBorder:SetBorderSizes (borderSize)\n    local canExportBorder = true\n    \n    --do not add the border to personal bar\n    local noPersonalBar = true\n    \n    --private\n    do\n        \n        local newBorder = CreateFrame (\"frame\", nil, unitFrame.healthBar, \"NamePlateFullBorderTemplate\")\n        envTable.BorderFrame = newBorder\n        \n        newBorder:SetBorderSizes (borderSize, borderSize, borderSize, borderSize)\n        newBorder:UpdateSizes()\n        \n        local r, g, b = DetailsFramework:ParseColors (borderColor)\n        newBorder:SetVertexColor (r, g, b, borderAlpha)\n        \n        envTable.ShowOnPersonalBar = not noPersonalBar\n        \n        if (canExportBorder) then\n            unitFrame.healthBar.extraBorder = newBorder\n        end\n        \n        if (not isEnabled) then\n            envTable.IsEnabled = false\n        else\n            envTable.IsEnabled = true\n        end\n    end\n    \nend\n\n\n",
					},
					["version"] = -1,
					["PlaterCore"] = 1,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["race"] = {
						},
						["affix"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["url"] = "",
					["Icon"] = 133689,
					["HooksTemp"] = {
					},
				}, -- [5]
				{
					["Enabled"] = false,
					["Revision"] = 93,
					["semver"] = "",
					["LastHookEdited"] = "",
					["Name"] = "Current Target Color [Plater]",
					["Author"] = "Izimode-Azralon",
					["Time"] = 1552354619,
					["Desc"] = "Changes the target color to the color set in the constructor script.",
					["Hooks"] = {
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    envTable.UpdateColor (unitFrame)\nend",
						["Nameplate Added"] = "function (self, unitId, unitFrame, envTable)\n    envTable.UpdateColor (unitFrame)\nend",
						["Target Changed"] = "function (self, unitId, unitFrame, envTable)\n    envTable.UpdateColor (unitFrame)\nend\n\n\n\n\n\n\n\n\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --usage: color name e.g \"red\" \"yellow\"; color table e.g {1, 0, 0} {1, 1, 0}; hex string e.g. \"#FF0000\" \"FFFF00\"\n    \n    envTable.TargetColor = \"purple\"\n    --envTable.TargetColor = \"#FF00FF\"\n    --envTable.TargetColor = {252/255, 0/255, 254/255}\n    \n    function envTable.UpdateColor (unitFrame)\n        --do not change the color of the personal bar\n        if (not unitFrame.IsSelf) then\n            \n            --if this nameplate the current target of the player?\n            if (unitFrame.namePlateIsTarget) then\n                Plater.SetNameplateColor (unitFrame, envTable.TargetColor)  --rgb\n            else\n                --refresh the nameplate color\n                Plater.RefreshNameplateColor (unitFrame)\n            end\n        end\n    end\n    \nend\n\n\n\n\n",
					},
					["version"] = -1,
					["PlaterCore"] = 1,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["race"] = {
						},
						["pvptalent"] = {
						},
						["role"] = {
						},
						["affix"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["url"] = "",
					["Icon"] = 878211,
					["HooksTemp"] = {
					},
				}, -- [6]
				{
					["HooksTemp"] = {
					},
					["Hooks"] = {
						["Cast Start"] = "function (self, unitId, unitFrame, envTable)\n    \n    unitFrame.castBar.BorderShield:SetDrawLayer(\"artwork\")\n    envTable.UpdateIconPosition (unitFrame)\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
						["Cast Update"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.UpdateIconPosition (unitFrame)\n    self.ThrottleUpdate = -1\n    \nend\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable, modTable)\n    \n    --private:\n    function envTable.UpdateIconPosition (unitFrame)\n        local castBar = unitFrame.castBar\n        local icon = castBar.Icon\n        local noInterruptTexture = castBar.BorderShield\n        \n        if (modTable.config.showIcon) then\n            icon:ClearAllPoints()\n            \n            if (modTable.config.iconOnLeftSide) then\n                if (modTable.config.useFullSize) then\n                    icon:SetPoint (\"topright\", unitFrame.healthBar, \"topleft\", modTable.config.iconPadding, modTable.config.iconSizeOffset)\n                    icon:SetPoint (\"bottomright\", unitFrame.castBar, \"bottomleft\", modTable.config.iconPadding, -modTable.config.iconSizeOffset)\n                    \n                else\n                    \n                    icon:SetPoint (\"topright\", unitFrame.castBar, \"topleft\", modTable.config.iconPadding, modTable.config.iconSizeOffset)\n                    icon:SetPoint (\"bottomright\", unitFrame.castBar, \"bottomleft\", modTable.config.iconPadding, -modTable.config.iconSizeOffset)\n                end\n                \n            else\n                if (modTable.config.useFullSize) then\n                    icon:SetPoint (\"topleft\", unitFrame.healthBar, \"topright\", modTable.config.iconPadding, modTable.config.iconSizeOffset)\n                    icon:SetPoint (\"bottomleft\", unitFrame.castBar, \"bottomright\", modTable.config.iconPadding, -modTable.config.iconSizeOffset)\n                    \n                else\n                    \n                    icon:SetPoint (\"topleft\", unitFrame.castBar, \"topright\", modTable.config.iconPadding, modTable.config.iconSizeOffset)\n                    icon:SetPoint (\"bottomleft\", unitFrame.castBar, \"bottomright\", modTable.config.iconPadding, -modTable.config.iconSizeOffset)\n                end\n            end\n            \n            icon:SetWidth (icon:GetHeight())\n            icon:Show()\n        else\n            icon:Hide()\n        end\n        \n        if (modTable.config.showTexture and not castBar.canInterrupt) then\n            noInterruptTexture:Show()\n            \n            local texturePath = modTable.config.iconTexturePath\n            texturePath = texturePath:gsub(\"//\", \"/\")\n            texturePath = texturePath:gsub(\"\\\\\", \"/\")\n            \n            noInterruptTexture:SetTexture (texturePath)\n            noInterruptTexture:SetTexCoord (0, 1, 0, 1)\n            \n            if (modTable.config.desaturatedTexture) then\n                noInterruptTexture:SetDesaturated (modTable.config.desaturatedTexture)\n            else\n                noInterruptTexture:SetVertexColor (DetailsFramework:ParseColors (modTable.config.textureColor))\n            end\n            \n            noInterruptTexture:SetSize (modTable.config.textureWidth, castBar:GetHeight() + modTable.config.textureHeightMod)\n            noInterruptTexture:ClearAllPoints()\n            noInterruptTexture:SetPoint (\"center\", castBar, \"left\", modTable.config.texturePosition, 0)\n            noInterruptTexture:SetAlpha (modTable.config.textureAlpha)\n        else\n            noInterruptTexture:Hide()\n        end\n    end\nend",
					},
					["Time"] = 1597097268,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["race"] = {
						},
						["affix"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\castbar_icon",
					["Enabled"] = false,
					["Revision"] = 348,
					["Options"] = {
						{
							["Type"] = 5,
							["Name"] = "Icon Settings",
							["Value"] = "Icon Settings:",
							["Key"] = "option4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 4,
							["Name"] = "Show Icon",
							["Value"] = true,
							["Key"] = "showIcon",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Show the castbar icon when enabled",
						}, -- [2]
						{
							["Type"] = 4,
							["Name"] = "Icon on Left Side",
							["Value"] = true,
							["Key"] = "iconOnLeftSide",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "If enabled it anchor the icon on the left side, right otherwise",
						}, -- [3]
						{
							["Type"] = 4,
							["Key"] = "useFullSize",
							["Value"] = false,
							["Name"] = "Use Big Icon",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "If enabled the icon has the size of the cast bar plus the healthbar",
						}, -- [4]
						{
							["Type"] = 2,
							["Max"] = 5,
							["Desc"] = "Fine tune the icon size",
							["Min"] = 0,
							["Fraction"] = true,
							["Value"] = 0,
							["Name"] = "Icon Size Offset",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "iconSizeOffset",
						}, -- [5]
						{
							["Type"] = 2,
							["Max"] = 5,
							["Desc"] = "Space between the icon and the cast bar",
							["Min"] = -5,
							["Name"] = "Icon Padding",
							["Value"] = 0,
							["Key"] = "iconPadding",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [6]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option6",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [7]
						{
							["Type"] = 5,
							["Name"] = "Interrupt Texture",
							["Value"] = "Can't Interrupt Texture:",
							["Key"] = "option5",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [8]
						{
							["Type"] = 4,
							["Name"] = "Show Texture",
							["Value"] = true,
							["Key"] = "showTexture",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "If enabled show a texture to tell the cast can't be interrupted",
						}, -- [9]
						{
							["Type"] = 3,
							["Name"] = "Texture Path",
							["Value"] = "Interface\\GROUPFRAME\\UI-GROUP-MAINTANKICON",
							["Key"] = "iconTexturePath",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_text",
							["Desc"] = "Insert the path for the texture",
						}, -- [10]
						{
							["Type"] = 4,
							["Name"] = "Texture Desaturated",
							["Value"] = true,
							["Key"] = "desaturatedTexture",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "If enbaled, texture is shown in black & white",
						}, -- [11]
						{
							["Type"] = 1,
							["Name"] = "Texture Color",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								0.3056715726852417, -- [4]
							},
							["Key"] = "textureColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Select the color of the texture",
						}, -- [12]
						{
							["Type"] = 2,
							["Max"] = 32,
							["Desc"] = "Adjust the texture width",
							["Min"] = 1,
							["Fraction"] = false,
							["Value"] = 10,
							["Name"] = "Texture Width",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "textureWidth",
						}, -- [13]
						{
							["Type"] = 2,
							["Max"] = 16,
							["Desc"] = "The texture is set to be the same size as the cast bar, fine tune the height as wanted",
							["Min"] = -16,
							["Name"] = "Texture Height Mod",
							["Value"] = 0,
							["Key"] = "textureHeightMod",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [14]
						{
							["Type"] = 2,
							["Max"] = 32,
							["Desc"] = "Adjust the texture position",
							["Min"] = -32,
							["Fraction"] = false,
							["Value"] = 0,
							["Name"] = "Texture Position",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "texturePosition",
						}, -- [15]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Adjust the texture transparency",
							["Min"] = 0,
							["Key"] = "textureAlpha",
							["Value"] = 1,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Texture Alpha",
						}, -- [16]
					},
					["Author"] = "Ditador-Azralon",
					["Desc"] = "Move the icon of the spell cast to the left or right side of the nameplate.",
					["Name"] = "Cast Bar Icon Settings [P]",
					["PlaterCore"] = 1,
					["semver"] = "",
					["LastHookEdited"] = "",
					["version"] = -1,
				}, -- [7]
				{
					["Enabled"] = false,
					["Revision"] = 84,
					["semver"] = "",
					["LastHookEdited"] = "",
					["Name"] = "Execute Range [Plater]",
					["Author"] = "Ahwa-Azralon",
					["Time"] = 1547406548,
					["Desc"] = "Add extra effects to execute range. See the constructor script for options.",
					["Hooks"] = {
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --execute detection, if true the script will handle the execute percent\n    --while false Plater will automatically trigger the execute range\n    --you only want to set this to true in case of Plater not detecting the execute range correctly\n    envTable.UseCustomExecutePercent = false\n    --execute percent, if not detecting automatic, this is the percent to active the execute range\n    --use from zero to one, 0.20 is equal to 20% of the unit life\n    envTable.ExecutePercent = 0.20\n    \n    --allow this script to change the nameplate color when the unit is in execute range\n    envTable.CanChangeColor = true\n    --change the health bar color to this color when the unit is in execute range\n    --color can be set as:\n    --color names: \"red\", \"yellow\"\n    --color hex: \"#FF0000\", \"#FFFF00\"\n    --color table: {1, 0, 0}, {1, 1, 0}\n    envTable.ExecuteColor = \"green\"\n    \n    --border color\n    envTable.CanChangeBorderColor = false\n    envTable.BorderColor = \"red\"\n    \n    --hide the default health divisor and the health execute indicator\n    envTable.HideHealthDivisor = false\n    --if not hidden, adjust the health divisor settings and the health execute indicator\n    envTable.HealthDivisorAlpha = 0.5\n    envTable.HealthDivisorColor = \"white\"\n    envTable.HealthExecuteIndicatorAlpha = 0.15\n    envTable.HealthExecuteIndicatorColor = \"darkred\"\n    \n    \n    --private (internal functions)\n    do\n        function envTable.UnitInExecuteRange (unitFrame)\n            --check if can change the execute color\n            if (envTable.CanChangeColor) then\n                Plater.SetNameplateColor (unitFrame, envTable.ExecuteColor)\n            end\n            \n            if (envTable.CanChangeBorderColor) then\n                Plater.SetBorderColor (unitFrame, envTable.BorderColor)\n            end\n            \n            if (envTable.HideHealthDivisor) then\n                unitFrame.healthBar.healthCutOff:Hide() \n                unitFrame.healthBar.executeRange:Hide()\n                \n            else\n                envTable.UpdateHealthDivisor (unitFrame)\n                \n            end\n        end\n        \n        function envTable.UpdateHealthDivisor (unitFrame)\n            local healthBar = unitFrame.healthBar\n            \n            healthBar.healthCutOff:Show()\n            healthBar.healthCutOff:SetVertexColor (DetailsFramework:ParseColors (envTable.HealthDivisorColor))\n            healthBar.healthCutOff:SetAlpha (envTable.HealthDivisorAlpha)\n            \n            healthBar.executeRange:Show()\n            healthBar.executeRange:SetVertexColor (DetailsFramework:ParseColors (envTable.HealthExecuteIndicatorColor))\n            healthBar.executeRange:SetAlpha (envTable.HealthExecuteIndicatorAlpha)\n            \n            if (envTable.UseCustomExecutePercent) then\n                healthBar.healthCutOff:ClearAllPoints()\n                healthBar.executeRange:ClearAllPoints()\n                \n                healthBar.healthCutOff:SetSize (healthBar:GetHeight(), healthBar:GetHeight())\n                healthBar.healthCutOff:SetPoint (\"center\", healthBar, \"left\", healthBar:GetWidth() * envTable.ExecutePercent, 0)\n                \n                healthBar.executeRange:SetTexCoord (0, envTable.ExecutePercent, 0, 1)\n                healthBar.executeRange:SetHeight (healthBar:GetHeight())\n                healthBar.executeRange:SetPoint (\"left\", healthBar, \"left\", 0, 0)\n                healthBar.executeRange:SetPoint (\"right\", healthBar.healthCutOff, \"center\")\n            end\n            \n        end\n    end\n    \nend",
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    \n    if (envTable.UseCustomExecutePercent) then\n        \n        --manual detection\n        local healthBar = unitFrame.healthBar\n        if (healthBar.CurrentHealth / healthBar.CurrentHealthMax <= envTable.ExecutePercent) then\n            envTable.UnitInExecuteRange (unitFrame)\n        end        \n        \n    else\n        \n        --auto detection\n        if (unitFrame.InExecuteRange) then\n            envTable.UnitInExecuteRange (unitFrame)\n        end\n        \n    end\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n",
					},
					["version"] = -1,
					["PlaterCore"] = 1,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["race"] = {
						},
						["pvptalent"] = {
						},
						["role"] = {
						},
						["affix"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["url"] = "",
					["Icon"] = 135358,
					["HooksTemp"] = {
					},
				}, -- [8]
				{
					["HooksTemp"] = {
					},
					["Hooks"] = {
						["Initialization"] = "function (modTable)\n    --list of npcs and their colors, can be inserted:\n    --name of the unit\n    --name of the unit in lower case\n    --npcID of the unit\n    \n    --color can be added as:\n    --color names: \"red\", \"yellow\"\n    --color hex: \"#FF0000\", \"#FFFF00\"\n    --color table: {1, 0, 0}, {1, 1, 0}    \n    \n    modTable.changeBarColor = modTable.config.changeBarColor\n    modTable.changeBorderColor = modTable.config.changeBorderColor\n    modTable.resetColors = modTable.config.resetColors\n    \n    modTable.ListOfNpcs = {\n        [61146] = modTable.config.color, --\"olive\", --monk statue npcID\n        [103822] = modTable.config.color, --\"olive\", --druid treant npcID\n        [15352] = modTable.config.color, --\"olive\", --shaman elemental\n        [95072] = modTable.config.color, --\"olive\", --shaman greater earth elemental npcID\n        [61056] = modTable.config.color, --\"olive\", --shaman primal earth elemental npcID\n        \n    }\nend\n\n\n",
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable, modTable)\n    if not unitId then\n        return\n    end\n    --get the GUID of the target of the unit\n    local targetGUID = UnitGUID (unitId .. \"target\")\n    \n    if (targetGUID) then\n        \n        --get the npcID of the target\n        local npcID = Plater.GetNpcIDFromGUID (targetGUID)\n        local unitName = UnitName (unitId .. \"target\")\n        local unitNameLower = string.lower (unitName)\n        \n        --check if the npcID of this unit is in the npc list \n        local color = modTable.ListOfNpcs [npcID] or modTable.ListOfNpcs [unitName] or modTable.ListOfNpcs [unitNameLower]\n        \n        if color then\n            if modTable.changeBarColor then\n                Plater.SetNameplateColor (unitFrame, color)\n            end\n            if modTable.changeBorderColor then\n                Plater.SetBorderColor (unitFrame, color)\n            end\n            unitFrame.attackingSpecificUnitFromMod = true\n        elseif unitFrame.attackingSpecificUnitFromMod and modTable.resetColors then\n            if modTable.changeBorderColor then\n                Plater.SetBorderColor (unitFrame)\n            end\n            if modTable.changeBarColor then\n                Plater.RefreshNameplateColor (unitFrame)\n            end\n            unitFrame.attackingSpecificUnitFromMod = false\n        end\n    end\nend",
					},
					["Time"] = 1620377377,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\icon_attacking_unit",
					["Enabled"] = false,
					["Revision"] = 363,
					["Options"] = {
						{
							["Type"] = 1,
							["Key"] = "color",
							["Value"] = {
								0.5019607843137255, -- [1]
								0.5019607843137255, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 4,
							["Key"] = "changeBarColor",
							["Value"] = true,
							["Name"] = "Change Bar Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 4,
							["Key"] = "changeBorderColor",
							["Value"] = false,
							["Name"] = "Change Border Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 4,
							["Key"] = "resetColors",
							["Value"] = true,
							["Name"] = "Reset Colors",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [4]
					},
					["Author"] = "Kastfall-Azralon",
					["Desc"] = "Change the nameplate color if the unit is attacking a specific unit like Monk's Ox Statue or Druid's Treants. You may edit which units it track in the constructor script.",
					["Name"] = "Attacking Specific Unit [Plater]",
					["PlaterCore"] = 1,
					["semver"] = "",
					["LastHookEdited"] = "",
					["version"] = -1,
				}, -- [9]
				{
					["HooksTemp"] = {
					},
					["Hooks"] = {
						["Nameplate Created"] = "function (self, unitId, unitFrame, envTable)\n    \n    --run constructor!\n    --constructor is executed only once when any script of the hook runs.\n    \nend\n\n\n",
						["Nameplate Added"] = "function (self, unitId, unitFrame, envTable)\n    \n    --check if need update the amount of combo points shown\n    if (envTable.LastPlayerTalentUpdate > envTable.LastUpdate) then\n        envTable.UpdateComboPointAmount()\n    end    \n    \n    if (unitFrame.namePlateIsTarget and not unitFrame.IsSelf) then\n        envTable.ComboPointFrame:Show()\n        envTable.UpdateComboPoints()\n        \n    else\n        envTable.ComboPointFrame:Hide()\n    end    \n    \nend\n\n\n",
						["Target Changed"] = "function (self, unitId, unitFrame, envTable)\n    \n    --check if this nameplate is the current target\n    if (unitFrame.namePlateIsTarget and not unitFrame.IsSelf) then\n        envTable.ComboPointFrame:Show()\n        envTable.UpdateComboPoints()\n    else\n        envTable.ComboPointFrame:Hide()\n    end\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
						["Player Power Update"] = "function (self, unitId, unitFrame, envTable, modTable, ...)\n    local powerType = ...\n    \n    if (powerType and powerType == \"COMBO_POINTS\" and unitFrame.namePlateIsTarget and not unitFrame.IsSelf) then\n        envTable.UpdateComboPoints()\n    end\n    \n    \nend",
						["Nameplate Removed"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.ComboPointFrame:Hide()\n    \nend\n\n\n",
						["Destructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.ComboPointFrame:Hide()\n    \nend\n\n\n\n\n",
						["Player Talent Update"] = "function (self, unitId, unitFrame, envTable)\n    \n    --update the amount of comboo points shown when the player changes talents or specialization\n    envTable.UpdateComboPointAmount()\n    \n    --save the time of the last talent change\n    envTable.LastPlayerTalentUpdate = GetTime()\n    \n    \nend\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    --settings\n    local anchors = {\n        {\"bottom\", unitFrame.healthBar, \"top\", 0, 24},\n    }\n    \n    local sizes = {\n        width = 12,\n        height = 12,\n        scale = 1,\n    }\n    \n    local textures = {\n        backgroundTexture = [[Interface\\PLAYERFRAME\\ClassOverlayComboPoints]],\n        backgroundTexCoords = {0/128, 21/128, 101/128, 122/128},\n        \n        comboPointTexture = [[Interface\\PLAYERFRAME\\ClassOverlayComboPoints]],\n        comboPointTexCoords = {3/128, 18/128, 81/128, 96/128},\n    }\n    if WOW_PROJECT_ID ~= WOW_PROJECT_MAINLINE then\n        textures = {\n            backgroundTexture = [[Interface\\PLAYERFRAME\\ClassOverlayComboPoints]],\n            backgroundTexCoords = {78/128, 98/128, 21/64, 41/64},\n            \n            comboPointTexture = [[Interface\\PLAYERFRAME\\ClassOverlayComboPoints]],\n            comboPointTexCoords = {100/128, 120/128, 21/64, 41/64},\n        }\n    end\n    \n    local frameLevel = 1000\n    local frameStrata = \"high\"    \n    \n    --private\n    do\n        --store combo points frames on this table\n        envTable.ComboPoints = {}\n        --save when the player changed talents or spec\n        envTable.LastPlayerTalentUpdate = GetTime()\n        --save when this nameplate got a combo point amount and alignment update        \n        \n        --build combo points frame anchor (combo point are anchored to this)\n        if (not unitFrame.PlaterComboPointFrame) then\n            local hostFrame = CreateFrame (\"frame\", nil, unitFrame)\n            hostFrame.ComboPointFramesPool = {}\n            unitFrame.PlaterComboPointFrame = hostFrame\n            envTable.ComboPointFrame = hostFrame\n            envTable.ComboPointFrame:SetScale (sizes.scale)\n            \n            --DetailsFramework:ApplyStandardBackdrop (envTable.ComboPointFrame) --debug anchor size\n            \n            --animations\n            local onPlayShowAnimation = function (animation)\n                --stop the hide animation if it's playing\n                if (animation:GetParent():GetParent().HideAnimation:IsPlaying()) then\n                    animation:GetParent():GetParent().HideAnimation:Stop()\n                end\n                \n                animation:GetParent():Show()\n            end\n            \n            local onPlayHideAnimation = function (animation)\n                --stop the show animation if it's playing\n                if (animation:GetParent():GetParent().ShowAnimation:IsPlaying()) then\n                    animation:GetParent():GetParent().ShowAnimation:Stop()\n                end\n            end        \n            local onStopHideAnimation = function (animation)\n                animation:GetParent():Hide()       \n            end\n            \n            local createAnimations = function (comboPoint)\n                --on show\n                comboPoint.ShowAnimation = Plater:CreateAnimationHub (comboPoint.comboPointTexture, onPlayShowAnimation, nil)\n                Plater:CreateAnimation (comboPoint.ShowAnimation, \"scale\", 1, 0.1, 0, 0, 1, 1)\n                Plater:CreateAnimation (comboPoint.ShowAnimation, \"alpha\", 1, 0.1, .5, 1)\n                Plater:CreateAnimation (comboPoint.ShowAnimation, \"scale\", 2, 0.1, 1.2, 1.2, 1, 1)\n                \n                --on hide\n                comboPoint.HideAnimation = Plater:CreateAnimationHub (comboPoint.comboPointTexture, onPlayHideAnimation, onStopHideAnimation)\n                Plater:CreateAnimation (comboPoint.HideAnimation, \"scale\", 1, 0.1, 1, 1, 0, 0)\n                Plater:CreateAnimation (comboPoint.HideAnimation, \"alpha\", 1, 0.1, 1, 0)\n            end\n            \n            --build combo point frame        \n            for i =1, 10 do \n                local f = CreateFrame (\"frame\", nil, envTable.ComboPointFrame)\n                f:SetSize (sizes.width, sizes.height)\n                tinsert (envTable.ComboPoints, f)\n                tinsert (unitFrame.PlaterComboPointFrame.ComboPointFramesPool, f)\n                \n                local backgroundTexture = f:CreateTexture (nil, \"background\")\n                backgroundTexture:SetTexture (textures.backgroundTexture)\n                backgroundTexture:SetTexCoord (unpack (textures.backgroundTexCoords))\n                backgroundTexture:SetSize (sizes.width, sizes.height)\n                backgroundTexture:SetPoint (\"center\")\n                \n                local comboPointTexture = f:CreateTexture (nil, \"artwork\")\n                comboPointTexture:SetTexture (textures.comboPointTexture)\n                comboPointTexture:SetTexCoord (unpack (textures.comboPointTexCoords))\n                \n                comboPointTexture:SetSize (sizes.width, sizes.height)\n                comboPointTexture:SetPoint (\"center\")\n                comboPointTexture:Hide()            \n                \n                f.IsActive = false\n                \n                f.backgroundTexture = backgroundTexture\n                f.comboPointTexture = comboPointTexture\n                \n                createAnimations (f)\n            end\n            \n        else\n            envTable.ComboPointFrame = unitFrame.PlaterComboPointFrame\n            envTable.ComboPointFrame:SetScale (sizes.scale)\n            envTable.ComboPoints = unitFrame.PlaterComboPointFrame.ComboPointFramesPool\n            \n        end            \n        \n        envTable.ComboPointFrame:SetFrameLevel (frameLevel)\n        envTable.ComboPointFrame:SetFrameStrata (frameStrata)\n        \n        function envTable.UpdateComboPoints()\n            local comboPoints = GetComboPoints(\"player\", \"target\")\n            --UnitPower (\"player\", Enum.PowerType.ComboPoints)\n            \n            for i = 1, envTable.TotalComboPoints do\n                local thisComboPoint = envTable.ComboPoints [i]\n                \n                if (i <= comboPoints ) then\n                    --combo point enabled\n                    if (not thisComboPoint.IsActive) then\n                        thisComboPoint.ShowAnimation:Play()\n                        thisComboPoint.IsActive = true\n                        \n                    end\n                    \n                else\n                    --combo point disabled\n                    if (thisComboPoint.IsActive) then\n                        thisComboPoint.HideAnimation:Play()\n                        thisComboPoint.IsActive = false\n                        \n                    end\n                end\n            end\n            \n            \n        end\n        \n        function envTable.UpdateComboPointAmount()\n            local namePlateWidth = Plater.db.profile.plate_config.enemynpc.health_incombat[1]\n            local comboPoints = UnitPowerMax (\"player\", Enum.PowerType.ComboPoints)\n            local reservedSpace = (namePlateWidth - sizes.width * comboPoints)  / comboPoints \n            \n            --store the total amount of combo points\n            envTable.TotalComboPoints = comboPoints\n            \n            --update anchor frame\n            envTable.ComboPointFrame:SetWidth (namePlateWidth)\n            envTable.ComboPointFrame:SetHeight (20)\n            envTable.ComboPointFrame:ClearAllPoints()\n            for i = 1, #anchors do\n                local anchor = anchors[i]\n                envTable.ComboPointFrame:SetPoint (unpack (anchor))\n            end        \n            \n            --\n            for i = 1, #envTable.ComboPoints do\n                envTable.ComboPoints[i]:Hide()\n                envTable.ComboPoints[i]:ClearAllPoints()\n            end\n            \n            for i = 1, comboPoints do\n                local comboPoint = envTable.ComboPoints[i]\n                if i == 1 then\n                    comboPoint:SetPoint (\"left\", envTable.ComboPointFrame, \"left\", reservedSpace/2, 0)\n                else\n                    comboPoint:SetPoint (\"left\", envTable.ComboPoints[i-1], \"right\", reservedSpace, 0)\n                end\n                \n                comboPoint:Show()\n            end\n            \n            envTable.LastUpdate = GetTime()\n            \n            envTable.UpdateComboPoints()\n        end\n        \n        --initialize\n        envTable.UpdateComboPointAmount()\n        envTable.ComboPointFrame:Hide()\n    end\n    \n    \nend",
					},
					["Time"] = 1621935143,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
							["Enabled"] = true,
							["DRUID"] = true,
							["ROGUE"] = true,
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["spec"] = {
							["103"] = true,
							["Enabled"] = true,
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["affix"] = {
						},
					},
					["url"] = "",
					["Icon"] = 135426,
					["Enabled"] = false,
					["Revision"] = 284,
					["Options"] = {
					},
					["Author"] = "Izimode-Azralon",
					["Desc"] = "Show combo points above the nameplate for Druid Feral and Rogues.",
					["Name"] = "Combo Points [Plater]",
					["PlaterCore"] = 1,
					["semver"] = "",
					["LastHookEdited"] = "",
					["version"] = -1,
				}, -- [10]
				{
					["Enabled"] = false,
					["Revision"] = 182,
					["semver"] = "",
					["LastHookEdited"] = "",
					["Name"] = "Players Targeting a Target [Plater]",
					["Author"] = "Izimode-Azralon",
					["Time"] = 1548278227,
					["Desc"] = "Show how many raid members are targeting the unit",
					["Hooks"] = {
						["Leave Combat"] = "function (self, unitId, unitFrame, envTable)\n    envTable.CanShow = false;\n    envTable.TargetAmount:SetText (\"\")\nend\n\n\n",
						["Nameplate Added"] = "function (self, unitId, unitFrame, envTable)\n    \n    --when a nameplate is added to the screen check if the player is in combat\n    if (InCombatLockdown()) then\n        --player is in combat, check if can check amount of targets\n        envTable.CanShow = envTable.CanShowTargetAmount();\n        \n    else\n        envTable.CanShow = false; \n    end\n    \n    envTable.TargetAmount:SetText (\"\");\n    \nend",
						["Nameplate Removed"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.TargetAmount:SetText (\"\");\n    envTable.CanShow = false;\n    \nend\n\n\n",
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    \n    --if the script is allowed to show the amount of targets\n    --also check if the unit is in combat\n    if (envTable.CanShow and UnitAffectingCombat (unitId)) then\n        \n        --check if can update the amount of targets following the cooldown set in the constructor script\n        --by default Plater updates the nameplate every 250ms, by default the cooldown is 2, so it'll update the amuont of target every 1/2 of a second\n        envTable.UpdateCooldown = envTable.UpdateCooldown + 1\n        if (envTable.UpdateCooldown < envTable.UpdateInterval) then\n            return\n        else\n            \n            --reset the cooldown interval to check the amount of target again\n            envTable.UpdateCooldown = 0\n            \n            --get the amount of targets\n            local amount;\n            if (envTable.InRaid) then\n                amount = envTable.NumTargetsInRaid (unitFrame)      \n                \n            elseif (envTable.InParty) then\n                amount = envTable.NumTargetsInParty (unitFrame)   \n                \n            else\n                envTable.TargetAmount:SetText (\"\")\n                return\n            end\n            \n            --update the amount text\n            if (amount == 0) then\n                envTable.TargetAmount:SetText (\"\")\n            else\n                envTable.TargetAmount:SetText (amount)\n            end\n            \n        end\n    end\nend\n\n\n",
						["Enter Combat"] = "function (self, unitId, unitFrame, envTable)\n    \n    --check if can show the amount of targets\n    envTable.CanShow = envTable.CanShowTargetAmount();\n    \n    if (not envTable.CanShow) then\n        envTable.TargetAmount:SetText (\"\") \n    end\nend\n\n\n\n\n",
						["Constructor"] = "--all gray text like this are comments and do not run as code\n--build the settings and basic functions for the hook\n\nfunction (self, unitId, unitFrame, envTable)\n    \n    --declare setting variables:\n    local textColor = \"orange\";\n    local textSize = 12;\n    \n    local showInRaid = true;\n    local showInDungeon = true;\n    local showInArena = false;\n    local showInBattleground = false;\n    local showInOpenWorld = true;\n    \n    envTable.UpdateInterval = 2; --each 2 updates in the nameplate it'll update the amount of targets\n    \n    local anchor = {\n        side = 6, --1 = topleft 2 = left 3 = bottomleft 4 = bottom 5 = bottom right 6 = right 7 = topright 8 = top\n        x = 4, --x offset\n        y = 0, --y offset\n    };\n    \n    \n    ---------------------------------------------------------------------------------------------------------------------------------------------\n    \n    \n    --frames:\n    \n    --create the text that will show the amount of people targeting the unit\n    if (not  unitFrame.healthBar.TargetAmount) then\n        envTable.TargetAmount = Plater:CreateLabel (unitFrame.healthBar, \"\", textSize, textColor);\n        Plater.SetAnchor (envTable.TargetAmount, anchor);\n        unitFrame.healthBar.TargetAmount = envTable.TargetAmount\n    end\n    \n    --in case Plater wipes the envTable\n    envTable.TargetAmount = unitFrame.healthBar.TargetAmount\n    \n    ---------------------------------------------------------------------------------------------------------------------------------------------           \n    --private variables (they will be used in the other scripts within this hook)\n    envTable.CanShow = false;\n    envTable.UpdateCooldown = 0;\n    envTable.InRaid = false;\n    envTable.InParty = false;\n    \n    ---------------------------------------------------------------------------------------------------------------------------------------------           \n    --functions\n    \n    --update the InRaid or InParty proprieties\n    function envTable.UpdateGroupType()\n        if (IsInRaid()) then\n            envTable.InRaid = true;\n            envTable.InParty = false;     \n            \n        elseif (IsInGroup()) then\n            envTable.InRaid = false;\n            envTable.InParty = true;   \n            \n        else\n            envTable.InRaid = false;            \n            envTable.InParty = false;\n        end\n    end\n    \n    --this function controls if the amount of targets can show following the settings in the top of this script\n    function envTable.CanShowTargetAmount()\n        \n        local _, instanceType, difficultyID, _, _, _, _, instanceMapID, instanceGroupSize = GetInstanceInfo()\n        \n        if (showInRaid and instanceType == \"raid\") then\n            envTable.UpdateGroupType()\n            return true\n        end\n        \n        if (showInDungeon and instanceType == \"party\") then\n            envTable.UpdateGroupType()\n            return true\n        end\n        \n        if (showInArena and instanceType == \"arena\") then\n            envTable.UpdateGroupType()\n            return true\n        end\n        \n        if (showInBattleground and instanceType == \"pvp\") then\n            envTable.UpdateGroupType()\n            return true\n        end\n        \n        if (showInOpenWorld and instanceType == \"none\") then\n            envTable.UpdateGroupType()\n            if (envTable.InRaid or envTable.InParty) then\n                return true\n            end\n        end\n        \n        return false\n    end\n    \n    --get the amount of player targetting the unit in raid or party\n    function envTable.NumTargetsInRaid (unitFrame)\n        local amount = 0\n        for i = 1, GetNumGroupMembers() do\n            local unit = \"raid\" .. i .. \"target\"\n            if (UnitGUID (unit) == unitFrame.namePlateUnitGUID) then\n                amount = amount + 1\n            end\n        end\n        \n        return amount\n    end\n    \n    function envTable.NumTargetsInParty()\n        local amount = 0\n        for i = 1, GetNumGroupMembers() - 1 do\n            local unit = \"party\" .. i .. \"target\"\n            if (UnitGUID (unit) == unitFrame.namePlateUnitGUID) then\n                amount = amount + 1\n            end\n        end\n        \n        local unit = \"playertarget\"\n        if (UnitGUID (unit) == unitFrame.namePlateUnitGUID) then\n            amount = amount + 1\n        end        \n        \n        return amount\n    end\n    \nend",
					},
					["version"] = -1,
					["PlaterCore"] = 1,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["race"] = {
						},
						["pvptalent"] = {
						},
						["spec"] = {
						},
						["affix"] = {
						},
						["encounter_ids"] = {
						},
						["role"] = {
						},
					},
					["url"] = "",
					["Icon"] = 1966587,
					["HooksTemp"] = {
					},
				}, -- [11]
				{
					["HooksTemp"] = {
					},
					["Hooks"] = {
						["Initialization"] = "function (modTable)\n    \n    --ATTENTION: after enabling this mod, you may have to adjust the anchor point at the Buff Settings tab\n    \n    local sortByTime = false\n    local invertSort = false\n    \n    --which auras goes first, assign a value (any number), bigger value goes first\n    local priority = {\n        [\"Vampiric Touch\"] = 50,\n        [\"Shadow Word: Pain\"] = 22,\n        [\"Mind Flay\"] = 5,\n        [\"Pistol Shot\"] = 50,\n        [\"Marked for Death\"] = 99,\n    }\n    \n    -- Sort function - do not touch\n    Plater.db.profile.aura_sort = true\n    \n    \n    function Plater.AuraIconsSortFunction (aura1, aura2)\n        local p1 = priority[aura1.SpellId] or priority[aura1.SpellName] or 1\n        local p2 = priority[aura2.SpellId] or priority[aura2.SpellName] or 1\n        \n        if sortByTime and p1 == p2 then\n            if invertSort then\n                return (aura1.Duration == 0 and 99999999 or aura1.RemainingTime or 0) > (aura2.Duration == 0 and 99999999 or aura2.RemainingTime or 0)\n            else\n                return (aura1.Duration == 0 and 99999999 or aura1.RemainingTime or 0) < (aura2.Duration == 0 and 99999999 or aura2.RemainingTime or 0)\n            end\n        else\n            if invertSort then\n                 return p1 < p2\n            else\n                return p1 > p2\n            end\n        end\n    end\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					},
					["Time"] = 1608663128,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["spec"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["affix"] = {
						},
					},
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\icon_aura_reorder",
					["Enabled"] = false,
					["Revision"] = 356,
					["Options"] = {
					},
					["Author"] = "Ditador-Azralon",
					["Desc"] = "Reorder buffs and debuffs following the settings set in the constructor.",
					["Name"] = "Aura Reorder [Plater]",
					["PlaterCore"] = 1,
					["semver"] = "",
					["LastHookEdited"] = "",
					["version"] = -1,
				}, -- [12]
			},
			["ghost_auras"] = {
				["auras"] = {
					["PRIEST"] = {
						[3] = {
							[589] = true,
							[34914] = true,
						},
					},
					["WARLOCK"] = {
						{
							[172] = true,
							[980] = true,
						}, -- [1]
					},
				},
			},
			["OptionsPanelDB"] = {
				["PlaterOptionsPanelFrame"] = {
					["scale"] = 1,
				},
			},
			["aura_x_offset"] = 0,
			["first_run3"] = true,
			["use_ui_parent"] = true,
			["ui_parent_scale_tune"] = 1.25000007450581,
			["health_statusbar_bgtexture"] = "Details D'ictum",
			["aura_tracker"] = {
				["buff_tracked"] = {
					[209859] = true,
				},
			},
			["patch_version"] = 34,
			["number_region_first_run"] = true,
			["hide_blizzard_castbar"] = true,
			["resources_settings"] = {
				["chr"] = {
					["Player-4454-052CFDEB"] = "ComboPoints",
				},
			},
		},
	},
}
PlaterLanguage = {
	["language"] = "enUS",
	["version"] = 1,
}
PlaterLogs = {
	["_general_logs"] = {
		"2024-01-18 03:22:26 | INIT | Plater-v573-Wrath | Framework v497 | 3.4.3 | enUS | Buddahla", -- [1]
		"2024-01-18 03:02:50 | INIT | Plater-v573-Wrath | Framework v497 | 3.4.3 | enUS | Azuradra", -- [2]
		"2024-01-18 02:59:05 | INIT | Plater-v573-Wrath | Framework v497 | 3.4.3 | enUS | Ggspot", -- [3]
		"2024-01-18 01:52:42 | INIT | Plater-v573-Wrath | Framework v497 | 3.4.3 | enUS | Azuradra", -- [4]
		"2024-01-18 00:32:33 | INIT | Plater-v573-Wrath | Framework v497 | 3.4.3 | enUS | Azuradra", -- [5]
		"2024-01-18 00:25:00 | INIT | Plater-v573-Wrath | Framework v497 | 3.4.3 | enUS | Buddahla", -- [6]
		"2024-01-18 00:18:23 | INIT | Plater-v573-Wrath | Framework v497 | 3.4.3 | enUS | Azuradra", -- [7]
		"2024-01-17 23:54:12 | INIT | Plater-v573-Wrath | Framework v497 | 3.4.3 | enUS | Ggspot", -- [8]
		"2024-01-17 17:48:16 | INIT | Plater-v573-Wrath | Framework v497 | 3.4.3 | enUS | Buddahla", -- [9]
		"2024-01-17 16:11:30 | INIT | Plater-v573-Wrath | Framework v497 | 3.4.3 | enUS | Ggspot", -- [10]
		"2024-01-17 15:58:49 | INIT | Plater-v573-Wrath | Framework v497 | 3.4.3 | enUS | Buddahla", -- [11]
		"2024-01-17 15:58:01 | INIT | Plater-v573-Wrath | Framework v497 | 3.4.3 | enUS | Ggspot", -- [12]
		"2024-01-17 10:59:25 | INIT | Plater-v573-Wrath | Framework v497 | 3.4.3 | enUS | Buddahla", -- [13]
		"2024-01-17 10:35:25 | INIT | Plater-v573-Wrath | Framework v497 | 3.4.3 | enUS | Ggspot", -- [14]
		"2024-01-17 01:20:38 | INIT | Plater-v573-Wrath | Framework v497 | 3.4.3 | enUS | Ggspot", -- [15]
		"2024-01-16 19:26:43 | INIT | Plater-v573-Wrath | Framework v497 | 3.4.3 | enUS | Buddahla", -- [16]
		"2024-01-16 18:47:26 | INIT | Plater-v573-Wrath | Framework v497 | 3.4.3 | enUS | Buddahla", -- [17]
		"2024-01-16 18:33:06 | INIT | Plater-v573-Wrath | Framework v497 | 3.4.3 | enUS | Ggspot", -- [18]
		"2024-01-16 18:11:11 | INIT | Plater-v573-Wrath | Framework v497 | 3.4.3 | enUS | Buddahla", -- [19]
	},
	["_error_logs"] = {
	},
}
