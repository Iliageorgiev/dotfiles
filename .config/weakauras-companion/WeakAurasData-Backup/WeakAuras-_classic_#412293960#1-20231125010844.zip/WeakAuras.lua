
WeakAurasSaved = {
	["dynamicIconCache"] = {
	},
	["editor_tab_spaces"] = 4,
	["login_squelch_time"] = 10,
	["lastArchiveClear"] = 1700400631,
	["minimap"] = {
		["hide"] = false,
	},
	["lastUpgrade"] = 1700400635,
	["dbVersion"] = 70,
	["registered"] = {
	},
	["displays"] = {
	},
	["editor_font_size"] = 12,
	["editor_theme"] = "Monokai",
}
